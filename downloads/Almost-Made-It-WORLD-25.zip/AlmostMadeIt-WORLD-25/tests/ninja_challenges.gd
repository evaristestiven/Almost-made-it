extends "res://tests/first_steps_course.gd"

func restart_fixture() -> void:
    await fresh()
    hits=0
    game.runner.hit.connect(func()->void:hits+=1)

func sweep_at(area:int,index:int) -> AnimatableBody3D:
    var point:Vector3=game.level_data.cells[area*12+index].at
    for hazard in get_nodes_in_group("hazards"):
        if hazard.get_script().resource_path.ends_with("rotating_bar.gd") and horizontal(hazard.position-point).length()<.1:return hazard
    return null

func penetration(bar:Node3D) -> float:
    var r:float=game.runner.BODY_RADIUS
    var capsule:Vector3=game.runner.global_position
    capsule.y=clampf(bar.global_position.y,capsule.y+r,capsule.y+game.runner.BODY_HEIGHT-r)
    var point:Vector3=bar.to_local(capsule)
    var half:Vector3=bar.colliders[0].shape.size*.5
    var nearest:=Vector3(clampf(point.x,-half.x,half.x),clampf(point.y,-half.y,half.y),clampf(point.z,-half.z,half.z))
    return maxf(0,r-point.distance_to(nearest))

func standing_impact(area:int,index:int,held:=false) -> float:
    await restart_fixture()
    var bar:=sweep_at(area,index)
    var foot:Vector3=bar.position-Vector3.UP*1.03
    fixture(foot+Vector3(bar.width*.5-.2,0,0))
    var start:Vector3=game.runner.position
    if held:drag_direction(Vector2.LEFT)
    var end:=Engine.get_physics_frames()+hz*8
    while hits==0 and game.deaths==0 and Engine.get_physics_frames()<end:await step()
    check(hits==1,"actual %s sweep accepts one %s contact"%[game.level_data.sections[area].name,"held-input" if held else "standing"])
    var impulse:Vector3=game.runner.last_impulse
    var external:Vector3=game.runner.knockback
    var max_depth:=0.0
    for i in range(maxi(2,ceili(.12*hz))):
        await step()
        max_depth=maxf(max_depth,penetration(bar))
    check(impulse.length()>.1 and impulse.dot(game.runner.last_normal)>0,"accepted sweep produces geometric normal impulse")
    check(game.runner.position.distance_to(start)>.05,"bar physically displaces actual avatar collider")
    check(max_depth<.07,"no persistent visible bar/capsule penetration (%.4fm)"%max_depth)
    check(hits==1,"repeated callbacks cannot stack impulses during one impact")
    if held:check(game.runner.knockback.dot(external)>0 and game.runner.knockback.length()>.1,"held drag cannot immediately cancel external impact velocity")
    print("NINJA_PHYSICS ",JSON.stringify({"body":str(bar.get_path()),"hz":hz,"spin":bar.spin_speed,"held":held,"displacement":str(game.runner.position-start),"impulse":str(impulse),"external":str(game.runner.knockback),"velocity":str(game.runner.velocity),"max_penetration":max_depth,"hits":hits}))
    release()
    if area==0:
        await seconds(.7)
        check(game.deaths==0 and game.runner.is_on_floor(),"forgiving introductory impact permits an ordinary grounded recovery")
    return impulse.length()

func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="):hz=argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second=hz;root.size=Vector2i(720,1280)
    campaign=root.get_node("Campaign");campaign.save_path="user://ninja24-physics.json"
    campaign.clear_progress();campaign.dirty=false
    await restart_fixture()
    var profile:Dictionary=game.level_data.duplicate(true)
    preload("res://scripts/levels/first_steps_course.gd").apply(profile)
    check(profile.obstacles==game.level_data.obstacles and profile.links==game.level_data.links,"gameplay timings/layout are deterministic and reproducible")
    var intro:=0;var moving_intro:=0
    for obstacle in profile.obstacles:
        if obstacle.type=="rotating_bar" and obstacle.at.z> -125:intro+=1
        if obstacle.type=="moving_platform" and obstacle.at.z> -125:moving_intro+=1
    check(intro==1 and moving_intro==2,"garden introduces exactly one slow bar and two gentle moving surfaces")
    var matched:=true
    for hazard in get_nodes_in_group("hazards"):
        for shape in hazard.colliders:matched=matched and not shape.disabled and shape.get_parent()==hazard
        if hazard.get_child(0).mesh is BoxMesh:
            matched=matched and hazard.get_child(0).mesh.size==hazard.colliders[0].shape.size and hazard.get_child(0).global_transform==hazard.colliders[0].global_transform
        else:matched=matched and is_equal_approx(hazard.get_child(0).mesh.radius,hazard.colliders[0].shape.radius)
        matched=matched and hazard.collision_layer==4 and hazard.collision_mask==2
    check(matched,"all sweep/pendulum shapes enabled, aligned and on interacting solid layers")
    var cell:Dictionary=profile.cells[13]
    fixture(cell.at+Vector3.UP*.08)
    await seconds(.2)
    var before:Vector3=game.runner.position
    await seconds(2)
    check(hits==0 and game.runner.position.distance_to(before)<.001,"courtyard waiting zone remains safe without movement")
    var ferry:Node3D=get_nodes_in_group("moving_platforms")[0]
    await seconds(.2)
    check(ferry.position.distance_to(ferry.origin+ferry.travel*sin(ferry.elapsed*TAU/ferry.period))<.001,"moving surfaces follow deterministic fixed-step cycle")
    game.set_paused(true);var transform:Transform3D=ferry.transform
    await seconds(.25)
    check(ferry.transform==transform,"pause freezes moving challenge geometry")
    game.set_paused(false)
    await standing_impact(0,8)
    await standing_impact(1,2,true)
    await standing_impact(4,9)
    # Comparable speeds: same real solid body, contact fixture and controller.
    var strengths:Array[float]=[]
    for speed in [.5,1.5]:
        await restart_fixture()
        var bar:=sweep_at(0,8)
        bar.spin_speed=speed;bar.rotation.y=0
        await step();await step() # Synchronize the real moving solid first.
        fixture(bar.position+Vector3(1.8,-1.03,-.9))
        var deadline:=Engine.get_physics_frames()+hz*3
        while hits==0 and Engine.get_physics_frames()<deadline:await step()
        check(hits==1,"controlled speed comparison registers real contact at "+str(speed))
        strengths.append(game.runner.last_impulse.length())
    print("NINJA_SPEED_STRENGTH ",strengths)
    check(strengths[1]>strengths[0]*1.5,"higher angular speed transfers greater impulse under comparable contact conditions")
    await restart_fixture()
    var bar:=sweep_at(0,8)
    var floor:Vector3=bar.position-Vector3.UP*1.05
    fixture(floor+Vector3(0,.02,4.2));await seconds(.1)
    var cleared:bool=await hop(fixed(floor+Vector3(0,0,-4.2)))
    release();await seconds(.2)
    check(cleared and hits==0 and game.deaths==0,"real jump clears introductory solid bar without a hit")
    await restart_fixture();bar=sweep_at(0,8);floor=bar.position-Vector3.UP*1.05
    var side:float=bar.width*.5+game.runner.BODY_RADIUS+.6
    fixture(floor+Vector3(side,.02,3.0));await seconds(.1)
    var dodged:bool=await move_to(floor+Vector3(side,0,-3.0))
    release();await seconds(.2)
    check(dodged and hits==0 and game.deaths==0,"actual drag outside sweep reach is a safe dodge")
    await restart_fixture()
    var ball:Node3D=get_nodes_in_group("swinging_balls")[0]
    fixture(ball.pivot+Vector3(0,-3.78,0))
    var deadline:=Engine.get_physics_frames()+hz*6
    while hits==0 and game.deaths==0 and Engine.get_physics_frames()<deadline:await step()
    check(hits>0 and game.runner.last_impulse.length()>.1,"actual hillside pendulum physically strikes avatar")
    drag_direction(Vector2(-.35,0));await seconds(.25);release();await seconds(.9)
    check(game.deaths==0 and game.runner.is_on_floor(),"existing drag steering permits stable recovery after a real pendulum impact")
    print("NINJA RECOVERY position=",game.runner.position," impulse=",game.runner.last_impulse," grounded=",game.runner.is_on_floor())
    for index in range(2):
        await restart_fixture()
        var ledge:Dictionary=game.level_data.recovery_ledges[index]
        var moving:Node3D
        for node in get_nodes_in_group("moving_platforms"):
            if horizontal(node.origin-ledge.ferry_at).length()<.1:moving=node;break
        fixture(moving.position+Vector3(0,.37,0));await seconds(.2)
        var saved_falls:int=game.deaths
        var caught:bool=await move_to(ledge.at,3.0)
        release();await seconds(.3)
        check(caught and game.runner.is_on_floor() and absf(game.runner.position.y-ledge.at.y)<.1 and game.deaths==saved_falls,"a steered physical fall reaches visible gorge recovery deck%d"%index)
        var back:bool=await hop(func()->Vector3:return moving.position+Vector3.UP*.35)
        release();await seconds(.1)
        check(back and game.deaths==saved_falls and game.runner.position.y>ledge.at.y+.9 and game.route.position_valid,"ordinary jump returns from recovery deck%d to moving course"%index)
        print("NINJA_LEDGE_RECOVERY index=",index," position=",game.runner.position," falls=",game.deaths," route=",game.route.position_valid)
    print("NINJA CHALLENGES RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
