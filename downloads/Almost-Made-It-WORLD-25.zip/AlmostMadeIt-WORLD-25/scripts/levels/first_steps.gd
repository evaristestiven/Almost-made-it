extends "res://scripts/main.gd"
const COURSE = preload("res://scripts/levels/first_steps_course.gd")
var course_surfaces: Array[Node3D] = []

func _scenery_script(nature_enabled:bool) -> Script:
    return load("res://scripts/environment/adventure_garden.gd") if nature_enabled else COURSE_ART

func _build_course() -> void:
    var sections:=clampi(int(ProjectSettings.get_setting("development/course23/sections",5)),1,5)
    COURSE.apply(level_data,sections)
    route_markers=PackedVector3Array(level_data.route3d)
    route.configure(route_markers)
    route.corridor_width=5.0
    finish_x=level_data.finish.x;finish_z=level_data.finish.y
    for cell in level_data.cells:
        _platform(cell.at.z,cell.length,cell.width,Color(level_data.theme.top),cell.at.x,cell.at.y)
        var platform:=get_child(-1) as Node3D
        platform.rotation.y=cell.yaw
        platform.set_meta("course_cell",course_surfaces.size())
        platform.set_meta("area",cell.area)
        course_surfaces.append(platform)
    for ledge in level_data.recovery_ledges:
        _platform(ledge.at.z,ledge.length,ledge.width,Color("b18c59"),ledge.at.x,ledge.at.y)
        var surface:=get_child(-1) as Node3D
        surface.rotation.y=ledge.yaw
        surface.set_meta("recovery_ledge",true)
    for link in level_data.links:
        if link.kind!="bridge":continue
        var a:Vector3=level_data.cells[link.from].at
        var b:Vector3=level_data.cells[link.to].at
        var direction:Vector3=b-a
        _platform(link.at.z,direction.length()+1.0,link.width,Color("caa975"),link.at.x,link.at.y)
        var bridge:=get_child(-1) as Node3D
        bridge.basis=Basis.looking_at(direction.normalized(),Vector3.UP)
        bridge.position=link.at-bridge.basis.y*.55+Vector3.UP*.06
        bridge.set_meta("course_bridge",true)
    for definition in level_data.obstacles:_obstacle(definition)
    for section in level_data.sections:
        if section.cell==0:continue
        _checkpoint(section.at.z,section.at.x,7.0)
        var saved:Dictionary=checkpoints[-1]
        saved.spawn.y=section.at.y+.08
        saved.distance=route.distance_at(saved.spawn)
        saved.area.position.y+=section.at.y
        saved.area.rotation.y=level_data.cells[section.cell].yaw
    for i in range(level_data.coins.size()):
        var point:Vector2=level_data.coins[i]
        _coin(point.y,point.x,level_data.coin_heights[i])
    _finish()
    finish_area.position.y+=level_data.finish_height
    finish_area.rotation.y=level_data.finish_yaw
    (finish_area.get_child(1) as MeshInstance3D).material_override=_mat(Color("efbd53"))
    finish_area.set_meta("build","NINJA-24")

func _physics_process(delta:float) -> void:
    if is_instance_valid(runner) and not route.points.is_empty():
        runner.horizontal_death_limit=65.0
        # The existing controller needs the local course floor for fall timing.
        # Use the ordered cursor, not global Y=0 or the nearest distant branch.
        var index:=mini(route.segment_index,route.points.size()-2)
        var a:Vector3=route.points[index];var b:Vector3=route.points[index+1]
        var along:=clampf((runner.global_position-a).dot(b-a)/a.distance_squared_to(b),0,1)
        runner.course_floor_height=lerpf(a.y,b.y,along)
    super._physics_process(delta)
