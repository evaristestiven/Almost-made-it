extends RefCounted
# Authored, ordered world-space landings. Geometry and tests consume the same
# public course description; physics/input remain the shared implementations.
const AREAS := ["Starting Garden","Training Courtyard","Waterfall Crossing","Windmill Hills","Finish Plaza"]
const LAYOUT := [
    [[0,5],[0,-7],[4,-20],[11,-32],[19,-42],[28,-51],[32,-64],[30,-77],[22,-87],[13,-96],[7,-108],[8,-121]],
    [[10,-134],[17,-147],[26,-159],[33,-172],[34,-186],[29,-199],[20,-209],[9,-220],[-3,-229],[-15,-239],[-23,-251],[-26,-264]],
    [[-28,-279],[-23,-294],[-14,-308],[-2,-320],[10,-331],[17,-345],[19,-361],[17,-377],[9,-390],[-2,-402],[-9,-416],[-10,-431]],
    [[-9,-444],[-3,-457],[7,-468],[19,-478],[30,-489],[37,-503],[39,-517],[35,-531],[26,-542],[15,-553],[5,-564],[1,-578]],
    [[3,-591],[9,-604],[18,-615],[28,-625],[34,-638],[33,-652],[26,-664],[16,-675],[7,-686],[2,-700],[2,-713],[2,-726]]]

static func yaw(direction: Vector3) -> float:
    return atan2(-direction.x,-direction.z)

static func challenge(area:int,index:int) -> String:
    if (area==0 and index==8) or (area==1 and index in [2,5,7,10]) or (area==3 and index==6) or (area==4 and index in [2,6,9]):return "sweep"
    if (area==3 and index in [2,5,8,10]) or (area==4 and index==8):return "pendulum"
    if area==1 and index==9:return "shutter"
    if (area==1 and index in [3,4]) or (area==4 and index in [3,5,7,10]):return "precision"
    return "rest" if index in [0,1,6,11] else "gap"

static func apply(data: Dictionary, count := 5) -> void:
    var cells: Array[Dictionary] = []
    for area in range(clampi(count,1,5)):
        for i in range(LAYOUT[area].size()):
            var pair: Array = LAYOUT[area][i]
            var height: float = [float(i)*.08, .88+sin(i*.4)*.28,1.0+float(i)*.07,1.77+sin(i*.25)*.55,2.0*(1.0-float(i)/11.0)][area]
            cells.append({"at":Vector3(pair[0],height,pair[1]),"area":area,"index":i,"width":9.5 if area==0 or i in [0,11] else (7.5 if area==2 else 8.5),"length":10.0,"yaw":0.0})
    for i in range(cells.size()):
        var before: Vector3 = cells[maxi(0,i-1)].at
        var after: Vector3 = cells[mini(cells.size()-1,i+1)].at
        cells[i].yaw = yaw(after-before)
        var cell:Dictionary=cells[i]
        cell.challenge=challenge(cell.area,cell.index)
        cell.hazard=cell.challenge in ["sweep","pendulum","shutter"]
        if cell.hazard:
            cell.width=10.5;cell.length=13.0 # Honest, visible recovery courtyards.
        elif cell.challenge=="precision":
            cell.width=3.4 if cell.area==1 else 3.1
    data.cells=cells
    data.platforms=[];data.extensions=[];data.obstacles=[];data.checkpoints=[]
    data.coins=[];data.coin_heights=[];data.route=[];data.route3d=[];data.links=[]
    data.sections=[]
    data.recovery_ledges=[]
    for i in range(cells.size()):
        var cell:Dictionary=cells[i]
        var p:Vector3=cell.at
        data.platforms.append([p.x,p.z,cell.length,cell.width,p.y,cell.yaw])
        data.route.append(Vector2(p.x,p.z));data.route3d.append(p)
        if cell.index==0:
            data.sections.append({"name":AREAS[cell.area],"at":p,"cell":i,"area":cell.area})
            if i>0:data.checkpoints.append(Vector2(p.x,p.z))
        # The courtyard coin rewards the narrow landing after its first sweep,
        # rather than occupying the center of another active bar.
        if cell.index==(3 if cell.area==1 else 7):
            data.coins.append(Vector2(p.x,p.z));data.coin_heights.append(p.y+1.25)
        if i>0:
            var previous:Dictionary=cells[i-1]
            var middle:Vector3=(previous.at+p)*.5
            var direction:Vector3=(p-previous.at).normalized()
            var link:Dictionary={"from":i-1,"to":i,"kind":"jump","at":middle,"yaw":yaw(direction),"width":3.2 if cell.area==2 else 5.0}
            # Wide introductory walkways, rest plazas and winding hillside
            # ramps alternate with real gaps; no cosmetic land bridges voids.
            if (cell.area==0 and cell.index in [1,2,4,6,9,11]) or (cell.area in [1,3,4] and cell.index in [0,3,6,9,11]):
                link.kind="bridge"
            if cell.area==2 or (cell.area==0 and cell.index in [5,10]) or (cell.area==1 and cell.index in [4,8]) or (cell.area==4 and cell.index==4):
                link.kind="moving" if cell.index%3!=0 else "bridge"
            if (cell.area==1 and cell.index==3) or (cell.area==4 and cell.index in [3,9,11]):link.kind="jump"
            data.links.append(link)
            if link.kind=="moving":
                var side:=Vector3(-direction.z,0,direction.x)
                var travel:Vector3=side*(.45 if cell.area==0 else 1.25 if cell.area==2 else .95)
                if cell.area==2 and cell.index in [5,8]:travel=side*.95+direction*.65
                var precision:bool=(cell.area==1 and cell.index==4) or cell.area==4
                data.obstacles.append({"type":"moving_platform","at":middle-Vector3.UP*.35,"dimensions":Vector3(2.8 if precision else 4.8 if cell.area==0 else 4.4,.7,3.8 if precision else 4.8),"travel":travel,"period":5.8 if cell.area==0 else 4.8+float(cell.index%3)*.5,"rotation":Vector3(0,link.yaw,0)})
                if cell.area==2 and cell.index in [5,8]:
                    # Visible, lower side decks allow a steered miss to be saved.
                    # They sit outside the ferry's entire horizontal sweep, so
                    # a stationary recovering player cannot be crushed below it.
                    data.recovery_ledges.append({"at":middle+side*(5.1 if cell.index==5 else -5.1)-Vector3.UP*1.15,"width":3.2,"length":4.4,"yaw":link.yaw,"ferry_at":middle})
        if cell.challenge=="sweep":
            var speed:float=.5 if cell.area==0 else 1.0
            if cell.area==1:speed={2:.7,5:-1.15,7:.9,10:-1.4}[cell.index]
            if cell.area==4:speed={2:.95,6:-1.25,9:1.55}[cell.index]
            data.obstacles.append({"type":"rotating_bar","at":p+Vector3(0,1.05,0),"width":4.4 if cell.area==0 else 5.6,"spin_speed":speed,"rotation":Vector3(0,0 if cell.area==0 else float(cell.index%4)*PI*.25,0)})
        if cell.area==1 and cell.index==9:
            data.obstacles.append({"type":"moving_platform","at":p+Vector3(0,2.0,0),"dimensions":Vector3(3.0,2.0,.45),"travel":Vector3(0,1.7,0),"period":4.6})
        if cell.area==3 and cell.index in [2,5,8,10] or cell.area==4 and cell.index==8:
            data.obstacles.append({"type":"swinging_ball","at":p+Vector3(0,3.8,0),"period":4.1+float(cell.index%3)*.35,"amplitude":.7,"phase":cell.index*.9})
    var last:Dictionary=cells[-1]
    # The final gate is inside the last landing, reached along its real tangent.
    var finish:Vector3=last.at+Basis(Vector3.UP,last.yaw)*Vector3(0,0,-2.4)
    data.finish=Vector2(finish.x,finish.z);data.finish_height=finish.y;data.finish_yaw=last.yaw
    data.route.append(data.finish);data.route3d.append(finish)
    data.theme.sections=AREAS
    data.theme.intro="FIRST STEPS|A SKY GARDEN ADVENTURE"
    data.target_seconds=Vector2(120,180)
