extends Node3D
# WORLD-25. All nodes here are cosmetic. The course builder and collision
# objects are never created, moved or disabled by this module.
var scenery:Node3D
var game:Node3D
var materials:Dictionary={}
var floor_materials:Dictionary={}
var shapes:Dictionary={}
var rotating:Array[Dictionary]=[]
var occluders:Array[AABB]=[]
var zone_stats:Array[Dictionary]=[]
var clock:=0.0

func material(hex:String,metal:=false) -> StandardMaterial3D:
    var key:=hex+str(metal)
    if not materials.has(key):
        var m:=StandardMaterial3D.new();m.albedo_color=Color(hex).srgb_to_linear()
        m.roughness=.34 if metal else .78;m.metallic=.08 if metal else 0.0
        m.metallic_specular=.48 if metal else .30;m.cull_mode=BaseMaterial3D.CULL_DISABLED
        materials[key]=m
    return materials[key]

func add_mesh(mesh:Mesh,mat:Material,pose:Transform3D,end:=95.0,occluding:=true) -> MeshInstance3D:
    var node:=MeshInstance3D.new();node.mesh=mesh;node.material_override=mat;node.transform=pose
    node.visibility_range_end=end;node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(node)
    if occluding:occluders.append(pose*mesh.get_aabb())
    return node

func block(at:Vector3,size:Vector3,hex:String,yaw:=0.0,metal:=false) -> void:
    scenery.place("box",at,size,hex,Vector3(0,yaw,0))
    occluders.append(Transform3D(Basis(Vector3.UP,yaw).scaled(size),at)*AABB(Vector3.ONE*-.5,Vector3.ONE))

func asset(asset_name:String,at:Vector3,size:float,yaw:float,top:=false) -> void:
    var source:Dictionary=scenery.source(asset_name)
    at.y-=(source.bounds.end.y if top else source.bounds.position.y)*size
    scenery.detail(asset_name,at,Vector3.ONE*size,yaw)

func floor_material(zone:int,wood:=false) -> ShaderMaterial:
    var key:=str(zone)+str(wood)
    if not floor_materials.has(key):
        var mat:=ShaderMaterial.new();mat.shader=load("res://shaders/world25/ground.gdshader")
        for pair in [["meadow","meadow_albedo"],["soil","soil_albedo"],["rock","rock_albedo"],["bark","bark_albedo"]]:mat.set_shader_parameter(pair[0],scenery.texture_asset(pair[1]))
        mat.set_shader_parameter("grass_tint",Vector3(.95,1.12,.85) if zone!=2 else Vector3(.87,1.1,.92))
        mat.set_shader_parameter("paved",1.0 if zone in [1,4] else .0)
        mat.set_shader_parameter("wood_deck",wood)
        floor_materials[key]=mat
    return floor_materials[key]

func flag(at:Vector3,hex:String,yaw:=0.0) -> void:
    scenery.place("post",at+Vector3.UP*2.1,Vector3(.12,4.2,.12),"d5bf88")
    var key:="flag"+hex
    if not materials.has(key):
        var mat:=ShaderMaterial.new();mat.shader=load("res://shaders/world25/flag.gdshader")
        mat.set_shader_parameter("cloth",Color(hex));materials[key]=mat;scenery.animated.append(mat)
    var cloth:=PlaneMesh.new();cloth.orientation=PlaneMesh.FACE_Z;cloth.size=Vector2(1.05,1.85)
    cloth.subdivide_width=5;cloth.subdivide_depth=3
    add_mesh(cloth,materials[key],Transform3D(Basis(Vector3.UP,yaw),at+Vector3(.52,3,0)),65)

func extruded(outline:PackedVector2Array,depth:float) -> ArrayMesh:
    var tool:=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES)
    var indices:=Geometry2D.triangulate_polygon(outline)
    for face in [-1,1]:
        for i in range(0,indices.size(),3):
            for k in ([2,1,0] if face==1 else [0,1,2]):
                var p:Vector2=outline[indices[i+k]]
                tool.set_normal(Vector3(0,0,face));tool.add_vertex(Vector3(p.x,p.y,depth*.5*face))
    for i in range(outline.size()):
        var a:Vector2=outline[i];var b:Vector2=outline[(i+1)%outline.size()]
        var n:=Vector3(b.y-a.y,a.x-b.x,0).normalized()
        for vertex in [Vector3(a.x,a.y,-depth*.5),Vector3(b.x,b.y,-depth*.5),Vector3(b.x,b.y,depth*.5),Vector3(a.x,a.y,-depth*.5),Vector3(b.x,b.y,depth*.5),Vector3(a.x,a.y,depth*.5)]:
            tool.set_normal(n);tool.add_vertex(vertex)
    return tool.commit()

func gear(at:Vector3,radius:float,speed:float) -> void:
    if not shapes.has("gear"):
        var polygon:=PackedVector2Array()
        for i in range(48):
            var angle:=i*TAU/48.;var r:=1.0 if i%4 in [1,2] else .79
            polygon.append(Vector2(cos(angle),sin(angle))*r)
        shapes.gear=extruded(polygon,.18)
    var node:=add_mesh(shapes.gear,material("c6a15a",true),Transform3D(Basis.from_scale(Vector3.ONE*radius),at),70)
    rotating.append({"node":node,"speed":speed,"scale":radius})
    var hub:=CylinderMesh.new();hub.top_radius=.15;hub.bottom_radius=.15;hub.height=.32;hub.radial_segments=12
    add_mesh(hub,material("5a6c72",true),Transform3D(Basis(Vector3.RIGHT,PI*.5),at+Vector3(0,0,.15)),70)

func machine(pose:Transform3D) -> void:
    var base:Vector3=pose*Vector3(-10.5,-.5,-7)
    block(base+Vector3.UP*.35,Vector3(5.1,.7,2.0),"84998c",0)
    block(base+Vector3.UP*1.7,Vector3(4.4,2.3,.5),"546f72",0)
    gear(base+Vector3(-.8,2,.36),1.1,.20)
    gear(base+Vector3(1.0,1.55,.36),.72,-.305)
    for side in [-1,1]:flag(base+Vector3(side*3,.2,0),"9173ad")

func mist(at:Vector3) -> void:
    if not materials.has("mist"):
        var mat:=ShaderMaterial.new();mat.shader=load("res://shaders/world25/mist.gdshader")
        materials.mist=mat;scenery.animated.append(mat)
    var quad:=QuadMesh.new();quad.size=Vector2(6,1.65)
    add_mesh(quad,materials.mist,Transform3D(Basis.IDENTITY,at),60,false)

func decorate(owner_scenery:Node3D) -> void:
    name="WorldIntegration";scenery=owner_scenery;game=scenery.game
    for area in range(5):zone_stats.append({"area":area,"path_stones":0,"edge_rocks":0,"landmarks":0})
    for i in range(game.level_data.cells.size()):
        var cell:Dictionary=game.level_data.cells[i]
        var pose:=Transform3D(Basis(Vector3.UP,cell.yaw),cell.at)
        game.course_surfaces[i].get_child(0).material_override=floor_material(cell.area)
        if cell.area in [0,1,4]:
            for j in range(6):
                var local:=Vector3(sin(i*1.3+j)*.16,.025,-3.4+j*1.35)
                asset("RockPath_Square_Thin",pose*local,.65,cell.yaw+sin(i+j)*.06,true)
                zone_stats[cell.area].path_stones+=1
        if cell.index%3==0 or cell.area==2 and cell.index%2==0:
            for side in [-1,1]:
                for j in range(3):
                    var p:Vector3=pose*Vector3(side*(cell.width*.5+.08),-.18-j*.65,-2.4+j*2.1)
                    asset("Rock_Medium_3",p,.40+float((i+j)%3)*.05,i*.3+j,true)
                    zone_stats[cell.area].edge_rocks+=1
        if cell.index in [0,6,11]:
            # Section markers sit on the side banks, beyond the playable edge.
            for side in [-1,1]:flag(pose*Vector3(side*(cell.width*.5+3.5),0,-4),["86b986","9173ad","6aafb4","c8a071","b585c6"][cell.area],cell.yaw*.4)
        if cell.area==0 and cell.index in [0,5,10]:
            scenery.flower_bed(pose*Vector3(-8.2,-.05,1),3.6)
            scenery.flower_bed(pose*Vector3(8.2,-.05,-1),3.0)
            scenery.flutter(pose*Vector3(-8.2,.7,1),cell.index)
            zone_stats[0].landmarks+=1
        if cell.area==1 and cell.index in [0,5,10]:machine(pose);zone_stats[1].landmarks+=1
        if cell.area==2 and cell.index in [0,3,6,9]:
            mist(pose*Vector3(-13,-2.4,-8));mist(pose*Vector3(10,-5,-1))
            for j in range(4):asset("Rock_Medium_3",pose*Vector3(-14-j*.9,3.5-j*1.7,-10),1.25+j*.12,j*.8,true)
            zone_stats[2].landmarks+=1
        if cell.area==3 and cell.index in [0,4,8]:
            scenery.fence(pose*Vector3(-13,.1,1),pose*Vector3(-8,.1,1))
            scenery.bench(pose*Vector3(-10.5,.1,.2))
            scenery.house(pose*Vector3(15,-.4,-7),"eddbb3",.72)
            scenery.flower_bed(pose*Vector3(-10.5,.1,-.8),3.2)
            zone_stats[3].landmarks+=1
        if cell.area==4 and cell.index in [0,5,10]:
            for side in [-1,1]:
                scenery.flower_bed(pose*Vector3(side*8.3,-.05,-1),4.0)
                scenery.fence(pose*Vector3(side*8.7,-.1,1),pose*Vector3(side*8.7,-.1,-4))
            zone_stats[4].landmarks+=1
    for platform in get_tree().get_nodes_in_group("platforms"):
        if platform.get_meta("recovery_ledge",false):platform.get_child(0).material_override=floor_material(2,true)
        elif platform.get_meta("course_bridge",false):
            for link in game.level_data.links:
                if Vector2(platform.position.x-link.at.x,platform.position.z-link.at.z).length()<.02:
                    var area:int=game.level_data.cells[link.to].area
                    platform.get_child(0).material_override=floor_material(area,area==2);break
    for mat in scenery.animated:
        if mat.shader.resource_path.ends_with("/falls.gdshader"):
            mat.shader=load("res://shaders/world25/falls.gdshader")
            mat.set_shader_parameter("noise_map",scenery.texture_asset("cloud_noise"))
    finish_garden()
    distant_world()

func finish_garden() -> void:
    var cell:Dictionary=game.level_data.cells[-1]
    var pose:=Transform3D(Basis(Vector3.UP,cell.yaw),Vector3(game.finish_x,game.level_data.finish_height,game.finish_z))
    # Hide only the old decorative straight bar. Trigger shape/transform stays.
    (game.finish_area.get_child(1) as MeshInstance3D).visible=false
    for side in [-1,1]:
        block(pose*Vector3(side*4.4,1.75,0),Vector3(.30,3.5,.42),"e4bd64",cell.yaw)
        block(pose*Vector3(side*4.4,.18,0),Vector3(.7,.36,.7),"d4c6a0",cell.yaw)
        flag(pose*Vector3(side*6.1,.0,-.5),"aa72ad",cell.yaw)
        scenery.flower_bed(pose*Vector3(side*7.2,-.1,0),4.2)
        scenery.flutter(pose*Vector3(side*7.2,.65,0),8+side)
    var arch:=PackedVector2Array()
    for i in range(33):
        var angle:=PI-float(i)*PI/32
        arch.append(Vector2(cos(angle)*4.55,3.5+sin(angle)*1.4))
    for i in range(32,-1,-1):
        var angle:=PI-float(i)*PI/32
        arch.append(Vector2(cos(angle)*4.25,3.5+sin(angle)*1.1))
    add_mesh(extruded(arch,.32),material("efc45d",true),pose,125)
    var outline:=PackedVector2Array([Vector2(-1.4,-.4),Vector2(-1.55,.8),Vector2(-.65,.35),Vector2(0,1.2),Vector2(.65,.35),Vector2(1.55,.8),Vector2(1.4,-.4)])
    var crown:=extruded(outline,.32)
    add_mesh(crown,material("f5c95e",true),Transform3D(pose.basis,pose*Vector3(0,5.2,0)),125)
    for i in range(3):
        var jewel:=SphereMesh.new();jewel.radius=.13;jewel.height=.26;jewel.radial_segments=10;jewel.rings=5
        add_mesh(jewel,material(["80c8c2","d77b8e","80c8c2"][i],true),Transform3D(pose.basis,pose*Vector3((i-1)*.72,5.25,.20)),90)
    scenery.label(pose*Vector3(0,3.9,.3),"FIRST STEPS",.0032)

func distant_world() -> void:
    # Anchor a coherent backdrop to each district. These high, distant islands
    # are visibly separate from the real landings and cannot bridge a jump.
    for area in range(5):
        var at:Vector3=game.level_data.cells[area*12+8].at
        for side in [-1,1]:
            var base:=at+Vector3(side*63,7+area,-30)
            scenery.hill(base,Vector3(20,13+area*1.2,17),"78be50")
            for j in range(6):scenery.small_tree(base+Vector3(j-3,2,-j),6.2+float(j%3),area+j)
    var end:Vector3=game.level_data.cells[-1].at
    for i in range(3):
        var at:=end+Vector3([-28,26,5][i],[8,11,16][i],[-65,-95,-135][i])
        scenery.hill(at,Vector3(18-i*2,13+i*2,15),"78be50")
        for j in range(6):scenery.small_tree(at+Vector3((j-3)*1.3,2,-j*.7),6.0+float(j%3),j)
        if i==0:scenery.house(scenery.grounded_root(at+Vector3(-2,5,-1)),"efdcb8",.8)

func configure_lighting(world:WorldEnvironment,sun:DirectionalLight3D) -> void:
    scenery.sky_material.shader=load("res://shaders/world25/sky.gdshader")
    scenery.sky_material.set_shader_parameter("noise_map",scenery.texture_asset("cloud_noise"))
    scenery.sky_material.set_shader_parameter("sun_direction",sun.global_basis.z.normalized())
    # Compatibility uses the sky cubemap in the visible background. 32px made
    # the horizon's clouds visibly blocky; 128px remains a small mobile texture.
    world.environment.sky.radiance_size=Sky.RADIANCE_SIZE_64 if scenery.quality==0 else Sky.RADIANCE_SIZE_128
    world.environment.ambient_light_energy=.52
    world.environment.tonemap_exposure=.96
    sun.light_energy=1.08;sun.shadow_blur=2.0

func _process(delta:float) -> void:
    clock+=delta
    if not is_instance_valid(game) or not is_instance_valid(game.camera):return
    var at:Vector3=game.camera.global_position
    for entry in rotating:
        if entry.node.global_position.distance_squared_to(at)<75.0*75.0:entry.node.rotation.z=clock*entry.speed
