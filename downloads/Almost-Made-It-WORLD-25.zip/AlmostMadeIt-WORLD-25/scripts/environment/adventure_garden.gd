extends "res://scripts/environment/garden_landscape.gd"
# Reuses the verified LANDSCAPE-22 asset/material/landmark builders, now placed
# alongside the real winding route instead of the former straight corridor.
var surface_bounds:Array[AABB]=[]
var course_landmarks:Array[Dictionary]=[]
var world_details:Node3D
var world25_enabled:=true

func decorate(owner_game:Node3D) -> void:
    name="AdventureScenery";game=owner_game;theme=game.level_data.theme
    world25_enabled=bool(ProjectSettings.get_setting("visuals/world25/enabled",true))
    rng.seed=23023;land_rng.seed=23023;garden_rng.seed=23023
    quality=clampi(int(ProjectSettings.get_setting("visuals/sky_garden/quality",1)),0,2)
    canopy_mesh=organic_mesh()
    upgrade_enabled=true;polish_enabled=true;landscape_enabled=true
    soft_grass=ShaderMaterial.new();soft_grass.shader=load("res://shaders/garden_polish/grass.gdshader")
    grass_material=soft_grass;garden_grass=soft_grass;animated.append(soft_grass)
    tuft_mesh=make_tuft()
    plant_material=ShaderMaterial.new();plant_material.shader=load("res://shaders/starting_garden/plant.gdshader")
    plant_material.set_shader_parameter("leaf_map",load(ASSETS+"Leaves.png"));animated.append(plant_material)
    rock_material=surface("rock");rock_material.set_shader_parameter("moss",1.0)
    land_material=ShaderMaterial.new();land_material.shader=load("res://shaders/landscape/terrain.gdshader")
    for texture in ["meadow_albedo","soil_albedo","rock_albedo","cloud_noise"]:land_material.set_shader_parameter(texture,texture_asset(texture))
    water_material=ShaderMaterial.new();water_material.shader=load("res://shaders/living_garden/water.gdshader");animated.append(water_material)
    for i in range(game.course_surfaces.size()):
        var cell:Dictionary=game.level_data.cells[i]
        var platform:Node3D=game.course_surfaces[i]
        var size:Vector3=platform.get_child(0).mesh.size
        var pose:=Transform3D(platform.basis,cell.at)
        var mat:=ShaderMaterial.new();mat.shader=load("res://shaders/landscape/route_ground.gdshader")
        mat.set_shader_parameter("meadow",texture_asset("meadow_albedo"));mat.set_shader_parameter("soil",texture_asset("soil_albedo"));mat.set_shader_parameter("rock",texture_asset("rock_albedo"))
        platform.get_child(0).material_override=mat
        platform.get_child(0).visibility_range_end=135
        for child in platform.get_children().slice(2):
            if child is MeshInstance3D:child.visible=false
        var first:=get_child_count();skirt(Vector3.ZERO,size)
        get_child(first).transform=pose
        get_child(first).visibility_range_end=125
        first=get_child_count()
        var grass_first:=grass_cells.size()
        grow_grass(Vector3.ZERO,size,i)
        for j in range(first,get_child_count()):
            if get_child(j) is Node3D:get_child(j).transform=pose*get_child(j).transform
        for j in range(grass_first,grass_cells.size()):
            var entry:Dictionary=grass_cells[j]
            entry.center=pose*entry.center
            entry.node.multimesh.mesh=tuft_mesh;entry.node.material_override=soft_grass
        for side in [-1,1]:
            var offset:=Vector3(side*(size.x*.5+5.4),-1.0,(i%3-1)*1.2)
            var at:Vector3=pose*offset
            hill(at,Vector3(4.8,1.4+float(i%4)*.25,6.0) if world25_enabled else Vector3(4.8,1.7,6.0),"78be50")
            for j in range(2+i%3 if world25_enabled else 3):
                small_tree(at+Vector3(side*j*.8,.3,-j*.9),4.6+float((i+j)%4)*.5,i+j)
            detail("Rock_Medium_3",at+Vector3(0,.1,1.5),Vector3.ONE*.6,i)
            for j in range(3):detail("Plant_1",pose*Vector3(side*(size.x*.5-.5),.02,-3+j*2.6),Vector3.ONE*.38,i+j)
            if cell.index in [0,5,11]:flower_bed(pose*Vector3(side*(size.x*.5-.65),.05,1.7),1.8)
        # Low edge markers follow the collider's exact yaw and stop at real gaps.
        for side in [-1,1]:
            var a:Vector3=pose*Vector3(side*(size.x*.5-.15),0,-3.8)
            var b:Vector3=pose*Vector3(side*(size.x*.5-.15),0,3.8)
            if cell.area in [0,3] and cell.index%3==0:fence(a,b)
        if cell.index==0:
            zones.append({"name":theme.sections[cell.area],"z":cell.at.z})
            signpost(pose*Vector3(-size.x*.5-1,.1,2.5),theme.sections[cell.area].to_upper())
            bench(pose*Vector3(size.x*.5+2,0,2))
            course_landmarks.append({"area":cell.area,"at":cell.at})
        if cell.area==0 and cell.index in [0,5,10]:house(pose*Vector3(-15,-.4,-3),"f5e3b6",.9)
        if cell.area==1 and cell.index in [0,5,10]:tower(pose*Vector3(-12,0,-2),true)
        if cell.area==2 and cell.index in [0,3,6,9]:
            for side in [-1,1]:curtain(pose*Vector3(side*9,-6,0),Vector2(3.2,13),cell.yaw)
            hill(pose*Vector3(-17,1.2,-9),Vector3(6.5,8,6.8),"78be50")
            curtain(pose*Vector3(-14,-.5,-9),Vector2(3.0,12),cell.yaw)
        if cell.area==3 and cell.index in [0,4,8]:windmill(pose*Vector3(-11,-.1,-2),1.25)
        if cell.area==4 and cell.index in [0,5,10]:house(pose*Vector3(13,-.4,-3),"f6db9b",.8)
        if cell.index%3==0:
            for side in [-1,1]:
                hill(cell.at+Vector3(side*38,-3,-12),Vector3(16+float(i%4)*1.5,10+float((i+side+2)%5)*2.4,19+float(i%3)*2.5) if world25_enabled else Vector3(18,14,22),"78be50")
                for j in range(5):small_tree(cell.at+Vector3(side*(33+j),2,-8+j*1.3),6.0+j*.3,j)
    for link in game.level_data.links:
        if link.kind!="bridge":continue
        var a:Vector3=game.level_data.cells[link.from].at
        var b:Vector3=game.level_data.cells[link.to].at
        var direction:Vector3=(b-a).normalized();var right:=Vector3(-direction.z,0,direction.x)
        # Rail and plank detail sits exactly on the real continuous bridge.
        if game.level_data.cells[link.to].area==2:
            for j in range(ceili(a.distance_to(b)/.7)):
                var p:Vector3=a.lerp(b,float(j)/maxf(1,ceili(a.distance_to(b)/.7)-1))
                place("box",p+Vector3.UP*.065,Vector3(link.width-.1,.04,.6),"a27843",Vector3(0,link.yaw,0))
            for side in [-1,1]:fence(a+right*(link.width*.5-.1),b+right*(link.width*.5-.1))
    for platform in get_tree().get_nodes_in_group("platforms"):
        if not platform.get_meta("course_bridge",false):continue
        var mat:=ShaderMaterial.new();mat.shader=load("res://shaders/landscape/route_ground.gdshader")
        mat.set_shader_parameter("meadow",texture_asset("meadow_albedo"));mat.set_shader_parameter("soil",texture_asset("soil_albedo"));mat.set_shader_parameter("rock",texture_asset("rock_albedo"))
        platform.get_child(0).material_override=mat
        platform.get_child(0).visibility_range_end=135
        for child in platform.get_children().slice(2):
            if child is MeshInstance3D:child.visible=false
    var final:Dictionary=game.level_data.cells[-1]
    var gate:=Transform3D(Basis(Vector3.UP,final.yaw),Vector3(game.finish_x,game.level_data.finish_height,game.finish_z))
    if world25_enabled:
        world_details=Node3D.new();world_details.set_script(load("res://scripts/environment/garden_world_details.gd"));add_child(world_details)
        world_details.decorate(self)
    else:
        for side in [-1,1]:
            place("post",gate*Vector3(side*4.4,2,0),Vector3(.5,4,.5),"eabd53")
            for j in range(4):place("box",gate*Vector3(side*(4.5+j*.22),3.0-j*.08,-.2),Vector3(.18,1.4,.14),"e6a5c6")
        place("box",gate*Vector3(0,4.1,0),Vector3(9.4,.5,.6),"ffd56c",Vector3(0,final.yaw,0))
        label(gate*Vector3(0,4.55,.3),"YOU'RE ALMOST THERE!",.004)
        for j in range(5):place("post",gate*Vector3((j-2)*.46,4.8+(j%2)*.2,0),Vector3(.3,.9,.35),"ffd35f")
    flush_landforms();flush_forest();flush_background();flush_batches()
    make_birds();make_footsteps()
    budgets={"grass_cells":grass_cells.size(),"grass_instances":0,"tree_instances":forest_roots.size(),"leaf_cards":0,"texture_maps":15,"texture_resolution":512}
    for entry in grass_cells:budgets.grass_instances+=entry.total
    world_stats={"districts":zones.size(),"windmills":rotors.size(),"batches":batch_nodes.size()+land_nodes.size()+forest_batches.size()+background_nodes.size()}
    set_quality(quality)

func configure_lighting(world:WorldEnvironment,sun:DirectionalLight3D) -> void:
    super.configure_lighting(world,sun)
    if is_instance_valid(world_details):world_details.configure_lighting(world,sun)

func place(kind:String,at:Vector3,size:Vector3,color:String,angles:=Vector3.ZERO) -> void:
    var key:=kind+":"+str(floori(at.x/40))+":"+str(floori(at.z/40))
    if not pieces.has(key):pieces[key]={"kind":kind,"poses":[],"colors":[]}
    pieces[key].poses.append(Transform3D(Basis.from_euler(angles).scaled(size),at))
    pieces[key].colors.append(Color(color).srgb_to_linear())

func beam(a:Vector3,b:Vector3,width:float,color:String) -> void:
    var direction:=b-a
    var key:="box:"+str(floori(a.x/40))+":"+str(floori(a.z/40))
    if not pieces.has(key):pieces[key]={"kind":"box","poses":[],"colors":[]}
    var basis:=Basis.looking_at(direction.normalized(),Vector3.UP if absf(direction.normalized().y)<.99 else Vector3.RIGHT)
    pieces[key].poses.append(Transform3D(basis.scaled(Vector3(width,width,direction.length())),(a+b)*.5))
    pieces[key].colors.append(Color(color).srgb_to_linear())
