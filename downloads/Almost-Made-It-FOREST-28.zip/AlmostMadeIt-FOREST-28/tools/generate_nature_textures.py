"""Original, seeded, tileable nature textures. Offline authoring tool only.
Runtime/Xogot loads the generated PNGs, with no Python dependencies.
"""
from pathlib import Path
import numpy as np
from scipy.ndimage import gaussian_filter
from PIL import Image,ImageDraw
OUT=Path(__file__).resolve().parents[1]/'art/sky_garden/textures';OUT.mkdir(parents=True,exist_ok=True)
SIZE=512
rng=np.random.default_rng(1601)
y,x=np.mgrid[0:SIZE,0:SIZE]/SIZE

def noise(scales=(2,5,12,30)):
 a=np.zeros((SIZE,SIZE),dtype=np.float64)
 for n,s in enumerate(scales):
  z=gaussian_filter(rng.standard_normal(a.shape),s,mode='wrap');z=(z-z.mean())/(z.std()+1e-8)
  a+=z/(n+1)
 return a/(np.std(a)+1e-8)
def image(name,a):
 Image.fromarray(np.uint8(np.clip(a,0,1)*255)).save(OUT/name)
def pbr(name,base,height,variation,rough=.85):
 image(name+'_albedo.png',np.array(base)[None,None,:]*(1+variation[:,:,None]*.17))
 dx=(np.roll(height,-1,axis=1)-np.roll(height,1,axis=1))*3.2
 dy=(np.roll(height,-1,axis=0)-np.roll(height,1,axis=0))*3.2
 normals=np.dstack((-dx,dy,np.ones_like(dx)));normals/=np.linalg.norm(normals,axis=2,keepdims=True)
 image(name+'_normal.png',normals*.5+.5)
 image(name+'_roughness.png',rough+height*.055)
rock=noise((1,4,10,34));veins=np.abs(np.sin((x*12+y*3+noise((10,30))*.09)*np.pi))
height=rock*.22-np.clip(.12-veins,0,.12)*5
pbr('rock',(.30,.315,.29),height,rock-.3,.87)
soil=noise((1,3,12,35));grit=rng.random((SIZE,SIZE))
pbr('soil',(.28,.22,.145),soil*.23+grit*.12,soil,.94)
grass=noise((1,3,10,30));filaments=np.sin(x*SIZE*.34+noise((2,8)))*.08
pbr('meadow',(.22,.31,.115),grass*.10+filaments,grass,.88)
long_noise=gaussian_filter(rng.standard_normal((SIZE,SIZE)),(25,2),mode='wrap');long_noise/=long_noise.std()
bark=noise((1,5,16,40))*.25+long_noise*.7
fissures=np.clip(-long_noise-.6,0,2)
pbr('bark',(.245,.205,.155),bark*.25-fissures*.25,bark-fissures,.91)
cloud=noise((4,13,35,65));cloud=(cloud-cloud.min())/(cloud.max()-cloud.min())
image('cloud_noise.png',cloud)
# A cutout sprig, not a green disc. Nine individually shaped serrated leaves,
# fine secondary veins, a central vein and twig. All pixels authored here.
leaf=Image.new('RGBA',(SIZE,SIZE),(0,0,0,0));d=ImageDraw.Draw(leaf)
h=Image.new('L',(SIZE,SIZE),0);hd=ImageDraw.Draw(h)
d.line([(256,490),(253,360),(268,210),(250,40)],fill=(70,86,30,255),width=8)
for i,(cx,cy,length,width,angle) in enumerate([(190,395,100,40,-.8),(320,365,106,44,.75),(176,290,112,44,-.95),(337,255,116,48,.85),(183,183,102,40,-.95),(323,149,103,42,.8),(220,95,90,36,-.3),(290,76,80,34,.4)]):
 direction=np.array([np.sin(angle),-np.cos(angle)]);side=np.array([direction[1],-direction[0]])
 start=np.array([cx,cy]);points=[]
 for sgn in [-1,1]:
  ts=np.linspace(0,1,27)
  if sgn==1:ts=ts[::-1]
  for j,t in enumerate(ts):
   serration=1+(0.065 if j%2 else -.035)
   point=start+direction*length*t+side*sgn*width*np.sin(np.pi*t)**.8*serration
   points.append(tuple(point))
 col=(51+i%3*6,91+i%4*5,28+i%2*8,255)
 d.polygon(points,fill=col);hd.polygon(points,fill=150)
 tip=start+direction*length
 d.line([tuple(start),tuple(tip)],fill=(124,145,67,255),width=2)
 hd.line([tuple(start),tuple(tip)],fill=220,width=3)
 for t in np.linspace(.18,.8,6):
  center=start+direction*length*t
  for s in [-1,1]:
   end=center+direction*length*.10+side*s*width*np.sin(np.pi*t)*.85
   d.line([tuple(center),tuple(end)],fill=(75,115,38,255),width=1)
 d.line([(260,int(cy+30)),tuple(start)],fill=(86,103,38,255),width=3)
leaf.save(OUT/'leaf_sprig.png')
a=np.asarray(h)/255.;dx=np.roll(a,-1,1)-np.roll(a,1,1);dy=np.roll(a,-1,0)-np.roll(a,1,0)
n=np.dstack((-dx,dy,np.ones_like(a)));n/=np.linalg.norm(n,axis=2,keepdims=True)
image('leaf_normal.png',n*.5+.5)
print('Generated',len(list(OUT.glob('*.png'))),'original 512px maps in',OUT)
