"""Render the actual authored tree assets for offline QA, NOT a game screenshot.
Run export_nature_preview.gd first, then Blender --background --python this file.
"""
import bpy,json,math,random
from pathlib import Path
from mathutils import Vector,Matrix
ART=Path('/workspace/almost-made-it/art/sky_garden/textures')
SOURCE=Path('/tmp/sky-garden-preview')
OUT=Path('/workspace/Sky-Garden-Tree-Asset-Preview.png')
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=32
scene.cycles.use_denoising=False
scene.render.resolution_x=900;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.58,.72,.9,1)
scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.38
scene.view_settings.view_transform='AgX'
def material(name):
 m=bpy.data.materials.new(name);m.use_nodes=True;return m
def image(nodes,name,noncolor=False):
 n=nodes.new('ShaderNodeTexImage');n.image=bpy.data.images.load(str(ART/(name+'.png')),check_existing=True)
 if noncolor:n.image.colorspace_settings.name='Non-Color'
 return n
def pbr(name):
 m=material(name);n=m.node_tree.nodes;l=m.node_tree.links;b=n.get('Principled BSDF')
 a=image(n,name+'_albedo');l.new(a.outputs['Color'],b.inputs['Base Color'])
 r=image(n,name+'_roughness',True);l.new(r.outputs['Color'],b.inputs['Roughness'])
 t=image(n,name+'_normal',True);nm=n.new('ShaderNodeNormalMap');nm.inputs['Strength'].default_value=.55;l.new(t.outputs['Color'],nm.inputs['Color']);l.new(nm.outputs['Normal'],b.inputs['Normal'])
 return m
bark=pbr('bark');ground=pbr('meadow')
leaf=material('Original cutout leaf sprig');n=leaf.node_tree.nodes;l=leaf.node_tree.links;b=n.get('Principled BSDF')
a=image(n,'leaf_sprig');l.new(a.outputs['Color'],b.inputs['Base Color']);b.inputs['Roughness'].default_value=.76
transparent=n.new('ShaderNodeBsdfTransparent');mix=n.new('ShaderNodeMixShader');l.new(a.outputs['Alpha'],mix.inputs[0]);l.new(transparent.outputs[0],mix.inputs[1]);l.new(b.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],n.get('Material Output').inputs['Surface'])
convert=Matrix(((1,0,0),(0,0,-1),(0,1,0)))
def godot_vec(v):return convert@Vector(v)
def obj(name,at):
 vs=[];uv=[];faces=[]
 for line in (SOURCE/(name+'.obj')).read_text().splitlines():
  p=line.split()
  if p[0]=='v':vs.append(tuple(godot_vec(tuple(map(float,p[1:4])))))
  elif p[0]=='vt':uv.append(tuple(map(float,p[1:3])))
  elif p[0]=='f':faces.append([int(s.split('/')[0])-1 for s in p[1:]])
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(vs,[],faces);mesh.update()
 layer=mesh.uv_layers.new(name='UVMap')
 for poly in mesh.polygons:
  poly.use_smooth=True
  for loop_index in poly.loop_indices:
   vi=mesh.loops[loop_index].vertex_index;layer.data[loop_index].uv=uv[vi]
 node=bpy.data.objects.new(name,mesh);scene.collection.objects.link(node);node.location=at;node.data.materials.append(bark);return node
for variant,at in [(0,(-1.7,0,0)),(1,(1.8,.3,0))]:
 obj('tree_trunk_'+str(variant),at)
 vertices=[];faces=[]
 for v in json.loads((SOURCE/('leaves_'+str(variant)+'.json')).read_text()):
  base=len(vertices);basis=Matrix((v[0:3],v[3:6],v[6:9])).transposed();origin=Vector(v[9:12])
  for p in [(-.5,-.5,0),(.5,-.5,0),(.5,.5,0),(-.5,.5,0)]:vertices.append(tuple(godot_vec(basis@Vector(p)+origin)))
  faces.append((base,base+1,base+2,base+3))
 mesh=bpy.data.meshes.new('Leaf sprigs');mesh.from_pydata(vertices,[],faces);mesh.update();uv=mesh.uv_layers.new()
 for p in mesh.polygons:
  for j,k in enumerate(p.loop_indices):uv.data[k].uv=[(0,1),(1,1),(1,0),(0,0)][j]
 node=bpy.data.objects.new('Actual baked foliage '+str(variant),mesh);scene.collection.objects.link(node);node.location=at;node.data.materials.append(leaf)
bpy.ops.mesh.primitive_plane_add(size=200);bpy.context.object.data.materials.append(ground)
bpy.ops.object.light_add(type='SUN',location=(4,-5,10));sun=bpy.context.object;sun.rotation_euler=(math.radians(30),math.radians(-20),math.radians(-30));sun.data.energy=2.0;sun.data.angle=math.radians(3)
bpy.ops.object.camera_add(location=(9,-13,7));camera=bpy.context.object;camera.rotation_euler=(Vector((0,0,2.6))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.lens=47;scene.camera=camera
scene.render.filepath=str(OUT);bpy.ops.render.render(write_still=True)
print('Actual tree-asset CPU preview saved:',OUT,'(NOT a Godot/Xogot screenshot)')
