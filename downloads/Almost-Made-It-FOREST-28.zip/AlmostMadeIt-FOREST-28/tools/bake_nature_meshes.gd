extends SceneTree
const OUT := "res://art/sky_garden/meshes/"
var rng := RandomNumberGenerator.new()
var tool: SurfaceTool
func _initialize() -> void:
    call_deferred("bake")
func triangle(a: Vector3,b: Vector3,c: Vector3,na: Vector3,nb: Vector3,nc: Vector3,ua: Vector2,ub: Vector2,uc: Vector2) -> void:
    # Godot uses clockwise fronts. Normals are explicitly outward.
    for entry in [[a,na,ua],[c,nc,uc],[b,nb,ub]]:
        tool.set_normal(entry[1]);tool.set_uv(entry[2]);tool.set_uv2(Vector2(0,clampf(entry[0].y/6,0,1)))
        tool.add_vertex(entry[0])
func limb(points: Array[Vector3],radii: Array[float],sides := 9) -> void:
    var rings: Array[Array] = []
    var normals: Array[Array] = []
    var length := 0.0
    var along: Array[float] = []
    for i in range(points.size()):
        if i>0:length+=points[i].distance_to(points[i-1])
        along.append(length)
        var direction: Vector3 = (points[mini(i+1,points.size()-1)]-points[maxi(i-1,0)]).normalized()
        var reference := Vector3.UP if absf(direction.dot(Vector3.UP))<.95 else Vector3.RIGHT
        var u := direction.cross(reference).normalized()
        var v := direction.cross(u).normalized()
        var ring: Array[Vector3]=[]
        var norms: Array[Vector3]=[]
        for j in range(sides):
            var angle := j*TAU/sides
            var normal := u*cos(angle)+v*sin(angle)
            ring.append(points[i]+normal*radii[i]*(1+.09*sin(j*3.1+i*.8)))
            norms.append(normal)
        rings.append(ring);normals.append(norms)
    for i in range(points.size()-1):
        for j in range(sides):
            var k := (j+1)%sides
            var a:Vector3=rings[i][j];var b:Vector3=rings[i+1][j];var c:Vector3=rings[i+1][k];var d:Vector3=rings[i][k]
            var uv_a:=Vector2(float(j)/sides,along[i]*.7);var uv_b:=Vector2(float(j)/sides,along[i+1]*.7)
            var uv_c:=Vector2(float(j+1)/sides,along[i+1]*.7);var uv_d:=Vector2(float(j+1)/sides,along[i]*.7)
            triangle(a,b,c,normals[i][j],normals[i+1][j],normals[i+1][k],uv_a,uv_b,uv_c)
            triangle(a,c,d,normals[i][j],normals[i+1][k],normals[i][k],uv_a,uv_c,uv_d)
func begin() -> void:
    tool=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES)
func finish(name: String) -> ArrayMesh:
    tool.generate_tangents()
    var mesh:=tool.commit()
    assert(ResourceSaver.save(mesh,OUT+name+".res")==OK)
    return mesh
func bake_tree(variant: int) -> void:
    rng.seed=1600+variant
    begin()
    var h:=5.8 if variant==0 else 5.1
    var points:Array[Vector3]=[];var radii:Array[float]=[]
    for i in range(10):
        var t:=i/9.0
        points.append(Vector3(sin(t*2.5)*.25,t*h,sin(t*4+variant)*.15*t))
        radii.append(lerpf(.29,.018,pow(t,.65)))
    limb(points,radii,11)
    var foliage: Array[Transform3D]=[]
    var values: Array[Color]=[]
    for i in range(16):
        var angle:=i*2.399+variant*.8
        var start:=points[4+i%5]
        var side:=Vector3(cos(angle),0,sin(angle))
        var end:=start+side*rng.randf_range(.9,1.65)+Vector3.UP*rng.randf_range(.25,.65)
        limb([start,start.lerp(end,.35)+Vector3.UP*.12,start.lerp(end,.72),end],[.10,.07,.035,.008],7)
        for j in range(3):
            var twig_start:=start.lerp(end,.5+j*.16)
            var tip:=twig_start+side*.35+Vector3(sin(angle+1.2)*.30,.30,cos(angle+1.2)*.3)
            limb([twig_start,twig_start.lerp(tip,.55),tip],[.025,.014,.003],5)
            for k in range(10):
                var at:=tip+Vector3(rng.randfn(0,.33),rng.randfn(0,.24),rng.randfn(0,.33))
                var basis:=Basis(Vector3.UP,rng.randf()*TAU)*Basis(Vector3.RIGHT,rng.randf_range(-1.0,1.0))
                var scale_value:=rng.randf_range(.32,.52)
                foliage.append(Transform3D(basis.scaled(Vector3(scale_value,scale_value,scale_value)),at))
                values.append(Color(rng.randf_range(.8,1.14),rng.randf()*TAU,at.y/h,rng.randf()))
    for i in range(6):
        var side:=Vector3(cos(i*TAU/6),0,sin(i*TAU/6))
        limb([side*.12+Vector3.UP*.4,side*.45,side*.85-Vector3.UP*.28],[.13,.085,.009],7)
    finish("tree_trunk_%d"%variant)
    # Shuffle once so every visible-instance prefix stays distributed in crown.
    for i in range(foliage.size()-1,0,-1):
        var j:=rng.randi_range(0,i)
        var temp:=foliage[i];foliage[i]=foliage[j];foliage[j]=temp
        var c:=values[i];values[i]=values[j];values[j]=c
    # Keep authored transforms on the CPU. A headless RenderingServer does not
    # retain MultiMesh GPU buffers, so saving those directly loses the foliage.
    var encoded:Array=[]
    for i in range(foliage.size()):
        var t:Transform3D=foliage[i];var c:Color=values[i]
        encoded.append([t.basis.x.x,t.basis.x.y,t.basis.x.z,t.basis.y.x,t.basis.y.y,t.basis.y.z,t.basis.z.x,t.basis.z.y,t.basis.z.z,t.origin.x,t.origin.y,t.origin.z,c.r,c.g,c.b,c.a])
    var data:=Resource.new();data.set_meta("cards",encoded)
    assert(ResourceSaver.save(data,OUT+"tree_foliage_%d.tres"%variant)==OK)

func bake() -> void:
    DirAccess.make_dir_recursive_absolute(OUT)
    bake_tree(0);bake_tree(1)
    begin()
    rng.seed=1610
    for i in range(5):
        var at:=Vector3(rng.randf_range(-.09,.09),0,rng.randf_range(-.09,.09))
        var angle:=rng.randf()*TAU
        var side:=Vector3(cos(angle),0,sin(angle))
        var width:=rng.randf_range(.006,.013)
        var height:=rng.randf_range(.13,.24)
        var bend:=Vector3(-sin(angle),0,cos(angle))*rng.randf_range(.025,.08)
        var normal:=side.cross(Vector3.UP).normalized()
        var middle:=at+Vector3.UP*height*.60+bend*.35
        var tip:=at+Vector3.UP*height+bend
        triangle(at-side*width,at+side*width,middle+side*width*.5,normal,normal,normal,Vector2(0,0),Vector2(1,0),Vector2(1,.6))
        triangle(at-side*width,middle+side*width*.5,middle-side*width*.5,normal,normal,normal,Vector2(0,0),Vector2(1,.6),Vector2(0,.6))
        triangle(middle-side*width*.5,middle+side*width*.5,tip,normal,normal,normal,Vector2(0,.6),Vector2(1,.6),Vector2(.5,1))
    finish("grass_clump")
    begin()
    for i in range(6):
        var at:=Vector3(rng.randf_range(-.4,.4),0,rng.randf_range(-.3,.3))
        limb([at,at+Vector3(.13,-.6,.10),at+Vector3(-.15,-1.25,.2),at+Vector3(.08,-2,.15)],[.045,.035,.018,.002],5)
    finish("hanging_roots")
    begin()
    var rings:Array[Array]=[]
    for j in range(6):
        var ring:Array[Vector3]=[]
        for i in range(17):
            var angle:=i*TAU/17
            var r:float=[.13,.75,1.0,.83,.51,.10][j]
            ring.append(Vector3(cos(angle)*r*(1+.18*sin(i*2.3+j)), -[0.0,.5,1.7,3.3,4.8,6.0][j]+rng.randf_range(-.14,.14),sin(angle)*r*1.3*(1+.15*cos(i*1.7+j))))
        rings.append(ring)
    for j in range(5):
        for i in range(17):
            var k:=(i+1)%17
            for tri in [[rings[j][i],rings[j+1][i],rings[j+1][k]],[rings[j][i],rings[j+1][k],rings[j][k]]]:
                var normal:Vector3=(tri[1]-tri[0]).cross(tri[2]-tri[0]).normalized()
                triangle(tri[0],tri[1],tri[2],normal,normal,normal,Vector2(i*.2,j*.4),Vector2(i*.2,(j+1)*.4),Vector2((i+1)*.2,(j+1)*.4))
    finish("rock_crag")
    print("NATURE BAKE: two curved branching trunks, two 480-sprig foliage MultiMeshes, five-blade clump and root bundle")
    quit()
