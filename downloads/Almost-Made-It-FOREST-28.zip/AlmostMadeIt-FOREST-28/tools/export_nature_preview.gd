extends SceneTree
# Offline artist QA export. These OBJ/JSON files are NOT used by the game.
func _initialize() -> void:
    var out:="/tmp/sky-garden-preview"
    DirAccess.make_dir_recursive_absolute(out)
    for name in ["tree_trunk_0","tree_trunk_1","grass_clump"]:
        var mesh:ArrayMesh=load("res://art/sky_garden/meshes/"+name+".res")
        var data:=mesh.surface_get_arrays(0)
        var vertices:PackedVector3Array=data[Mesh.ARRAY_VERTEX]
        var normals:PackedVector3Array=data[Mesh.ARRAY_NORMAL]
        var uvs:PackedVector2Array=data[Mesh.ARRAY_TEX_UV]
        var file:=FileAccess.open(out+"/"+name+".obj",FileAccess.WRITE)
        for v in vertices:file.store_line("v %.6f %.6f %.6f"%[v.x,v.y,v.z])
        for v in uvs:file.store_line("vt %.6f %.6f"%[v.x,v.y])
        for v in normals:file.store_line("vn %.6f %.6f %.6f"%[v.x,v.y,v.z])
        for i in range(0,vertices.size(),3):file.store_line("f %d/%d/%d %d/%d/%d %d/%d/%d"%[i+1,i+1,i+1,i+3,i+3,i+3,i+2,i+2,i+2])
        file.close()
    for variant in range(2):
        var data:Resource=load("res://art/sky_garden/meshes/tree_foliage_%d.tres"%variant)
        var file:=FileAccess.open(out+"/leaves_%d.json"%variant,FileAccess.WRITE)
        file.store_string(JSON.stringify(data.get_meta("cards")));file.close()
    print("Original nature meshes exported to offline QA directory")
    quit()
