extends "res://scripts/environment/garden_polish.gd"
# LANDSCAPE-22. Decorative terrain/forests only; no course or HUD changes.
var landscape_enabled := true
var land_rng := RandomNumberGenerator.new()
var land_meshes: Dictionary = {}
var landforms: Array[Dictionary] = []
var land_nodes: Array[MultiMeshInstance3D] = []
var land_material: ShaderMaterial
var forest_seeds: Array[Dictionary] = []
var grove_meshes: Dictionary = {}
var background_poses: Dictionary = {}
var background_nodes: Array[MultiMeshInstance3D] = []
var background_bounds: Array[AABB] = []
var landscape_stats: Dictionary = {}
var active_hill := -1

func decorate(owner_game: Node3D) -> void:
    landscape_enabled=bool(ProjectSettings.get_setting("visuals/landscape/enabled",true))
    land_rng.seed=22022
    if landscape_enabled:
        land_material=ShaderMaterial.new()
        land_material.shader=load("res://shaders/landscape/terrain.gdshader")
        for texture in ["meadow_albedo","soil_albedo","rock_albedo","cloud_noise"]:
            land_material.set_shader_parameter(texture,texture_asset(texture))
    super.decorate(owner_game)
    if not landscape_enabled:return
    flush_landforms()
    background_details()
    flush_batches() # New lookout/foam reuse the existing scenery batching.
    world_stats.batches=batch_nodes.size()
    world_stats.instances=0
    for node in batch_nodes:world_stats.instances+=node.multimesh.instance_count
    flush_background()
    landscape_stats={"terrain_forms":landforms.size(),"terrain_batches":land_nodes.size(),"groves":0,"trees":forest_roots.size(),"detail_batches":background_nodes.size(),"detail_instances":background_bounds.size(),"new_textures":0}
    var groves:Dictionary={}
    for entry in forest_seeds:groves[entry.hill]=true
    landscape_stats.groves=groves.size()
    update_lod()

func hill(at:Vector3,scale_value:Vector3,green:String) -> void:
    if not landscape_enabled:
        super.hill(at,scale_value,green)
        return
    var layer:=0 if scale_value.y<3 else 2 if at.z< -110 else 1
    var mesh:Mesh
    var kind:String
    var scale_new:=Vector3(scale_value.x*.98,scale_value.y,scale_value.z*.98)
    if scale_value.y<3:
        kind="terrace";mesh=primitive(kind)
        # Keep the side villages' existing terrace surfaces and structural heights.
        landforms.append({"mesh":primitive("blob"),"pose":Transform3D(Basis.from_scale(Vector3(scale_value.x,4,scale_value.z)),at-Vector3.UP*4.1),"layer":0,"base":true})
    else:
        var variant:=landforms.size()%4
        kind="landform_%d"%variant;mesh=rolling_landform(variant)
        if at.y> -10:scale_new.y*=.72 # Avoid the old stretched pyramid silhouette.
    if not support_faces.has(kind):support_faces[kind]=mesh.get_faces()
    supports.append({"at":at,"scale":scale_new,"kind":kind})
    active_hill=supports.size()-1
    landforms.append({"mesh":mesh,"pose":Transform3D(Basis.from_scale(scale_new),at),"layer":layer,"base":false})

func relief(x:float,z:float,variant:int) -> float:
    var angle:=atan2(z,x)
    var outline:=1+.055*sin(angle*3+variant)+.035*cos(angle*7-variant)
    var radius:=sqrt(x*x+z*z)/outline
    var dome:=pow(maxf(0,1-radius*radius),1.12)
    var ridges:=.10*sin(x*7+variant*.8)*cos(z*5-variant)+.055*sin(z*11+x*4+variant)
    return dome*(.70+ridges)+.045*sin(x*12+z*7)*smoothstep(.90,.35,radius)

func rolling_landform(variant:int) -> ArrayMesh:
    if land_meshes.has(variant):return land_meshes[variant]
    var tool:=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES)
    var segments:=36;var rings:=9
    for ring in range(rings):
        for section in range(segments):
            var corners:Array[Vector3]=[]
            for pair in [Vector2(section,ring),Vector2(section+1,ring),Vector2(section+1,ring+1),Vector2(section,ring+1)]:
                var angle:float=pair.x*TAU/segments
                var radius:float=pair.y/rings
                var shape:=1+.055*sin(angle*3+variant)+.035*cos(angle*7-variant)
                var x:=cos(angle)*radius*shape;var z:=sin(angle)*radius*shape
                corners.append(Vector3(x,relief(x,z,variant),z))
            for index in [0,1,2,0,2,3]:
                var point:Vector3=corners[index]
                var dx:float=(relief(point.x+.002,point.z,variant)-relief(point.x-.002,point.z,variant))/.004
                var dz:float=(relief(point.x,point.z+.002,variant)-relief(point.x,point.z-.002,variant))/.004
                tool.set_normal(Vector3(-dx,1,-dz).normalized());tool.add_vertex(point)
    # Irregular layered skirt: a real silhouette, rather than a stretched sphere.
    for ring in range(3):
        for section in range(segments):
            var corners:Array[Vector3]=[]
            for pair in [Vector2(section,ring),Vector2(section+1,ring),Vector2(section+1,ring+1),Vector2(section,ring+1)]:
                var angle:float=pair.x*TAU/segments
                var radial:float=[1.0,.96,.73,.08][int(pair.y)]
                var shape:=1+.055*sin(angle*3+variant)+.035*cos(angle*7-variant)
                var height:float=[0.0,-.25,-.57,-.88][int(pair.y)]
                if pair.y>0:height+=sin(angle*5+variant)*.035
                corners.append(Vector3(cos(angle)*radial*shape,height,sin(angle)*radial*shape))
            for triangle in [[0,1,2],[0,2,3]]:
                var normal:Vector3=(corners[triangle[1]]-corners[triangle[0]]).cross(corners[triangle[2]]-corners[triangle[0]]).normalized()
                for index in triangle:tool.set_normal(normal);tool.add_vertex(corners[index])
    var result:=tool.commit();land_meshes[variant]=result;return result

func horizon() -> void:
    super.horizon()
    if landscape_enabled:
        hill(Vector3(-53,12,-163),Vector3(6,4,7),"789b7b")
        hill(Vector3(53,13,-178),Vector3(7,4.5,6),"789b7b")
        # Cooler silhouettes behind the inhabited ridge, not extra walkable land.
        hill(Vector3(-30,-4,-210),Vector3(42,44,26),"789b7b")
        hill(Vector3(34,-5,-222),Vector3(38,41,25),"789b7b")

func small_tree(at:Vector3,height:float,variant:int) -> void:
    if not landscape_enabled:
        super.small_tree(at,height,variant)
        return
    if upgrade_enabled and in_garden(at,2.2):
        super.small_tree(at,height,variant) # Preserve the good entrance models.
        return
    forest_seeds.append({"hill":active_hill,"height":height,"variant":variant})

func flush_forest() -> void:
    if not landscape_enabled:
        super.flush_forest()
        return
    var members:Dictionary={}
    for seed in forest_seeds:
        if not members.has(seed.hill):members[seed.hill]=[]
        members[seed.hill].append(seed)
    for index in members:
        var surface:Dictionary=supports[index]
        var count:int=members[index].size()
        var layer:=0 if surface.scale.x<12 else 2 if surface.at.z< -110 else 1
        var centre:=Vector2(land_rng.randf_range(-.23,.23),land_rng.randf_range(-.10,.27))
        for i in range(count):
            var seed:Dictionary=members[index][i]
            # Golden-angle groves, with a second small pocket on larger hills.
            var pocket:=Vector2(.32,-.12) if count>6 and i>=count-3 else Vector2.ZERO
            var radius:=sqrt(float(i%maxi(count-3,3))+ .5)*(.105 if layer>0 else .13)
            var angle:float=i*2.399963+index*.83
            var local:=centre+pocket+Vector2(cos(angle),sin(angle))*radius
            var at:Vector3=surface.at+Vector3(local.x*surface.scale.x,0,local.y*surface.scale.z)
            at=grounded_root(at)
            var name:String=seed.get("species","CommonTree_4" if (i+index)%3==0 else "CommonTree_3")
            var data:Dictionary=source(name)
            var height:float=seed.height*land_rng.randf_range(.82,1.22)
            var size:float=height/data.bounds.size.y
            var width:=land_rng.randf_range(1.55,2.10) if layer>0 else land_rng.randf_range(1.25,1.65)
            width*=float(seed.get("width_multiplier",1.0))
            var pose:=Transform3D(Basis(Vector3.UP,land_rng.randf()*TAU).scaled(Vector3(size*width,size,size*width*land_rng.randf_range(.88,1.10))),at-Vector3.UP*data.bounds.position.y*size)
            var key:=name+":"+str(layer)+":"+str(floori(at.z/60))
            if not forest.has(key):forest[key]={"name":name,"poses":[],"layer":layer}
            forest[key].poses.append(pose*data.local)
            forest_bounds.append(pose*data.bounds)
            forest_roots.append({"root":at,"name":name,"height":height,"key":key,"index":forest[key].poses.size()-1})
    for key in forest:
        var data:Dictionary=forest[key]
        var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D
        mm.mesh=grove_mesh(data.name,data.layer);mm.instance_count=data.poses.size()
        for i in range(mm.instance_count):mm.set_instance_transform(i,data.poses[i])
        var node:=MultiMeshInstance3D.new();node.name="ImportedForest_"+key.replace(":","_");node.multimesh=mm
        node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;node.lod_bias=.6
        add_child(node);forest_batches.append(node)

func grove_mesh(name:String,layer:int) -> Mesh:
    var key:=name+str(layer)
    if not grove_meshes.has(key):
        var mesh:=source(name).mesh.duplicate() as ArrayMesh
        for i in range(mesh.get_surface_count()):
            var material:=mesh.surface_get_material(i).duplicate() as StandardMaterial3D
            material.roughness=.88
            if i==1:
                material.diffuse_mode=BaseMaterial3D.DIFFUSE_LAMBERT_WRAP
                material.backlight_enabled=true;material.backlight=Color(.12,.17,.065)
                material.albedo_color=[Color(.94,1,.84),Color(.85,.97,.88),Color(.77,.89,.94)][layer]
            mesh.surface_set_material(i,material)
        grove_meshes[key]=mesh
    return grove_meshes[key]

func flush_landforms() -> void:
    var groups:Dictionary={}
    for form in landforms:
        var key:=str(form.mesh.get_instance_id())+":"+str(form.layer)+":"+str(floori(form.pose.origin.z/60))
        if not groups.has(key):groups[key]={"mesh":form.mesh,"layer":form.layer,"forms":[]}
        groups[key].forms.append(form)
    for key in groups:
        var data:Dictionary=groups[key]
        var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.use_custom_data=true;mm.mesh=data.mesh;mm.instance_count=data.forms.size()
        for i in range(mm.instance_count):
            mm.set_instance_transform(i,data.forms[i].pose)
            mm.set_instance_custom_data(i,Color(land_rng.randf_range(.90,1.08),float(data.layer),1 if data.forms[i].base else 0,0))
        var node:=MultiMeshInstance3D.new();node.name="LandscapeTerrain_%02d"%land_nodes.size();node.multimesh=mm;node.material_override=land_material
        node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;node.visibility_range_end=250
        add_child(node);land_nodes.append(node)

func detail(name:String,at:Vector3,size:Vector3,yaw:float) -> void:
    var data:Dictionary=source(name)
    var pose:Transform3D=Transform3D(Basis(Vector3.UP,yaw).scaled(size),at)*data.local
    var key:=name+":"+str(floori(at.z/50))
    if not background_poses.has(key):background_poses[key]={"name":name,"poses":[]}
    background_poses[key].poses.append(pose)
    background_bounds.append(pose*data.mesh.get_aabb())

func background_details() -> void:
    for index in range(supports.size()):
        var surface:Dictionary=supports[index]
        if surface.at.y< -10 or surface.at.z< -180:continue
        var near:bool=surface.scale.x<12
        for i in range(3 if near else 2):
            var local:=Vector2(land_rng.randf_range(-.6,.6),land_rng.randf_range(-.5,.5))
            var at:Vector3=surface.at+Vector3(local.x*surface.scale.x,0,local.y*surface.scale.z)
            var y:=terrain_height(at)
            if not is_finite(y):continue
            at.y=y-.12
            var size:=land_rng.randf_range(.38,.67) if near else land_rng.randf_range(.8,1.5)
            detail("Rock_Medium_3",at,Vector3(size,size*land_rng.randf_range(.75,1.35),size),land_rng.randf()*TAU)
            for j in range(3 if near else 1):
                var plant:=at+Vector3(land_rng.randf_range(-1.2,1.2),0,land_rng.randf_range(-1.2,1.2))
                plant.y=terrain_height(plant)
                if is_finite(plant.y):detail("Plant_1",plant,Vector3.ONE*(.55 if near else .8),land_rng.randf()*TAU)
    # Existing village/windmill/waterfall landmarks remain. One extra distant
    # lookout and a rock waterfall provide asymmetry, never a new playable route.
    var at:=Vector3(-33,0,-29);var y:=terrain_height(at)
    if is_finite(y):tower(Vector3(at.x,y,at.z),true)
    at=Vector3(33,0,-55);y=terrain_height(at)
    if is_finite(y):
        for i in range(3):detail("Rock_Medium_3",Vector3(at.x+i*.8,y-.4,at.z),Vector3(.9,1.8+i*.4,1),i*.6)
        curtain(Vector3(at.x,y-3.2,at.z+.3),Vector2(1.6,7),0)

func flush_background() -> void:
    for key in background_poses:
        var data:Dictionary=background_poses[key]
        var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.mesh=source(data.name).mesh;mm.instance_count=data.poses.size()
        for i in range(mm.instance_count):mm.set_instance_transform(i,data.poses[i])
        var node:=MultiMeshInstance3D.new();node.name="LandscapeDetail_"+key.replace(":","_");node.multimesh=mm
        node.visibility_range_end=65 if data.name=="Plant_1" else 150
        node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(node);background_nodes.append(node)

func update_lod() -> void:
    super.update_lod()
    if not landscape_enabled:return
    for node in land_nodes:node.visibility_range_end=190 if quality==0 else 250
    for node in background_nodes:
        node.visibility_range_end=(38 if quality==0 else 65) if "Plant_1" in node.name else (100 if quality==0 else 150)
