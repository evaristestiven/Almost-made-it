extends "res://scripts/environment/living_garden.gd"
# TREE-GAME-19. Only replaces Level 1's eight nearby decorative trees.
# Imported scene/material/texture resources are shared between instances.
const COMMON_TREE := preload("res://assets/nature/quaternius/CommonTree_3/CommonTree_3.gltf")
var imported_trees: Array[Dictionary]=[]
func decorate(owner_game: Node3D) -> void:
    super.decorate(owner_game)
    budgets.tree_instances=imported_trees.size()
    budgets.leaf_cards=0 # No procedural canopy cards; the imported mesh is used.
    world_stats.primary_trees=imported_trees.size()
    world_stats.imported_tree_triangles=imported_trees.size()*3505
func tree(at: Vector3,scale_value: float,_variant: int) -> void:
    var model:=COMMON_TREE.instantiate() as Node3D
    model.name="CommonTree3_%02d"%(imported_trees.size()+1)
    # Match the previous near-tree height rather than using the 9.4m source at
    # full scale. Keep the same RNG draw as the previous tree for scene stability.
    var size:=scale_value*.75
    at.x-=signf(at.x)*.65
    if imported_trees.size()<2:at.z=-6.5
    model.scale=Vector3.ONE*size
    model.rotation.y=rng.randf()*TAU
    var mesh:=model.find_children("*","MeshInstance3D",true,false)[0] as MeshInstance3D
    model.position=at-Vector3.UP*mesh.mesh.get_aabb().position.y*size
    add_child(model)
    mesh.visibility_range_end=72
    mesh.lod_bias=1.0
    imported_trees.append({"model":model,"mesh":mesh,"bounds":mesh.global_transform*mesh.mesh.get_aabb(),"phase":float(imported_trees.size())*1.7})
    # Retain the existing decorative stone foundation; no collider is added.
    var stone:=mesh_node(load(ROOT+"meshes/rock_crag.res"),tint("78988b"),at)
    stone.scale=Vector3(1.4,.9,1.25)
func update_lod() -> void:
    super.update_lod()
    var camera_position:=Vector3(0,5.7,16)
    if is_instance_valid(game.camera):camera_position=game.camera.global_position
    var range_end:float=[48.0,72.0,85.0][quality]
    for entry in imported_trees:
        entry.mesh.visibility_range_end=range_end
        entry.mesh.lod_bias=.65 if quality==0 else 1.0
        entry.mesh.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_ON if quality>0 and entry.model.global_position.distance_to(camera_position)<28 else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
func _process(delta: float) -> void:
    super._process(delta)
    for entry in imported_trees:
        # Cosmetic, root-pivoted sway of about a quarter degree. No physics body.
        entry.model.rotation.z=sin(clock*1.1+entry.phase)*.004
