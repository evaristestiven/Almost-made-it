extends "res://scripts/environment/quaternius_garden.gd"
# STARTING-GARDEN-20: cosmetic entrance only, z=-4..9. Private RNG keeps
# all later course decoration identical to TREE-GAME-19.
const ASSETS := "res://assets/nature/quaternius/CommonTree_3/"
const START_MIN := -4.0
const START_MAX := 9.0
var upgrade_enabled:=true
var garden_rng:=RandomNumberGenerator.new()
var asset_cache:Dictionary={}
var garden_trees:Array[Dictionary]=[]
var garden_batches:Array[MultiMeshInstance3D]=[]
var garden_bounds:Array[AABB]=[]
var garden_poses:Dictionary={}
var outside_records:Array[String]=[]
var garden_grass:ShaderMaterial
var plant_material:ShaderMaterial
var leaf_variants:Dictionary={}
var garden_fill:OmniLight3D
var garden_stats:Dictionary={}
func in_garden(at: Vector3,margin:=0.0) -> bool:
    return at.z>=START_MIN+margin and at.z<=START_MAX-margin and absf(at.x)<30.0-margin
func decorate(owner_game: Node3D) -> void:
    upgrade_enabled=bool(ProjectSettings.get_setting("visuals/starting_garden/enabled",true))
    garden_rng.seed=20020
    if upgrade_enabled:
        garden_grass=ShaderMaterial.new();garden_grass.shader=load("res://shaders/starting_garden/grass.gdshader");animated.append(garden_grass)
        plant_material=ShaderMaterial.new();plant_material.shader=load("res://shaders/starting_garden/plant.gdshader")
        plant_material.set_shader_parameter("leaf_map",load(ASSETS+"Leaves.png"));animated.append(plant_material)
    super.decorate(owner_game)
    if upgrade_enabled:
        flush_garden()
        garden_fill=OmniLight3D.new();garden_fill.name="StartingGardenFill";garden_fill.position=Vector3(0,3.2,3)
        garden_fill.omni_range=6.8;garden_fill.light_energy=.20;garden_fill.light_color=Color(1,.94,.82)
        garden_fill.shadow_enabled=false;add_child(garden_fill)
        garden_stats={"trees":garden_trees.size(),"batches":garden_batches.size(),"instances":0,"model_types":5,"new_texture_maps":3}
        for node in garden_batches:garden_stats.instances+=node.multimesh.instance_count
        update_lod()
func source(name: String) -> Dictionary:
    if not asset_cache.has(name):
        var scene:PackedScene=load(ASSETS+name+".gltf")
        var model:Node3D=scene.instantiate()
        var meshes:=model.find_children("*","MeshInstance3D",true,false)
        assert(meshes.size()==1,"Verified small garden assets must have one mesh node")
        var node:=meshes[0] as MeshInstance3D
        var transform:=node.transform
        var ancestor:Node3D=node.get_parent()
        while ancestor!=model:
            transform=ancestor.transform*transform;ancestor=ancestor.get_parent()
        asset_cache[name]={"scene":scene,"mesh":node.mesh,"local":transform,"bounds":transform*node.mesh.get_aabb()}
        model.free()
    return asset_cache[name]
func place(kind: String,at: Vector3,size: Vector3,color: String,angles:=Vector3.ZERO) -> void:
    if not in_garden(at):outside_records.append(str([kind,at,size,color,angles]))
    if upgrade_enabled and in_garden(at):
        # Replace the existing entrance pavers, not a new walkable surface.
        if kind=="blob" and color=="e4d5aa" and at.z>START_MIN+.1:return
        if kind=="blob" and color=="8ea69a" and in_garden(at,1.2):
            var scale_value:=garden_rng.randf_range(.29,.40)
            imported("Rock_Medium_3",at-Vector3.UP*.5,scale_value,garden_rng.randf()*TAU)
            return
    super.place(kind,at,size,color,angles)
func beam(a: Vector3,b: Vector3,width: float,color: String) -> void:
    if not in_garden(a) or not in_garden(b):outside_records.append(str(["beam",a,b,width,color]))
    super.beam(a,b,width,color)
func small_tree(at: Vector3,height: float,variant: int) -> void:
    if upgrade_enabled and in_garden(at,2.2):
        garden_tree(at,height,"CommonTree_4" if variant%2==0 else "CommonTree_3",variant*.81)
    else:super.small_tree(at,height,variant)
func grow_grass(at: Vector3,size: Vector3,index: int) -> void:
    var first:=grass_cells.size()
    super.grow_grass(at,size,index) # Preserve all original RNG draws and placement.
    if upgrade_enabled and is_zero_approx(at.z):
        for i in range(first,grass_cells.size()):
            var cell:Dictionary=grass_cells[i]
            if cell.root_bounds.position.z>=0:cell.node.material_override=garden_grass
func garden_tree(at: Vector3,height: float,name: String,yaw: float) -> void:
    var data:=source(name)
    var model:=data.scene.instantiate() as Node3D
    model.name="Garden_"+name+"_%02d"%garden_trees.size()
    var scale_value:float=height/data.bounds.size.y
    model.scale=Vector3.ONE*scale_value;model.rotation.y=yaw
    model.position=at-Vector3.UP*data.bounds.position.y*scale_value
    add_child(model)
    var mesh:=model.find_children("*","MeshInstance3D",true,false)[0] as MeshInstance3D
    # Leaf wrap/backlighting is confined to the new Starting Garden trees.
    if not leaf_variants.has(name):
        var material:=mesh.mesh.surface_get_material(1).duplicate() as StandardMaterial3D
        material.diffuse_mode=BaseMaterial3D.DIFFUSE_LAMBERT_WRAP
        material.backlight_enabled=true;material.backlight=Color(.13,.18,.07)
        material.roughness=.83
        leaf_variants[name]=material
    mesh.set_surface_override_material(1,leaf_variants[name])
    mesh.visibility_range_end=58
    var bounds:AABB=mesh.global_transform*mesh.mesh.get_aabb()
    garden_trees.append({"model":model,"mesh":mesh,"bounds":bounds,"yaw":yaw})
    garden_bounds.append(bounds)
func imported(name: String,at: Vector3,scale_value: float,yaw:=0.0) -> void:
    var data:=source(name)
    var pose:Transform3D=Transform3D(Basis(Vector3.UP,yaw).scaled(Vector3.ONE*scale_value),at)*data.local
    if not garden_poses.has(name):garden_poses[name]=[]
    garden_poses[name].append(pose)
    garden_bounds.append(pose*data.mesh.get_aabb())
func starting_garden() -> void:
    super.starting_garden() # Keeps houses, ponds, fences and original flower RNG.
    if not upgrade_enabled:return
    # Existing paired gold circles are replaced by genuine imported path stones.
    for i in range(8):
        var z:=8.1-i*1.6
        var size:=garden_rng.randf_range(.72,.78)
        var data:=source("RockPath_Square_Thin")
        var y:float=.021+i*.0007-data.bounds.end.y*size
        imported("RockPath_Square_Thin",Vector3(sin(z*.28)*.38,y,z),size,garden_rng.randf_range(-.12,.12))
    # Textured, normal-mapped visual overlay is restricted to the original floor.
    var mat:=ShaderMaterial.new();mat.shader=load("res://shaders/starting_garden/ground.gdshader")
    for name in ["meadow_albedo","meadow_normal","soil_albedo","cloud_noise"]:mat.set_shader_parameter(name,texture_asset(name))
    var plane:=PlaneMesh.new();plane.size=Vector2(9.96,12.9)
    var top:=mesh_node(plane,mat,Vector3(0,.006,2.55));top.name="StartingGardenSurface"
    # Plant_1 is genuine leafy ground cover, not a renamed grass/flower model.
    for side in [-1,1]:
        for centre in [Vector3(side*4.05,0,6.7),Vector3(side*4.1,0,2.7),Vector3(side*4.0,0,-1.3),Vector3(side*8.8,.12,3.0),Vector3(side*9,.12,-1.0)]:
            for i in range(9):
                var at:Vector3=centre+Vector3(garden_rng.randf_range(-.45,.45),0,garden_rng.randf_range(-.65,.65))
                var size:=garden_rng.randf_range(.26,.48)
                imported("Plant_1",at,size,garden_rng.randf()*TAU)
        # Layer imported rocks below the walking edge; they cannot imply a wall.
        for z in [-2.2,1.0,4.3,7.3]:
            var size:=garden_rng.randf_range(.36,.46);var data:=source("Rock_Medium_3")
            imported("Rock_Medium_3",Vector3(side*5.85,-.07-data.bounds.end.y*size,z),size,garden_rng.randf()*TAU)
        # True model trees frame the entrance without changing the tested eight.
        garden_tree(Vector3(side*7.65,-.7,-1.7),5.0,"CommonTree_4" if side==1 else "CommonTree_3",side*.7)
        var rock:=source("Rock_Medium_3");var rock_size:=.64
        imported("Rock_Medium_3",Vector3(side*7.65,-.69-rock.bounds.end.y*rock_size,-1.7),rock_size,side*.7)
        for i in range(13):
            var z:=garden_rng.randf_range(-3.1,8.2)
            var size:=garden_rng.randf_range(.45,.85);var data:=source("Pebble_Round_2")
            imported("Pebble_Round_2",Vector3(side*garden_rng.randf_range(1.1,1.7),.018-data.bounds.end.y*size,z),size,garden_rng.randf()*TAU)
func flush_garden() -> void:
    for name in garden_poses:
        var data:=source(name);var poses:Array=garden_poses[name]
        var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.mesh=data.mesh;mm.instance_count=poses.size()
        for i in range(poses.size()):mm.set_instance_transform(i,poses[i])
        var node:=MultiMeshInstance3D.new();node.name="Starting_"+name;node.multimesh=mm
        if name=="Plant_1":node.material_override=plant_material
        node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;node.visibility_range_end=48
        add_child(node);garden_batches.append(node)
func update_lod() -> void:
    super.update_lod()
    if not upgrade_enabled:return
    var camera_position:=Vector3(0,5.7,16)
    if is_instance_valid(game.camera):camera_position=game.camera.global_position
    for entry in garden_trees:
        entry.mesh.visibility_range_end=44 if quality==0 else 62
        entry.mesh.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_ON if quality>0 and entry.model.global_position.distance_to(camera_position)<24 else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    for node in garden_batches:
        node.visibility_range_end=32 if quality==0 else 48
        if node.name=="Starting_Plant_1":node.multimesh.visible_instance_count=int(node.multimesh.instance_count*(.55 if quality==0 else .8 if quality==1 else 1.0))
    if is_instance_valid(garden_fill):garden_fill.visible=quality>0
func _process(delta: float) -> void:
    super._process(delta)
    if not upgrade_enabled:return
    if is_instance_valid(game.runner):garden_grass.set_shader_parameter("avatar_position",game.runner.global_position)
    for i in range(garden_trees.size()):garden_trees[i].model.rotation.z=sin(clock*1.1+i)*.004
