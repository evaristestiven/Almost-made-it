extends "res://scripts/environment/sky_garden.gd"
# LIVING-GARDEN-17: scenery only. Never writes input, physics or course data.
const AREAS := ["Starting Garden","Training Courtyard","Waterfall Crossing","Windmill Hills","Finish Plaza"]
var pieces: Dictionary={}
var palette: Dictionary={}
var shapes: Dictionary={}
var rotors: Array[Node3D]=[]
var butterflies: Array[Dictionary]=[]
var banners: Array[Node3D]=[]
var zones: Array[Dictionary]=[]
var water_material: ShaderMaterial
var terrain_material: StandardMaterial3D
var decoration_bounds: Array[AABB]=[]
var batch_nodes: Array[MultiMeshInstance3D]=[]
var world_stats: Dictionary={}
var canopy_mesh: ArrayMesh

func tint(hex: String) -> StandardMaterial3D:
    if not palette.has(hex):
        var mat:=StandardMaterial3D.new()
        mat.albedo_color=Color(hex).srgb_to_linear();mat.roughness=.72;mat.metallic_specular=.35
        mat.cull_mode=BaseMaterial3D.CULL_DISABLED
        palette[hex]=mat
    return palette[hex]
func primitive(kind: String) -> Mesh:
    if not shapes.has(kind):
        var mesh: Mesh
        if kind=="box":mesh=BoxMesh.new()
        elif kind=="post":
            var cylinder:=CylinderMesh.new();cylinder.top_radius=.5;cylinder.bottom_radius=.5;cylinder.height=1;cylinder.radial_segments=8;cylinder.rings=1;mesh=cylinder
        elif kind=="roof":
            var s:=SurfaceTool.new();s.begin(Mesh.PRIMITIVE_TRIANGLES)
            var a:=Vector3(-.5,0,.5);var b:=Vector3(.5,0,.5);var c:=Vector3(0,1,.5)
            var d:=Vector3(-.5,0,-.5);var e:=Vector3(.5,0,-.5);var f:=Vector3(0,1,-.5)
            for v in [a,b,c,d,f,e,a,c,f,a,f,d,c,b,e,c,e,f,a,d,e,a,e,b]:s.add_vertex(v)
            s.generate_normals();mesh=s.commit()
        elif kind=="terrace":mesh=terrace_mesh()
        elif kind=="petal":mesh=organic_mesh(6,4)
        else:mesh=organic_mesh()
        shapes[kind]=mesh
    return shapes[kind]
func organic_mesh(segments:=12,rings:=8) -> ArrayMesh:
    var s:=SurfaceTool.new();s.begin(Mesh.PRIMITIVE_TRIANGLES)
    for j in range(rings):
        for i in range(segments):
            var quad:Array[Vector3]=[]
            for pair in [[i,j],[i+1,j],[i+1,j+1],[i,j+1]]:
                var u:float=pair[0]*TAU/segments;var v:float=pair[1]*PI/rings
                var radius:=1+sin(v)*(.055*sin(u*3+v*5)+.025*cos(u*5-v*4))
                quad.append(Vector3(sin(v)*cos(u),cos(v),sin(v)*sin(u))*radius)
            for triangle in [[quad[0],quad[2],quad[1]],[quad[0],quad[3],quad[2]]]:
                if (triangle[1]-triangle[0]).cross(triangle[2]-triangle[0]).length_squared()<.0000001:continue
                for vertex in triangle:
                    s.set_normal(vertex.normalized());s.add_vertex(vertex)
    return s.commit()
func terrace_mesh() -> ArrayMesh:
    var s:=SurfaceTool.new();s.begin(Mesh.PRIMITIVE_TRIANGLES)
    for j in range(3):
        for i in range(32):
            var p:Array[Vector3]=[]
            for pair in [[i,j],[i+1,j],[i+1,j+1],[i,j+1]]:
                var angle:float=pair[0]*TAU/32
                var radius:float=[0.0,.55,.88,1.0][pair[1]]
                var height:float=[.17,.13,.0,-.65][pair[1]]
                height+=sin(angle*3)*.025*radius
                p.append(Vector3(cos(angle)*radius,height,sin(angle)*radius))
            for k in [0,2,1,0,3,2]:s.add_vertex(p[k])
    s.generate_normals();return s.commit()
func place(kind: String,at: Vector3,size: Vector3,color: String,angles:=Vector3.ZERO) -> void:
    var chunk:=clampi(floori((8-at.z)/18),-2,7)
    var key:=kind+":"+str(chunk)
    if not pieces.has(key):pieces[key]={"kind":kind,"chunk":chunk,"poses":[],"colors":[]}
    pieces[key].poses.append(Transform3D(Basis.from_euler(angles).scaled(size),at))
    pieces[key].colors.append(Color(color).srgb_to_linear())
func beam(a: Vector3,b: Vector3,width: float,color: String) -> void:
    var direction:=b-a
    var basis:=Basis.looking_at(direction.normalized(),Vector3.UP if absf(direction.normalized().y)<.99 else Vector3.RIGHT)
    # Unit box local Z points along the beam.
    var transform:=Transform3D(basis.scaled(Vector3(width,width,direction.length())),(a+b)*.5)
    var key:="box:"+str(clampi(floori((8-a.z)/18),-2,7))
    if not pieces.has(key):pieces[key]={"kind":"box","chunk":floori((8-a.z)/18),"poses":[],"colors":[]}
    pieces[key].poses.append(transform);pieces[key].colors.append(Color(color).srgb_to_linear())
func label(at: Vector3,words: String,scale_value:=.003) -> void:
    var sign:=Label3D.new();sign.text=words;sign.font_size=56;sign.pixel_size=scale_value
    sign.position=at;sign.modulate=Color("fff5cb");sign.outline_modulate=Color("275969");sign.outline_size=10
    sign.billboard=BaseMaterial3D.BILLBOARD_ENABLED;sign.visibility_range_end=38;add_child(sign)
func decorate(owner_game: Node3D) -> void:
    canopy_mesh=organic_mesh()
    super.decorate(owner_game)
    grass_material.shader=load("res://shaders/living_garden/grass.gdshader")
    water_material=ShaderMaterial.new();water_material.shader=load("res://shaders/living_garden/water.gdshader");animated.append(water_material)
    # The original rocky skirts remain; tint their material toward a cheerful slate.
    for node in get_children():
        if node is MeshInstance3D and node.material_override==rock_material:node.material_override=tint("8da38d")
    for i in range(AREAS.size()):zones.append({"name":AREAS[i],"z":[4.0,-5.0,-15.7,-43.0,-70.0][i]})
    landscape()
    starting_garden()
    training_courtyard()
    waterfall_crossing()
    windmill_hills()
    finish_plaza()
    horizon()
    flush_batches()
    world_stats={"districts":zones.size(),"batches":batch_nodes.size(),"instances":0,"windmills":rotors.size(),"butterflies":butterflies.size(),"banners":banners.size(),"primary_trees":trees.size()}
    for node in batch_nodes:world_stats.instances+=node.multimesh.instance_count
    set_quality(quality)
func configure_lighting(world: WorldEnvironment,sun: DirectionalLight3D) -> void:
    super.configure_lighting(world,sun)
    world.environment.ambient_light_color=Color("b5d9ed");world.environment.ambient_light_energy=.36
    world.environment.fog_light_color=Color("b8e3f1");world.environment.fog_density=.0018
    sun.light_color=Color("fff0ce");sun.light_energy=1.05
    sky_material.shader=load("res://shaders/living_garden/sky.gdshader")
    sky_material.set_shader_parameter("noise_map",texture_asset("cloud_noise"))
    sky_material.set_shader_parameter("sun_direction",sun.global_basis.z.normalized())
func ground(platform: Node3D,center: float) -> void:
    platform.get_child(0).material_override=tint("70b44e")
    for i in range(2,platform.get_child_count()):
        if platform.get_child(i) is MeshInstance3D:platform.get_child(i).visible=false
    var size:Vector3=platform.get_child(0).mesh.size
    var top:Vector3=platform.position+Vector3.UP*size.y*.5
    if size.x>5:
        for i in range(floori(size.z/1.3)):
            var z:=top.z-size.z*.5+.6+i*1.3
            var bend:=sin(z*.18)*.32
            for side in [-1,1]:place("blob",Vector3(center+bend+side*.38,.018,z),Vector3(.36,.015,.54),"e4d5aa",Vector3(0,sin(z)*.13,0))
func tree(at: Vector3,scale_value: float,variant: int) -> void:
    var trunk:=mesh_node(load(ROOT+"meshes/tree_trunk_%d.res"%variant),tint("94643e"),at,true)
    trunk.scale=Vector3.ONE*scale_value;trunk.rotation.y=rng.randf()*TAU;trunk.visibility_range_end=85
    var leaves:=MultiMeshInstance3D.new();var instances:=MultiMesh.new()
    instances.transform_format=MultiMesh.TRANSFORM_3D;instances.use_colors=true;instances.mesh=canopy_mesh;instances.instance_count=11
    var centres:Array[Vector3]=[]
    for i in range(11):
        var angle:=i*2.39996
        var radial:=1.05 if i<8 else .35
        var p:=Vector3(cos(angle)*radial,4.25+(i%3)*.64,sin(angle)*radial)
        var scale_leaf:=Vector3(1.35,1.05,1.22) if i<8 else Vector3(1.25,1.15,1.15)
        centres.append(trunk.transform*p)
        instances.set_instance_transform(i,Transform3D(Basis.from_euler(Vector3(.12*i,.7*i,.1)).scaled(scale_leaf),p))
        instances.set_instance_color(i,Color(["4f9f48","68b747","82c34e","93cb57"][i%4]).srgb_to_linear())
    var crown_material:ShaderMaterial=instance_material().duplicate()
    crown_material.set_shader_parameter("sway",.025);animated.append(crown_material)
    leaves.multimesh=instances;leaves.material_override=crown_material;leaves.transform=trunk.transform;leaves.visibility_range_end=85
    leaves.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_ON;add_child(leaves);trees.append({"trunk":trunk,"leaves":leaves,"centres":centres})
    var stone:=mesh_node(load(ROOT+"meshes/rock_crag.res"),tint("78988b"),at);stone.scale=Vector3(1.4,.9,1.25)
func instance_material() -> ShaderMaterial:
    if not palette.has("instances"):
        var mat:=ShaderMaterial.new();mat.shader=load("res://shaders/living_garden/props.gdshader")
        animated.append(mat)
        palette.instances=mat
    return palette.instances
func distant_islands() -> void:pass # Replaced by connected hills and a horizon.
func small_tree(at: Vector3,height: float,variant: int) -> void:
    place("post",at+Vector3(0,height*.34,0),Vector3(.30,height*.68,.30),"91613f")
    for i in range(4):
        var angle:=i*2.4
        place("blob",at+Vector3(cos(angle)*height*.15,height*(.68+.09*(i%2)),sin(angle)*height*.15),Vector3(height*.27,height*.25,height*.26),["429249","58ab4a","79bd4e","9bce61"][(variant+i)%4])
func hill(at: Vector3,scale_value: Vector3,green: String) -> void:
    # Thick sculpted landforms join only the decorative side world, never gaps.
    place("blob",at-Vector3.UP*4.1,Vector3(scale_value.x,4.0,scale_value.z),"829986")
    place("terrace" if scale_value.y<3 else "blob",at,Vector3(scale_value.x*.98,scale_value.y,scale_value.z*.98),green)
func landscape() -> void:
    for side in [-1,1]:
        for i in range(8):
            var z:=8-i*13.0
            var at:=Vector3(side*(17.8+sin(i*.9)*1.2),-.2+sin(i*.7)*.16,z)
            hill(at,Vector3(9.0,1.35,9.4),["78be50","87c65b","68b750"][i%3])
            for j in range(4):
                var p:=at+Vector3(side*(rng.randf_range(-3.4,4.0)),.22,rng.randf_range(-5.1,5.1))
                small_tree(p,rng.randf_range(3.4,5.3),i+j)
            for j in range(3):
                var p:=at+Vector3(rng.randf_range(-6,6),.5,rng.randf_range(-6,6))
                place("blob",p,Vector3(.7,.65,.6),"8ea69a")
            # A meandering village trail on the side hills, clearly off-course.
            for j in range(6):
                var p:=at+Vector3(sin((z+j)*.16)*2,.23,-5+j*2)
                place("blob",p,Vector3(.75,.10,1.04),"ddcf9a")
    # A green valley far below the death boundary replaces the empty sky floor.
    for i in range(5):hill(Vector3(-19+i*10,-20,-38),Vector3(17,3.2,73),"80bfa0")
    water(Vector3(0,-15,-38),Vector2(9,150))
func house(at: Vector3,color: String,scale_value:=1.0) -> void:
    place("box",at+Vector3(0,1.05,0)*scale_value,Vector3(3,2.1,2.7)*scale_value,color)
    place("roof",at+Vector3(0,2.05,0)*scale_value,Vector3(3.7,1.65,3.4)*scale_value,"b76349")
    for side in [-1,1]:
        place("box",at+Vector3(side*1.42,1.0,1.38)*scale_value,Vector3(.15,2.0,.12)*scale_value,"795e40")
        place("box",at+Vector3(side*.95,1.3,1.38)*scale_value,Vector3(.52,.68,.07)*scale_value,"87cfe0")
        place("box",at+Vector3(side*.95,1.3,1.43)*scale_value,Vector3(.06,.7,.05)*scale_value,"fff0bf")
    place("box",at+Vector3(0,.67,1.39)*scale_value,Vector3(.64,1.34,.09)*scale_value,"6c6851")
    place("box",at+Vector3(.9,3.0,-.55)*scale_value,Vector3(.42,1.05,.5)*scale_value,"dfbc89")
    # Roof shingles read from the course camera without texture memory.
    for j in range(3):
        place("box",at+Vector3(0,2.1+j*.45,1.73-j*.35)*scale_value,Vector3(3.6-j*.9,.10,.12)*scale_value,"d98556")
func fence(a: Vector3,b: Vector3) -> void:
    for h in [.45,.95]:beam(a+Vector3.UP*h,b+Vector3.UP*h,.11,"efe0b0")
    var count:=ceili(a.distance_to(b)/1.6)
    for i in range(count+1):place("post",a.lerp(b,float(i)/maxi(count,1))+Vector3.UP*.65,Vector3(.17,1.3,.17),"d8bd84")
func flower_bed(at: Vector3,length: float) -> void:
    place("blob",at,Vector3(length*.5,.16,.75),"658e44")
    for i in range(16):
        var p:=at+Vector3(rng.randf_range(-length*.45,length*.45),.25,rng.randf_range(-.55,.55))
        place("post",p,Vector3(.035,.4,.035),"4c8f43")
        for j in range(4):
            var angle:=j*TAU/4
            place("petal",p+Vector3(cos(angle)*.10,.21,sin(angle)*.10),Vector3(.13,.07,.13),["f7c866","e997ad","b7a1df","fff4c6"][i%4])
        place("petal",p+Vector3.UP*.24,Vector3(.07,.05,.07),"f7d06f")
func signpost(at: Vector3,words: String) -> void:
    place("post",at+Vector3.UP*.8,Vector3(.16,1.6,.16),"94734d")
    place("box",at+Vector3.UP*1.6,Vector3(2.4,.62,.14),"658b75")
    label(at+Vector3(0,1.62,.12),words,.0022)
func starting_garden() -> void:
    house(Vector3(-13,-.1,3),"f5e3b6",.95)
    house(Vector3(17,.0,-2),"e4c997",.7)
    fence(Vector3(-9.8,.25,8),Vector3(-9.8,.25,-2))
    flower_bed(Vector3(8.7,.05,3),4.0);flower_bed(Vector3(-9.5,.1,-3),3)
    signpost(Vector3(6.7,.05,3.5),"SKY GARDEN")
    for side in [-1,1]:
        # Corner gardens lie outside the camera/player envelope.
        flower_bed(Vector3(side*8,.1,5),2)
    pond(Vector3(12,.05,5),Vector2(4.0,2.5))
    bridge(Vector3(16,.5,4),Vector3(16,.5,-3),1.7)
    flutter(Vector3(8.6,.9,2.5),0);flutter(Vector3(-9.1,.9,-2.5),1)
func training_courtyard() -> void:
    # Machinery gardens flank the real red bars, with no added hazard response.
    for side in [-1,1]:
        var at:=Vector3(side*9,-.05,-6)
        place("post",at+Vector3.UP*.35,Vector3(2.5,.7,2.5),"d9cca0")
        place("post",at+Vector3.UP*.9,Vector3(.35,1.8,.35),"8b7554")
        for i in range(8):
            var angle:=i*TAU/8
            place("box",at+Vector3(cos(angle)*.8,1.0,sin(angle)*.8),Vector3(.22,.15,.22),"efc86d",Vector3(0,-angle,0))
        banner(Vector3(side*7,0,-4),"f0b45c")
        fence(Vector3(side*10,.0,-8.5),Vector3(side*15,.0,-8.5))
    signpost(Vector3(-7,.05,-9),"TRAINING GARDEN")
    tower(Vector3(16,.0,-14),false)
func water(at: Vector3,size: Vector2) -> void:
    var plane:=PlaneMesh.new();plane.size=size
    var node:=mesh_node(plane,water_material,at);node.visibility_range_end=140
func pond(at: Vector3,size: Vector2) -> void:
    place("blob",at-Vector3.UP*.16,Vector3(size.x*.57,.23,size.y*.65),"c4c8a2")
    water(at+Vector3.UP*.03,size)
    for i in range(9):
        var angle:=i*TAU/9
        place("blob",at+Vector3(cos(angle)*size.x*.52,.07,sin(angle)*size.y*.56),Vector3(.42,.18,.32),"b9c4a0")
func waterfall_crossing() -> void:
    # Side streams supply large waterfalls down the same gorge as the moving stone.
    for side in [-1,1]:
        pond(Vector3(side*11.8,.08,-17),Vector2(5.0,7))
        water(Vector3(side*9,.10,-12.3),Vector2(4.4,2.8))
        curtain(Vector3(side*7.5,-5,-12.3),Vector2(2.8,10),side*PI*.5)
        for j in range(3):place("blob",Vector3(side*(7.5+j*.65),-1.5-j*.8,-13.7),Vector3(1.05,1.3,1.1),"849e90")
        bridge(Vector3(side*12,.65,-9.5),Vector3(side*12,.65,-21),1.8)
        banner(Vector3(side*7.0,.15,-18),"78c8cf")
    signpost(Vector3(6.8,.05,-21),"WATERFALL CROSSING")
    curtain(Vector3(9,-3,-32),Vector2(3.3,8),0)
    curtain(Vector3(-12,-3,-33),Vector2(3.3,8),0)
    # Rest plaza surrounds the existing checkpoint at z=-30, without hiding it.
    for side in [-1,1]:
        flower_bed(Vector3(side*8.6,.0,-30),3.2)
        bench(Vector3(side*9.0,.0,-28))
    house(Vector3(-15,.2,-28),"f2dba3",.85)
    tower(Vector3(13,.2,-27),true)
    flutter(Vector3(-8.3,1.0,-30),2)
func curtain(at: Vector3,size: Vector2,angle: float) -> void:
    var material:=ShaderMaterial.new();material.shader=load("res://shaders/living_garden/falls.gdshader");animated.append(material)
    var quad:=QuadMesh.new();quad.size=size
    var node:=mesh_node(quad,material,at);node.rotation.y=angle;node.visibility_range_end=100
    for i in range(5):place("blob",at-Vector3.UP*size.y*.5+Vector3(sin(i)*.6,.15,cos(i)*.45),Vector3(.65,.12,.65),"dbf8ed")
func bridge(a: Vector3,b: Vector3,width: float) -> void:
    var length:=a.distance_to(b);var count:=ceili(length/.42)
    for i in range(count):
        var fraction:=float(i)/maxi(count-1,1)
        var p:=a.lerp(b,fraction);p.y-=sin(fraction*PI)*.35
        place("box",p,Vector3(width,.12,.35),"bd925d")
    for side in [-1,1]:fence(a+Vector3(side*width*.5,0,0),b+Vector3(side*width*.5,0,0))
func bench(at: Vector3) -> void:
    place("box",at+Vector3.UP*.5,Vector3(1.8,.15,.55),"bf915f")
    place("box",at+Vector3(0,.95,-.28),Vector3(1.8,.65,.12),"bf915f")
    for side in [-1,1]:place("box",at+Vector3(side*.65,.23,0),Vector3(.12,.46,.4),"76654b")
func tower(at: Vector3,roof: bool) -> void:
    for side in [-1,1]:
        for depth in [-1,1]:place("box",at+Vector3(side*1.05,2,depth*1.05),Vector3(.24,4,.24),"a07c50")
    place("box",at+Vector3.UP*3.0,Vector3(2.7,.22,2.7),"cfaa71")
    if roof:place("roof",at+Vector3.UP*4.4,Vector3(3.3,1.5,3.3),"c8734e")
    fence(at+Vector3(-1.1,3.1,1.1),at+Vector3(1.1,3.1,1.1))
    beam(at+Vector3(-1,0,1),at+Vector3(1,3,-1),.14,"b28c5a")
func windmill(at: Vector3,scale_value: float) -> void:
    place("post",at+Vector3.UP*2.25*scale_value,Vector3(2.4,4.5,2.4)*scale_value,"efd7a4")
    place("roof",at+Vector3.UP*4.45*scale_value,Vector3(3.1,1.8,3.1)*scale_value,"c16c4c")
    for i in range(3):place("box",at+Vector3(0,(1+i)*scale_value,1.23*scale_value),Vector3(.38,.45,.06)*scale_value,"719fbd")
    var pivot:=Node3D.new();pivot.position=at+Vector3(0,4.1,1.75)*scale_value;add_child(pivot);rotors.append(pivot)
    for i in range(4):
        var blade:=MeshInstance3D.new();var mesh:=BoxMesh.new();mesh.size=Vector3(.52,2.7,.09)*scale_value
        blade.mesh=mesh;blade.material_override=tint("f9edc6");blade.position=Vector3(sin(i*PI*.5),cos(i*PI*.5),0)*1.35*scale_value;blade.rotation.z=-i*PI*.5
        blade.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;pivot.add_child(blade)
    var hub:=MeshInstance3D.new();hub.mesh=primitive("blob");hub.scale=Vector3.ONE*.28*scale_value;hub.material_override=tint("8a6a46");pivot.add_child(hub)
func windmill_hills() -> void:
    windmill(Vector3(8.8,.35,-62),1.3)
    windmill(Vector3(-9.5,.55,-68),1.0)
    house(Vector3(-11.8,.1,-40),"f1dba2",.85)
    house(Vector3(18.0,.2,-54),"f3d8b2",.80)
    for side in [-1,1]:
        fence(Vector3(side*8.7,.1,-39),Vector3(side*8.7,.1,-46))
        flower_bed(Vector3(side*8.6,.1,-47),3.5)
        banner(Vector3(side*6.9,.0,-43),"e4a0a5")
    signpost(Vector3(6.8,.05,-39),"WINDMILL HILLS")
    # The second moving-platform gap stays open: waterfall spillways sit aside it.
    for side in [-1,1]:curtain(Vector3(side*8,-5,-56.3),Vector2(2.3,10),side*PI*.5)
func banner(at: Vector3,color: String) -> void:
    place("post",at+Vector3.UP*1.65,Vector3(.12,3.3,.12),"c4a476")
    var flag:=MeshInstance3D.new();var mesh:=BoxMesh.new();mesh.size=Vector3(.85,.65,.035);flag.mesh=mesh;flag.material_override=tint(color)
    flag.position=at+Vector3(.48,2.8,0);flag.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;add_child(flag);banners.append(flag)
func flutter(at: Vector3,index: int) -> void:
    var node:=Node3D.new();node.position=at;add_child(node)
    for side in [-1,1]:
        var wing:=MeshInstance3D.new();wing.mesh=primitive("blob");wing.scale=Vector3(.13,.015,.095);wing.position.x=side*.08;wing.material_override=tint("f8d17c" if index%2==0 else "c1a2e5");node.add_child(wing)
    butterflies.append({"node":node,"home":at,"phase":index*1.7})
func finish_plaza() -> void:
    for side in [-1,1]:
        house(Vector3(side*9.5,.0,-83),"f4dcb0",1.05)
        flower_bed(Vector3(side*8.4,.05,-74),4.2)
        bench(Vector3(side*9,.05,-66))
        banner(Vector3(side*6.8,0,-72),"e9b85f")
        tower(Vector3(side*9,.1,-81),true)
    # High bunting is entirely above the established maximum normal jump.
    for i in range(11):
        var x:=-4.6+i*.92;var y:=5.2+pow(absf(x)/4.6,2)*.65
        place("roof",Vector3(x,y,-75),Vector3(.55,.55,.04),["edb85f","d69ba5","7fc5c3"][i%3],Vector3(0,0,PI))
    hill(Vector3(0,-.25,-98),Vector3(11,1.5,11),"82bb56")
    house(Vector3(0,.0,-98),"efdbb5",1.5)
    for side in [-1,1]:flower_bed(Vector3(side*4.5,.05,-95),3.0)
    signpost(Vector3(-6.8,.05,-64),"FINISH PLAZA")
    place("post",Vector3(0,-.04,-76),Vector3(6.7,.08,5.5),"dfd2a8")
    # Existing finish arch/trigger are retained; all finish text and results logic unchanged.
func horizon() -> void:
    for side in [-1,1]:
        for i in range(7):
            var at:=Vector3(side*(37+(i%2)*10),-2,15-i*23)
            hill(at,Vector3(16,8+(i%3)*2,18),"a5c9b3")
            for j in range(3):small_tree(at+Vector3(j*3-3,7,-j*2),5.0,i)
    for i in range(6):
        var at:=Vector3(-50+i*20,-1,-128-(i%2)*12)
        var height:=12.0+(i%3)*4
        hill(at,Vector3(23,height,22),["a7ccca","98c0bd","b4d5cc"][i%3])
        # Forest bands follow the visible slopes; distant hills have scale and
        # habitation cues instead of occupying the background as blank shapes.
        for j in range(12):
            var x:=-15.0+(j%6)*6
            var z:=11.0+floori(float(j)/6)*5
            var y:=height*scenery_surface_y(Vector2(x/(23*.98),z/(22*.98)))-.12
            small_tree(at+Vector3(x,y,z),4.0+(j%3)*.65,i+j)
    # Far cloud banks are cheap opaque silhouettes, never a fog particle field.
    for i in range(14):
        var p:=Vector3(-64+(i%7)*20,18+(i%3)*2,-68-floori(float(i)/7)*67)
        for j in range(3):place("cloud",p+Vector3((j-1)*2.8,sin(j*2.0)*.65,0),Vector3(3.7,1.65,2.8),"edf7f4")
func scenery_surface_y(point: Vector2) -> float:
    # Sample the actual decorative mesh once while building. An analytical
    # ellipsoid differs from this irregular mesh and can leave trees floating.
    var vertices:=primitive("blob").get_faces()
    var best:=-2.0
    for i in range(0,vertices.size(),3):
        var hit:Variant=Geometry3D.segment_intersects_triangle(Vector3(point.x,2,point.y),Vector3(point.x,-2,point.y),vertices[i],vertices[i+1],vertices[i+2])
        if hit!=null:best=maxf(best,hit.y)
    return best
func flush_batches() -> void:
    for key in pieces:
        var data:Dictionary=pieces[key]
        var instances:=MultiMesh.new();instances.transform_format=MultiMesh.TRANSFORM_3D;instances.use_colors=true
        instances.mesh=primitive(data.kind);instances.instance_count=data.poses.size()
        for i in range(data.poses.size()):instances.set_instance_transform(i,data.poses[i]);instances.set_instance_color(i,data.colors[i])
        for pose in data.poses:decoration_bounds.append(pose*instances.mesh.get_aabb())
        var node:=MultiMeshInstance3D.new();node.name="GardenBatch_"+key.replace(":","_");node.multimesh=instances;node.material_override=instance_material()
        # Opaque repeated geometry is culled by spatial chunks. Distant landscape
        # remains visible, small details vanish with the chunk before wasting work.
        if data.kind=="cloud":
            var cloud_material:ShaderMaterial=instance_material().duplicate()
            cloud_material.set_shader_parameter("cloud_drift",true);animated.append(cloud_material);node.material_override=cloud_material
        node.visibility_range_end=200 if data.kind in ["blob","cloud","terrace"] else 90
        node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(node);batch_nodes.append(node)
    pieces.clear()
func update_lod() -> void:
    super.update_lod()
    # Opaque canopy lobes keep their complete silhouette; use object distance LOD.
    for entry in trees:
        entry.leaves.multimesh.visible_instance_count=entry.leaves.multimesh.instance_count
func _process(delta: float) -> void:
    super._process(delta)
    for i in range(rotors.size()):rotors[i].rotation.z=clock*(.24+i*.035)
    for i in range(banners.size()):banners[i].rotation.y=sin(clock*1.6+i)*.10
    for entry in butterflies:
        entry.node.position=entry.home+Vector3(sin(clock*.8+entry.phase)*.65,sin(clock*1.5+entry.phase)*.16,cos(clock*.7+entry.phase)*.4)
        for side in range(entry.node.get_child_count()):entry.node.get_child(side).rotation.z=sin(clock*19+entry.phase)*.65*(1 if side==0 else -1)
