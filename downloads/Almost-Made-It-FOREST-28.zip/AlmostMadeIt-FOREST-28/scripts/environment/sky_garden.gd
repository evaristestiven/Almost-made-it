extends Node3D
# Level 1 visual layer only. No physics bodies, queries, input or gameplay writes.
const ROOT := "res://art/sky_garden/"
const SHADERS := "res://shaders/sky_garden/"
var game: Node3D
var theme: Dictionary
var living: Array[Node3D]=[]
var grass_cells: Array[Dictionary]=[]
var trees: Array[Dictionary]=[]
var animated: Array[ShaderMaterial]=[]
var ground_materials: Array[ShaderMaterial]=[]
var clock:=0.0
var quality:=1
var lod_clock:=0.0
var step_distance:=0.0
var connected_player:=false
var grass_material: ShaderMaterial
var leaf_material: ShaderMaterial
var bark_material: ShaderMaterial
var rock_material: ShaderMaterial
var sky_material: ShaderMaterial
var footsteps: CPUParticles3D
var rng:=RandomNumberGenerator.new()
var budgets: Dictionary={}
var foliage_data: Dictionary={}
func texture_asset(name: String) -> Texture2D:
    return load(ROOT+"textures/"+name+".png") as Texture2D
func shader_material(name: String) -> ShaderMaterial:
    var material:=ShaderMaterial.new()
    material.shader=load(SHADERS+name+".gdshader")
    return material
func surface(name: String) -> ShaderMaterial:
    var material:=shader_material("surface")
    for pair in [["albedo_map","albedo"],["normal_map","normal"],["roughness_map","roughness"]]:
        material.set_shader_parameter(pair[0],texture_asset(name+"_"+pair[1]))
    return material
func decorate(owner_game: Node3D) -> void:
    name="AdventureScenery"
    game=owner_game;theme=game.level_data.theme
    rng.seed=16016
    quality=clampi(int(ProjectSettings.get_setting("visuals/sky_garden/quality",1)),0,2)
    grass_material=shader_material("grass");animated.append(grass_material)
    leaf_material=shader_material("foliage")
    leaf_material.set_shader_parameter("leaf_map",texture_asset("leaf_sprig"))
    leaf_material.set_shader_parameter("normal_map",texture_asset("leaf_normal"));animated.append(leaf_material)
    bark_material=surface("bark");bark_material.set_shader_parameter("branch_wind",.015);animated.append(bark_material)
    rock_material=surface("rock");rock_material.set_shader_parameter("moss",1.0)
    var platforms:=get_tree().get_nodes_in_group("platforms")
    for index in range(platforms.size()):
        var platform: Node3D=platforms[index]
        var size: Vector3=platform.get_child(0).mesh.size
        var at:=platform.global_position+Vector3.UP*size.y*.5
        ground(platform,at.x)
        skirt(at,size)
        grow_grass(at,size,index)
        roots(at,size)
        if size.x>5:
            for side in [-1,1]:
                var scale_value:=rng.randf_range(.78,.94)
                tree(Vector3(side*(size.x*.5+3.1),at.y-1.3,at.z-2+side*1.8),scale_value,index%2)
            if index in [0,2]: waterfall(at+Vector3(size.x*.5+.04,-.10,-1.4),8.0)
    finish_arch()
    distant_islands()
    make_birds()
    make_footsteps()
    budgets={"grass_cells":grass_cells.size(),"grass_instances":0,"tree_instances":trees.size(),"leaf_cards":0,"texture_maps":15,"texture_resolution":512}
    for cell in grass_cells:budgets.grass_instances+=cell.total
    for entry in trees:budgets.leaf_cards+=entry.leaves.multimesh.instance_count
    set_quality(quality)
func configure_lighting(world: WorldEnvironment,sun: DirectionalLight3D) -> void:
    var env:=world.environment
    env.background_mode=Environment.BG_SKY
    env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color=Color(.64,.73,.82)
    env.ambient_light_energy=.32
    env.reflected_light_source=Environment.REFLECTION_SOURCE_DISABLED
    env.tonemap_mode=Environment.TONE_MAPPER_LINEAR
    env.tonemap_exposure=1.0
    env.fog_enabled=true
    env.fog_light_color=Color(.71,.79,.83)
    env.fog_density=.002
    sun.rotation_degrees=Vector3(-38,-28,0)
    sun.light_color=Color(1.0,.95,.86)
    sun.light_energy=1.12
    sun.directional_shadow_max_distance=36
    # Keep the existing 1024 shadow map and single orthogonal sun projection.
    # No global ProjectSettings changes that could affect another level.
    sun.shadow_blur=1.4
    sky_material=shader_material("atmosphere")
    sky_material.set_shader_parameter("noise_map",texture_asset("cloud_noise"))
    sky_material.set_shader_parameter("sun_direction",sun.global_basis.z.normalized())
    sky_material.set_shader_parameter("detail",1.0 if quality>0 else 0.0)
    var sky:=Sky.new();sky.sky_material=sky_material
    sky.radiance_size=Sky.RADIANCE_SIZE_32
    sky.process_mode=Sky.PROCESS_MODE_INCREMENTAL
    env.sky=sky
func ground(platform: Node3D,center: float) -> void:
    var material:=shader_material("ground")
    for prefix in ["meadow","soil"]:
        material.set_shader_parameter(prefix,texture_asset(prefix+"_albedo"))
        material.set_shader_parameter(prefix+"_normal",texture_asset(prefix+"_normal"))
        material.set_shader_parameter(prefix+"_rough",texture_asset(prefix+"_roughness"))
    material.set_shader_parameter("rock",texture_asset("rock_albedo"))
    material.set_shader_parameter("noise_map",texture_asset("cloud_noise"))
    material.set_shader_parameter("center_x",center)
    platform.get_child(0).material_override=material
    # The old yellow trim is decorative, not a collision or route boundary.
    for i in range(2,platform.get_child_count()):
        if platform.get_child(i) is MeshInstance3D:platform.get_child(i).visible=false
    ground_materials.append(material)
func mesh_node(mesh: Mesh,material: Material,at: Vector3,shadow := false) -> MeshInstance3D:
    var node:=MeshInstance3D.new();node.mesh=mesh;node.material_override=material;node.position=at
    node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(node);return node
func skirt(at: Vector3,size: Vector3) -> void:
    var surface_tool:=SurfaceTool.new();surface_tool.begin(Mesh.PRIMITIVE_TRIANGLES)
    var rings: Array[Array]=[]
    var levels:=[-.04,-.70,-1.6,-3.7,-6.8]
    var scales:=[.999,1.055,1.11,.72,.12]
    var count:=40
    for j in range(levels.size()):
        var ring:Array[Vector3]=[]
        for i in range(count):
            var angle:=i*TAU/count
            var radius:=minf(size.x*.5/maxf(absf(cos(angle)),.001),size.z*.5/maxf(absf(sin(angle)),.001))
            var variation:=1.0 if j==0 else 1+.10*sin(i*2.7+j)+rng.randf_range(-.045,.045)
            ring.append(at+Vector3(cos(angle)*radius*scales[j]*variation,levels[j]+(0.0 if j==0 else rng.randf_range(-.19,.19)),sin(angle)*radius*scales[j]*variation))
        rings.append(ring)
    for j in range(levels.size()-1):
        for i in range(count):
            var k:=(i+1)%count
            for triangle in [[rings[j][i],rings[j+1][k],rings[j+1][i]],[rings[j][i],rings[j][k],rings[j+1][k]]]:
                for vertex in triangle:
                    surface_tool.set_uv(Vector2(atan2(vertex.z-at.z,vertex.x-at.x)*2,vertex.y*.5))
                    surface_tool.add_vertex(vertex)
    surface_tool.generate_normals();surface_tool.generate_tangents()
    mesh_node(surface_tool.commit(),rock_material,Vector3.ZERO)
func grow_grass(at: Vector3,size: Vector3,index: int) -> void:
    var base: Mesh=load(ROOT+"meshes/grass_clump.res")
    var cells_x:=ceili(size.x/5.0);var cells_z:=ceili(size.z/5.0)
    for x in range(cells_x):
        for z in range(cells_z):
            var width:=size.x/cells_x;var length:=size.z/cells_z
            var center:=at+Vector3(-size.x*.5+(x+.5)*width,.012,-size.z*.5+(z+.5)*length)
            var poses:Array[Transform3D]=[];var colors:Array[Color]=[]
            # Maximum density is baked once; quality/LOD uses instance prefixes.
            for i in range(ceili(width*length*16)):
                var p:=Vector3(rng.randf_range(-width*.5+.10,width*.5-.10),0,rng.randf_range(-length*.5+.10,length*.5-.10))
                var world:=center+p
                var path_distance:=absf(world.x-at.x+sin(world.z*.18)*.18)
                if path_distance<1.15 and rng.randf()>.07:continue
                var patch:=sin(world.x*1.6+index)*sin(world.z*.55)
                if patch>.72 and rng.randf()>.18:continue
                var height_scale:=rng.randf_range(.6,1.15) if path_distance>1.15 else rng.randf_range(.22,.4)
                var basis:=Basis(Vector3.UP,rng.randf()*TAU).scaled(Vector3.ONE*height_scale)
                poses.append(Transform3D(basis,p));colors.append(Color(rng.randf_range(.78,1.12),rng.randf()*TAU,0,rng.randf()))
            var multimesh:=MultiMesh.new();multimesh.transform_format=MultiMesh.TRANSFORM_3D;multimesh.use_custom_data=true;multimesh.mesh=base;multimesh.instance_count=poses.size()
            for i in range(poses.size()):multimesh.set_instance_transform(i,poses[i]);multimesh.set_instance_custom_data(i,colors[i])
            var node:=MultiMeshInstance3D.new();node.multimesh=multimesh;node.material_override=grass_material;node.position=center
            node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;node.visibility_range_end=64
            var root_bounds:=AABB(center,Vector3.ZERO)
            for pose in poses:root_bounds=root_bounds.expand(center+pose.origin)
            add_child(node);grass_cells.append({"node":node,"total":poses.size(),"center":center,"width":width,"length":length,"root_bounds":root_bounds,"surface":at,"platform_size":size})
    wildflowers(at,size)
func tree(at: Vector3,scale_value: float,variant: int) -> void:
    var trunk:=mesh_node(load(ROOT+"meshes/tree_trunk_%d.res"%variant),bark_material,at,true)
    trunk.scale=Vector3.ONE*scale_value;trunk.rotation.y=rng.randf()*TAU;trunk.visibility_range_end=85
    var leaves:=MultiMeshInstance3D.new()
    if not foliage_data.has(variant):
        foliage_data[variant]=load(ROOT+"meshes/tree_foliage_%d.tres"%variant).get_meta("cards")
    var data:Array=foliage_data[variant]
    var instances:=MultiMesh.new()
    instances.transform_format=MultiMesh.TRANSFORM_3D;instances.use_custom_data=true
    var quad:=QuadMesh.new();quad.size=Vector2.ONE;instances.mesh=quad;instances.instance_count=data.size()
    for i in range(data.size()):
        var v:Array=data[i]
        instances.set_instance_transform(i,Transform3D(Basis(Vector3(v[0],v[1],v[2]),Vector3(v[3],v[4],v[5]),Vector3(v[6],v[7],v[8])),Vector3(v[9],v[10],v[11])))
        instances.set_instance_custom_data(i,Color(v[12],v[13],v[14],v[15]))
    leaves.multimesh=instances
    leaves.material_override=leaf_material;leaves.transform=trunk.transform
    leaves.visibility_range_end=85;add_child(leaves)
    trees.append({"trunk":trunk,"leaves":leaves})
    # A narrow, steep stone tooth anchors the tree below the playable surface.
    # It has no horizontal landing shelf and no collision.
    var tooth:=mesh_node(load(ROOT+"meshes/rock_crag.res"),rock_material,at)
    tooth.scale=Vector3(1.4,.9,1.25)
func roots(at: Vector3,size: Vector3) -> void:
    for side in [-1,1]:
        var node:=mesh_node(load(ROOT+"meshes/hanging_roots.res"),bark_material,at+Vector3(side*(size.x*.5-.15),-.12,size.z*.15))
        node.rotation.y=side*.7
func wildflowers(at: Vector3,size: Vector3) -> void:
    if size.x<3:return
    # Sparse opaque four-petal meadow flowers, with geometry instead of alpha.
    var surface_tool:=SurfaceTool.new();surface_tool.begin(Mesh.PRIMITIVE_TRIANGLES)
    for i in range(18 if size.x>5 else 3):
        var side:=-1.0 if i%2==0 else 1.0
        var p:=at+Vector3(side*rng.randf_range(1.8,maxf(1.81,size.x*.5-.35)),.08,rng.randf_range(-size.z*.44,size.z*.44))
        if absf(p.x-at.x)>size.x*.5-.15:continue
        var color:=Color("e9ddb0") if i%3 else Color("8f8aae")
        for j in range(4):
            var angle:=j*PI*.5
            for vertex in [p,p+Vector3(cos(angle)*.04,.02,sin(angle)*.04),p+Vector3(cos(angle+.9)*.045,0,sin(angle+.9)*.045)]:
                surface_tool.set_color(color);surface_tool.add_vertex(vertex)
    surface_tool.generate_normals()
    var material:=StandardMaterial3D.new();material.vertex_color_use_as_albedo=true;material.roughness=.9;material.cull_mode=BaseMaterial3D.CULL_DISABLED
    mesh_node(surface_tool.commit(),material,Vector3.ZERO)
func waterfall(at: Vector3,height: float) -> void:
    var material:=shader_material("waterfall");material.set_shader_parameter("noise_map",texture_asset("cloud_noise"));animated.append(material)
    var quad:=QuadMesh.new();quad.size=Vector2(.5,height)
    mesh_node(quad,material,at-Vector3.UP*height*.5)
func finish_arch() -> void:
    for side in [-1,1]:
        var post:=BoxMesh.new();post.size=Vector3(.28,3.5,.3)
        mesh_node(post,bark_material,Vector3(game.finish_x+side*4.2,1.75,game.finish_z))
    var beam:=BoxMesh.new();beam.size=Vector3(8.7,.65,.35)
    mesh_node(beam,bark_material,Vector3(game.finish_x,3.5,game.finish_z))
    var sign:=Label3D.new();sign.text="FINISH";sign.font_size=72;sign.pixel_size=.006
    sign.position=Vector3(game.finish_x,3.5,game.finish_z+.21);sign.billboard=BaseMaterial3D.BILLBOARD_ENABLED;add_child(sign)
func distant_islands() -> void:
    for i in range(6):
        var side:=-1.0 if i%2==0 else 1.0
        var at:=Vector3(side*(24+(i%3)*7),-9,5-i*18)
        var node:=mesh_node(load(ROOT+"meshes/rock_crag.res"),rock_material,at)
        node.scale=Vector3(4.5,2.3,4.0);node.rotation.y=i*.8
func make_birds() -> void:
    for i in range(3):
        var surface_tool:=SurfaceTool.new();surface_tool.begin(Mesh.PRIMITIVE_TRIANGLES)
        for p in [Vector3(-.25,0,0),Vector3(-.03,.06,0),Vector3(0,-.04,0),Vector3(0,-.04,0),Vector3(.03,.06,0),Vector3(.25,0,0)]:surface_tool.add_vertex(p)
        surface_tool.generate_normals()
        var material:=StandardMaterial3D.new();material.albedo_color=Color("e4e8e7");material.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;material.cull_mode=BaseMaterial3D.CULL_DISABLED
        var node:=mesh_node(surface_tool.commit(),material,Vector3(7+i*2,7+i,-28-i*14))
        living.append(node)
func make_footsteps() -> void:
    footsteps=CPUParticles3D.new();footsteps.amount=5;footsteps.one_shot=true;footsteps.emitting=false;footsteps.lifetime=.24;footsteps.explosiveness=1
    footsteps.direction=Vector3.UP;footsteps.spread=50;footsteps.initial_velocity_min=.15;footsteps.initial_velocity_max=.35;footsteps.gravity=Vector3(0,-1.2,0)
    footsteps.scale_amount_min=.009;footsteps.scale_amount_max=.018
    var mesh:=SphereMesh.new();mesh.radial_segments=6;mesh.rings=3;mesh.radius=1;mesh.height=2
    var material:=StandardMaterial3D.new();material.albedo_color=Color("a59b80");material.roughness=1
    mesh.material=material;footsteps.mesh=mesh;add_child(footsteps)
func _on_moved(before: Vector3,after: Vector3,_delta: float) -> void:
    if game.state!=game.RunState.PLAYING or not game.runner.is_on_floor() or game.runner.control_velocity.length()<1.5:return
    step_distance+=Vector2(after.x-before.x,after.z-before.z).length()
    if step_distance>.80 and not footsteps.emitting:
        step_distance=0;footsteps.position=after+Vector3.UP*.025;footsteps.restart();footsteps.emitting=true
func set_quality(value: int) -> void:
    quality=clampi(value,0,2);lod_clock=0.0
    if sky_material!=null:sky_material.set_shader_parameter("detail",1.0 if quality>0 else 0.0)
    update_lod()
func update_lod() -> void:
    var camera_position:=Vector3(0,5.7,16)
    if is_instance_valid(game.camera):camera_position=game.camera.global_position
    for cell in grass_cells:
        var distance:float=cell.center.distance_to(camera_position)
        var factor:float=[.38,.72,1.0][quality]
        if distance>26:factor*=.35
        if distance>(42 if quality==0 else 58):factor=0
        cell.node.multimesh.visible_instance_count=int(cell.total*factor)
    for entry in trees:
        var distance:float=entry.trunk.global_position.distance_to(camera_position)
        var fraction:float=[.42,.72,1.0][quality]
        if distance>35:fraction*=.38
        if distance>70:fraction*=.3
        entry.leaves.multimesh.visible_instance_count=int(entry.leaves.multimesh.instance_count*fraction)
        entry.leaves.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_ON if quality>0 and distance<28 else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
func _process(delta: float) -> void:
    clock+=delta
    for material in animated:material.set_shader_parameter("nature_time",clock)
    if is_instance_valid(game.runner):
        grass_material.set_shader_parameter("avatar_position",game.runner.global_position)
        if not connected_player:
            game.runner.moved.connect(_on_moved);connected_player=true
    for i in range(living.size()):
        living[i].rotation.z=sin(clock*.4+i)*.07
        living[i].position.x=7+i*2+sin(clock*.12+i)*2
    lod_clock-=delta
    if lod_clock<=0:
        lod_clock=.20
        update_lod()
        if sky_material!=null:sky_material.set_shader_parameter("cloud_time",clock)
