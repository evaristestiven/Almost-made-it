extends "res://scripts/environment/starting_garden.gd"
# GARDEN-POLISH-21. Visual changes only; no input, route or physics writes.
var polish_enabled := true
var supports: Array[Dictionary] = []
var support_faces: Dictionary = {}
var forest: Dictionary = {}
var forest_batches: Array[MultiMeshInstance3D] = []
var forest_bounds: Array[AABB] = []
var forest_roots: Array[Dictionary] = []
var forest_meshes: Dictionary = {}
var edge_bounds: Array[AABB] = []
var edge_nodes: Array[MultiMeshInstance3D] = []
var edge_poses: Dictionary = {}
var entrance_cliff: MeshInstance3D
var tuft_mesh: ArrayMesh
var soft_grass: ShaderMaterial
var polish_stats: Dictionary = {}
var replaced_clouds := 0
var supported_relocations := 0

func decorate(owner_game: Node3D) -> void:
    polish_enabled = bool(ProjectSettings.get_setting("visuals/garden_polish/enabled",true))
    if polish_enabled:
        soft_grass = ShaderMaterial.new()
        soft_grass.shader = load("res://shaders/garden_polish/grass.gdshader")
        animated.append(soft_grass)
        tuft_mesh = make_tuft()
    super.decorate(owner_game)
    if not polish_enabled: return
    var surface := get_node_or_null("StartingGardenSurface") as MeshInstance3D
    if is_instance_valid(surface): surface.material_override.shader = load("res://shaders/garden_polish/ground.gdshader")
    if is_instance_valid(entrance_cliff):
        var cliff := ShaderMaterial.new()
        cliff.shader=load("res://shaders/garden_polish/cliff.gdshader")
        cliff.set_shader_parameter("rock_map",texture_asset("rock_albedo"))
        cliff.set_shader_parameter("noise_map",texture_asset("cloud_noise"))
        entrance_cliff.material_override=cliff
        # The box's old all-green material also colored its vertical 60cm rim.
        # Shade that rim as cliff while retaining the original turf on top.
        var rim := cliff.duplicate() as ShaderMaterial
        rim.set_shader_parameter("keep_turf_top",true)
        for platform in get_tree().get_nodes_in_group("platforms"):
            if is_zero_approx(platform.global_position.z):
                var floor_mesh := platform.get_child(0) as MeshInstance3D
                floor_mesh.material_override=rim
    flush_forest()
    build_cliff_edges()
    polish_stats = {"imported_forest_trees":forest_roots.size(),"forest_batches":forest_batches.size(),"removed_cloud_lobes":replaced_clouds,"edge_instances":edge_bounds.size(),"new_textures":0,"supported_root_relocations":supported_relocations}
    update_lod()

func hill(at: Vector3,scale_value: Vector3,green: String) -> void:
    if polish_enabled:
        var kind := "terrace" if scale_value.y<3 else "blob"
        if not support_faces.has(kind): support_faces[kind] = primitive(kind).get_faces()
        supports.append({"at":at,"scale":Vector3(scale_value.x*.98,scale_value.y,scale_value.z*.98),"kind":kind})
    super.hill(at,scale_value,green)

func terrain_height(at: Vector3) -> float:
    var best := -INF
    for surface in supports:
        var local: Vector3 = (at-surface.at)/surface.scale
        if absf(local.x)>1.05 or absf(local.z)>1.05: continue
        var vertices: PackedVector3Array = support_faces[surface.kind]
        for i in range(0,vertices.size(),3):
            var hit: Variant = Geometry3D.segment_intersects_triangle(Vector3(local.x,2,local.z),Vector3(local.x,-2,local.z),vertices[i],vertices[i+1],vertices[i+2])
            if hit!=null: best = maxf(best,surface.at.y+hit.y*surface.scale.y)
    return best

func grounded_root(at: Vector3) -> Vector3:
    var best := terrain_height(at)
    if is_finite(best): at.y = best-.025 # Slightly bury the trunk's lowest vertex.
    return at

func small_tree(at: Vector3,height: float,variant: int) -> void:
    if not polish_enabled:
        super.small_tree(at,height,variant)
        return
    at = grounded_root(at)
    if upgrade_enabled and in_garden(at,2.2):
        super.small_tree(at,height,variant)
        return
    # Break the old six-column forest bands into loose deterministic clusters.
    # Reuse no course RNG; retain the old location if the offset leaves land.
    var clustered := at+Vector3(sin(at.z*.43+variant*1.71)*.9,0,cos(at.x*.31+variant*1.39)*1.1)
    if is_finite(terrain_height(clustered)): at=grounded_root(clustered)
    height *= .94+.10*sin(variant*2.1+at.x*.27)
    var name := "CommonTree_4" if variant%3==0 else "CommonTree_3"
    var data: Dictionary = source(name)
    var scale_value: float = height/data.bounds.size.y
    var yaw := variant*1.713+at.z*.17
    var pose: Transform3D = Transform3D(Basis(Vector3.UP,yaw).scaled(Vector3.ONE*scale_value),at-Vector3.UP*data.bounds.position.y*scale_value)
    var key := name+":"+str(floori(at.z/30.0))
    if not forest.has(key): forest[key] = {"name":name,"poses":[]}
    forest[key].poses.append(pose*data.local)
    forest_bounds.append(pose*data.bounds)
    forest_roots.append({"root":at,"name":name,"height":height,"key":key,"index":forest[key].poses.size()-1})

func place(kind: String,at: Vector3,size: Vector3,color: String,angles:=Vector3.ZERO) -> void:
    if polish_enabled and kind=="cloud":
        replaced_clouds += 1
        return # Replace opaque white lobes with the continuous layered sky.
    super.place(kind,at,size,color,angles)

func forest_mesh(name: String) -> Mesh:
    if not forest_meshes.has(name):
        var data: Dictionary = source(name)
        var mesh := data.mesh.duplicate() as ArrayMesh
        var leaf := mesh.surface_get_material(1).duplicate() as StandardMaterial3D
        leaf.diffuse_mode = BaseMaterial3D.DIFFUSE_LAMBERT_WRAP
        leaf.backlight_enabled = true
        leaf.backlight = Color(.12,.17,.065)
        leaf.roughness = .88
        mesh.surface_set_material(1,leaf)
        forest_meshes[name] = mesh
    return forest_meshes[name]

func flush_forest() -> void:
    # Later hills may overlap earlier ones. Resolve roots only after the complete
    # decorative landscape exists, then move each original imported mesh once.
    for i in range(forest_roots.size()):
        var entry: Dictionary = forest_roots[i]
        var final_root := grounded_root(entry.root)
        if not is_finite(terrain_height(final_root)):
            # Two old forest-band corners fall outside the actual irregular
            # hill mesh. Move only those decorative roots inward onto land.
            var nearest := Vector3.ZERO
            var nearest_distance := INF
            for surface in supports:
                var centre := Vector3(surface.at.x,entry.root.y,surface.at.z)
                var distance: float = entry.root.distance_squared_to(centre)
                if distance<nearest_distance:
                    nearest_distance=distance;nearest=centre
            for fraction in [.04,.08,.16,.32,1.0]:
                var candidate: Vector3 = entry.root.lerp(nearest,fraction)
                if is_finite(terrain_height(candidate)):
                    final_root=grounded_root(candidate)
                    supported_relocations+=1
                    break
        var shift: Vector3 = final_root-entry.root
        var poses: Array = forest[entry.key].poses
        var pose: Transform3D = poses[entry.index]
        pose.origin += shift
        poses[entry.index] = pose
        entry.root = final_root
        forest_bounds[i].position += shift
    for key in forest:
        var data: Dictionary = forest[key]
        var mm := MultiMesh.new()
        mm.transform_format = MultiMesh.TRANSFORM_3D
        mm.mesh = forest_mesh(data.name)
        mm.instance_count = data.poses.size()
        for i in range(mm.instance_count): mm.set_instance_transform(i,data.poses[i])
        var node := MultiMeshInstance3D.new()
        node.name = "ImportedForest_"+key.replace(":","_")
        node.multimesh = mm
        node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        node.visibility_range_end = 185
        node.lod_bias = .65
        add_child(node)
        forest_batches.append(node)

func skirt(at: Vector3,size: Vector3) -> void:
    var first := get_child_count()
    super.skirt(at,size)
    if polish_enabled and is_zero_approx(at.z):
        for i in range(first,get_child_count()):
            if get_child(i) is MeshInstance3D: entrance_cliff=get_child(i)

func grow_grass(at: Vector3,size: Vector3,index: int) -> void:
    var first := grass_cells.size()
    super.grow_grass(at,size,index)
    if not polish_enabled or not is_zero_approx(at.z): return
    for i in range(first,grass_cells.size()):
        grass_cells[i].node.multimesh.mesh = tuft_mesh
        grass_cells[i].node.material_override = soft_grass

func make_tuft() -> ArrayMesh:
    # Five rounded, curved leaf strips: 30 triangles per reused tuft. Existing
    # scattered instance roots/density and the actual floor are left untouched.
    var tool := SurfaceTool.new()
    tool.begin(Mesh.PRIMITIVE_TRIANGLES)
    for blade in range(5):
        var angle := blade*2.399963
        var direction := Vector3(cos(angle),0,sin(angle))
        var side := Vector3(-direction.z,0,direction.x)
        var height := .12+float(blade%3)*.026
        for segment in range(3):
            var vertices: Array[Vector3] = []
            var uvs: Array[Vector2] = []
            for pair in [Vector2(0,segment),Vector2(1,segment),Vector2(1,segment+1),Vector2(0,segment+1)]:
                var t: float = pair.y/3.0
                var width: float = .075*sqrt(maxf(0.0,1.0-t*t))
                vertices.append(direction*(.025+t*t*.12)+Vector3.UP*(t*height)+side*(pair.x-.5)*width)
                uvs.append(Vector2(pair.x,t))
            for i in [0,1,2,0,2,3]:
                tool.set_normal(Vector3.UP)
                tool.set_uv(uvs[i])
                tool.add_vertex(vertices[i])
    return tool.commit()

func edge_piece(name: String,at: Vector3,size: float,yaw: float) -> void:
    var data: Dictionary = source(name)
    var pose: Transform3D = Transform3D(Basis(Vector3.UP,yaw).scaled(Vector3.ONE*size),at)*data.local
    if not edge_poses.has(name): edge_poses[name] = []
    edge_poses[name].append(pose)
    edge_bounds.append(pose*data.mesh.get_aabb())

func build_cliff_edges() -> void:
    # Only the first island's long sides. Tops stay below the true floor, and
    # neither end gap is bridged by decorative stones or a false grass ledge.
    var rock: Dictionary = source("Rock_Medium_3")
    for side in [-1,1]:
        for i in range(10):
            var z := -7.1+i*1.55
            var size := .29+float(i%3)*.035
            edge_piece("Rock_Medium_3",Vector3(side*5.1,-.12-rock.bounds.end.y*size,z),size,side*.6+i*.73)
            if i%2==0:
                edge_piece("Rock_Medium_3",Vector3(side*5.25,-1.15-rock.bounds.end.y*size,z+.3),size*.95,i*.93)
                edge_piece("Plant_1",Vector3(side*4.88,-.07,z),.24+i*.007,i*.97)
    # Expose imported cliff strata on the two end faces as well. The highest
    # rock vertex remains 12cm below the unchanged walking plane.
    for end in [-1,1]:
        for i in range(8):
            var size := .28+float(i%3)*.025
            edge_piece("Rock_Medium_3",Vector3(-4.15+i*1.18,-.12-rock.bounds.end.y*size,end*9.02),size,i*.67)
    for name in edge_poses:
        var data: Dictionary = source(name)
        var mesh := data.mesh.duplicate() as ArrayMesh
        if name=="Rock_Medium_3":
            var material := mesh.surface_get_material(0).duplicate() as StandardMaterial3D
            material.roughness = .94
            material.metallic_specular = .18
            mesh.surface_set_material(0,material)
        var mm := MultiMesh.new()
        mm.transform_format = MultiMesh.TRANSFORM_3D
        mm.mesh = mesh
        mm.instance_count = edge_poses[name].size()
        for i in range(mm.instance_count): mm.set_instance_transform(i,edge_poses[name][i])
        var node := MultiMeshInstance3D.new()
        node.name = "PolishedEdge_"+name
        node.multimesh = mm
        if name=="Plant_1": node.material_override = plant_material
        node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        node.visibility_range_end = 42
        add_child(node)
        edge_nodes.append(node)

func configure_lighting(world: WorldEnvironment,sun: DirectionalLight3D) -> void:
    super.configure_lighting(world,sun)
    if not polish_enabled: return
    world.environment.ambient_light_color = Color("c5dbee").srgb_to_linear()
    world.environment.ambient_light_energy = .48
    world.environment.tonemap_exposure = .94
    world.environment.fog_light_color = Color("c5dfef").srgb_to_linear()
    world.environment.fog_density = .0015
    world.environment.fog_sky_affect = .025
    sun.light_color = Color("fff0d8").srgb_to_linear()
    sun.light_energy = 1.10
    sun.shadow_blur = 1.8
    sky_material.shader = load("res://shaders/garden_polish/sky.gdshader")
    sky_material.set_shader_parameter("noise_map",texture_asset("cloud_noise"))
    sky_material.set_shader_parameter("sun_direction",sun.global_basis.z.normalized())
    # No SSAO/glow: unsupported by this project's Compatibility renderer.

func update_lod() -> void:
    super.update_lod()
    if not polish_enabled: return
    for node in forest_batches:
        node.visibility_range_end = 135 if quality==0 else 185
        node.lod_bias = .4 if quality==0 else .65
    for node in edge_nodes: node.visibility_range_end = 28 if quality==0 else 42

func _process(delta: float) -> void:
    super._process(delta)
    if polish_enabled and is_instance_valid(game.runner):
        soft_grass.set_shader_parameter("avatar_position",game.runner.global_position)
