extends Control
signal jump_pressed
signal restart_pressed
signal pause_pressed
signal next_pressed
signal selection_pressed
signal resume_pressed
@export var jump_anchor := Vector2(0.83, 0.85)
@export_range(0.8, 1.3) var control_scale := 1.0
var buttons: Dictionary = {}
var fingers: Dictionary = {}
@export_range(0.0, 40.0) var drag_dead_zone := 8.0
@export_range(24.0, 240.0) var max_drag_distance := 96.0
@export_range(0.25, 3.0) var drag_sensitivity := 1.0
var movement_finger := -999
var drag_origin := Vector2.ZERO
var drag_vector := Vector2.ZERO
var movement_area := Rect2()
var gesture_scale := 1.0
var layout_size := Vector2.ZERO
var touch_blockers: Array[Control] = []
var jump_center := Vector2.ZERO
var jump_radius := 74.0
var safe_rect := Rect2()
var gameplay_enabled := true
var accept_gameplay_input := true
var modal_open := false
var enabled := true
var jump_pulse := 0.0
var injected_safe_rect := Rect2() # For automated safe-area tests.

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    resized.connect(update_layout)
    update_layout()

func register_button(action: String, button: Button) -> void:
    buttons[action] = button
    button.mouse_filter = Control.MOUSE_FILTER_IGNORE
    button.focus_mode = Control.FOCUS_NONE

func update_layout() -> void:
    # The full-rect Control is briefly zero-sized while entering the tree.
    # Wait for its existing resized callback before intersecting safe areas.
    if size.x <= 48.0 or size.y <= 48.0: return
    safe_rect = Rect2(Vector2.ZERO, size).grow(-24.0)
    if injected_safe_rect.has_area():
        safe_rect = injected_safe_rect
    elif DisplayServer.get_name() != "headless":
        var safe_pixels := DisplayServer.get_display_safe_area()
        if safe_pixels.has_area():
            # Display pixels -> window coordinates -> stretched canvas units.
            var screen_to_canvas := get_viewport().get_screen_transform().affine_inverse()
            var logical := screen_to_canvas * Rect2(safe_pixels)
            safe_rect = safe_rect.intersection(logical.grow(-16.0))
    jump_radius = 74.0 * control_scale
    jump_center = safe_rect.position + safe_rect.size * jump_anchor
    jump_center.x = clampf(jump_center.x, safe_rect.position.x + jump_radius, safe_rect.end.x - jump_radius)
    jump_center.y = clampf(jump_center.y, safe_rect.position.y + jump_radius, safe_rect.end.y - jump_radius)
    # Reference canvas units, scaled by the usable short dimension rather than
    # raw hardware pixels. A resize cancels old-coordinate gesture ownership.
    if layout_size != Vector2.ZERO and layout_size != size: clear_input()
    layout_size = size
    gesture_scale = maxf(0.1, minf(size.x, size.y) / 720.0)
    movement_area = Rect2(safe_rect.position+Vector2(0,240), Vector2(safe_rect.size.x,maxf(0,safe_rect.size.y-240)))
    queue_redraw()

func register_touch_blocker(control: Control) -> void:
    touch_blockers.append(control)

func clear_input() -> void:
    fingers.clear()
    movement_finger = -999
    drag_origin = Vector2.ZERO
    drag_vector = Vector2.ZERO
    queue_redraw()

func movement() -> Vector2:
    if not gameplay_enabled or not enabled or not accept_gameplay_input or modal_open:
        return Vector2.ZERO
    return drag_vector

func _update_drag(point: Vector2) -> void:
    if not point.is_finite():
        drag_vector = Vector2.ZERO
        return
    var shift := (point-drag_origin) * drag_sensitivity / gesture_scale
    var length := shift.length()
    var dead := maxf(0,drag_dead_zone)
    var full := maxf(dead+1,max_drag_distance)
    drag_vector = shift.normalized()*clampf((length-dead)/(full-dead),0,1) if length > dead else Vector2.ZERO

func _press(index: int, point: Vector2) -> void:
    if not enabled or fingers.has(index):
        return
    for action in buttons:
        var button: Button = buttons[action]
        if modal_open and action == "pause":
            continue
        if button.is_visible_in_tree() and button.get_global_rect().has_point(point):
            fingers[index] = action
            match action:
                "restart": restart_pressed.emit()
                "pause": pause_pressed.emit()
                "resume": resume_pressed.emit()
                "next": next_pressed.emit()
                "selection": selection_pressed.emit()
            return
    if not gameplay_enabled or not accept_gameplay_input or modal_open:
        return
    if point.distance_to(jump_center) <= jump_radius:
        fingers[index] = "jump"
        jump_pulse = 1.0
        jump_pressed.emit()
        queue_redraw()
    else:
        for control in touch_blockers:
            if is_instance_valid(control) and control.is_visible_in_tree() and control.get_global_rect().has_point(point):
                fingers[index] = "ui"
                return
        if movement_finger == -999 and movement_area.has_point(point):
            movement_finger = index
            fingers[index] = "movement"
            drag_origin = point
            drag_vector = Vector2.ZERO # A touch alone is never movement.
        else:
            fingers[index] = "ignored"

func _release(index: int) -> void:
    fingers.erase(index)
    if index == movement_finger:
        movement_finger = -999
        drag_origin = Vector2.ZERO
        drag_vector = Vector2.ZERO
    queue_redraw()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and not event.canceled:
            _press(event.index, event.position)
        else:
            _release(event.index)
    elif event is InputEventScreenDrag and event.index == movement_finger:
        _update_drag(event.position)
    elif event is InputEventMouseButton and event.device != InputEvent.DEVICE_ID_EMULATION and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            _press(-1, event.position)
        else:
            _release(-1)
    elif event is InputEventMouseMotion and movement_finger == -1 and event.device != InputEvent.DEVICE_ID_EMULATION:
        _update_drag(event.position)

func _process(delta: float) -> void:
    if jump_pulse > 0.0:
        jump_pulse = maxf(0.0, jump_pulse - delta * 5.0)
        queue_redraw()

func _draw() -> void:
    if not gameplay_enabled:
        return
    var radius := jump_radius * (1.0 - jump_pulse * 0.045)
    draw_circle(jump_center + Vector2(0, 6), radius, Color(0.05, 0.13, 0.2, 0.25), true, -1.0, true)
    draw_circle(jump_center, radius, Color("ffdc85") if jump_pulse > 0.0 else Color("ffc35b"), true, -1.0, true)
    draw_arc(jump_center, radius - 5, 0, TAU, 48, Color(1, 1, 1, 0.6), 2.0, true)
    var font := ThemeDB.fallback_font
    var text_width := font.get_string_size("JUMP", HORIZONTAL_ALIGNMENT_LEFT, -1, 25).x
    draw_string(font, jump_center + Vector2(-text_width * 0.5, 9), "JUMP", HORIZONTAL_ALIGNMENT_LEFT, -1, 25, Color("173549"))

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        clear_input()

func _unhandled_key_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.physical_keycode in [KEY_ESCAPE, KEY_P]:
            if not modal_open:
                pause_pressed.emit()
            else:
                resume_pressed.emit()
            get_viewport().set_input_as_handled()
        elif event.physical_keycode == KEY_R:
            if enabled:
                restart_pressed.emit()
            get_viewport().set_input_as_handled()
        elif event.is_action_pressed("ui_accept") and enabled and accept_gameplay_input and not modal_open:
            jump_pressed.emit()
            get_viewport().set_input_as_handled()
