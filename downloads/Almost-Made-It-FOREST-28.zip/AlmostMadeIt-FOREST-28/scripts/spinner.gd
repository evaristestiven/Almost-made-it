extends AnimatableBody3D
signal contact(body: Node3D)
@export var spin_speed := 2.0
var delivered: Dictionary = {}
# Compatibility diagnostics; neither flag changes solid collision.
var monitoring := true
var monitorable := true
var contact_point := Vector3.ZERO
var contact_normal := Vector3.ZERO
var contact_velocity := Vector3.ZERO
var target: CharacterBody3D
var colliders: Array[CollisionShape3D] = []
var query: PhysicsShapeQueryParameters3D
var contact_this_tick := false
var contact_source := ""
var last_any_contact_frame := -100
var sweep_radius := 0.0
var half_height := 0.0
const SWEEP_STEP := 0.20
const MAX_SWEEP_SAMPLES := 128
var collision_logging := false
var visible_diagnostics := false
var diagnostic_contact_count := 0
var diagnostic_native_entries := 0
var diagnostic_queries_last := 0
var diagnostic_scan_frame := 0
var diagnostic_last_contact_frame := 0
var diagnostic_scan_reason := "not_scanned"

func enable_visible_diagnostics() -> void:
    visible_diagnostics = true

func collision_log(stage: String, body: Node3D) -> void:
    if not collision_logging:
        return
    print("COLLISION_TRACE ",JSON.stringify({"stage": stage, "frame": Engine.get_physics_frames(),
        "obstacle": str(get_path()), "instance_id": get_instance_id(), "script": get_script().resource_path,
        "body": str(body.get_path()), "body_id": body.get_instance_id(), "source": contact_source,
        "angle": rotation.y, "layer": collision_layer, "mask": collision_mask,
        "monitoring": monitoring, "monitorable": monitorable}))

func _ready() -> void:
    process_physics_priority = -2
    sync_to_physics = true
    # Moving solid body: transform updates occur only in fixed physics steps.
    # Exact geometry sweeps supplement native CharacterBody sliding contacts.

func track_body(body: CharacterBody3D) -> void:
    target = body
    colliders.clear()
    for child in get_children():
        if child is CollisionShape3D:
            colliders.append(child)
            if child.shape is BoxShape3D:
                sweep_radius = maxf(sweep_radius, Vector2(child.shape.size.x,child.shape.size.z).length() * 0.5)
                half_height = maxf(half_height,child.shape.size.y * 0.5)
            elif child.shape is CylinderShape3D:
                sweep_radius = maxf(sweep_radius,child.shape.radius)
                half_height = maxf(half_height,child.shape.height * 0.5)
    query = PhysicsShapeQueryParameters3D.new()
    query.collision_mask = collision_mask
    query.margin = 0.015

func has_contact(body: Node3D) -> bool:
    return monitoring and body == target and contact_this_tick

func mark_hit(body: Node3D) -> void:
    delivered[body.get_instance_id()] = true

func _physics_process(delta: float) -> void:
    var was_contact := contact_this_tick
    if visible_diagnostics:
        diagnostic_queries_last = 0
        diagnostic_scan_frame = Engine.get_physics_frames()
        diagnostic_scan_reason = "scanning"
    var previous := global_transform
    var turn := spin_speed * delta if is_finite(spin_speed) else 0.0
    sweep_solid_motion(previous, turn)
    rotate_y(turn)
    contact_this_tick = false
    contact_source = ""
    # Contacts ignored during protection remain pending. Once accepted, that
    # same continuous contact cannot hit again until the body actually exits.
    if not monitoring or not is_instance_valid(target) or query == null or (target.collision_layer & collision_mask) == 0:
        if visible_diagnostics:
            if not monitoring: diagnostic_scan_reason = "monitoring_off"
            elif not is_instance_valid(target): diagnostic_scan_reason = "missing_player"
            elif query == null: diagnostic_scan_reason = "query_not_configured"
            else: diagnostic_scan_reason = "player_layer_not_in_mask"
        release_if_separated()
        return
    var before: Vector3 = target.physics_start_position
    var after := target.global_position
    var reach: float = sweep_radius + target.BODY_RADIUS
    # Broad phase only culls; it never awards a hit using an enlarged radius.
    if minf(before.y,after.y) > global_position.y + half_height or maxf(before.y,after.y) + target.BODY_HEIGHT < global_position.y - half_height:
        if visible_diagnostics: diagnostic_scan_reason = "vertical_clearance"
        release_if_separated()
        return
    var flat_before := Vector2(before.x-global_position.x,before.z-global_position.z)
    var flat_after := Vector2(after.x-global_position.x,after.z-global_position.z)
    var travel := flat_after-flat_before
    var t := clampf(-flat_before.dot(travel)/travel.length_squared(),0,1) if travel.length_squared() > 0.00001 else 0.0
    if (flat_before + travel * t).length() > reach:
        if visible_diagnostics: diagnostic_scan_reason = "outside_sweep_radius"
        release_if_separated()
        return
    var samples := clampi(ceili((absf(turn)*sweep_radius + before.distance_to(after))/SWEEP_STEP),1,MAX_SWEEP_SAMPLES)
    var space := get_world_3d().direct_space_state
    query.collision_mask = collision_mask
    for i in range(samples,-1,-1):
        var fraction := float(i)/samples
        var pose := previous
        # Use the full signed angular motion, not quaternion shortest-path
        # interpolation (which loses half/full revolutions at stress speeds).
        pose.basis = previous.basis * Basis(Vector3.UP,turn*fraction)
        # Relative-motion query: translate the sampled bar by the difference
        # between current and sampled player positions. Query the real capsule
        # at its current server pose without ever teleporting/scaling that body.
        pose.origin += after-before.lerp(after,fraction)
        for collider in colliders:
            if collider.disabled:
                continue
            query.shape = collider.shape
            query.transform = pose * collider.transform
            if visible_diagnostics: diagnostic_queries_last += 1
            for result in space.intersect_shape(query,8):
                if result.collider == target:
                    measure_contact(pose, collider)
                    contact_this_tick = true
                    contact_source = "current" if i == samples else "swept"
                    break
            if contact_this_tick:
                break
        if contact_this_tick:
            break
    if contact_this_tick:
        last_any_contact_frame = Engine.get_physics_frames()
    if visible_diagnostics:
        diagnostic_scan_reason = "CONTACT_" + contact_source if contact_this_tick else "query_clear"
        if contact_this_tick:
            diagnostic_last_contact_frame = Engine.get_physics_frames()
            if not was_contact: diagnostic_contact_count += 1
    if not contact_this_tick:
        release_if_separated()
    elif not delivered.has(target.get_instance_id()):
        collision_log("obstacle_contact_detected",target)
        contact.emit(target)

func measure_contact(pose: Transform3D, collider: CollisionShape3D) -> void:
    # Nearest point on the exact bar box to the capsule's vertical axis.
    var center: Vector3 = target.global_position
    center.y = clampf(pose.origin.y, target.global_position.y + target.BODY_RADIUS, target.global_position.y + target.BODY_HEIGHT - target.BODY_RADIUS)
    var local: Vector3 = pose.affine_inverse() * center
    var extent := Vector3(sweep_radius, half_height, 0.275)
    if collider.shape is BoxShape3D:
        extent = collider.shape.size * 0.5
    else:
        extent = Vector3(0.36, 0.29, 0.36)
    var closest: Vector3 = local.clamp(-extent, extent)
    if collider.shape is CylinderShape3D:
        var flat := Vector2(local.x, local.z).limit_length(collider.shape.radius)
        closest.x = flat.x
        closest.z = flat.y
    var normal: Vector3 = local - closest
    if normal.length_squared() < 0.000001:
        var gap: Vector3 = extent - local.abs()
        var axis: int = gap.min_axis_index()
        normal[axis] = 1.0 if local[axis] >= 0 else -1.0
        closest[axis] = extent[axis] * normal[axis]
    contact_point = pose * closest
    contact_normal = (pose.basis * normal).normalized()
    contact_velocity = Vector3.UP.cross(contact_point - global_position) * spin_speed

func report_solid_contact(point: Vector3, normal: Vector3) -> void:
    contact_point = point
    contact_normal = normal.normalized()
    contact_velocity = Vector3.UP.cross(point - global_position) * spin_speed
    if not contact_this_tick:
        diagnostic_contact_count += 1
    contact_this_tick = true
    last_any_contact_frame = Engine.get_physics_frames()
    contact_source = "solid_slide"
    diagnostic_native_entries += 1
    diagnostic_last_contact_frame = Engine.get_physics_frames()
    collision_log("solid_contact",target)
    if not delivered.has(target.get_instance_id()):
        contact.emit(target)

func sweep_solid_motion(previous: Transform3D, turn: float) -> void:
    if not is_instance_valid(target) or not target.running or target.collision_layer == 0:
        return
    var reach: float = sweep_radius + target.BODY_RADIUS + 0.05
    if Vector2(target.position.x-position.x,target.position.z-position.z).length() > reach:
        return
    # Angular conservative advancement, with tip travel below capsule radius.
    # Each accepted displacement uses CharacterBody3D's swept solid motion;
    # floor and walls stay active, including during spawn protection.
    var steps := clampi(ceili(absf(turn)*sweep_radius/0.15),1,MAX_SWEEP_SAMPLES)
    for step in range(1,steps+1):
        var pose := previous
        pose.basis = previous.basis * Basis(Vector3.UP,turn*float(step)/steps)
        for collider in colliders:
            if collider.disabled: continue
            var center: Vector3 = target.global_position
            center.y = clampf(pose.origin.y,center.y+target.BODY_RADIUS,center.y+target.BODY_HEIGHT-target.BODY_RADIUS)
            var local: Vector3 = pose.affine_inverse()*center
            var closest := Vector3.ZERO
            var inside_depth := 0.0
            if collider.shape is BoxShape3D:
                var extent: Vector3 = collider.shape.size*.5
                closest = local.clamp(-extent,extent)
                if local.is_equal_approx(closest):
                    var gap: Vector3 = extent-local.abs()
                    inside_depth = gap[gap.min_axis_index()]
            elif collider.shape is CylinderShape3D:
                var flat := Vector2(local.x,local.z).limit_length(collider.shape.radius)
                closest = Vector3(flat.x,clampf(local.y,-collider.shape.height*.5,collider.shape.height*.5),flat.y)
            var distance := local.distance_to(closest)
            if distance >= target.BODY_RADIUS: continue
            measure_contact(pose,collider)
            var depth: float = target.BODY_RADIUS-distance+inside_depth+0.002
            var motion := contact_normal*depth
            if not target.has_external_displacement:
                target.external_motion_start = target.global_position
                target.has_external_displacement = true
            target.move_and_collide(motion)

func release_if_separated() -> void:
    # Native sliding and proactive shape sweeps are sampled at different points
    # in the step. One missed snapshot must not rearm a sustained solid contact.
    if Engine.get_physics_frames()-last_any_contact_frame > 2:
        delivered.clear()
