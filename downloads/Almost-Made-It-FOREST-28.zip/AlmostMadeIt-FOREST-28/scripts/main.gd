extends Node3D
const CATALOG = preload("res://scripts/campaign/level_catalog.gd")
@export_range(1,10) var level_number := 1
var level_data: Dictionary
var campaign: Node
var elapsed_seconds := 0.0
var completed_seconds := 0.0
var finish_x := 0.0
var finish_z := -76.0
const PLAYER = preload("res://scripts/player.gd")
const TOUCH_CONTROLS = preload("res://scripts/touch_controls.gd")
const HUD = preload("res://scripts/components/game_hud.gd")
const CAMERA = preload("res://scripts/components/follow_camera.gd")
const FEEDBACK = preload("res://scripts/components/feedback.gd")
const COURSE_ART = preload("res://scripts/components/course_art.gd")
const ALMOST_MOMENTS = preload("res://scripts/components/almost_moments.gd")
var almost_moments: Node
var moment_obstacle_serial := 0
var moment_platform_serial := 0
const ROUTE = preload("res://scripts/components/route_progress.gd")
signal state_changed(previous: int, current: int)
signal level_completed(coins: int, falls: int)
enum RunState { READY, PLAYING, PAUSED, DYING, RESPAWNING, COMPLETED, TRANSITIONING }
@export var route_markers := PackedVector3Array([
    Vector3(0, 0, 5), Vector3(0, 0, -9), Vector3(0, 0, -15.5),
    Vector3(0, 0, -32.5), Vector3(0, 0, -37.5), Vector3(0, 0, -54.5),
    Vector3(0, 0, -58), Vector3(0, 0, -76)
])
var state: RunState = RunState.READY
var paused_state: RunState = RunState.READY
var won: bool:
    get: return state == RunState.COMPLETED or (state == RunState.PAUSED and paused_state == RunState.COMPLETED)
var respawning: bool:
    get: return state in [RunState.DYING, RunState.RESPAWNING] or (state == RunState.PAUSED and paused_state in [RunState.DYING, RunState.RESPAWNING])
var route = ROUTE.new()
var checkpoints: Array[Dictionary] = []
var checkpoint_index := -1
var completion_count := 0
var keyboard_armed := true
var background_suspended := false
var manually_paused := false
var completed_coins := 0
var completed_falls := 0
var spawn_query: PhysicsShapeQueryParameters3D
var ground_query: PhysicsRayQueryParameters3D
var finish_area: Area3D
var retry_overlaps := false
@export var gameplay_debug := false
var diagnostics: Node
@export var collision_logging := false
var mobile_collision_test := false
const START_Z := 5.0
var runner: CharacterBody3D
var camera: Camera3D
var spawn := Vector3(0, 0.08, START_Z)
var deaths := 0
var coins := 0
var controls: Control
var hud: Control
var feedback: Node3D
var materials: Dictionary = {}
var recovery_timer: Timer

func _ready() -> void:
    campaign = get_node_or_null("/root/Campaign")
    if campaign != null:
        campaign.transitioning = false
        if not campaign.can_start(level_number):
            state = RunState.TRANSITIONING
            campaign.open_selection()
            return
    level_data = CATALOG.get_level(level_number)
    route_markers = PackedVector3Array()
    for point in level_data.route: route_markers.append(Vector3(point.x,0,point.y))
    finish_x = level_data.finish.x
    finish_z = level_data.finish.y
    # Explicit development-package switch, default OFF in the normal project.
    # Do not depend on Xogot's editor/debug feature flags to show mobile proof.
    mobile_collision_test = bool(ProjectSettings.get_setting("debug/collision_test/enabled",false))
    collision_logging = (OS.is_debug_build() or OS.has_feature("editor")) and (collision_logging or "--collision-log" in OS.get_cmdline_user_args())
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(level_data.theme.sky)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("dcecf4")
    env.ambient_light_energy = 0.7
    world.environment = env
    add_child(world)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-45, -20, 0)
    sun.light_energy = 1.05
    sun.light_color = Color("fff1d6")
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 42.0
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
    add_child(sun)
    if not route.configure(route_markers):
        push_error("Course requires at least two distinct ordered route markers.")
        state = RunState.TRANSITIONING
        return
    _build_course()
    var scenery := Node3D.new()
    var nature_enabled := level_number == 1 and bool(ProjectSettings.get_setting("visuals/sky_garden/enabled",true))
    scenery.set_script(_scenery_script(nature_enabled))
    add_child(scenery)
    scenery.decorate(self)
    if nature_enabled: scenery.configure_lighting(world,sun)
    feedback = Node3D.new()
    feedback.set_script(FEEDBACK)
    add_child(feedback)
    runner = CharacterBody3D.new()
    runner.name = "Runner"
    runner.set_script(PLAYER)
    add_child(runner)
    runner.collision_logging = collision_logging
    # A new run is not a checkpoint recovery: no silent initial immunity.
    runner.reset_at(spawn, false)
    for hazard in get_tree().get_nodes_in_group("hazards"):
        hazard.collision_logging = collision_logging
        hazard.visible_diagnostics = mobile_collision_test or gameplay_debug
        hazard.track_body(runner)
    runner.fell.connect(_respawn)
    runner.moved.connect(_on_runner_moved)
    spawn_query = PhysicsShapeQueryParameters3D.new()
    spawn_query.shape = runner.get_child(0).shape
    spawn_query.collision_mask = 5 # Terrain 1 + hazards 4.
    spawn_query.collide_with_areas = true
    spawn_query.exclude = [runner.get_rid()]
    ground_query = PhysicsRayQueryParameters3D.new()
    ground_query.collision_mask = 1
    ground_query.exclude = [runner.get_rid()]
    route.restore(spawn, 0.0, false)
    camera = Camera3D.new()
    camera.set_script(CAMERA)
    camera.current = true
    camera.fov = 67
    camera.position = runner.position + Vector3(0, 6, 12)
    add_child(camera)
    _build_hud()
    camera.setup(runner)
    recovery_timer = Timer.new()
    recovery_timer.one_shot = true
    recovery_timer.process_callback = Timer.TIMER_PROCESS_PHYSICS
    recovery_timer.timeout.connect(_complete_respawn)
    add_child(recovery_timer)
    runner.jumped.connect(func() -> void: feedback.play("jump", runner.global_position))
    runner.landed.connect(func(impact: float) -> void:
        feedback.play("landing", runner.global_position)
        if impact > 10.0:
            camera.impact(0.05)
    )
    runner.hit.connect(func() -> void:
        feedback.play("hit", runner.global_position)
        camera.impact(0.1)
    )
    almost_moments = Node.new()
    almost_moments.name = "AlmostMoments"
    almost_moments.set_script(ALMOST_MOMENTS)
    add_child(almost_moments)
    almost_moments.performance_bonus_enabled = bool(ProjectSettings.get_setting("gameplay/almost_moments/performance_bonus",false))
    almost_moments.setup(self)
    almost_moments.feedback_requested.connect(func(kind: String, words: String, at: Vector3) -> void:
        if state != RunState.PLAYING: return
        feedback.play(kind,at)
        # Keep checkpoint/protection notices visible; moment particles/audio can
        # still play. A clutch save has priority over an ordinary hit notice.
        if kind == "clutch" or hud.notified <= .25:
            hud.notify(words)
            hud.notified = .85
    )
    _sync_state()
    keyboard_armed = _keyboard_released()
    if collision_logging:
        log_collision_instances()
    if mobile_collision_test or (OS.is_debug_build() and (gameplay_debug or "--gameplay-debug" in OS.get_cmdline_user_args())):
        for hazard in get_tree().get_nodes_in_group("hazards"):
            hazard.enable_visible_diagnostics()
        diagnostics = Node.new()
        diagnostics.set_script(load("res://scripts/components/gameplay_debug.gd"))
        add_child(diagnostics)
        diagnostics.setup(self)

func _scenery_script(nature_enabled:bool) -> Script:
    return load("res://scripts/environment/garden_landscape.gd") if nature_enabled else COURSE_ART

func _physics_process(_delta: float) -> void:
    if state in [RunState.PLAYING,RunState.DYING,RunState.RESPAWNING]: elapsed_seconds += _delta
    if runner == null or controls == null:
        return
    if state in [RunState.READY, RunState.RESPAWNING] and runner.running and runner.collision_layer == 2 and runner.grace_left <= 0.0 and runner.is_on_floor():
        if state == RunState.READY or camera.is_recovery_ready():
            _set_state(RunState.PLAYING)
    if not keyboard_armed and _keyboard_released():
        keyboard_armed = true
    if state == RunState.PLAYING:
        var keyboard_vector := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down") if keyboard_armed else Vector2.ZERO
        # Joystick up is world -Z, matching the established fixed camera view.
        runner.move_input = (controls.movement() + keyboard_vector).limit_length(1.0)
    else:
        runner.move_input = Vector2.ZERO

func _process(_delta: float) -> void:
    if runner == null or hud == null:
        return
    hud.update_stats(coins, deaths, progress_percent())

func _on_runner_moved(before: Vector3, after: Vector3, delta: float) -> void:
    if state == RunState.PLAYING:
        route.observe(before, after, delta)
        if retry_overlaps:
            retry_overlaps = false
            # Only on state resumption, not every frame. A paused callback may
            # have been rejected while the physical overlap remains active.
            for i in range(checkpoints.size()):
                _activate_checkpoint(i, runner)
            for pickup in get_tree().get_nodes_in_group("coins"):
                _collect_coin(pickup, runner)
        _try_finish()
    elif state in [RunState.READY, RunState.RESPAWNING]:
        route.hold_position(after)

func progress_percent() -> int:
    return route.percent(won)

func _feedback(text: String) -> void:
    hud.notify(text)

func _snap_camera() -> void:
    camera.recover()

func _keyboard_released() -> bool:
    return not (Input.is_action_pressed("ui_left") or Input.is_action_pressed("ui_right") or Input.is_action_pressed("ui_up") or Input.is_action_pressed("ui_down"))

func _clear_input() -> void:
    controls.clear_input()
    runner.clear_input()
    keyboard_armed = false

func _sync_state() -> void:
    runner.accept_jump_input = state == RunState.PLAYING
    controls.accept_gameplay_input = state in [RunState.READY, RunState.PLAYING] and not background_suspended
    controls.enabled = state != RunState.TRANSITIONING and not background_suspended
    controls.modal_open = state in [RunState.PAUSED, RunState.COMPLETED]
    controls.queue_redraw()

func _set_state(next: RunState) -> void:
    if state == next:
        return
    var previous := state
    state = next
    if next == RunState.PLAYING:
        if previous == RunState.RESPAWNING:
            runner.finish_recovery()
            _feedback("BACK ON TRACK - BRIEFLY PROTECTED")
            hud.notified = runner.spawn_protection_left
        retry_overlaps = true
    if next != RunState.PLAYING:
        _clear_input()
    _sync_state()
    state_changed.emit(previous, next)

func set_paused(value: bool) -> void:
    if state in [RunState.COMPLETED, RunState.TRANSITIONING] or background_suspended:
        return
    if value:
        if state == RunState.PAUSED:
            return
        paused_state = state
        manually_paused = true
        _set_state(RunState.PAUSED)
        hud.show_pause()
        get_tree().paused = true
    elif state == RunState.PAUSED and manually_paused:
        manually_paused = false
        _set_state(paused_state)
        hud.hide_pause()
        get_tree().paused = false

func restart() -> void:
    if state == RunState.TRANSITIONING or background_suspended:
        return
    _set_state(RunState.TRANSITIONING)
    recovery_timer.stop()
    runner.stop()
    get_tree().paused = false
    get_tree().call_deferred("reload_current_scene")

func _notification(what: int) -> void:
    if not is_instance_valid(runner) or not is_instance_valid(controls):
        return
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        if state == RunState.TRANSITIONING:
            return
        background_suspended = true
        _clear_input()
        if state != RunState.PAUSED:
            paused_state = state
            _set_state(RunState.PAUSED)
        _sync_state()
        get_tree().paused = true
    elif what == NOTIFICATION_APPLICATION_FOCUS_IN and background_suspended:
        background_suspended = false
        if not manually_paused:
            _set_state(paused_state)
            get_tree().paused = false
        _sync_state()

func _can_play(body: Node3D) -> bool:
    return body == runner and state == RunState.PLAYING and not get_tree().paused and runner.running

func _can_interact(body: Node3D) -> bool:
    return _can_play(body) and route.position_valid and route.on_route and runner.global_position.distance_to(route.expected_position) <= 0.15

func _valid_area_entry(area: Area3D, body: Node3D, distance: float) -> bool:
    return _can_interact(body) and area.overlaps_body(body) and absf(route.current_distance - distance) <= 1.3

func _on_hazard_contact(hazard: AnimatableBody3D, body: Node3D) -> void:
    if almost_moments != null: almost_moments.note_contact(hazard,body)
    # Reward/route validation must never confer immunity to a real hazard.
    var accepted := false
    var called := false
    var reason := ""
    if body != runner: reason = "wrong_body"
    elif state != RunState.PLAYING: reason = "state_" + RunState.keys()[state]
    elif get_tree().paused: reason = "tree_paused"
    elif not runner.running: reason = "player_not_running"
    elif not hazard.has_contact(body): reason = "no_verified_geometry_contact"
    elif hazard.delivered.has(body.get_instance_id()): reason = "contact_already_delivered"
    else:
        called = true
        accepted = runner.apply_bar_impact(hazard)
        reason = runner.last_hit_rejection
    if collision_logging:
        print("COLLISION_TRACE ",JSON.stringify({"stage": "owner_hit_decision", "frame": Engine.get_physics_frames(),
            "obstacle": str(hazard.get_path()), "body": str(body.get_path()), "state": RunState.keys()[state],
            "hit_handler_called": called, "accepted": accepted, "reason": reason,
            "immunity": runner.invulnerable_left, "spawn_protection": runner.spawn_protection_left}))
    if diagnostics != null:
        diagnostics.record_contact(hazard, accepted, reason, called)
    if accepted:
        hazard.mark_hit(body)
        _feedback("WHOA! KEEP YOUR BALANCE!")

func log_collision_instances() -> void:
    print("COLLISION_TRACE ",JSON.stringify({"stage": "level_loaded", "scene": scene_file_path,
        "configured_main_scene": ProjectSettings.get_setting("application/run/main_scene"),
        "level": level_data.name, "engine": Engine.get_version_info().string,
        "player_script_sha256": FileAccess.get_sha256("res://scripts/player.gd"),
        "spinner_script_sha256": FileAccess.get_sha256("res://scripts/spinner.gd"),
        "main_script_sha256": FileAccess.get_sha256("res://scripts/main.gd")}))
    for hazard in get_tree().get_nodes_in_group("hazards"):
        var shapes: Array[Dictionary] = []
        for collider in hazard.colliders:
            var entry := {"path": str(collider.get_path()), "class": collider.shape.get_class(), "disabled": collider.disabled,
                "position": [collider.position.x,collider.position.y,collider.position.z], "parent": str(collider.get_parent().get_path())}
            if collider.shape is BoxShape3D:
                entry["size"] = [collider.shape.size.x,collider.shape.size.y,collider.shape.size.z]
                entry["matches_visible_bar"] = collider.shape.size == hazard.get_child(0).mesh.size and collider.global_transform == hazard.get_child(0).global_transform
            elif collider.shape is CylinderShape3D:
                entry["radius"] = collider.shape.radius
                entry["height"] = collider.shape.height
            shapes.append(entry)
        print("COLLISION_TRACE ",JSON.stringify({"stage": "obstacle_instance", "path": str(hazard.get_path()),
            "script": hazard.get_script().resource_path, "collision_body": hazard.get_class(), "shapes": shapes,
            "position": [hazard.position.x,hazard.position.y,hazard.position.z], "spin_speed": hazard.spin_speed,
            "layer": hazard.collision_layer, "mask": hazard.collision_mask, "monitoring": hazard.monitoring,
            "monitorable": hazard.monitorable, "contact_connections": hazard.get_signal_connection_list("contact").size(),
            "player_layer": runner.collision_layer, "player_mask": runner.collision_mask}))

func _mat(color: Color) -> StandardMaterial3D:
    if materials.has(color):
        return materials[color]
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.8
    materials[color] = m
    return m

func _mesh(size: Vector3, color: Color) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    node.mesh = box
    node.material_override = _mat(color)
    return node

func _platform(z: float, length: float, width: float, color: Color, x := 0.0, top := 0.0) -> void:
    var body := StaticBody3D.new()
    body.name = "Platform"
    moment_platform_serial += 1
    body.set_meta("moment_id","L%02d/P%03d" % [level_number,moment_platform_serial])
    body.add_to_group("platforms")
    body.position = Vector3(x, top - 0.55, z)
    body.collision_layer = 1
    body.collision_mask = 0
    add_child(body)
    var size := Vector3(width, 1.1, length)
    body.add_child(_mesh(size, color))
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = size
    shape.shape = box
    body.add_child(shape)
    var trim := _mesh(Vector3(width, 0.1, 0.25), Color("ffe07b"))
    trim.position = Vector3(0, 0.61, -length * 0.5 + 0.25)
    body.add_child(trim)

func _obstacle(definition: Dictionary) -> Node3D:
    var obstacle: Node3D = load("res://scenes/obstacles/%s.tscn" % definition.type).instantiate()
    moment_obstacle_serial += 1
    obstacle.set_meta("moment_id","L%02d/O%03d" % [level_number,moment_obstacle_serial])
    obstacle.position = definition.at
    for key in definition:
        if key not in ["type","at"]: obstacle.set(key,definition[key])
    add_child(obstacle)
    if obstacle.is_in_group("hazards"):
        obstacle.contact.connect(func(body: Node3D) -> void: _on_hazard_contact(obstacle,body))
    return obstacle

func _checkpoint(z: float, x := 0.0, width := 7.0) -> void:
    var area := Area3D.new()
    area.name = "Checkpoint"
    area.add_to_group("checkpoints")
    area.position = Vector3(x, 0.9, z)
    area.collision_layer = 0
    area.collision_mask = 2
    add_child(area)
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(width, 2, 0.8)
    shape.shape = box
    area.add_child(shape)
    var marker := _mesh(Vector3(width, 0.06, 0.5), Color("38edbd"))
    marker.position.y = -0.86
    area.add_child(marker)
    var index := checkpoints.size()
    var saved_spawn := Vector3(x, 0.08, z)
    var distance: float = route.distance_at(saved_spawn)
    checkpoints.append({"spawn": saved_spawn, "distance": distance, "area": area})
    area.body_entered.connect(func(body: Node3D) -> void: _activate_checkpoint(index, body))

func _activate_checkpoint(index: int, body: Node3D) -> void:
    var saved: Dictionary = checkpoints[index]
    if index <= checkpoint_index or not _valid_area_entry(saved.area, body, saved.distance) or route.last_forward_motion <= 0.0:
        return
    checkpoint_index = index
    spawn = saved.spawn
    route.furthest_distance = maxf(route.furthest_distance, saved.distance)
    _feedback("CHECKPOINT SAVED")
    feedback.play("checkpoint", saved.area.global_position)

func _coin(z: float, x: float, height := 1.25) -> void:
    var pickup := Area3D.new()
    pickup.name = "Coin"
    pickup.add_to_group("coins")
    pickup.position = Vector3(x, height, z)
    pickup.collision_layer = 0
    pickup.collision_mask = 2
    add_child(pickup)
    var ball := SphereMesh.new()
    ball.radius = 0.37
    ball.height = 0.74
    ball.radial_segments = 16
    ball.rings = 8
    var visual := MeshInstance3D.new()
    visual.mesh = ball
    visual.material_override = _mat(Color("ffdb54"))
    visual.scale = Vector3(1, 1, 0.35)
    pickup.add_child(visual)
    var collider := CollisionShape3D.new()
    var shape := SphereShape3D.new()
    shape.radius = 0.55
    collider.shape = shape
    pickup.add_child(collider)
    var distance: float = route.distance_at(pickup.global_position)
    pickup.set_meta("route_distance", distance)
    pickup.body_entered.connect(func(body: Node3D) -> void: _collect_coin(pickup, body))

func _collect_coin(pickup: Area3D, body: Node3D) -> void:
    if not _valid_area_entry(pickup, body, pickup.get_meta("route_distance", INF)) or pickup.get_meta("collected", false):
        return
    pickup.set_meta("collected", true)
    coins += 1
    _feedback("+1 COIN")
    feedback.play("coin", pickup.global_position)
    pickup.set_deferred("monitoring", false)
    pickup.call_deferred("queue_free")

func _finish() -> void:
    var finish := Area3D.new()
    finish.name = "Finish"
    finish.position = Vector3(finish_x, 1.2, finish_z)
    finish.collision_layer = 0
    finish.collision_mask = 2
    add_child(finish)
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(9, 3, 1.2)
    shape.shape = box
    finish.add_child(shape)
    var banner := _mesh(Vector3(9, 0.2, 0.6), Color("3ae7b1"))
    banner.position.y = 1.0
    finish.add_child(banner)
    finish_area = finish
    finish.body_entered.connect(func(body: Node3D) -> void:
        if body == runner:
            _try_finish()
    )

func _finish_supported() -> bool:
    if runner.is_on_floor():
        return true
    ground_query.from = runner.global_position + Vector3(0, 0.25, 0)
    ground_query.to = runner.global_position - Vector3(0, 4.0, 0)
    var ground := get_world_3d().direct_space_state.intersect_ray(ground_query)
    return not ground.is_empty() and ground.normal.dot(Vector3.UP) >= cos(runner.floor_max_angle)

func finish_status() -> String:
    # Shared by the actual win path and the optional development overlay.
    if state != RunState.PLAYING: return "state_"+RunState.keys()[state]
    if get_tree().paused or not runner.running: return "inactive_player"
    if not route.position_valid or not route.on_route: return "invalid_route"
    if runner.global_position.distance_to(route.expected_position) > .15: return "untracked_motion"
    if not finish_area.monitoring or not finish_area.overlaps_body(runner): return "outside"
    if absf(route.current_distance-route.total_length) > 1.3: return "route_incomplete"
    if route.last_forward_motion <= 0: return "not_forward_entry"
    if not _finish_supported(): return "unsupported"
    return "eligible"

func _try_finish() -> void:
    if finish_status() != "eligible":
        return
    _set_state(RunState.COMPLETED)
    runner.stop(true)
    completion_count += 1
    completed_coins = coins
    completed_falls = deaths
    hud.update_stats(coins, deaths, 100)
    feedback.play("win", runner.global_position)
    if level_number == 10:
        feedback.play("win",runner.global_position+Vector3(1.8,0,0))
        feedback.play("win",runner.global_position+Vector3(-1.8,0,0))
    completed_seconds = elapsed_seconds
    var saved := true
    if campaign != null: saved = campaign.record_completion(level_number,coins,completed_seconds)
    hud.show_win(coins,deaths)
    if not saved: hud.detail.text += "\nProgress not saved - check storage"
    level_completed.emit(completed_coins, completed_falls)

func _build_course() -> void:
    var colors := [Color(level_data.theme.top),Color(level_data.theme.side)]
    for i in range(level_data.platforms.size()):
        var platform: Array = level_data.platforms[i]
        _platform(platform[1],platform[2],platform[3],colors[i%colors.size()],platform[0])
    for p in level_data.extensions:
        _platform(p[1],p[2],p[3],Color(level_data.theme.accent),p[0],p[4])
    for definition in level_data.obstacles: _obstacle(definition)
    for point in level_data.checkpoints: _checkpoint(point.y,point.x)
    for i in range(level_data.coins.size()):
        var point: Vector2 = level_data.coins[i]
        _coin(point.y,point.x,level_data.coin_heights[i])
    _finish()

func _respawn() -> void:
    # The same entry point can be used by future lethal hazards.
    if state != RunState.PLAYING:
        return
    deaths += 1
    for obstacle in get_tree().get_nodes_in_group("recovery_reset"): obstacle.reset_after_death()
    _set_state(RunState.DYING)
    runner.stop()
    _feedback("ALMOST! LET'S TRY THAT AGAIN.")
    feedback.play("fail", runner.global_position)
    recovery_timer.start(0.55)

func _spawn_safe(point: Vector3) -> bool:
    if not point.is_finite():
        return false
    spawn_query.transform = Transform3D(Basis.IDENTITY, point + Vector3(0, runner.BODY_HEIGHT * 0.5, 0))
    if not get_world_3d().direct_space_state.intersect_shape(spawn_query, 1).is_empty():
        return false
    ground_query.from = point + Vector3(0, 0.25, 0)
    ground_query.to = point - Vector3(0, 0.5, 0)
    var floor_hit := get_world_3d().direct_space_state.intersect_ray(ground_query)
    return not floor_hit.is_empty() and floor_hit.normal.dot(Vector3.UP) >= cos(runner.floor_max_angle)

func _complete_respawn() -> void:
    if state not in [RunState.DYING, RunState.RESPAWNING]:
        return
    var saved_distance := 0.0
    var safe_position := Vector3(0, 0.08, START_Z)
    var found := false
    for i in range(checkpoint_index, -2, -1):
        var candidate: Vector3 = checkpoints[i].spawn if i >= 0 else Vector3(0, 0.08, START_Z)
        if _spawn_safe(candidate):
            safe_position = candidate
            saved_distance = checkpoints[i].distance if i >= 0 else 0.0
            found = true
            break
    _set_state(RunState.RESPAWNING)
    if not found:
        _feedback("WAITING FOR A SAFE RESPAWN")
        recovery_timer.start(0.1)
        return
    runner.reset_at(safe_position)
    runner.recovery_hold = true
    route.restore(safe_position, saved_distance)
    _clear_input()
    _sync_state()
    _snap_camera()
    _feedback("BACK ON TRACK - BRIEFLY PROTECTED")
    hud.notified = runner.spawn_protection_left
    feedback.play("respawn", safe_position)

func _build_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    controls = Control.new()
    controls.set_script(TOUCH_CONTROLS)
    layer.add_child(controls)
    controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud = Control.new()
    hud.set_script(load("res://scripts/components/garden_hud.gd") if level_number == 1 else HUD)
    controls.add_child(hud)
    hud.build(controls)
    hud.configure_level(level_number,level_data.name)
    hud.next_button.pressed.connect(_next_level)
    hud.selection_button.pressed.connect(_level_selection)
    controls.jump_pressed.connect(func() -> void:
        if state == RunState.PLAYING and not get_tree().paused:
            runner.jump_requested = true
    )
    controls.restart_pressed.connect(restart)
    controls.pause_pressed.connect(func() -> void: set_paused(true))
    controls.resume_pressed.connect(func() -> void: set_paused(false))
    controls.next_pressed.connect(_next_level)
    controls.selection_pressed.connect(_level_selection)

func _next_level() -> void:
    if state != RunState.COMPLETED or level_number >= 10 or campaign == null: return
    if campaign.open_level(level_number+1):
        _set_state(RunState.TRANSITIONING)
        recovery_timer.stop()
        runner.stop()
    else: hud.notify(campaign.save_error)

func _level_selection() -> void:
    if state not in [RunState.COMPLETED,RunState.PAUSED] or campaign == null: return
    if campaign.open_selection():
        _set_state(RunState.TRANSITIONING)
        recovery_timer.stop()
        runner.stop()
    else: hud.notify(campaign.save_error)
