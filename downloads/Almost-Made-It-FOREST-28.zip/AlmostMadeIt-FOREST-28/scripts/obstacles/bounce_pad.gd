extends StaticBody3D
const G = preload("res://scripts/obstacles/geometry.gd")
@export var launch_speed := 20.0
@export var dimensions := Vector3(3,.24,2)
var sensor: Area3D
var cooldown := 0.0
func _ready() -> void:
    collision_layer = 1
    collision_mask = 0
    add_to_group("bounce_pads")
    G.box(self,dimensions,"ffc35b",true)
    var mark := G.box(self,Vector3(dimensions.x*.65,.02,.2),"fff1d6")
    mark.position.y = dimensions.y*.5+.015
    sensor = Area3D.new()
    sensor.collision_layer = 0
    sensor.collision_mask = 2
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(dimensions.x,.4,dimensions.z)
    shape.shape = box
    shape.position.y = dimensions.y*.5+.15
    sensor.add_child(shape)
    add_child(sensor)
func _physics_process(delta: float) -> void:
    cooldown = maxf(0,cooldown-delta)
    if cooldown > 0: return
    for body in sensor.get_overlapping_bodies():
        if body.has_method("launch_vertical") and body.running and not body.recovery_hold and body.accept_jump_input and body.is_on_floor() and body.velocity.y <= .1:
            if body.launch_vertical(launch_speed): cooldown = .3
