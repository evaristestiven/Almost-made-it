extends StaticBody3D
const G = preload("res://scripts/obstacles/geometry.gd")
@export var dimensions := Vector3(5,.5,12)
@export var surface_velocity := Vector3(0,0,2)
func _ready() -> void:
    collision_layer = 1
    collision_mask = 0
    constant_linear_velocity = surface_velocity
    add_to_group("conveyors")
    G.box(self,dimensions,"655781",true)
    for i in range(int(dimensions.z/1.5)):
        var marker := G.box(self,Vector3(dimensions.x*.8,.025,.16),"ffc35b")
        marker.position = Vector3(0,dimensions.y*.5+.02,-dimensions.z*.5+.8+i*1.5)
    var arrow := Label3D.new()
    arrow.text = "▼" if surface_velocity.z >= 0 else "▲"
    arrow.rotation_degrees.x = -90
    arrow.position.y = dimensions.y*.5+.04
    arrow.font_size = 64
    arrow.pixel_size = .012
    add_child(arrow)
