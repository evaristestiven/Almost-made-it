extends RefCounted
static var materials: Dictionary = {}
static func material(color: String) -> StandardMaterial3D:
    if not materials.has(color):
        var m := StandardMaterial3D.new()
        m.albedo_color = Color(color)
        m.roughness = .8
        materials[color] = m
    return materials[color]
static func box(parent: Node3D, size: Vector3, color: String, solid := false) -> MeshInstance3D:
    var visible := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    visible.mesh = mesh
    visible.material_override = material(color)
    parent.add_child(visible)
    if solid:
        var shape := CollisionShape3D.new()
        var collision := BoxShape3D.new()
        collision.size = size
        shape.shape = collision
        parent.add_child(shape)
    return visible
static func cylinder(parent: Node3D,radius: float,height: float,color: String,solid := false) -> MeshInstance3D:
    var visible := MeshInstance3D.new()
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = height
    mesh.radial_segments = 24
    visible.mesh = mesh
    visible.material_override = material(color)
    parent.add_child(visible)
    if solid:
        var shape := CollisionShape3D.new()
        var collision := CylinderShape3D.new()
        collision.radius = radius
        collision.height = height
        shape.shape = collision
        parent.add_child(shape)
    return visible
