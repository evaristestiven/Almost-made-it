extends AnimatableBody3D
const G = preload("res://scripts/obstacles/geometry.gd")
@export var dimensions := Vector3(4,.6,6)
@export var warning_time := 1.0
@export var fall_acceleration := 12.0
var origin := Vector3.ZERO
var elapsed := 0.0
var triggered := false
var fall_velocity := 0.0
var sensor: Area3D
var visible_mesh: MeshInstance3D
var warning_material: StandardMaterial3D
var collider: CollisionShape3D
func _ready() -> void:
    origin = position
    collision_layer = 1
    collision_mask = 0
    sync_to_physics = true
    process_physics_priority = -1
    add_to_group("collapsing_platforms")
    add_to_group("recovery_reset")
    visible_mesh = G.box(self,dimensions,"efbf75",true)
    warning_material = G.material("efbf75").duplicate()
    visible_mesh.material_override = warning_material
    collider = get_child(1)
    G.box(self,Vector3(dimensions.x-.3,.025,.18),"ff746d").position.y = dimensions.y*.5+.02
    sensor = Area3D.new()
    sensor.collision_layer = 0
    sensor.collision_mask = 2
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(dimensions.x,.35,dimensions.z)
    shape.shape = box
    shape.position.y = dimensions.y*.5+.14
    sensor.add_child(shape)
    add_child(sensor)
func _physics_process(delta: float) -> void:
    if not triggered:
        for body in sensor.get_overlapping_bodies():
            if body is CharacterBody3D and body.running and body.accept_jump_input and body.is_on_floor():
                triggered = true
                break
    else:
        elapsed += delta
        if elapsed < warning_time:
            warning_material.albedo_color = Color("efbf75").lerp(Color("ff746d"),.5+.5*sin(elapsed*24))
        else:
            warning_material.albedo_color = Color("ff746d")
            fall_velocity += fall_acceleration*delta
            position.y -= fall_velocity*delta
            if position.y < origin.y-8:
                collider.set_deferred("disabled",true)
                set_physics_process(false)
func reset_after_death() -> void:
    position = origin
    elapsed = 0
    triggered = false
    fall_velocity = 0
    collider.set_deferred("disabled",false)
    warning_material.albedo_color = Color("efbf75")
    set_physics_process(true)
