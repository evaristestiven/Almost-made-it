extends AnimatableBody3D
signal contact(body: Node3D)
const G = preload("res://scripts/obstacles/geometry.gd")
@export var radius := .7
@export var rope_length := 3.0
@export var period := 4.0
@export var amplitude := .75
@export var phase := 0.0
var pivot := Vector3.ZERO
var elapsed := 0.0
var target: CharacterBody3D
var rope: MeshInstance3D
var colliders: Array[CollisionShape3D] = []
var delivered: Dictionary = {}
var monitoring := true
var monitorable := true
var contact_this_tick := false
var contact_source := "pendulum_sweep"
var contact_point := Vector3.ZERO
var contact_normal := Vector3.ZERO
var contact_velocity := Vector3.ZERO
var spin_speed := 0.0
var collision_logging := false
var visible_diagnostics := false
var diagnostic_contact_count := 0
var diagnostic_native_entries := 0
var diagnostic_last_contact_frame := 0
var diagnostic_queries_last := 0
var diagnostic_scan_frame := 0
var diagnostic_scan_reason := "pendulum"
func enable_visible_diagnostics() -> void: visible_diagnostics = true
func center_at(angle: float) -> Vector3:
    return pivot+Vector3(sin(angle)*rope_length,-cos(angle)*rope_length,0)
func _ready() -> void:
    pivot = position
    collision_layer = 4
    collision_mask = 2
    process_physics_priority = -2
    add_to_group("hazards")
    add_to_group("swinging_balls")
    var visual := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius*2
    mesh.radial_segments = 20
    mesh.rings = 12
    visual.mesh = mesh
    visual.material_override = G.material("ff746d")
    add_child(visual)
    var collider := CollisionShape3D.new()
    var shape := SphereShape3D.new()
    shape.radius = radius
    collider.shape = shape
    add_child(collider)
    colliders.append(collider)
    rope = G.cylinder(self,.055,rope_length,"655781")
    rope.top_level = true
    var angle := amplitude*sin(phase)
    position = center_at(angle)
    rope.position = (pivot+position)*.5
    rope.rotation.z = angle
    sync_to_physics = true
func track_body(body: CharacterBody3D) -> void: target = body
func has_contact(body: Node3D) -> bool: return body == target and contact_this_tick
func mark_hit(body: Node3D) -> void: delivered[body.get_instance_id()] = true
func capsule_point(center: Vector3) -> Vector3:
    var p := target.global_position
    p.y = clampf(center.y,p.y+target.BODY_RADIUS,p.y+target.BODY_HEIGHT-target.BODY_RADIUS)
    return p
func _physics_process(delta: float) -> void:
    elapsed += delta
    var frequency := TAU/maxf(period,.5)
    var angle := amplitude*sin(elapsed*frequency+phase)
    spin_speed = amplitude*frequency*cos(elapsed*frequency+phase)
    var destination := center_at(angle)
    contact_velocity = Vector3(0,0,spin_speed).cross(destination-pivot)
    var start := position
    contact_this_tick = false
    if is_instance_valid(target) and target.collision_layer & 2:
        var samples := clampi(ceili(start.distance_to(destination)/.12),1,64)
        for index in range(1,samples+1):
            var center := start.lerp(destination,float(index)/samples)
            var nearest := capsule_point(center)
            var difference := nearest-center
            var distance := difference.length()
            if distance <= radius+target.BODY_RADIUS+.015:
                contact_this_tick = true
                contact_normal = difference.normalized() if distance > .001 else contact_velocity.normalized()
                if contact_normal == Vector3.ZERO: contact_normal = Vector3.RIGHT
                contact_point = center+contact_normal*radius
                var depth: float = radius+target.BODY_RADIUS-distance
                if depth > 0:
                    if not target.has_external_displacement:
                        target.external_motion_start = target.global_position
                        target.has_external_displacement = true
                    target.move_and_collide(contact_normal*depth)
        if contact_this_tick:
            diagnostic_contact_count += 1
            diagnostic_last_contact_frame = Engine.get_physics_frames()
            contact_source = "pendulum_sweep"
            contact.emit(target)
        elif capsule_point(destination).distance_to(destination) > radius+target.BODY_RADIUS+.04:
            delivered.clear()
    position = destination
    rope.position = (pivot+destination)*.5
    rope.rotation.z = angle
func report_solid_contact(point: Vector3, normal: Vector3) -> void:
    if not is_instance_valid(target): return
    diagnostic_native_entries += 1
    diagnostic_last_contact_frame = Engine.get_physics_frames()
    contact_this_tick = true
    contact_point = point
    contact_normal = normal
    contact_source = "solid_slide"
    contact.emit(target)
