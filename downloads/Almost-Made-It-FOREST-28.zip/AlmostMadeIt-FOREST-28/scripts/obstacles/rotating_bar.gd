extends "res://scripts/spinner.gd"
const G = preload("res://scripts/obstacles/geometry.gd")
@export var width := 5.9
func _ready() -> void:
    collision_layer = 4
    collision_mask = 2
    add_to_group("hazards")
    G.box(self,Vector3(width,.55,.55),"ff746d")
    for side in [-1,1]:
        G.box(self,Vector3(.28,.56,.56),"fff1d6").position.x = side*(width*.5-.17)
    G.cylinder(self,.36,.58,"173d57")
    var box_shape := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(width,.55,.55)
    box_shape.shape = shape
    add_child(box_shape)
    var hub := CollisionShape3D.new()
    var cylinder := CylinderShape3D.new()
    cylinder.radius = .36
    cylinder.height = .58
    hub.shape = cylinder
    add_child(hub)
    G.box(self,Vector3(.3,2,.3),"655781").position.y = -1
    super._ready()
