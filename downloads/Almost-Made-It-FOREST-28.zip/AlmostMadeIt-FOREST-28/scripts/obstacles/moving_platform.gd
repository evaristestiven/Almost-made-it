extends "res://scripts/components/moving_platform.gd"
const G = preload("res://scripts/obstacles/geometry.gd")
@export var dimensions := Vector3(3.5,.7,4)
func _ready() -> void:
    G.box(self,dimensions,"47c6b5",true)
    var stripe := G.box(self,Vector3(dimensions.x-.3,.03,.16),"dbfff0")
    stripe.position.y = dimensions.y*.5+.015
    super._ready()
