extends AnimatableBody3D
const G = preload("res://scripts/obstacles/geometry.gd")
@export var radius := 3.0
@export var angular_speed := 1.0
@export var thickness := .5
func _ready() -> void:
    collision_layer = 1
    collision_mask = 0
    sync_to_physics = true
    process_physics_priority = -1
    add_to_group("rotating_discs")
    G.cylinder(self,radius,thickness,"599ec8",true)
    for i in range(4):
        var mark := G.box(self,Vector3(radius*.65,.03,.12),"fff1d6")
        mark.position = Vector3(cos(i*PI*.5)*radius*.55,thickness*.5+.02,sin(i*PI*.5)*radius*.55)
        mark.rotation.y = -i*PI*.5
func _physics_process(delta: float) -> void:
    rotate_y(angular_speed*delta)
