extends CharacterBody3D
signal fell
signal jumped
signal landed(impact: float)
signal hit
signal moved(before: Vector3, after: Vector3, delta: float)
const VISUAL = preload("res://scripts/components/runner_visual.gd")
var move_input := Vector2.ZERO
var jump_requested := false
var running := true
var accept_jump_input := true
var settle_when_stopped := false
@export_range(0.1, 3.0) var hit_cooldown := 1.0
const BODY_HEIGHT := 1.35
const BODY_RADIUS := 0.43
const MOVE_SPEED := 9.8
const GRAVITY := 22.0
const JUMP_SPEED := 10.4
const JUMP_BUFFER := 0.12
const COYOTE_TIME := 0.10
const HIT_RECOVERY_TIME := 0.25
@export var effective_mass := 1.0
@export var obstacle_mass := 12.0
@export_range(0.0, 1.0) var restitution := 0.15
@export_range(0.0, 1.0) var impact_friction := 0.15
@export var maximum_impact_speed := 18.0
@export var ground_acceleration := 45.0
@export var air_acceleration := 45.0
@export var ground_drag := 10.0
@export var air_drag := 2.0
@export var recovery_duration := 0.25
@export_range(0.1, 5.0) var spawn_protection_duration := 1.3
# All playable landing surfaces in Skybound Sprint have top Y=0. Once the
# whole capsule is below them and descending, recovery by jumping is impossible.
@export var course_floor_height := 0.0
@export_range(0.1, 1.0) var fall_visibility_duration := 0.25
@export var maximum_fall_depth := 4.5
@export var horizontal_death_limit := 14.0
var fall_elapsed := 0.0
var recovery_hold := false
var control_velocity := Vector3.ZERO
var requested_velocity := Vector3.ZERO
var last_impulse := Vector3.ZERO
var last_relative := Vector3.ZERO
var last_normal := Vector3.ZERO
var last_contact_speed := 0.0
var last_obstacle := "none"
var last_impact_frame := 0
var last_impact_source := "none"
var impact_incoming := Vector3.ZERO
var impact_outgoing := Vector3.ZERO
var face: Node3D
var jump_buffer := 0.0
var coyote_left := 0.0
var grace_left := 0.0
var invulnerable_left := 0.0
var spawn_protection_left := 0.0
var physics_start_position := Vector3.ZERO
var has_external_displacement := false
var external_motion_start := Vector3.ZERO
var knockback := Vector3.ZERO
var hit_recovery_left := 0.0
var collision_logging := false
var last_hit_rejection := ""
var logged_motion_left := 0

func collision_log(stage: String, extra: Dictionary = {}) -> void:
    if not collision_logging:
        return
    var data := {"stage": stage, "frame": Engine.get_physics_frames(), "player": str(get_path()),
        "script": get_script().resource_path, "velocity": [velocity.x,velocity.y,velocity.z],
        "knockback": [knockback.x,knockback.y,knockback.z], "position": [global_position.x,global_position.y,global_position.z],
        "immunity": invulnerable_left, "spawn_protection": spawn_protection_left, "settling": grace_left,
        "hit_recovery": hit_recovery_left, "control": str(control_velocity),
        "requested": str(requested_velocity), "accepted_impact_frame": last_impact_frame}
    data.merge(extra,true)
    print("COLLISION_TRACE ",JSON.stringify(data))

func _ready() -> void:
    process_physics_priority = 1
    floor_snap_length = 0.25
    platform_floor_layers = 1 # Only terrain carries the runner; impacts handle bars.
    collision_layer = 2
    collision_mask = 5
    var collider := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = BODY_RADIUS
    capsule.height = BODY_HEIGHT
    collider.shape = capsule
    collider.position.y = BODY_HEIGHT * 0.5
    add_child(collider)
    platform_on_leave = CharacterBody3D.PLATFORM_ON_LEAVE_DO_NOTHING
    face = Node3D.new()
    face.set_script(VISUAL)
    add_child(face)

func _process(delta: float) -> void:
    face.animate(delta, velocity, is_on_floor(), running and grace_left <= 0.0)

func _after_move(was_grounded: bool, impact: float) -> void:
    if not was_grounded and is_on_floor() and impact > 1.0:
        face.react("landing")
        landed.emit(impact)

func _physics_process(delta: float) -> void:
    var before := external_motion_start if has_external_displacement else global_position
    has_external_displacement = false
    physics_start_position = before
    var was_grounded := is_on_floor()
    var impact := maxf(0.0, -velocity.y)
    if not running:
        jump_requested = false
        jump_buffer = 0.0
        if not settle_when_stopped:
            velocity = Vector3.ZERO
            return
        # Victory can settle; death and transition freeze physics entirely.
        velocity.x = 0.0
        velocity.z = 0.0
        velocity.y = -0.1 if is_on_floor() else velocity.y - GRAVITY * delta
        jump_requested = false
        move_and_slide()
        _after_move(was_grounded, impact)
        return
    if not recovery_hold:
        invulnerable_left = maxf(0.0, invulnerable_left - delta)
    var recovering_from_hit := hit_recovery_left > 0.0
    hit_recovery_left = maxf(0.0, hit_recovery_left - delta)
    if not recovery_hold:
        spawn_protection_left = maxf(0.0, spawn_protection_left - delta)
    grace_left = maxf(0.0, grace_left - delta)
    jump_buffer = maxf(0.0, jump_buffer - delta)
    if jump_requested and accept_jump_input:
        jump_buffer = JUMP_BUFFER
    jump_requested = false
    if is_on_floor() and velocity.y <= 0.0:
        coyote_left = COYOTE_TIME
    else:
        coyote_left = maxf(0.0, coyote_left - delta)
    # The motor requests only the two-axis input vector. External delta-v is
    # independent: releasing the joystick brakes the motor, never the impact.
    var direction := move_input.limit_length(1.0) if grace_left <= 0.0 and not recovering_from_hit else Vector2.ZERO
    var motor_target := Vector3(direction.x, 0, direction.y) * MOVE_SPEED
    var acceleration := ground_acceleration if is_on_floor() else air_acceleration
    control_velocity = control_velocity.move_toward(motor_target, acceleration * delta)
    knockback = knockback.move_toward(Vector3.ZERO, (ground_drag if is_on_floor() else air_drag) * delta)
    velocity.x = control_velocity.x + knockback.x
    velocity.z = control_velocity.z + knockback.z
    if is_on_floor() and velocity.y <= 0.0:
        velocity.y = -0.1
    else:
        velocity.y -= GRAVITY * delta
    if jump_buffer > 0.0 and coyote_left > 0.0 and grace_left <= 0.0:
        velocity.y = JUMP_SPEED
        jump_buffer = 0.0
        coyote_left = 0.0
        jumped.emit()
    requested_velocity = velocity
    move_and_slide()
    # Solid contacts remain active during immunity. move_and_slide resolves
    # blocking; the motor-driven bar's measured motion supplies impact energy.
    for index in range(get_slide_collision_count()):
        var collision := get_slide_collision(index)
        var normal := collision.get_normal()
        if knockback.dot(normal) < 0:
            var remaining := knockback.slide(normal)
            knockback = Vector3(remaining.x, 0, remaining.z)
        var body := collision.get_collider()
        if body != null and body.has_method("report_solid_contact"):
            body.report_solid_contact(collision.get_position(), collision.get_normal())
    _after_move(was_grounded, impact)
    if collision_logging and logged_motion_left > 0:
        collision_log("post_hit_physics",{"displacement": [global_position.x-before.x,global_position.y-before.y,global_position.z-before.z]})
        logged_motion_left -= 1
    moved.emit(before, global_position, delta)
    var committed_fall := global_position.y + BODY_HEIGHT < course_floor_height - 0.15 and velocity.y < 0.0
    fall_elapsed = fall_elapsed + delta if committed_fall else 0.0
    if fall_elapsed >= fall_visibility_duration or global_position.y < course_floor_height - maximum_fall_depth or absf(global_position.x) > horizontal_death_limit:
        # Latch before emitting: only one failure until reset_at().
        running = false
        velocity = Vector3.ZERO
        face.react("fail")
        fell.emit()

func hit_rejection_reason(origin: Vector3, spin_speed: float) -> String:
    if not running: return "player_not_running"
    if get_tree().paused: return "tree_paused"
    if recovery_hold: return "camera_recovery"
    if invulnerable_left > 0.0: return "spawn_protection" if spawn_protection_left > 0.0 else "hit_cooldown"
    if grace_left > 0.0: return "spawn_settling"
    if not origin.is_finite(): return "nonfinite_origin"
    if not is_finite(spin_speed): return "nonfinite_spin_speed"
    return ""

func apply_bar_impact(bar: AnimatableBody3D) -> bool:
    collision_log("hit_handler_called", {"obstacle": str(bar.get_path())})
    last_hit_rejection = hit_rejection_reason(bar.global_position, bar.spin_speed)
    var normal: Vector3 = bar.contact_normal
    var incoming: Vector3 = requested_velocity if bar.contact_source == "solid_slide" else velocity
    var relative: Vector3 = bar.contact_velocity - incoming
    if last_hit_rejection != "":
        collision_log("hit_rejected", {"reason": last_hit_rejection})
        return false
    # move_and_slide's -0.1 floor press is support, not an obstacle strike.
    if normal.dot(Vector3.UP) >= cos(floor_max_angle) and absf(bar.contact_velocity.y) < 0.001 and incoming.y >= -0.11:
        last_hit_rejection = "resting_support"
        collision_log("hit_rejected", {"reason": last_hit_rejection})
        return false
    var closing := maxf(0.0, relative.dot(normal))
    if closing <= 0.05:
        last_hit_rejection = "separating_or_resting"
        return false
    last_obstacle = str(bar.get_path())
    last_impact_frame = Engine.get_physics_frames()
    last_impact_source = bar.contact_source
    last_normal = normal
    last_contact_speed = bar.contact_velocity.length()
    last_relative = relative
    var inverse_mass := 1.0 / maxf(effective_mass, 0.01)
    var inverse_bar_mass := 1.0 / maxf(obstacle_mass, 0.01)
    var normal_impulse := (1.0 + restitution) * closing / (inverse_mass + inverse_bar_mass)
    var tangent := last_relative - last_normal * last_relative.dot(last_normal)
    var friction_impulse := (tangent / (inverse_mass + inverse_bar_mass)).limit_length(impact_friction * normal_impulse)
    last_impulse = last_normal * normal_impulse + friction_impulse
    var change := (last_impulse * inverse_mass).limit_length(maximum_impact_speed)
    # Transfer the actual pre-impact motion, then suspend the motor. No fixed
    # upward launch and no world-axis impulse unrelated to contact geometry.
    var result := (incoming + change).limit_length(maximum_impact_speed)
    last_impulse = (result - incoming) / inverse_mass
    impact_incoming = incoming
    impact_outgoing = result
    var previous_external := knockback
    control_velocity = Vector3(incoming.x, 0, incoming.z) - previous_external
    # Only delta-v belongs in the external channel. Preserve any earlier
    # external motion rather than copying the motor into it.
    knockback = previous_external + Vector3(result.x-incoming.x, 0, result.z-incoming.z)
    velocity = result
    hit_recovery_left = recovery_duration
    coyote_left = 0.0
    jump_buffer = 0.0
    invulnerable_left = clampf(hit_cooldown, 0.1, 3.0)
    logged_motion_left = 4 if collision_logging else 0
    collision_log("hit_accepted", {"obstacle": last_obstacle, "normal": str(last_normal),
        "contact_speed": last_contact_speed, "relative": str(last_relative),
        "incoming": str(impact_incoming), "outgoing": str(impact_outgoing),
        "impulse": str(last_impulse), "closing": closing})
    face.react("hit")
    hit.emit()
    return true

func reset_at(pos: Vector3, protected := true) -> void:
    collision_layer = 2
    collision_mask = 5
    rotation = Vector3.ZERO
    settle_when_stopped = false
    global_position = pos
    physics_start_position = pos
    has_external_displacement = false
    velocity = Vector3.ZERO
    knockback = Vector3.ZERO
    control_velocity = Vector3.ZERO
    requested_velocity = Vector3.ZERO
    hit_recovery_left = 0.0
    move_input = Vector2.ZERO
    jump_requested = false
    jump_buffer = 0.0
    coyote_left = 0.0
    logged_motion_left = 0
    last_hit_rejection = ""
    last_impulse = Vector3.ZERO
    last_relative = Vector3.ZERO
    last_normal = Vector3.ZERO
    last_contact_speed = 0.0
    last_obstacle = "none"
    last_impact_frame = 0
    last_impact_source = "none"
    impact_incoming = Vector3.ZERO
    impact_outgoing = Vector3.ZERO
    grace_left = 0.3
    recovery_hold = false
    fall_elapsed = 0.0
    spawn_protection_left = clampf(spawn_protection_duration,0.1,5.0) if protected else 0.0
    invulnerable_left = spawn_protection_left
    face.reset_pose()
    running = true
    collision_log("player_reset",{"protected_reset": protected})

func finish_recovery() -> void:
    recovery_hold = false
    fall_elapsed = 0.0
    # Camera settling and pause never spend the protected play window.
    spawn_protection_left = clampf(spawn_protection_duration,0.1,5.0)
    invulnerable_left = spawn_protection_left
    clear_input()

func clear_input() -> void:
    move_input = Vector2.ZERO
    jump_requested = false
    jump_buffer = 0.0

func stop(settle := false) -> void:
    running = false
    recovery_hold = false
    fall_elapsed = 0.0
    accept_jump_input = false
    settle_when_stopped = settle
    clear_input()
    coyote_left = 0.0
    knockback = Vector3.ZERO
    control_velocity = Vector3.ZERO
    requested_velocity = Vector3.ZERO
    hit_recovery_left = 0.0
    velocity = Vector3.ZERO
    if not settle:
        collision_layer = 0
        spawn_protection_left = 0.0
        invulnerable_left = 0.0

# Spring pads change vertical velocity only; motor and external channels survive.
func launch_vertical(speed: float) -> bool:
    if not running or recovery_hold or not accept_jump_input or get_tree().paused: return false
    velocity.y = clampf(speed,JUMP_SPEED,20.0)
    coyote_left = 0
    jump_buffer = 0
    jump_requested = false
    jumped.emit()
    return true
