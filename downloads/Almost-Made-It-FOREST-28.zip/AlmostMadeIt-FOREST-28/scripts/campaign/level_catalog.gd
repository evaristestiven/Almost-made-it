extends RefCounted
const NAMES := ["First Steps", "Leap of Faith", "Spin Cycle", "Moving Target", "Bounce House", "Swing Away", "Don't Stop", "Dizzy Heights", "Against the Flow", "The First Gauntlet"]
const FILES := ["01_first_steps", "02_leap_of_faith", "03_spin_cycle", "04_moving_target", "05_bounce_house", "06_swing_away", "07_dont_stop", "08_dizzy_heights", "09_against_the_flow", "10_first_gauntlet"]
static func scene_path(number: int) -> String:
    return "res://levels/world1/%s.tscn" % FILES[clampi(number,1,10)-1]
# Platform tuple [x,z,length,width]; obstacle dictionaries are scene exports.
static func get_level(number: int) -> Dictionary:
    var d := {"number":number,"name":NAMES[clampi(number,1,10)-1],"platforms":[],"obstacles":[],"checkpoints":[],"coins":[],"finish":Vector2(0,-76),"route":[]}
    match number:
        1:
            d.platforms = [[0,0,18,10],[0,-24,17,10],[0,-46,17,9],[0,-69,22,10]]
            d.obstacles = [bar(-5,5.4,.8),bar(-25,5,-.9),bar(-48,4.8,1.1),moving(0,-12.25,3,3,Vector3(.6,0,0),5),moving(0,-56.25,2.5,3,Vector3(.5,0,0),5)]
            d.checkpoints = [Vector2(0,-30)]
            d.coins = [Vector2(2,-1),Vector2(-2,-21),Vector2(2,-43),Vector2(-2,-65),Vector2(2,-72)]
            d.route = [Vector2(0,5),Vector2(0,-9),Vector2(0,-15.5),Vector2(0,-32.5),Vector2(0,-37.5),Vector2(0,-54.5),Vector2(0,-58),d.finish]
        2:
            d.platforms = [[0,0,16,8],[-1.5,-15,10,7],[1.5,-29,10,7],[-1.5,-44,12,7],[0,-60,14,8]]
            d.obstacles = [moving(0,-22,4,3,Vector3(.9,0,0),5)]
            d.checkpoints = [Vector2(-1.5,-44)]
            d.coins = [Vector2(1.8,1),Vector2(-1.5,-15),Vector2(1.5,-29),Vector2(-1.5,-45),Vector2(1.8,-60)]
            d.finish = Vector2(0,-65)
        3:
            d.platforms = [[0,0,16,9],[0,-20,16,9],[0,-40,16,8],[0,-60,18,9]]
            d.obstacles = [bar(-3,5.8,.9),bar(-17,6,-1.8),bar(-24,4.6,2.2),bar(-41,5.5,-2.4),bar(-58,5.2,2.8)]
            d.checkpoints = [Vector2(0,-36),Vector2(0,-53)]
            d.coins = [Vector2(2,2),Vector2(-2,-20),Vector2(2,-38),Vector2(-2,-54),Vector2(2,-64)]
            d.finish = Vector2(0,-66)
        4:
            d.platforms = [[0,0,14,8],[0,-24,10,7],[0,-48,10,7],[0,-72,14,8]]
            d.obstacles = [moving(0,-13,4,3.5,Vector3(0,0,3),5),moving(0,-36,6,3.5,Vector3(1.8,0,0),4.5),moving(0,-59,4,3.2,Vector3(0,0,2.8),4)]
            d.checkpoints = [Vector2(0,-24),Vector2(0,-48)]
            d.coins = [Vector2(1.5,1),Vector2(-1.5,-24),Vector2(0,-36),Vector2(1.5,-48),Vector2(-1.5,-73)]
            d.finish = Vector2(0,-77)
            d.route = [Vector2(0,5),Vector2(0,-13),Vector2(0,-24),Vector2(0,-36),Vector2(0,-48),Vector2(0,-59),d.finish]
        5:
            d.platforms = [[0,0,18,9],[2,-26,12,6],[-2,-51,14,6],[0,-78,16,8]]
            d.obstacles = [pad(0,-7.5),pad(2,-30.5),pad(-2,-56.5)]
            d.checkpoints = [Vector2(2,-26),Vector2(-2,-51)]
            d.coins = [Vector2(1.5,1),Vector2(2,-25),Vector2(-2,-49),Vector2(1.5,-76),Vector2(-1.5,-81)]
            d.finish = Vector2(0,-83)
        6:
            d.platforms = [[0,0,16,8],[0,-20,14,7],[0,-40,14,7],[0,-60,14,7],[0,-80,18,9]]
            d.obstacles = [ball(-15,4.2,.7),ball(-37,3.8,.75),ball(-59,3.4,.8),ball(-79,3.2,.85)]
            d.checkpoints = [Vector2(0,-24),Vector2(0,-64)]
            d.coins = [Vector2(1.8,1),Vector2(-1.8,-22),Vector2(1.8,-42),Vector2(-1.8,-62),Vector2(1.8,-83)]
            d.finish = Vector2(0,-86)
        7:
            d.platforms = [[0,0,16,8],[0,-30,10,7],[0,-60,10,7],[0,-88,16,8]]
            d.obstacles = [collapse(-13,6,4.5,1.1),collapse(-20,6,4.5,1),collapse(-40,6,4,.95),collapse(-48,6,4,.9),collapse(-70,5,3.6,.85),collapse(-76,5,3.6,.8)]
            d.checkpoints = [Vector2(0,-30),Vector2(0,-60)]
            d.coins = [Vector2(1.5,1),Vector2(0,-13),Vector2(-1.5,-30),Vector2(0,-48),Vector2(1.5,-86)]
            d.finish = Vector2(0,-93)
            d.route = [Vector2(0,5),Vector2(0,-13),Vector2(0,-30),Vector2(0,-48),Vector2(0,-60),Vector2(0,-76),d.finish]
        8:
            d.platforms = [[0,0,14,8],[0,-19,4,2.6],[2,-35,8,7],[-1,-52,5,2.4],[0,-63,12,8]]
            d.obstacles = [disc(0,-13,3,.8),disc(2,-26,3,-1),disc(-1,-45,2.7,1.2)]
            d.checkpoints = [Vector2(2,-35)]
            d.coins = [Vector2(1.5,1),Vector2(1,-13),Vector2(1,-26),Vector2(0,-45),Vector2(1.5,-62)]
            d.finish = Vector2(0,-66)
            d.route = [Vector2(0,5),Vector2(0,-13),Vector2(0,-19),Vector2(2,-26),Vector2(2,-35),Vector2(-1,-45),Vector2(-1,-52),d.finish]
        9:
            d.platforms = [[0,0,16,8],[2,-33,8,7],[-2,-59,8,7],[0,-90,14,8]]
            d.obstacles = [belt(0,-19,16,6,Vector3(0,0,2)),belt(2,-46,14,5,Vector3(-1.5,0,1.5)),belt(-2,-73,16,5,Vector3(1.8,0,2.5))]
            d.checkpoints = [Vector2(2,-33),Vector2(-2,-59)]
            d.coins = [Vector2(1.5,1),Vector2(-1,-18),Vector2(2,-33),Vector2(-2,-61),Vector2(1.5,-91)]
            d.finish = Vector2(0,-94)
            d.route = [Vector2(0,5),Vector2(0,-19),Vector2(2,-33),Vector2(2,-46),Vector2(-2,-59),Vector2(-2,-73),d.finish]
        10:
            d.platforms = [[0,0,18,9],[0,-24,12,8],[0,-48,12,8],[0,-76,12,8],[0,-100,12,8],[0,-127,20,10]]
            d.obstacles = [bar(-4,5,1.5),moving(0,-13.5,4,3.5,Vector3(1,0,0),4.5),pad(0,-28.5),ball(-47,4,.7),collapse(-58,6,4.5,1),collapse(-64,6,4.5,.85),disc(0,-88,3.5,1.0),belt(0,-112,6,4,Vector3(0,0,2)),bar(-122,5,-2),ball(-129,4,.75)]
            d.checkpoints = [Vector2(0,-24),Vector2(0,-52),Vector2(0,-76),Vector2(0,-100),Vector2(0,-118)]
            d.coins = [Vector2(1.5,1),Vector2(-1.5,-24),Vector2(1.5,-50),Vector2(-1.5,-100),Vector2(1.5,-132)]
            d.finish = Vector2(0,-134)
            d.route = [Vector2(0,5),Vector2(0,-13.5),Vector2(0,-24),Vector2(0,-48),Vector2(0,-64),Vector2(0,-76),Vector2(0,-88),Vector2(0,-100),Vector2(0,-112),d.finish]
    if d.route.is_empty():
        d.route = [Vector2(0,5)]
        for p in d.platforms:
            if p[1] < 0 and p[1] > d.finish.y: d.route.append(Vector2(p[0],p[1]))
        d.route.append(d.finish)
    enrich_adventure(d,number)
    return d
static func bar(z: float, width: float, speed: float) -> Dictionary:
    return {"type":"rotating_bar","at":Vector3(0,1.05,z),"width":width,"spin_speed":speed}
static func moving(x: float,z: float,length: float,width: float,travel: Vector3,period: float) -> Dictionary:
    return {"type":"moving_platform","at":Vector3(x,-.35,z),"dimensions":Vector3(width,.7,length),"travel":travel,"period":period}
static func pad(x: float,z: float) -> Dictionary:
    return {"type":"bounce_pad","at":Vector3(x,0,z),"launch_speed":20.0}
static func ball(z: float,period: float,amplitude: float) -> Dictionary:
    return {"type":"swinging_ball","at":Vector3(0,3.8,z),"period":period,"amplitude":amplitude}
static func collapse(z: float,length: float,width: float,warning: float) -> Dictionary:
    return {"type":"collapsing_platform","at":Vector3(0,-.3,z),"dimensions":Vector3(width,.6,length),"warning_time":warning}
static func disc(x: float,z: float,radius: float,speed: float) -> Dictionary:
    return {"type":"rotating_disc","at":Vector3(x,-.25,z),"radius":radius,"angular_speed":speed}
static func belt(x: float,z: float,length: float,width: float,velocity: Vector3) -> Dictionary:
    return {"type":"conveyor","at":Vector3(x,-.25,z),"dimensions":Vector3(width,.5,length),"surface_velocity":velocity}

# These additions extend the existing courses; their original safe route remains.
# Extra platform tuples: x, z, length, width, top height. No hidden colliders.
static func enrich_adventure(d: Dictionary, number: int) -> void:
    var themes := [
        ["Meadow Post", "79cf91", "559d86", "ffe191", "FIRST STEPS|THE POSTMAN LEFT A TRAIL", "FIND YOUR FEET|ISLAND HOP|HOME STRETCH"],
        ["Cloud Orchard", "8fcdd9", "657ab5", "ffe5ad", "LEAP OF FAITH|THE HIGH ROAD HIDES A COIN", "STEP UP|ORCHARD SHORTCUT|THE LAST LEAP"],
        ["Clockwork Garden", "aa91c8", "596a98", "ffd367", "SPIN CYCLE|EVERY GEAR HAS A RHYTHM", "WATCH A TURN|DOUBLE DECKER|BEAT THE CLOCK"],
        ["Sky Harbor", "63bbbc", "427c99", "ffe19b", "MOVING TARGET|CARGO BOUND FOR THE SUMMIT", "BOARDING|TRANSFER DOCK|LAST DEPARTURE"],
        ["Sky Carnival", "efad9f", "8d84bf", "fff0a5", "BOUNCE HOUSE|THE TENTS TOOK FLIGHT", "FIRST FLIGHT|BONUS BALCONY|STICK THE LANDING"],
        ["Bell Foundry", "d3a274", "697d86", "f4dfa4", "SWING AWAY|THE FORGE IS STILL AWAKE", "READ THE SWING|RECOVERY LEDGES|FINAL BELL"],
        ["Broken Aqueduct", "c1a58d", "777b9a", "ffc98a", "DON'T STOP|THE OLD WATERWAY IS CRUMBLING", "KEEP MOVING|THE SIDE AQUEDUCT|ONE LAST DASH"],
        ["Star Observatory", "929acb", "577d9a", "bef0e6", "DIZZY HEIGHTS|FOLLOW THE LOST CONSTELLATION", "FIRST ORBIT|UPPER WALKWAY|RETURN TO EARTH"],
        ["Wind Station", "74b8ba", "647b9c", "ffe68e", "AGAINST THE FLOW|THE WIND POWERS THE ISLANDS", "HEADWIND|WAIT OR SKIRT THE GATE|CROSSCURRENT"],
        ["Summit Relay", "e4b370", "9a7e9b", "fff0ba", "THE FIRST GAUNTLET|RELIGHT THE SUMMIT BEACON", "THE CROSSING|RUINS AND ORBITS|THE SUMMIT"]]
    var t: Array = themes[number-1]
    d.theme = {"name":t[0],"top":t[1],"side":t[2],"accent":t[3],"intro":t[4],"sections":t[5].split("|")}
    d.theme.sky = ["8fc9db","8eb6db","6e739f","81aebd","c2b2d6","b4a1a0","a7a2ae","607a9c","84b6c4","c79f9a"][number-1]
    d.extensions = []
    d.coin_heights = [1.25,1.25,1.25,1.25,1.25]
    match number:
        1:
            d.extensions = [[-4.4,-22,3.4,1.8,.55]]
            d.coins[1] = Vector2(-4.4,-22)
            d.coin_heights[1] = 1.8
        2:
            d.extensions = [[-4,-21.5,3,2,.6],[-3,-25,2.8,2,1.05]]
            d.coins[2] = Vector2(-4,-21.5)
            d.coin_heights[2] = 1.85
        3:
            var upper := bar(-24,4.6,-1.4)
            upper.at.y = 2.85
            d.obstacles.append(upper)
        4:
            d.extensions = [[4.1,-36,4,1.8,0]]
            d.coins[2] = Vector2(4.1,-36)
        5:
            d.extensions = [[4.3,-39,4,2.2,2.0]]
            d.coins[2] = Vector2(4.3,-39)
            d.coin_heights[2] = 3.25
        6:
            d.extensions = [[4.4,-38,5,2,0],[-4.4,-60,5,2,0]]
            d.coins[2] = Vector2(4.4,-38)
        7:
            d.extensions = [[3.8,-39,5,1.6,.35],[3.8,-46,5,1.6,.65],[2.5,-53,4,2,.3]]
            d.coins[3] = Vector2(3.8,-46)
            d.coin_heights[3] = 1.9
        8:
            d.extensions = [[3.5,-38.5,3,1.5,.6],[3.5,-43,3,1.5,1.2],[2,-48,3,1.5,.6]]
            d.coins[3] = Vector2(3.5,-43)
            d.coin_heights[3] = 2.45
        9:
            # The real solid shutter rises vertically. Its narrow edges permit a
            # precision bypass; waiting for a clear opening is the safer option.
            var gate := moving(2,-44,.4,3.2,Vector3(0,1.8,0),5)
            gate.at.y = 2.1
            gate.dimensions.y = 2.0
            d.obstacles.append(gate)
        10:
            d.extensions = [[-3.8,-101,3,1.5,.7]]
            d.coins[3] = Vector2(-3.8,-101)
            d.coin_heights[3] = 1.95
