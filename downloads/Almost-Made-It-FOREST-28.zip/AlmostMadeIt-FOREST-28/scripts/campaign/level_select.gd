extends Control
const CATALOG = preload("res://scripts/campaign/level_catalog.gd")
const HUD = preload("res://scripts/components/game_hud.gd")
var campaign: Node
var buttons: Array[Button] = []
var status: Label
var margin: MarginContainer
var scroll: ScrollContainer
var scroll_finger := -999
var scroll_origin := Vector2.ZERO
var scroll_last := Vector2.ZERO
var scroll_dragged := false
var touch_button: Button
func _ready() -> void:
    campaign = get_node("/root/Campaign")
    campaign.transitioning = false
    var background := ColorRect.new()
    background.color = Color("77b9ce")
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(background)
    margin = MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(margin)
    scroll = ScrollContainer.new()
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    margin.add_child(scroll)
    var column := VBoxContainer.new()
    column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    column.add_theme_constant_override("separation",16)
    scroll.add_child(column)
    var design := HUD.new()
    for text in ["ALMOST MADE IT!", "WORLD 1 · THE BEGINNING"]:
        var label := design.label(text,30 if text.begins_with("ALMOST") else 24)
        label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        column.add_child(label)
    status = design.label("WORLD COMPLETE!" if campaign.world_completed() else "Drag to move · Jump to clear gaps",20)
    status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    column.add_child(status)
    for number in range(1,11):
        var button := design.button("%02d  %s%s" % [number,CATALOG.NAMES[number-1],"  ✓" if campaign.completed[number-1] else ("  LOCKED" if not campaign.can_start(number) else "")])
        button.custom_minimum_size.y = 76
        button.add_theme_font_size_override("font_size",22)
        button.disabled = not campaign.can_start(number)
        button.pressed.connect(func() -> void:
            if not campaign.open_level(number): status.text = campaign.save_error
        )
        column.add_child(button)
        buttons.append(button)
    var preview := design.label("WORLDS 2–5 · LOCKED\nMore worlds will come later.",20)
    preview.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    column.add_child(preview)
    design.free()
    resized.connect(layout)
    layout()
func layout() -> void:
    var left := 24
    var top := 32
    var right := 24
    var bottom := 32
    if DisplayServer.get_name() != "headless" and size.x > 0:
        var pixels := DisplayServer.get_display_safe_area()
        if pixels.has_area():
            var logical: Rect2 = get_viewport().get_screen_transform().affine_inverse()*Rect2(pixels)
            left = maxi(left,int(logical.position.x)+16)
            top = maxi(top,int(logical.position.y)+16)
            right = maxi(right,int(size.x-logical.end.x)+16)
            bottom = maxi(bottom,int(size.y-logical.end.y)+16)
    margin.add_theme_constant_override("margin_left",left)
    margin.add_theme_constant_override("margin_top",top)
    margin.add_theme_constant_override("margin_right",right)
    margin.add_theme_constant_override("margin_bottom",bottom)

# Own native screen touches so dragging a list never also activates a level.
# Real mouse/wheel/keyboard continue through standard Godot GUI handling.
func _input(event: InputEvent) -> void:
    if event is InputEventMouse and event.device == InputEvent.DEVICE_ID_EMULATION:
        get_viewport().set_input_as_handled()
    elif event is InputEventScreenTouch:
        if event.pressed and not event.canceled and scroll_finger == -999 and scroll.get_global_rect().has_point(event.position):
            scroll_finger = event.index
            scroll_origin = event.position
            scroll_last = event.position
            scroll_dragged = false
            for button in buttons:
                if not button.disabled and button.get_global_rect().has_point(event.position):
                    touch_button = button
                    button.set_pressed_no_signal(true)
                    break
        elif not event.pressed or event.canceled:
            if event.index == scroll_finger:
                var activate: bool = not event.canceled and not scroll_dragged and is_instance_valid(touch_button) and touch_button.get_global_rect().has_point(event.position)
                var button := touch_button
                clear_touch()
                if activate: button.pressed.emit()
        get_viewport().set_input_as_handled()
    elif event is InputEventScreenDrag and event.index == scroll_finger:
        if scroll_dragged or event.position.distance_to(scroll_origin) > 12:
            scroll_dragged = true
            if is_instance_valid(touch_button): touch_button.set_pressed_no_signal(false)
            scroll.scroll_vertical -= roundi(event.position.y-scroll_last.y)
        scroll_last = event.position
        get_viewport().set_input_as_handled()
func clear_touch() -> void:
    if is_instance_valid(touch_button): touch_button.set_pressed_no_signal(false)
    touch_button = null
    scroll_finger = -999
    scroll_dragged = false
func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT: clear_touch()
