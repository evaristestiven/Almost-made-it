extends Node
const CATALOG = preload("res://scripts/campaign/level_catalog.gd")
@export var save_path := "user://world1_progress.json"
var completed: Array = []
var best_coins: Array = []
var best_seconds: Array = []
var selected_level := 1
var transitioning := false
var dirty := false
var save_error := ""
func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--campaign-save=user://"):
            save_path = argument.trim_prefix("--campaign-save=")
    load_progress()
func clear_progress() -> void:
    completed = []
    best_coins = []
    best_seconds = []
    for i in range(10):
        completed.append(false)
        best_coins.append(0)
        best_seconds.append(0.0)
func unlocked_count() -> int:
    var count := 1
    for i in range(9):
        if not completed[i]: break
        count = i+2
    return count
func world_completed() -> bool:
    return completed.size() == 10 and not completed.has(false)
func can_start(number: int) -> bool:
    return number >= 1 and number <= 10 and number <= unlocked_count()
func payload() -> Dictionary:
    return {"version":1,"completed":completed,"best_coins":best_coins,"best_seconds":best_seconds}
func decode(path: String) -> Dictionary:
    if not FileAccess.file_exists(path): return {}
    var parser := JSON.new()
    if parser.parse(FileAccess.get_file_as_string(path)) != OK: return {}
    var wrapper = parser.data
    if not wrapper is Dictionary or not wrapper.get("data_json") is String: return {}
    var encoded: String = wrapper.data_json
    if wrapper.get("sha256","") != encoded.sha256_text(): return {}
    if parser.parse(encoded) != OK: return {}
    var parsed = parser.data
    if not parsed is Dictionary or parsed.get("version") != 1: return {}
    var data: Dictionary = parsed
    for key in ["completed","best_coins","best_seconds"]:
        if not data.get(key) is Array or data[key].size() != 10: return {}
    for i in range(10):
        if not data.completed[i] is bool: return {}
        if not (data.best_coins[i] is float or data.best_coins[i] is int) or data.best_coins[i] < 0 or data.best_coins[i] > 5: return {}
        if not (data.best_seconds[i] is float or data.best_seconds[i] is int) or not is_finite(float(data.best_seconds[i])) or data.best_seconds[i] < 0: return {}
        if i > 0 and data.completed[i] and not data.completed[i-1]: return {}
    return data
func load_progress() -> void:
    clear_progress()
    var data := decode(save_path)
    var recovered := false
    if data.is_empty():
        data = decode(save_path+".bak")
        recovered = not data.is_empty()
    if not data.is_empty():
        completed = data.completed.duplicate()
        best_coins = data.best_coins.duplicate()
        best_seconds = data.best_seconds.duplicate()
    selected_level = clampi(selected_level,1,unlocked_count())
    dirty = recovered
    save_error = "Recovered backup" if recovered else ""
func save_progress() -> bool:
    var data := payload()
    var encoded := JSON.stringify(data)
    var wrapper := {"data_json":encoded,"sha256":encoded.sha256_text()}
    var file := FileAccess.open(save_path+".tmp",FileAccess.WRITE)
    if file == null:
        save_error = "Cannot write progress"
        dirty = true
        return false
    file.store_string(JSON.stringify(wrapper))
    file.flush()
    file.close()
    if decode(save_path+".tmp").is_empty():
        save_error = "Progress verification failed"
        dirty = true
        return false
    # Never replace a known-good backup with a corrupt/interrupted primary.
    if not decode(save_path).is_empty():
        var backup_error := DirAccess.copy_absolute(ProjectSettings.globalize_path(save_path),ProjectSettings.globalize_path(save_path+".bak"))
        if backup_error != OK:
            save_error = "Cannot back up progress"
            dirty = true
            return false
    var error := DirAccess.rename_absolute(ProjectSettings.globalize_path(save_path+".tmp"),ProjectSettings.globalize_path(save_path))
    if error != OK:
        save_error = "Cannot commit progress"
        dirty = true
        return false
    save_error = ""
    dirty = false
    return true
func record_completion(number: int, coins: int, seconds: float) -> bool:
    if not can_start(number) or not is_finite(seconds) or seconds < 0: return false
    completed[number-1] = true # Idempotent one-time unlock; no invented currency.
    best_coins[number-1] = maxi(int(best_coins[number-1]),clampi(coins,0,5))
    if float(best_seconds[number-1]) == 0 or seconds < float(best_seconds[number-1]): best_seconds[number-1] = seconds
    dirty = true
    return save_progress()
func open_level(number: int) -> bool:
    if transitioning or not can_start(number) or not ResourceLoader.exists(CATALOG.scene_path(number)): return false
    if dirty and not save_progress(): return false
    selected_level = number
    transitioning = true
    get_tree().paused = false
    call_deferred("commit_scene",CATALOG.scene_path(number))
    return true
func open_selection() -> bool:
    if transitioning or dirty and not save_progress(): return false
    transitioning = true
    get_tree().paused = false
    call_deferred("commit_scene","res://scenes/level_select.tscn")
    return true
func commit_scene(path: String) -> void:
    if get_tree().change_scene_to_file(path) != OK:
        transitioning = false
        save_error = "Level could not load"
