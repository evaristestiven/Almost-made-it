extends "res://scripts/components/game_hud.gd"
# Presentation-only Level 1 HUD. Signals, counters, tutorial text and menus
# continue to use the authoritative base HUD. All backing ignores touch input.
var progress_backing: Panel
var notice_backing: Panel
func build(input:Control) -> void:
    super.build(input)
    if not bool(ProjectSettings.get_setting("visuals/garden_polish/enabled",true)):return
    progress_backing=Panel.new()
    progress_backing.name="GardenProgressBacking"
    progress_backing.mouse_filter=Control.MOUSE_FILTER_IGNORE
    progress_backing.add_theme_stylebox_override("panel",style(Color(.035,.12,.17,.86),14))
    add_child(progress_backing)
    move_child(progress_backing,0)
    notice_backing=Panel.new()
    notice_backing.name="GardenTutorialBacking"
    notice_backing.mouse_filter=Control.MOUSE_FILTER_IGNORE
    notice_backing.add_theme_stylebox_override("panel",style(Color(.035,.12,.17,.88),14))
    add_child(notice_backing)
    move_child(notice_backing,0)
    for node in [level_label,progress_label,notice]:
        node.add_theme_color_override("font_shadow_color",Color(0,.04,.06,.6))
        node.add_theme_constant_override("shadow_offset_y",1)
    var track := style(Color(.65,.80,.82,.40),5)
    var fill := style(Color("ffc35b"),5)
    for box in [track,fill]:
        box.content_margin_top=0;box.content_margin_bottom=0
        box.content_margin_left=0;box.content_margin_right=0
    progress_bar.add_theme_stylebox_override("background",track)
    progress_bar.add_theme_stylebox_override("fill",fill)
    progress_bar.custom_minimum_size.y=10
    notice.add_theme_font_size_override("font_size",20)
    layout()
func layout() -> void:
    super.layout()
    if not is_instance_valid(progress_backing):return
    var safe:Rect2=controls.safe_rect
    progress_backing.position=safe.position+Vector2(0,82)
    progress_backing.size=Vector2(safe.size.x,62)
    stack.position=safe.position+Vector2(14,91)
    stack.size=Vector2(safe.size.x-28,42)
    notice.position=safe.position+Vector2(20,162)
    notice.size=Vector2(safe.size.x-40,38)
    notice.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
    notice_backing.position=safe.position+Vector2(0,154)
    notice_backing.size=Vector2(safe.size.x,54)
func _process(delta:float) -> void:
    super._process(delta)
    if is_instance_valid(notice_backing):
        notice_backing.modulate.a=notice.modulate.a
        notice_backing.visible=notice.visible and not menu_open
        progress_backing.visible=not menu_open
