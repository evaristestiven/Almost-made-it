extends RefCounted
# Ordered horizontal route. Height/steering do not inflate distance; restore()
# is reserved for the owner's spawn/respawn, never ordinary overlap callbacks.
var points := PackedVector3Array()
var lengths := PackedFloat32Array()
var offsets := PackedFloat32Array()
var total_length := 0.0
var segment_index := 0
var current_distance := 0.0
var traversal_distance := 0.0
var furthest_distance := 0.0
var expected_position := Vector3.ZERO
var position_valid := true
var on_route := true
var last_forward_motion := 0.0
var corridor_width := 5.0

func configure(markers: PackedVector3Array) -> bool:
    points = markers
    lengths.clear()
    offsets.clear()
    total_length = 0.0
    if points.size() < 2:
        return false
    for i in range(points.size() - 1):
        var delta := Vector2(points[i + 1].x - points[i].x, points[i + 1].z - points[i].z)
        var length := delta.length()
        if length < 0.01:
            return false
        offsets.append(total_length)
        lengths.append(length)
        total_length += length
    restore(points[0], 0.0, false)
    return true

func _project(point: Vector3, index: int) -> Vector2:
    var origin := Vector2(points[index].x, points[index].z)
    var direction := Vector2(points[index + 1].x, points[index + 1].z) - origin
    var at := Vector2(point.x, point.z)
    var t := clampf((at - origin).dot(direction) / direction.length_squared(), 0, 1)
    return Vector2(offsets[index] + lengths[index] * t, at.distance_to(origin + direction * t))

func distance_at(point: Vector3) -> float:
    var best_error := INF
    var distance := 0.0
    for i in range(lengths.size()):
        var projected := _project(point, i)
        if projected.y < best_error:
            best_error = projected.y
            distance = projected.x
    return distance

func restore(point: Vector3, distance: float, keep_furthest := true) -> void:
    expected_position = point
    current_distance = clampf(distance, 0, total_length)
    traversal_distance = current_distance
    if not keep_furthest:
        furthest_distance = current_distance
    segment_index = 0
    for i in range(lengths.size()):
        if current_distance >= offsets[i]:
            segment_index = i
    position_valid = true
    on_route = true
    last_forward_motion = 0.0

func hold_position(point: Vector3) -> void:
    expected_position = point
    last_forward_motion = 0.0

func observe(before: Vector3, after: Vector3, delta: float) -> bool:
    if not position_valid:
        return false
    var horizontal_step := Vector2(after.x - before.x, after.z - before.z).length()
    if not before.is_finite() or not after.is_finite() or before.distance_to(expected_position) > 0.12 or horizontal_step > 24.0 * delta + 0.05:
        position_valid = false
        on_route = false
        return false
    expected_position = after
    var best := Vector2(0, INF)
    var best_index := segment_index
    for i in range(maxi(0, segment_index - 1), mini(lengths.size(), segment_index + 2)):
        if i > segment_index and traversal_distance < offsets[i] - 0.6:
            continue
        var projected := _project(after, i)
        if projected.y < best.y:
            best = projected
            best_index = i
    # Keep following continuous physical travel even outside the reward corridor.
    # Otherwise returning from a recoverable side jump compares the entire
    # excursion against one frame's movement and permanently rejects the route.
    # This cursor awards nothing; displacement/adjacent-branch guards still apply.
    last_forward_motion = 0.0
    # A closest-point projection changes discontinuously when a continuous
    # physical path cuts inside a wide corner. Permit only that adjacent corner
    # transition; the per-step teleport guard and ordered-marker gate remain.
    var near_corner := false
    if best_index == segment_index+1:
        var corner := Vector2(points[best_index].x,points[best_index].z)
        near_corner = Vector2(after.x,after.z).distance_to(corner) <= corridor_width and best.x <= offsets[best_index]+corridor_width
    if best.x > traversal_distance + horizontal_step + 0.08 and not near_corner:
        on_route = false
        return true
    traversal_distance = best.x
    segment_index = best_index
    var along := clampf((best.x - offsets[best_index]) / lengths[best_index], 0, 1)
    var route_height := lerpf(points[best_index].y, points[best_index + 1].y, along)
    on_route = best.y <= corridor_width and after.y >= route_height - 0.2 and after.y <= route_height + 4.0
    if not on_route:
        return true
    var direction := Vector2(points[best_index + 1].x - points[best_index].x, points[best_index + 1].z - points[best_index].z).normalized()
    last_forward_motion = Vector2(after.x - before.x, after.z - before.z).dot(direction)
    current_distance = best.x
    furthest_distance = maxf(furthest_distance, current_distance)
    return true

func percent(completed := false) -> int:
    if completed:
        return 100
    return clampi(int(furthest_distance / maxf(total_length, 0.01) * 100.0), 0, 99)
