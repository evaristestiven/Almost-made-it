extends Camera3D
# Follow the body's actual world position. Requested velocity, autorun speed,
# course progress and timers never drive the follow target.
var target: CharacterBody3D
var transitioning := false
var impact_left := 0.0
var clock := 0.0
const OFFSET := Vector3(0, 5.7, 11)
const FOCUS := Vector3(0, 0.7, -6)
@export var follow_rate := 14.0
@export var vertical_rate := 10.0
@export var recovery_rate := 16.0
@export_range(0.0, 1.0) var jump_follow := 0.35
@export var maximum_fall_follow := 4.5
@export var contact_clearance_distance := 3.0
var tracking_mode := "FOLLOW"
var follow_position := Vector3.ZERO
var last_target_position := Vector3.ZERO
var last_physics_position := Vector3.ZERO
var movement_direction_z := 0.0
var boom_fraction := 1.0
var ray: PhysicsRayQueryParameters3D
var boom_query: PhysicsShapeQueryParameters3D

func _ready() -> void:
    process_physics_priority = 100 # Observe after the player and moving bodies.

func _physics_process(_delta: float) -> void:
    if not is_instance_valid(target): return
    var actual := target.global_position
    var shift := actual.z-last_physics_position.z
    movement_direction_z = signf(shift) if absf(shift) > 0.00001 else 0.0
    last_physics_position = actual

func follow_anchor(position: Vector3) -> Vector3:
    var anchor := position
    # A restrained jump bob, but follow a fall long enough to keep it visible.
    if position.y > 0:
        # Normal jump framing is unchanged. Spring-pad height needs extra follow
        # above the normal apex, otherwise the avatar disappears behind the HUD.
        anchor.y = minf(position.y,2.5)*jump_follow + maxf(0,position.y-2.5)*.85
    else:
        anchor.y = maxf(position.y,target.course_floor_height-maximum_fall_follow)
    return anchor

func setup(player: CharacterBody3D) -> void:
    target = player
    transitioning = false
    impact_left = 0
    clock = 0
    boom_fraction = 1
    last_target_position = player.global_position
    last_physics_position = player.global_position
    movement_direction_z = 0
    ray = PhysicsRayQueryParameters3D.new()
    ray.collision_mask = 5 # Terrain and solid obstacles, not pickups/triggers.
    ray.exclude = [player.get_rid()]
    boom_query = PhysicsShapeQueryParameters3D.new()
    var sphere := SphereShape3D.new()
    sphere.radius = 0.22
    boom_query.shape = sphere
    boom_query.collision_mask = ray.collision_mask
    boom_query.exclude = ray.exclude
    boom_query.margin = 0.02
    var anchor := follow_anchor(player.global_position)
    follow_position = anchor + OFFSET
    global_position = follow_position
    # Same angle and perspective as the existing camera; never rotate on follow.
    look_at(anchor + FOCUS, Vector3.UP)

func recover() -> void:
    transitioning = true
    impact_left = 0
    if is_instance_valid(target):
        # Teleport the reference frame with the body. Interpolating world-space
        # history from below the course sweeps the boom through floors and makes
        # the avatar tiny/off-center. Only a small LOCAL framing error may ease.
        var old_desired := follow_anchor(last_target_position) + OFFSET
        var local_error := (follow_position-old_desired).limit_length(0.75)
        follow_position = follow_anchor(target.global_position) + OFFSET + local_error
        global_position = follow_position
        boom_fraction = 1.0
        last_target_position = target.global_position
        last_physics_position = target.global_position
        movement_direction_z = 0
        tracking_mode = "RECENTER"

func impact(strength := 0.08) -> void:
    impact_left = maxf(impact_left, minf(strength, 0.12))

func _process(delta: float) -> void:
    if not is_instance_valid(target) or delta <= 0:
        return
    tracking_mode = "RECENTER" if transitioning else ("FALL" if target.fall_elapsed > 0 or not target.running and target.position.y < 0 else ("IMPACT" if target.hit_recovery_left > 0 else "FOLLOW"))
    var actual := target.global_position
    var displacement := actual - last_target_position
    last_target_position = actual
    if absf(displacement.z) > 0.00001:
        movement_direction_z = signf(displacement.z)
    var desired := follow_anchor(actual) + OFFSET
    var rate := recovery_rate if transitioning else follow_rate
    var weight := 1.0 - exp(-rate * delta)
    var next := follow_position.lerp(desired, weight)
    next.y = lerpf(follow_position.y, desired.y, 1.0-exp(-(recovery_rate if transitioning else vertical_rate)*delta))
    # A stale smoothed target must not pull forward during a real backward hit
    # (or backward while the avatar moves forward). Hold until it catches up.
    if not transitioning and movement_direction_z != 0:
        if (next.z-follow_position.z)*movement_direction_z < 0:
            next.z = follow_position.z
    follow_position = next
    if transitioning and follow_position.distance_to(desired) < 0.75:
        transitioning = false
    # Shake is only a transient rendered offset, never fed into follow history.
    clock += delta
    var rendered := follow_position
    if impact_left > 0:
        rendered.x += sin(clock*67.0)*impact_left*.25
        rendered.y += sin(clock*53.0)*impact_left*.15
        impact_left = maxf(0,impact_left-delta)
    # Keep the near-camera volume clear, including bars. Collision shortening
    # never overwrites the smoothed follow position, preventing feedback drift.
    var origin := actual + Vector3.UP*.7
    var motion := rendered-origin
    # Do not start the camera sphere inside the bar touching the capsule. A
    # zero-length safe sweep there used to place the lens inside the avatar.
    # At this distance the established elevated boom clears low sweep bars;
    # farther terrain/obstacles still shorten it to keep the lens clear.
    var length := motion.length()
    var clearance := minf(contact_clearance_distance, length)
    var probe_origin := origin + motion.normalized()*clearance
    boom_query.transform = Transform3D(Basis.IDENTITY,probe_origin)
    boom_query.motion = rendered-probe_origin
    var space := get_world_3d().direct_space_state
    var fractions := space.cast_motion(boom_query)
    var safe := (clearance+(length-clearance)*fractions[0])/maxf(length,.01)
    ray.from = probe_origin
    ray.to = rendered
    var obstruction := space.intersect_ray(ray)
    if not obstruction.is_empty() and motion.length() > .01:
        safe = minf(safe,maxf(0,(origin.distance_to(obstruction.position)-.25)/motion.length()))
    # Shorten immediately for safety; ease back out once the obstruction clears.
    boom_fraction = safe if safe < boom_fraction else lerpf(boom_fraction,safe,weight)
    global_position = origin + motion*boom_fraction

func is_recovery_ready() -> bool:
    if not is_instance_valid(target) or transitioning:
        return false
    if follow_position.distance_to(follow_anchor(target.global_position)+OFFSET) > 1.0:
        return false
    if global_position.distance_to(target.global_position+Vector3.UP*.7) < 3.0:
        return false
    # Check the whole capsule height, not just a single center point.
    var view := get_viewport().get_visible_rect()
    var safe := view.grow(-minf(view.size.x,view.size.y)*.04)
    for height in [.05, target.BODY_HEIGHT]:
        var point: Vector3 = target.global_position+Vector3.UP*height
        if is_position_behind(point) or not safe.has_point(unproject_position(point)):
            return false
    return true
