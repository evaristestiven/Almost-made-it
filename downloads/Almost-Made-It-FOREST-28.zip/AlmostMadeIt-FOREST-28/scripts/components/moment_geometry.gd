extends RefCounted
# Read-only capsule clearance against the actual hazard shapes. Current bars
# rotate around Y; balls are spheres. Unsupported tilted/scaled shapes decline
# recognition rather than granting a false near miss. No collider is enlarged.
static func clearance(pose: Transform3D, shape: Shape3D, foot: Vector3, radius: float, height: float) -> float:
    if not pose.basis.get_scale().is_equal_approx(Vector3.ONE): return INF
    var bottom := foot+Vector3.UP*radius
    var top := foot+Vector3.UP*(height-radius)
    if shape is SphereShape3D:
        var closest := Vector3(foot.x,clampf(pose.origin.y,bottom.y,top.y),foot.z)
        return closest.distance_to(pose.origin)-shape.radius-radius
    if absf(pose.basis.y.dot(Vector3.UP)) < .999: return INF
    var axis := Vector3(foot.x,clampf(pose.origin.y,bottom.y,top.y),foot.z)
    var local := pose.affine_inverse()*axis
    var nearest: Vector3
    if shape is BoxShape3D:
        var extent: Vector3 = shape.size*.5
        nearest = local.clamp(-extent,extent)
    elif shape is CylinderShape3D:
        var flat := Vector2(local.x,local.z).limit_length(shape.radius)
        nearest = Vector3(flat.x,clampf(local.y,-shape.height*.5,shape.height*.5),flat.y)
    else: return INF
    return local.distance_to(nearest)-radius

static func reach(shape: Shape3D) -> float:
    if shape is SphereShape3D: return shape.radius
    if shape is BoxShape3D: return shape.size.length()*.5
    if shape is CylinderShape3D: return maxf(shape.radius,shape.height*.5)
    return 0.0
