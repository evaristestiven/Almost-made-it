extends AnimatableBody3D
@export var travel := Vector3(1.2, 0, 0)
@export var period := 4.0
var origin := Vector3.ZERO
var elapsed := 0.0
func _ready() -> void:
    origin = position
    sync_to_physics = true
    process_physics_priority = -1
    collision_layer = 1
    collision_mask = 0
    add_to_group("moving_platforms")
func _physics_process(delta: float) -> void:
    if not is_finite(period) or period < 0.1 or not travel.is_finite():
        position = origin
        return
    elapsed += delta
    position = origin + travel * sin(elapsed * TAU / period)
