extends Control
const INK := Color("173549")
const PAPER := Color("fff9ed")
var level_number := 1
var level_name := "First Steps"
var level_label: Label
var next_button: Button
var selection_button: Button
var time_label: Label
var controls: Control
var coin_label: Label
var falls_label: Label
var progress_label: Label
var progress_bar: ProgressBar
var notice: Label
var panel: PanelContainer
var overlay: ColorRect
var title: Label
var detail: Label
var resume_button: Button
var restart_button: Button
var pause_button: Button
var height_slider: HSlider
var options: VBoxContainer
var menu_open := false
var completed := false
var notified := 0.0
var last_values := Vector3i(-1, -1, -1)
var top: HBoxContainer
var stack: VBoxContainer
var contents: VBoxContainer
var results: HBoxContainer
var result_coins: Label
var result_falls: Label
var menu_tween: Tween
var menu_layout_queued := false

func style(color: Color, radius := 22, border := Color.TRANSPARENT) -> StyleBoxFlat:
    var box := StyleBoxFlat.new()
    box.bg_color = color
    box.set_corner_radius_all(radius)
    box.content_margin_left = 22
    box.content_margin_right = 22
    box.content_margin_top = 14
    box.content_margin_bottom = 14
    box.border_color = border
    box.set_border_width_all(1 if border.a > 0.0 else 0)
    return box

func label(text: String, font_size: int, color := INK) -> Label:
    var node := Label.new()
    node.text = text
    node.add_theme_font_size_override("font_size", font_size)
    node.add_theme_color_override("font_color", color)
    node.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return node

func button(text: String) -> Button:
    var node := Button.new()
    node.text = text
    node.custom_minimum_size = Vector2(0, 68)
    node.add_theme_font_size_override("font_size", 24)
    node.add_theme_color_override("font_color", INK)
    node.add_theme_color_override("font_hover_color", INK)
    node.add_theme_stylebox_override("normal", style(Color("ffc35b"), 20))
    node.add_theme_stylebox_override("hover", style(Color("ffdc85"), 20))
    node.add_theme_stylebox_override("pressed", style(Color("e8a942"), 20))
    return node

func build(input: Control) -> void:
    controls = input
    process_mode = Node.PROCESS_MODE_ALWAYS
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    top = HBoxContainer.new()
    top.add_theme_constant_override("separation", 14)
    add_child(top)
    var chip := PanelContainer.new()
    chip.add_theme_stylebox_override("panel", style(PAPER))
    top.add_child(chip)
    coin_label = label("COINS  0", 24)
    chip.add_child(coin_label)
    chip = PanelContainer.new()
    chip.add_theme_stylebox_override("panel", style(Color(0.09, 0.2, 0.27, 0.85)))
    top.add_child(chip)
    falls_label = label("FALLS  0", 24, PAPER)
    chip.add_child(falls_label)
    var spacer := Control.new()
    spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(spacer)
    pause_button = button("II")
    pause_button.custom_minimum_size = Vector2(70, 68)
    top.add_child(pause_button)
    controls.register_button("pause", pause_button)
    stack = VBoxContainer.new()
    stack.add_theme_constant_override("separation", 8)
    add_child(stack)
    var row := HBoxContainer.new()
    stack.add_child(row)
    level_label = label("01  /  FIRST STEPS",18,PAPER)
    row.add_child(level_label)
    var fill := Control.new()
    fill.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(fill)
    progress_label = label("0%", 18, PAPER)
    row.add_child(progress_label)
    progress_bar = ProgressBar.new()
    progress_bar.custom_minimum_size.y = 9
    progress_bar.show_percentage = false
    progress_bar.add_theme_stylebox_override("background", style(Color(1, 1, 1, 0.2), 5))
    progress_bar.add_theme_stylebox_override("fill", style(Color("ffc35b"), 5))
    stack.add_child(progress_bar)
    notice = label("DRAG TO MOVE. JUMP THE GAPS.", 22, PAPER)
    notice.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    add_child(notice)
    overlay = ColorRect.new()
    overlay.color = Color(0.03, 0.1, 0.16, 0.7)
    overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(overlay)
    panel = PanelContainer.new()
    panel.add_theme_stylebox_override("panel", style(PAPER, 30))
    overlay.add_child(panel)
    contents = VBoxContainer.new()
    contents.add_theme_constant_override("separation", 18)
    panel.add_child(contents)
    title = label("TAKE A BREATHER", 30)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    contents.add_child(title)
    detail = label("Run paused. Keep Going resumes.\nTry Again restarts the whole run.", 23)
    detail.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    # Explicit short lines avoid autowrap's width/minimum-height feedback during
    # first container layout (which left the old card over 1,500 pixels tall).
    detail.clip_text = true
    contents.add_child(detail)
    results = HBoxContainer.new()
    results.add_theme_constant_override("separation", 14)
    contents.add_child(results)
    result_coins = result_card("COINS", "0 / 5", Color("ffdfa0"))
    result_falls = result_card("FALLS", "0", Color("d7eae7"))
    results.hide()
    time_label = label("",20)
    time_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    time_label.hide()
    contents.add_child(time_label)
    resume_button = button("KEEP GOING")
    contents.add_child(resume_button)
    controls.register_button("resume", resume_button)
    restart_button = button("TRY AGAIN")
    restart_button.add_theme_stylebox_override("normal", style(Color("d7eae7")))
    contents.add_child(restart_button)
    controls.register_button("restart", restart_button)
    next_button = button("NEXT LEVEL")
    next_button.hide()
    contents.add_child(next_button)
    controls.register_button("next",next_button)
    selection_button = button("LEVEL SELECTION")
    selection_button.hide()
    contents.add_child(selection_button)
    selection_button.add_theme_stylebox_override("normal",style(Color("d7eae7"),20))
    controls.register_button("selection",selection_button)
    options = VBoxContainer.new()
    options.add_child(label("JUMP BUTTON HEIGHT", 17))
    height_slider = HSlider.new()
    height_slider.min_value = 0.7
    height_slider.max_value = 0.88
    height_slider.step = 0.01
    height_slider.value = controls.jump_anchor.y
    height_slider.custom_minimum_size = Vector2(0, 48)
    options.add_child(height_slider)
    contents.add_child(options)
    height_slider.value_changed.connect(func(value: float) -> void:
        controls.jump_anchor.y = value
        controls.update_layout()
    )
    controls.register_touch_blocker(top)
    controls.register_touch_blocker(stack)
    controls.register_touch_blocker(overlay)
    overlay.hide()
    contents.minimum_size_changed.connect(queue_menu_layout)
    resized.connect(layout)
    layout()

func layout() -> void:
    if controls == null or top == null:
        return
    controls.update_layout()
    var safe: Rect2 = controls.safe_rect
    if not safe.has_area(): return
    top.position = safe.position
    top.size = Vector2(safe.size.x, 70)
    stack.position = safe.position + Vector2(0, 84)
    stack.size = Vector2(safe.size.x, 60)
    notice.position = safe.position + Vector2(0, 160)
    notice.size = Vector2(safe.size.x, 72)
    var panel_width := minf(520, safe.size.x - 24)
    var title_size := mini(30, int((panel_width-44)/9.0))
    var detail_size := mini(23, int((panel_width-44)/19.0)) if not completed else mini(23, int((panel_width-44)/12.0))
    if title.get_theme_font_size("font_size") != title_size:
        title.add_theme_font_size_override("font_size", title_size)
    if detail.get_theme_font_size("font_size") != detail_size:
        detail.add_theme_font_size_override("font_size", detail_size)
    # Size to actual content, including style margins; never reuse a transient
    # oversized container height or center using a requested, clamped size.
    panel.size = Vector2(panel_width, panel.get_combined_minimum_size().y)
    panel.position = safe.get_center() - panel.size * 0.5

func result_card(caption: String, value: String, color: Color) -> Label:
    var card := PanelContainer.new()
    card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    card.add_theme_stylebox_override("panel", style(color, 20))
    results.add_child(card)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 6)
    card.add_child(column)
    var heading := label(caption, 17)
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    column.add_child(heading)
    var amount := label(value, 38)
    amount.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    column.add_child(amount)
    return amount

func queue_menu_layout() -> void:
    if menu_layout_queued: return
    menu_layout_queued = true
    call_deferred("settle_menu_layout")

func settle_menu_layout() -> void:
    menu_layout_queued = false
    layout()

func configure_level(number: int, name: String) -> void:
    level_number = number
    level_name = name
    level_label.text = "%02d  /  %s" % [number,name.to_upper()]

func update_stats(coins: int, falls: int, progress: int) -> void:
    var values := Vector3i(coins, falls, progress)
    if values == last_values:
        return
    last_values = values
    coin_label.text = "COINS  %d" % coins
    falls_label.text = "FALLS  %d" % falls
    progress_label.text = "%d%%" % progress
    progress_bar.value = progress

func notify(text: String) -> void:
    notice.text = text
    notified = 2.0
    notice.modulate.a = 1.0

func show_pause() -> void:
    menu_open = true
    title.text = "TAKE A BREATHER"
    next_button.hide()
    time_label.hide()
    selection_button.show()
    results.hide()
    restart_button.text = "TRY AGAIN"
    detail.text = "Run paused. Keep Going resumes.\nTry Again restarts the whole run."
    resume_button.show()
    options.show()
    overlay.show()
    controls.gameplay_enabled = false
    controls.clear_input()
    controls.queue_redraw()
    layout()

func hide_pause() -> void:
    menu_open = false
    overlay.hide()
    controls.gameplay_enabled = not completed
    controls.clear_input()
    controls.queue_redraw()

func show_win(coins: int, falls: int) -> void:
    completed = true
    menu_open = true
    title.text = "YOU MADE IT!"
    detail.text = "%02d / %s" % [level_number,level_name.to_upper()]
    var owner_game := get_parent().get_parent().get_parent()
    var seconds: float = owner_game.completed_seconds
    time_label.text = "TIME  %d:%05.2f" % [int(seconds/60),fmod(seconds,60)]
    time_label.show()
    selection_button.show()
    next_button.visible = level_number < 10
    if level_number < 10:
        contents.move_child(next_button,contents.get_children().find(restart_button))
        restart_button.add_theme_stylebox_override("normal",style(Color("d7eae7"),20))
    if level_number == 10: detail.text += "\nTHE BEGINNING COMPLETE!"
    result_coins.text = "%d / 5" % coins
    result_falls.text = str(falls)
    results.show()
    restart_button.text = "REPLAY"
    restart_button.add_theme_stylebox_override("normal", style(Color("ffc35b"), 20))
    resume_button.hide()
    options.hide()
    pause_button.hide()
    overlay.show()
    controls.gameplay_enabled = false
    controls.clear_input()
    controls.queue_redraw()
    layout()
    queue_menu_layout()
    # Fade only: layout and touch hitboxes stay stationary throughout the reveal.
    if menu_tween != null: menu_tween.kill()
    panel.modulate.a = 0.0
    menu_tween = create_tween()
    menu_tween.tween_property(panel, "modulate:a", 1.0, 0.18)

func _process(delta: float) -> void:
    if notified > 0.0 and not get_tree().paused:
        notified = maxf(0.0, notified - delta)
        notice.modulate.a = minf(1.0, notified * 2.0)
