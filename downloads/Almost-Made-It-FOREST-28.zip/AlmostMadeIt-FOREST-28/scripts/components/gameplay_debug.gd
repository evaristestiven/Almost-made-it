extends Node
# Explicit development opt-in only. Normal HUD and controls are untouched.
const BUILD_ID := "ALMOST-15"
var game: Node3D
var label: Label
var build_label: Label
var panel: PanelContainer
var header_button: Button
var expanded := false
var captured_fingers: Dictionary = {}
var contact_count := 0
var native_entries := 0
var decisions := 0
var accepted_hits := 0
var last_obstacle := "none"
var last_result := "NONE"
var last_reason := "no contact yet"
var last_handler_called := false
var last_decision_frame := 0
var last_detected_frame := 0
var last_detected_obstacle := "none"
var player_fingerprint := ""
var spinner_fingerprint := ""
var camera_fingerprint := ""
var recent: Array[String] = []
var refresh_left := 0.0
var last_event := ""
var last_event_frame := -100

func setup(owner_game: Node3D) -> void:
    game = owner_game
    process_mode = Node.PROCESS_MODE_ALWAYS
    var layer := CanvasLayer.new()
    layer.layer = 20
    add_child(layer)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(.025,.055,.08,.92)
    style.border_color = Color("ffd36a")
    style.set_border_width_all(1)
    style.set_corner_radius_all(8)
    style.content_margin_left = 8
    style.content_margin_right = 8
    style.content_margin_top = 5
    style.content_margin_bottom = 5
    header_button = Button.new()
    header_button.name = "DevelopmentDiagnosticsToggle"
    header_button.mouse_filter = Control.MOUSE_FILTER_IGNORE
    header_button.focus_mode = Control.FOCUS_NONE
    header_button.add_theme_stylebox_override("normal",style)
    layer.add_child(header_button)
    build_label = Label.new()
    build_label.add_theme_font_size_override("font_size",18)
    build_label.add_theme_color_override("font_color",Color("ffd36a"))
    build_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    build_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    build_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    header_button.add_child(build_label)
    build_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    panel = PanelContainer.new()
    panel.name = "CompactGameplayDiagnostics"
    panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.add_theme_stylebox_override("panel",style)
    layer.add_child(panel)
    label = Label.new()
    label.add_theme_font_size_override("font_size",18)
    label.add_theme_color_override("font_color",Color.WHITE)
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.clip_text = true
    label.custom_minimum_size.y = 124
    panel.add_child(label)
    panel.hide()
    player_fingerprint = FileAccess.get_sha256("res://scripts/player.gd").left(8)
    spinner_fingerprint = FileAccess.get_sha256("res://scripts/spinner.gd").left(8)
    camera_fingerprint = FileAccess.get_sha256("res://scripts/components/follow_camera.gd").left(8)
    game.controls.resized.connect(layout)
    # Preserve opt-in shape outlines for explicit developer debugging, without
    # adding them to the compact mobile acceptance package by default.
    if game.gameplay_debug or "--gameplay-debug" in OS.get_cmdline_user_args():
        outline_body(game.runner,Color.GREEN)
        for hazard in game.get_tree().get_nodes_in_group("hazards"):
            outline_body(hazard,Color.RED)
    refresh()

func layout() -> void:
    var safe: Rect2 = game.controls.safe_rect
    var free: Rect2 = game.hud.top.get_child(2).get_global_rect()
    var width := minf(230,free.size.x)
    header_button.visible = width >= 130
    header_button.size = Vector2(maxf(130,width),60)
    header_button.position = Vector2(free.position.x+(free.size.x-width)*.5,safe.position.y+5)
    # Expanded details stay within the existing upper HUD band. The default
    # collapsed badge uses only the header's empty spacer, never the course.
    panel.custom_minimum_size = Vector2(minf(680,safe.size.x),140)
    panel.size = panel.custom_minimum_size
    panel.position = safe.position+Vector2(0,76)

func toggle() -> void:
    expanded = not expanded
    panel.visible = expanded
    refresh()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and not event.canceled and header_button.visible and header_button.get_global_rect().has_point(event.position):
            if not captured_fingers.has(event.index):
                captured_fingers[event.index] = true
                toggle()
            get_viewport().set_input_as_handled()
        elif captured_fingers.has(event.index):
            captured_fingers.erase(event.index)
            get_viewport().set_input_as_handled()
    elif event is InputEventMouseButton and event.device != InputEvent.DEVICE_ID_EMULATION and event.button_index == MOUSE_BUTTON_LEFT:
        if header_button.visible and header_button.get_global_rect().has_point(event.position):
            if event.pressed: toggle()
            get_viewport().set_input_as_handled()
    elif event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_F3:
        toggle()
        get_viewport().set_input_as_handled()

func line(mesh: ImmediateMesh, a: Vector3, b: Vector3) -> void:
    mesh.surface_add_vertex(a)
    mesh.surface_add_vertex(b)

func outline_body(body: CollisionObject3D, color: Color) -> void:
    for collider in body.get_children():
        if not collider is CollisionShape3D:
            continue
        var mesh := ImmediateMesh.new()
        var material := StandardMaterial3D.new()
        material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        material.albedo_color = color
        material.no_depth_test = true
        mesh.surface_begin(Mesh.PRIMITIVE_LINES,material)
        if collider.shape is BoxShape3D:
            var half: Vector3 = collider.shape.size * 0.5
            for axis in range(3):
                for a in [-1.0,1.0]:
                    for b in [-1.0,1.0]:
                        var first := Vector3.ZERO
                        first[axis] = -half[axis]
                        first[(axis+1)%3] = a * half[(axis+1)%3]
                        first[(axis+2)%3] = b * half[(axis+2)%3]
                        var second := first
                        second[axis] = half[axis]
                        line(mesh,first,second)
        elif collider.shape is CylinderShape3D:
            var radius: float = collider.shape.radius
            var h: float = collider.shape.height * 0.5
            for i in range(24):
                var angle := i*TAU/24
                var next := (i+1)*TAU/24
                for y in [-h,h]:
                    line(mesh,Vector3(cos(angle)*radius,y,sin(angle)*radius),Vector3(cos(next)*radius,y,sin(next)*radius))
                if i%6 == 0:
                    line(mesh,Vector3(cos(angle)*radius,-h,sin(angle)*radius),Vector3(cos(angle)*radius,h,sin(angle)*radius))
        elif collider.shape is CapsuleShape3D:
            var radius: float = collider.shape.radius
            var centers: float = collider.shape.height*0.5-radius
            for axis in [0,2]:
                for side in [-1.0,1.0]:
                    var a := Vector3.ZERO
                    a[axis] = side*radius
                    a.y = -centers
                    var b := a
                    b.y = centers
                    line(mesh,a,b)
                for upper in [false,true]:
                    for i in range(16):
                        var a := Vector3.ZERO
                        var b := Vector3.ZERO
                        var angle := i*PI/16
                        var next := (i+1)*PI/16
                        a[axis] = cos(angle)*radius
                        b[axis] = cos(next)*radius
                        a.y = (centers+sin(angle)*radius)*(1 if upper else -1)
                        b.y = (centers+sin(next)*radius)*(1 if upper else -1)
                        line(mesh,a,b)
        mesh.surface_end()
        var drawing := MeshInstance3D.new()
        drawing.name = "DebugCollisionOutline"
        drawing.mesh = mesh
        drawing.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        collider.add_child(drawing)

func record_contact(hazard: AnimatableBody3D, accepted: bool, rejection_reason := "", handler_called := true) -> void:
    decisions += 1
    if accepted: accepted_hits += 1
    last_obstacle = "%s z%.1f" % [hazard.name,hazard.position.z]
    last_result = "ACCEPTED" if accepted else "REJECTED"
    last_reason = "none" if accepted else rejection_reason
    last_handler_called = handler_called
    last_decision_frame = Engine.get_physics_frames()
    var reason := last_result + ": " + last_reason
    var event := "bar z=%.1f %s %s" % [hazard.position.z,hazard.contact_source,reason]
    var frame := Engine.get_physics_frames()
    if event == last_event and frame-last_event_frame < 12:
        return
    last_event = event
    last_event_frame = frame
    recent.push_front("%d: %s" % [frame,event])
    if recent.size() > 6:
        recent.pop_back()
    refresh()

func refresh() -> void:
    layout()
    var runner = game.runner
    contact_count = 0
    native_entries = 0
    for hazard in game.get_tree().get_nodes_in_group("hazards"):
        contact_count += hazard.diagnostic_contact_count
        native_entries += hazard.diagnostic_native_entries
        if hazard.diagnostic_last_contact_frame > last_detected_frame:
            last_detected_frame = hazard.diagnostic_last_contact_frame
            last_detected_obstacle = "%s %.0f" % [hazard.name,hazard.position.z]
    var state: String = game.RunState.keys()[game.state]
    var checkpoint_text := "START" if game.checkpoint_index < 0 else str(game.checkpoint_index+1)
    var trigger := "OFF" if not game.finish_area.monitoring else ("IN" if game.finish_area.overlaps_body(runner) else "OUT")
    build_label.text = BUILD_ID+"\n"+state+("  ▾" if expanded else "  ▸")
    var protection := "OFF" if runner.spawn_protection_left <= 0 else "%.2fs" % runner.spawn_protection_left
    var camera_state: String = game.camera.tracking_mode
    var lag: float = game.camera.follow_position.distance_to(game.camera.follow_anchor(runner.position)+game.camera.OFFSET)
    label.text = "State:%s | CP:%s | protection:%s | camera:%s\nv:(%.1f,%.1f,%.1f)  k:(%.1f,%.1f,%.1f) recovery:%.2f\nContact:%s f%d %s | finish:%s\nImpulse:(%.1f,%.1f,%.1f) f%d | lag:%.2f | ready:%s\nP %s S %s C %s" % [
        state,checkpoint_text,protection,camera_state,
        runner.velocity.x,runner.velocity.y,runner.velocity.z,runner.knockback.x,runner.knockback.y,runner.knockback.z,runner.hit_recovery_left,
        last_detected_obstacle,last_detected_frame,last_result,trigger+"/"+game.finish_status(),
        runner.last_impulse.x,runner.last_impulse.y,runner.last_impulse.z,runner.last_impact_frame,lag,game.camera.is_recovery_ready(),
        player_fingerprint,spinner_fingerprint,camera_fingerprint]

func _process(delta: float) -> void:
    refresh_left -= delta
    if refresh_left <= 0 and is_instance_valid(game):
        refresh_left = .1
        refresh()

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        captured_fingers.clear()
