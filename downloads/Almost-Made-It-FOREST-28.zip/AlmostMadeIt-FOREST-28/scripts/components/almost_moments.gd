extends Node
# Per-actor, read-only physics observer. Never writes player motion, transforms,
# collision masks, time scale or race results. A future server can own one node
# per actor and consume versioned events; this is not a replay/video recorder.
signal moment_detected(event: Dictionary)
signal feedback_requested(kind: String, words: String, at: Vector3)
signal performance_bonus_awarded(actor_id: String, points: int, event_id: String)
const GEOMETRY = preload("res://scripts/components/moment_geometry.gd")
@export var enabled := true
@export var authoritative := true
@export var performance_bonus_enabled := false
@export_range(.05,.6) var near_margin := .32
@export var exit_margin := .55
@export var contact_safety_margin := .025
@export var separation_hold := .12
@export var minimum_hazard_travel := .18
@export var minimum_recovery_impulse := 3.0
@export var stable_landing_time := .22
@export var recovery_window := 3.0
@export var maximum_events := 64
@export var maximum_file_bytes := 32768
@export var maximum_bonus := 60
@export var persist_highlights := true
var save_path := "user://almost_moments/latest.json"
var actor_id := "local-player"
var run_id := ""
static var local_run_serial := 0
var game: Node3D
var player: CharacterBody3D
var hazards: Array[Dictionary] = []
var events: Array[Dictionary] = []
var performance_points := 0
var tick := 0
var active_seconds := 0.0
var sequence := 0
var candidate: Dictionary = {}
var awarded: Dictionary = {}
var noticed: Dictionary = {}
var bonus_claims: Dictionary = {}
var finish_recorded := false
var last_bonus_progress := -INF
var last_feedback := -INF
var last_notable_time := -INF
var last_grounded := true
var jumped_since_ground := false
var previous_position := Vector3.ZERO
var previous_velocity := Vector3.ZERO
var support_query: PhysicsRayQueryParameters3D
var persistence_error := ""
var support_source := ""
var configured := false

func setup(owner_game: Node3D, identity := "local-player", identity_run := "") -> void:
    if configured: return
    configured = true
    game = owner_game
    player = game.runner
    actor_id = identity
    local_run_serial += 1
    run_id = identity_run if not identity_run.is_empty() else "L%d-R%d" % [game.level_number,local_run_serial]
    process_physics_priority = 3 # After native player movement and contacts.
    previous_position = player.global_position
    last_grounded = player.is_on_floor()
    support_query = PhysicsRayQueryParameters3D.new()
    support_query.collision_mask = 1
    support_query.exclude = [player.get_rid()]
    for hazard in get_tree().get_nodes_in_group("hazards"):
        var shapes: Array[CollisionShape3D] = []
        var reach := 0.0
        for child in hazard.get_children():
            if child is CollisionShape3D and child.shape != null:
                shapes.append(child)
                reach = maxf(reach,GEOMETRY.reach(child.shape)+child.position.length())
        hazards.append({"body":hazard,"shapes":shapes,"reach":reach,"previous":hazard.global_transform,
            "episode":false,"minimum":INF,"contact":false,"clear":0.0,"travel":0.0})
    player.hit.connect(_on_hit)
    player.jumped.connect(_on_jump)
    game.state_changed.connect(_on_state)
    game.level_completed.connect(_on_complete)

func _active() -> bool:
    return enabled and is_instance_valid(player) and game.state == game.RunState.PLAYING and player.running and not player.recovery_hold and not get_tree().paused and game.route.position_valid

func note_contact(hazard: Node3D, body: Node3D) -> void:
    if body != player: return
    for item in hazards:
        if item.body == hazard: item.contact = true; return

func _reset_passes() -> void:
    for item in hazards:
        item.episode = false
        item.contact = false
        item.minimum = INF
        item.travel = 0.0
        item.clear = 0.0
        if is_instance_valid(item.body): item.previous = item.body.global_transform

func _physics_process(delta: float) -> void:
    if not _active():
        candidate.clear()
        _reset_passes()
        previous_position = player.global_position
        last_grounded = player.is_on_floor()
        return
    tick += 1
    active_seconds += delta
    var position_now := player.global_position
    # Any unannounced teleport is not an escape or recovery. The owner already
    # invalidates its route; this extra guard also protects observer reuse.
    if previous_position.distance_to(position_now) > 24*delta+.08:
        candidate.clear()
        _reset_passes()
        previous_position = position_now
        return
    if player.invulnerable_left <= 0 and player.grace_left <= 0:
        for item in hazards: _observe_pass(item,delta)
    else: _reset_passes()
    _observe_recovery(delta)
    previous_position = position_now
    previous_velocity = player.velocity
    last_grounded = player.is_on_floor()
    if last_grounded: jumped_since_ground = false

func _observe_pass(item: Dictionary, delta: float) -> void:
    var body: Node3D = item.body
    if not is_instance_valid(body): return
    var current := body.global_transform
    var previous: Transform3D = item.previous
    var rotation_travel := previous.basis.get_rotation_quaternion().angle_to(current.basis.get_rotation_quaternion())*float(item.reach)
    var body_travel := previous.origin.distance_to(current.origin)+rotation_travel
    var player_travel := previous_position.distance_to(player.global_position)
    var budget := ceili((body_travel+player_travel)/.07)
    # Fast motion outside our bounded sampling budget cannot earn a near miss.
    # Collision resolution remains entirely with the existing physics solver.
    if budget>48:
        item.episode = false
        item.previous = current
        item.contact = false
        return
    var minimum := INF
    var end_clearance := INF
    if current.origin.distance_to(player.global_position+Vector3.UP*.675) <= float(item.reach)+2+body_travel+player_travel:
        for index in range(maxi(1,budget)+1):
            var fraction := float(index)/maxi(1,budget)
            var pose := previous.interpolate_with(current,fraction)
            var at := previous_position.lerp(player.global_position,fraction)
            for shape in item.shapes:
                if shape.disabled: continue
                var gap: float = GEOMETRY.clearance(pose*shape.transform,shape.shape,at,player.BODY_RADIUS,player.BODY_HEIGHT)
                minimum = minf(minimum,gap)
                if index==maxi(1,budget): end_clearance=minf(end_clearance,gap)
    if minimum <= near_margin:
        if not item.episode:
            item.episode = true
            item.minimum = minimum
            item.travel = 0.0
            # note_contact may have run before the episode opened this tick.
            item.clear = 0.0
        item.minimum = minf(float(item.minimum),minimum)
    if item.episode:
        item.travel += body_travel
        item.contact = item.contact or body.contact_this_tick or minimum<=contact_safety_margin
        item.clear = float(item.clear)+delta if end_clearance>maxf(near_margin+.1,exit_margin) else 0.0
        if item.clear>=maxf(.08,separation_hold):
            var id := obstacle_id(body)
            if not item.contact and float(item.minimum)>contact_safety_margin and float(item.travel)>=minimum_hazard_travel and not noticed.has(id) and game.route.on_route:
                noticed[id] = true # Once per obstacle per run, even after death.
                var event := _record("near_miss",id,{"clearance":snappedf(item.minimum,.001),"extreme":item.minimum<.12,"obstacle_position":vector_data(body.global_position),"obstacle_rotation":vector_data(body.rotation)})
                _celebrate("near_miss","ALMOST!",event)
            item.episode = false
            item.minimum = INF
            item.contact = false
            item.travel = 0.0
            item.clear = 0.0
    elif end_clearance>maxf(near_margin+.1,exit_margin):
        item.contact = false
    item.previous = current

func obstacle_id(body: Node3D) -> String:
    return str(body.get_meta("moment_id",str(body.get_path())))

func _on_hit() -> void:
    if not _active() or player.last_impact_frame!=Engine.get_physics_frames(): return
    var body := get_node_or_null(NodePath(player.last_obstacle)) as Node3D
    if body == null: return
    var id := obstacle_id(body)
    _record("impact",id,{"impulse":vector_data(player.last_impulse),"normal":vector_data(player.last_normal),"relative":vector_data(player.last_relative),"contact_point":vector_data(body.contact_point),"obstacle_position":vector_data(body.global_position)})
    # No steering/drag/friction parameter is changed here. The established motor
    # resumes after its existing .25s hit reaction, independently of recognition.
    if Vector2(player.last_impulse.x,player.last_impulse.z).length()>=minimum_recovery_impulse:
        candidate = {"source":id,"kind":"knockback","start":active_seconds,"position":player.global_position,"input":player.move_input,
            "danger":false,"reaction":false,"reaction_delay":-1.0,"stable":0.0,"stable_start":-1.0,"unsupported":0.0,"probe":0.0}

func _on_jump() -> void:
    jumped_since_ground = true
    if not candidate.is_empty() and active_seconds-float(candidate.start)>.015: _react()

func _react() -> void:
    if candidate.reaction: return
    candidate.reaction = true
    candidate.reaction_delay = active_seconds-float(candidate.start)

func _support_count() -> int:
    var count := 0
    support_source = ""
    var at := player.global_position
    # A half-metre footprint demands a safe landing, not a single edge ray.
    for offset in [Vector3.ZERO,Vector3(.50,0,0),Vector3(-.50,0,0),Vector3(0,0,.50),Vector3(0,0,-.50)]:
        support_query.from = at+offset+Vector3.UP*.12
        support_query.to = at+offset-Vector3.UP*.25
        var result := player.get_world_3d().direct_space_state.intersect_ray(support_query)
        if not result.is_empty() and result.normal.dot(Vector3.UP)>=cos(player.floor_max_angle):
            count+=1
            if offset==Vector3.ZERO: support_source=obstacle_id(result.collider)
    return count

func _observe_recovery(delta: float) -> void:
    var grounded := player.is_on_floor()
    if candidate.is_empty() and last_grounded and not grounded and not jumped_since_ground and player.velocity.y<=0 and player.spawn_protection_left<=0:
        candidate = {"source":"edge:%d" % int(game.route.current_distance/5),"kind":"edge","start":active_seconds,"position":previous_position,"input":player.move_input,
            "danger":false,"reaction":false,"reaction_delay":-1.0,"stable":0.0,"stable_start":-1.0,"unsupported":0.0,"probe":0.0}
    if candidate.is_empty(): return
    if candidate.kind=="edge" and not candidate.danger and not grounded and player.global_position.y<float(candidate.position.y)+.05 and Vector2(player.velocity.x,player.velocity.z).length()>2.5 and _support_count()<=1:
        candidate.danger = true
    if active_seconds-float(candidate.start)>recovery_window or player.spawn_protection_left>0:
        candidate.clear()
        return
    if not grounded:
        candidate.stable_start = -1.0
        candidate.stable = 0.0
        candidate.unsupported += delta
        if candidate.unsupported>=.04 and (candidate.kind=="knockback" or player.global_position.y<float(candidate.position.y)+.05): candidate.danger = true
    var input_now: Vector2 = player.move_input
    if input_now.length()>.2 and input_now.distance_to(candidate.input)>.3: _react()
    candidate.probe -= delta
    if candidate.probe>0: return
    var interval := .05
    candidate.probe = interval
    var supports := _support_count() if grounded else 0
    if candidate.kind=="knockback" and grounded and supports<=3 and player.velocity.length()>2.5: candidate.danger = true
    if grounded and supports==5 and candidate.danger and candidate.reaction and player.hit_recovery_left<=0 and game.route.on_route:
        if candidate.stable_start<0: candidate.stable_start=active_seconds
        candidate.stable=active_seconds-float(candidate.stable_start)
    else:
        candidate.stable = 0.0
        candidate.stable_start = -1.0
    if float(candidate.stable)<maxf(.15,stable_landing_time): return
    var id: String = candidate.source
    if not awarded.has(id):
        awarded[id] = true
        var event := _record("clutch_recovery",id,{"cause":candidate.kind,"landing_surface":support_source,"reaction_seconds":snappedf(candidate.reaction_delay,.001),"recovery_seconds":snappedf(active_seconds-float(candidate.start),.001),"displacement":vector_data(player.global_position-candidate.position)})
        _award_bonus(event)
        _celebrate("clutch","WHAT A SAVE!",event)
    candidate.clear()

func _award_bonus(event: Dictionary) -> void:
    if not _active() or not authoritative or not performance_bonus_enabled or performance_points>=maximum_bonus or bonus_claims.has(event.id): return
    # A fresh source alone is insufficient: require new legitimate course travel.
    if game.route.furthest_distance<last_bonus_progress+4: return
    var amount := mini(10 if float(event.reaction_seconds)<=.35 else 5,maximum_bonus-performance_points)
    bonus_claims[event.id] = true
    performance_points += amount
    last_bonus_progress = game.route.furthest_distance
    event["performance_bonus"] = amount
    performance_bonus_awarded.emit(actor_id,amount,event.id)

func _celebrate(kind: String, words: String, event: Dictionary) -> void:
    last_notable_time = game.elapsed_seconds
    if kind=="near_miss" and active_seconds-last_feedback<1.0: return
    last_feedback = active_seconds
    if kind=="clutch" and int(event.get("performance_bonus",0))>0:
        words += " +%d SKILL" % int(event.performance_bonus)
    feedback_requested.emit(kind,words,player.global_position)

static func vector_data(value: Vector3) -> Array:
    return [snappedf(value.x,.001),snappedf(value.y,.001),snappedf(value.z,.001)]

func _record(kind: String, source: String, details: Dictionary = {}) -> Dictionary:
    sequence += 1
    var event := {"id":"%s/%s/%d" % [run_id,actor_id,sequence],"actor":actor_id,"tick":tick,"run_seconds":snappedf(game.elapsed_seconds,.001),
        "kind":kind,"source":source,"checkpoint":game.checkpoint_index,"falls":game.deaths,"input":[snappedf(player.move_input.x,.001),snappedf(player.move_input.y,.001)],"position":vector_data(player.global_position),"velocity":vector_data(player.velocity),"progress":snappedf(game.route.current_distance,.001)}
    event.merge(details)
    if events.size()>=clampi(maximum_events,1,128): events.pop_front()
    events.append(event)
    moment_detected.emit(event.duplicate(true))
    return event

func _on_state(_previous: int, current: int) -> void:
    if current==game.RunState.PAUSED: return # Physics clock and candidates freeze.
    if current==game.RunState.PLAYING: return
    _reset_passes()
    candidate.clear()
    if current==game.RunState.DYING and enabled:
        _record("fall","course",{"fall":game.deaths,"incoming":vector_data(previous_velocity)})
    if current==game.RunState.TRANSITIONING: flush_highlights()

func _on_complete(coins: int, falls: int) -> void:
    if not enabled or finish_recorded: return
    finish_recorded = true
    _record("finish","finish_zone",{"coins":coins,"falls":falls,"dramatic":game.elapsed_seconds-last_notable_time<=5})
    flush_highlights()

func snapshot() -> Dictionary:
    return {"schema":1,"run":run_id,"actor":actor_id,"level_scene":game.scene_file_path,"physics_hz":Engine.physics_ticks_per_second,
        "performance_points":performance_points,"events":events.duplicate(true)}

func flush_highlights() -> bool:
    if not enabled or not authoritative or not persist_highlights or events.is_empty(): return true
    var data := snapshot()
    var json := JSON.stringify(data)
    while json.to_utf8_buffer().size()>clampi(maximum_file_bytes,2048,32768) and not data.events.is_empty():
        data.events.pop_front()
        json = JSON.stringify(data)
    if json.to_utf8_buffer().size()>clampi(maximum_file_bytes,2048,32768):
        persistence_error = "envelope_too_large"
        return false
    var directory := save_path.get_base_dir()
    if DirAccess.make_dir_recursive_absolute(directory)!=OK:
        persistence_error = "directory"
        return false
    var file := FileAccess.open(save_path+".tmp",FileAccess.WRITE)
    if file == null:
        persistence_error = "open"
        return false
    file.store_string(json)
    file.flush()
    var error := file.get_error()
    file.close()
    if error!=OK or DirAccess.rename_absolute(save_path+".tmp",save_path)!=OK:
        persistence_error = "write_or_rename"
        return false
    persistence_error = ""
    return true
