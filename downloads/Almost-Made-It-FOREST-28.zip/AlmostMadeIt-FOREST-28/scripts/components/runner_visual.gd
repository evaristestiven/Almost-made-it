extends Node3D
# All animation is confined to this visual child, never the physics capsule.
var body: MeshInstance3D
var eyes: Array[Node3D] = []
var arms: Array[Node3D] = []
var feet: Array[Node3D] = []
var mouth: Node3D
var state := "idle"
var clock := 0.0
var reaction := 0.0
var landing := 0.0
var facing := 0.0
var palette: Dictionary = {}

func material(color: String) -> StandardMaterial3D:
    if palette.has(color):
        return palette[color]
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(color)
    mat.roughness = 0.75
    palette[color] = mat
    return mat

func ball(parent: Node3D, at: Vector3, radius: float, color: String, stretch := Vector3.ONE) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 16
    mesh.rings = 8
    node.mesh = mesh
    node.position = at
    node.scale = stretch
    node.material_override = material(color)
    parent.add_child(node)
    return node

func _ready() -> void:
    name = "MiloVisual"
    body = MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.43
    capsule.height = 1.25
    capsule.radial_segments = 16
    capsule.rings = 8
    body.mesh = capsule
    body.position.y = 0.72
    body.material_override = material("21b7ad")
    add_child(body)
    # Cream muzzle, dark eyes, coral cheeks, and an amber tuft.
    ball(self, Vector3(0, 0.91, -0.37), 0.34, "fff1d6", Vector3(1.0, 0.85, 0.38))
    for side in [-1.0, 1.0]:
        ball(self, Vector3(side * 0.31, 1.29, 0), 0.14, "168b88", Vector3(1, 1.35, 0.8))
        var eye := Node3D.new()
        eye.position = Vector3(side * 0.14, 0.97, -0.47)
        add_child(eye)
        ball(eye, Vector3.ZERO, 0.085, "ffffff", Vector3(1, 1.18, 0.48))
        ball(eye, Vector3(0, 0, -0.039), 0.047, "173549", Vector3(1, 1.12, 0.4))
        ball(eye, Vector3(-0.013, 0.017, -0.058), 0.014, "ffffff")
        eyes.append(eye)
        ball(self, Vector3(side * 0.25, 0.82, -0.43), 0.063, "ff907e", Vector3(1, 0.55, 0.3))
        var arm := Node3D.new()
        arm.position = Vector3(side * 0.4, 0.85, 0)
        add_child(arm)
        ball(arm, Vector3(side * 0.045, -0.18, 0), 0.12, "168b88", Vector3(0.8, 1.75, 0.85))
        ball(arm, Vector3(side * 0.045, -0.32, 0), 0.1, "fff1d6")
        arms.append(arm)
        var foot := ball(self, Vector3(side * 0.21, 0.12, -0.06), 0.15, "ffc35b", Vector3(1, 0.8, 1.45))
        feet.append(foot)
    mouth = ball(self, Vector3(0, 0.81, -0.487), 0.067, "173549", Vector3(1, 0.45, 0.3))
    ball(self, Vector3(0, 1.37, 0.03), 0.11, "ffc35b", Vector3(0.85, 1.5, 0.7))
    ball(self, Vector3(0, 0.61, 0.39), 0.18, "168b88", Vector3(0.9, 0.9, 1.2))

func react(kind: String) -> void:
    if kind == "landing":
        landing = 1.0
    elif kind in ["hit", "fail"]:
        reaction = 0.5

func animate(delta: float, velocity: Vector3, grounded: bool, enabled: bool) -> void:
    clock += delta
    reaction = maxf(0.0, reaction - delta)
    landing = maxf(0.0, landing - delta * 6.0)
    if reaction > 0.0:
        state = "reaction"
    elif not grounded:
        state = "jumping" if velocity.y > 0.0 else "falling"
    elif enabled and Vector2(velocity.x, velocity.z).length() > 1.0:
        state = "running"
    else:
        state = "idle"
    var desired_scale := Vector3.ONE
    if state == "jumping":
        desired_scale = Vector3(0.96, 1.08, 0.96)
    elif state == "falling":
        desired_scale = Vector3(0.98, 1.04, 0.98)
    desired_scale += Vector3(0.12, -0.2, 0.12) * landing
    scale = scale.lerp(desired_scale, 1.0 - exp(-18.0 * delta))
    var gait := sin(clock * 19.0) if state == "running" else sin(clock * 2.5) * 0.12
    for i in range(2):
        var sign_side := -1.0 if i == 0 else 1.0
        arms[i].rotation.x = gait * sign_side * 0.65 if grounded else -0.65
        feet[i].position.z = -0.06 + gait * sign_side * 0.07
        feet[i].position.y = 0.12 + maxf(0.0, gait * sign_side) * 0.04 if grounded else 0.17
        eyes[i].scale.y = 0.35 if reaction > 0.0 else (1.2 if state == "falling" else 1.0)
    mouth.scale.y = 1.1 if state in ["falling", "reaction"] else 0.45
    var desired_yaw := atan2(-velocity.x, -velocity.z) if enabled and velocity.length_squared() > 0.1 else 0.0
    # Celebrate toward the camera when stopped on the finish platform.
    if not enabled and grounded and reaction <= 0.0:
        desired_yaw = PI
    facing = lerp_angle(facing, desired_yaw, 1.0 - exp(-9.0 * delta))
    rotation.y = facing
    rotation.z = lerpf(rotation.z, clampf(-velocity.x * 0.017, -0.16, 0.16), 1.0 - exp(-12.0 * delta))

func reset_pose() -> void:
    scale = Vector3.ONE
    rotation = Vector3.ZERO
    reaction = 0.0
    landing = 0.0
    facing = 0.0
