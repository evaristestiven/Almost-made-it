extends Node3D
signal sound_triggered(kind: String)
const SOUND_PATHS := {
    "near_miss": "res://audio/almost.wav", "clutch": "res://audio/clutch.wav",
    "jump": "res://audio/jump.wav", "landing": "res://audio/landing.wav",
    "coin": "res://audio/coin.wav", "checkpoint": "res://audio/checkpoint.wav",
    "hit": "res://audio/hit.wav", "fail": "res://audio/fail.wav",
    "respawn": "res://audio/respawn.wav", "win": "res://audio/win.wav"
}
var streams: Dictionary = {}
var voices: Array[AudioStreamPlayer] = []
var voice_index := 0
var effects: Array[Node3D] = []
var colors := {"coin": Color("ffc35b"), "checkpoint": Color("83ffcd"), "hit": Color("ff817b"), "win": Color("ffc35b"), "near_miss": Color("fff1a9"), "clutch": Color("83ffcd")}

func _ready() -> void:
    for kind in SOUND_PATHS:
        streams[kind] = load(SOUND_PATHS[kind])
    for i in range(4):
        var voice := AudioStreamPlayer.new()
        voice.volume_db = -18.0
        add_child(voice)
        voices.append(voice)

func play(kind: String, at: Vector3) -> void:
    sound_triggered.emit(kind)
    if streams.has(kind) and DisplayServer.get_name() != "headless":
        var voice: AudioStreamPlayer = voices[voice_index]
        voice.stop()
        voice.stream = streams[kind]
        voice.play()
        voice_index = (voice_index + 1) % voices.size()
    if kind in ["near_miss", "clutch", "jump", "landing", "coin", "checkpoint", "hit", "respawn", "win"]:
        burst(at, colors.get(kind, Color("fff1d6")), kind == "win")

func burst(at: Vector3, color: Color, celebration := false) -> void:
    # A capped, one-shot CPU particle batch; no expensive bloom or GPU shader.
    if effects.size() >= 6:
        var old: Node3D = effects.pop_front()
        if is_instance_valid(old):
            old.queue_free()
    var particles := CPUParticles3D.new()
    particles.amount = 16 if celebration else 7
    particles.one_shot = true
    particles.lifetime = 0.75 if celebration else 0.35
    particles.explosiveness = 1.0
    particles.direction = Vector3.UP
    particles.spread = 75.0
    particles.initial_velocity_min = 1.0
    particles.initial_velocity_max = 3.0 if celebration else 1.7
    particles.gravity = Vector3(0, -7, 0)
    particles.scale_amount_min = 0.04
    particles.scale_amount_max = 0.09
    var mesh := SphereMesh.new()
    mesh.radial_segments = 8
    mesh.rings = 4
    mesh.radius = 1.0
    mesh.height = 2.0
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mesh.material = mat
    particles.mesh = mesh
    particles.position = at + Vector3(0, 0.18, 0)
    add_child(particles)
    effects.append(particles)
    particles.emitting = true
    particles.finished.connect(func() -> void:
        effects.erase(particles)
        particles.queue_free()
    )

func _exit_tree() -> void:
    for voice in voices:
        voice.stop()
        voice.stream = null
    streams.clear()
