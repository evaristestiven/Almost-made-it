extends Node3D
# Static scenery is batched by material. Only six lightweight landmark rotors
# animate; they have no physics and never impersonate a walkable surface.
var batches: Dictionary = {}
var materials: Dictionary = {}
var living: Array[Node3D] = []
var clock := 0.0
var theme: Dictionary

func material(color: String) -> StandardMaterial3D:
    if not materials.has(color):
        var mat := StandardMaterial3D.new()
        mat.albedo_color = Color(color)
        mat.roughness = .85
        materials[color] = mat
    return materials[color]

func box(at: Vector3, size: Vector3, color: String) -> void:
    if not batches.has(color): batches[color] = []
    batches[color].append(Transform3D(Basis.from_scale(size),at))

func text(at: Vector3, words: String, scale_value := .004) -> void:
    var sign := Label3D.new()
    sign.text = words
    sign.font_size = 56
    sign.pixel_size = scale_value
    sign.position = at
    sign.modulate = Color("fff6df")
    sign.outline_modulate = Color("173d57")
    sign.outline_size = 12
    sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    add_child(sign)

func ring(at: Vector3, radius: float, color: String) -> void:
    # Segmented rings are kept well outside the playable envelope.
    for i in range(16):
        var angle := i*TAU/16.0
        var point := at+Vector3(cos(angle)*radius,sin(angle)*radius,0)
        box(point,Vector3(.4,.4,.35),color)

func rotor(at: Vector3, color: String, vertical := false) -> void:
    var pivot := Node3D.new()
    pivot.position = at
    pivot.set_meta("vertical",vertical)
    add_child(pivot)
    living.append(pivot)
    for i in range(4):
        var blade := MeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = Vector3(.35,2.7,.12)
        mesh.material = material(color)
        blade.mesh = mesh
        blade.rotation.z = i*PI*.5
        blade.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        pivot.add_child(blade)

func decorate(game: Node3D) -> void:
    name = "AdventureScenery"
    theme = game.level_data.theme
    var number: int = game.level_number
    for platform in game.get_tree().get_nodes_in_group("platforms"):
        var size: Vector3 = platform.get_child(0).mesh.size
        var center: Vector3 = platform.position
        var top := center.y+size.y*.5
        for side in [-1.0,1.0]:
            box(Vector3(center.x+side*(size.x*.5-.12),top+.014,center.z),Vector3(.16,.028,size.z-.4),theme.accent)
            box(Vector3(center.x+side*(size.x*.5-.1),top-.34,center.z),Vector3(.2,.12,size.z),theme.side)
        # Tiny inset diamonds indicate the real route, never an invisible wall.
        for i in range(int(size.z/3.0)):
            box(Vector3(center.x,top+.009,center.z+size.z*.5-1.6-i*3),Vector3(.12,.018,.65),"fff6df")
        box(Vector3(center.x,top-1.1,center.z),Vector3(size.x*.75,.28,size.z*.92),theme.side)
    # Island silhouettes and landmarks scale with the actual course length.
    var count := ceili(absf(game.finish_z)/12.0)
    for i in range(count):
        var side := -1.0 if i%2 == 0 else 1.0
        var at := Vector3(side*(11.5+(i%3)*2),-2.8,2-i*12)
        box(at,Vector3(4,.8,5),theme.side)
        box(at+Vector3(0,.45,0),Vector3(4.2,.2,5.2),theme.top)
        landmark(at+Vector3(0,.6,0),number,i)
    for i in range(3):
        var z := lerpf(1.0,game.finish_z+6,i/2.0)
        var x := -6.5 if i%2 == 0 else 6.5
        box(Vector3(x,1.3,z),Vector3(.12,2.6,.12),theme.side)
        box(Vector3(x,2.6,z),Vector3(3.8,.75,.16),theme.side)
        text(Vector3(x,2.6,z+.1),theme.sections[i],.0025)
        # Pennant trails provide rhythm between sections without obstructing play.
        for j in range(3):
            box(Vector3(x,2.2-j*.12,z+1+j*.7),Vector3(.7,.24,.09),theme.accent)
    text(Vector3(0,3.2,7.5),theme.intro.replace("|","\n"),.0033)
    # The return mailbox/beacon is the story's destination, framing the real area.
    for side in [-1.0,1.0]:
        box(Vector3(game.finish_x+side*4.2,1.75,game.finish_z),Vector3(.28,3.5,.3),theme.accent)
    box(Vector3(game.finish_x,3.5,game.finish_z),Vector3(8.7,.65,.35),theme.side)
    for i in range(16):
        box(Vector3(game.finish_x-4+i*.53,.016,game.finish_z),Vector3(.49,.03,.6),"fff6df" if i%2 == 0 else theme.side)
    text(Vector3(game.finish_x,3.5,game.finish_z+.21),"FINISH",.006)
    if number == 10:
        for side in [-1,1]:
            var at := Vector3(side*7,3,game.finish_z-5)
            box(at,Vector3(1.2,8,1.2),theme.side)
            ring(at+Vector3(0,4,0),1.7,theme.accent)
            rotor(at+Vector3(0,4,0),theme.accent)
        # Each safe checkpoint is a section handover, not another hazard.
        for i in range(game.level_data.checkpoints.size()):
            var point: Vector2 = game.level_data.checkpoints[i]
            text(Vector3(-5.8,2.6,point.y),["CROSSING","FOUNDRY","AQUEDUCT","ORBIT","SUMMIT"][i],.003)
    for i in range(game.level_data.extensions.size()):
        if i == 0:
            var p: Array = game.level_data.extensions[i]
            text(Vector3(p[0],p[4]+2.4,p[1]),"BONUS WAY",.0022)
    flush()

func landmark(at: Vector3, number: int, index: int) -> void:
    match number:
        1,2:
            # Orchard islands, mailboxes and wind-powered delivery vanes.
            box(at+Vector3(0,1,0),Vector3(.45,2,.45),"877c75")
            box(at+Vector3(0,2.2,0),Vector3(2.3,1.4,2.3),theme.top)
            box(at+Vector3(1,.8,1),Vector3(.8,.5,.65),theme.accent)
            if index%2 == 0: rotor(at+Vector3(0,4,0),theme.accent)
        3:
            box(at+Vector3(0,2,0),Vector3(1,4,1),theme.side)
            ring(at+Vector3(0,3.2,0),1.8,theme.accent)
            if index%2 == 0: rotor(at+Vector3(0,3.2,.2),theme.accent)
        4:
            # Cargo cranes reveal why the moving ferries are here.
            box(at+Vector3(-1,2,0),Vector3(.35,4,.35),theme.accent)
            box(at+Vector3(.3,4,0),Vector3(3,.3,.4),theme.accent)
            box(at+Vector3(1.5,2.8,0),Vector3(.06,2.4,.06),theme.side)
            box(at+Vector3(1.5,1.5,0),Vector3(1.3,1,1.3),theme.top)
            if index%2 == 0: rotor(at+Vector3(-1,4.6,0),theme.accent)
        5:
            for side in [-1,1]: box(at+Vector3(side*1.4,1.5,0),Vector3(.15,3,.15),theme.accent)
            ring(at+Vector3(0,2.7,0),1.9,theme.accent)
            if index%2 == 0: rotor(at+Vector3(0,2.7,.2),theme.top)
        6:
            # Open foundry frames and suspended bell counterweights.
            for side in [-1,1]: box(at+Vector3(side*1.3,2,0),Vector3(.4,4,.4),theme.side)
            box(at+Vector3(0,4,0),Vector3(3.2,.5,1.4),theme.accent)
            box(at+Vector3(0,2.5,0),Vector3(1,1.6,1),theme.top)
            if index%2 == 0: rotor(at+Vector3(0,4.8,0),theme.accent)
        7:
            for side in [-1,1]: box(at+Vector3(side*1.4,1.4,0),Vector3(.7,2.8,1.2),theme.side)
            box(at+Vector3(0,2.8,0),Vector3(3.5,.45,1.2),theme.accent)
            # Broken cap stones remain decorative, beyond any jump route.
            box(at+Vector3(1.7,.2,1.3),Vector3(.8,.4,.7),theme.accent)
            if index%2 == 0: rotor(at+Vector3(-1.4,3.5,0),theme.accent)
        8:
            box(at+Vector3(0,2,0),Vector3(1,4,1),theme.side)
            ring(at+Vector3(0,3.6,0),2,theme.accent)
            if index%2 == 0: rotor(at+Vector3(0,3.6,.2),theme.accent,true)
        9:
            box(at+Vector3(0,2,0),Vector3(.55,4,.55),theme.side)
            ring(at+Vector3(0,3.5,0),1.8,theme.accent)
            if index%2 == 0: rotor(at+Vector3(0,3.5,.2),theme.accent)
        10:
            box(at+Vector3(0,2,0),Vector3(1.4,4,1.4),theme.side)
            for h in range(3): box(at+Vector3(0,1+h,0),Vector3(2.6,.25,2.6),theme.accent)
            if index%2 == 0: rotor(at+Vector3(0,4,0),theme.accent)

func _process(delta: float) -> void:
    clock += delta
    for i in range(living.size()):
        # Cosmetic motion is fixed to elapsed time and freezes with the game tree.
        living[i].rotation.z = clock*(.3+i*.04)
        if living[i].get_meta("vertical"): living[i].rotation.y = sin(clock*.35)*.3

func flush() -> void:
    for color in batches:
        var instance := MultiMeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = Vector3.ONE
        mesh.material = material(color)
        var multimesh := MultiMesh.new()
        multimesh.transform_format = MultiMesh.TRANSFORM_3D
        multimesh.mesh = mesh
        multimesh.instance_count = batches[color].size()
        for i in range(multimesh.instance_count): multimesh.set_instance_transform(i,batches[color][i])
        instance.multimesh = multimesh
        instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(instance)
    batches.clear()
