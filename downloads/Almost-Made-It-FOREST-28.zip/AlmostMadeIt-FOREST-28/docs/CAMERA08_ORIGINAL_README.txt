Almost Made It! — CAMERA-FOLLOW-08

Open this NEW folder's project.godot in Xogot. The project name is
Almost Made It! CAMERA-FOLLOW-08. Let source assets import, then run main.tscn.
Do not merge into an old Xogot import or assume an existing copy synchronized.

Only the camera gameplay script changed. Avatar/obstacle physics, controls,
normal HUD/graphics and level layout are unchanged. The normal project's
optional physics overlay remains disabled by default; no HUD badge was added.

Camera position now follows actual avatar displacement with exponential
smoothing, restrained jump framing, falling visibility and collision-aware boom.
The prior independent-forward-scroll allegation was not reproduced with a truly
stationary body: existing autorun actually advances the avatar. Autorun is not
changed in this camera-only update.

See docs/CAMERA08_REPAIR_REPORT.txt for before/after evidence, exact changed
files, all executed cases, import/device checklist and remaining limitations.
CAMERA08_MANIFEST.json identifies the exact camera/source files in this archive.

Xogot/iPhone/iPad verification has NOT been executed here.
