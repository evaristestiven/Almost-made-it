Almost Made It! — PHYSICS-TEST-07 — screenshot follow-up

Import this folder's project.godot as a NEW project in Xogot. Confirm the
PHYSICS-TEST-07 banner and P d9a63813 / S 78a02ff2. Full hashes are in
PHYSICS07_MANIFEST.json.
Wait for source assets/audio to import before launching res://main.tscn.

This fixes confirmed TEST-06 velocity double-counting, false resting support
hits and mismatched impact diagnostics. All three bars retain their real solid
colliders and the same graphics, dimensions, speeds and controls.

Read docs/PHYSICS07_SCREENSHOT_REPAIR.txt for exact before/after evidence,
changed files, screenshot comparisons and executed tests. Current test commands
are in tests/PHYSICS07_TESTS.txt. Older TEST-06 documents are historical.

The named archive explicitly enables the temporary diagnostic overlay. Normal
source defaults it OFF. For release set debug/collision_test/enabled=false.
Xogot/iPhone behavior of THIS new build still needs device confirmation.
