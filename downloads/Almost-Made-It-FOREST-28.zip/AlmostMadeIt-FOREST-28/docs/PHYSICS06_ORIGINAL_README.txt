Almost Made It! — PHYSICS-TEST-06

This is the identified DEVELOPMENT collision test build. Open this folder's
project.godot in Xogot and confirm PHYSICS-TEST-06 appears above the controls.
An earlier TEST-05 or Phase-4 project is a different build.

The bars are now solid AnimatableBody3D bodies, with exact existing bar/hub
shapes. Protection suppresses additional impact impulses, never solid collision.
Player movement remains CharacterBody3D, with separate control/external velocity.

Read docs/PHYSICS06_REPORT.txt for architecture, equations, executed test results,
limitations and changed files. Read docs/PHYSICS06_XOGOT_TESTING.txt for import
and device verification. Raw logs and source fingerprints are included.

Actual physics was run headlessly in Godot 4.6.3. Xogot/iPhone testing has NOT
been performed here. The project's declared 4.7 version and Compatibility
renderer have been preserved. Device confirmation is required before expansion.

Normal source project defaults diagnostics OFF. The named test ZIP explicitly
sets debug/collision_test/enabled=true. Set it false before a normal release.
