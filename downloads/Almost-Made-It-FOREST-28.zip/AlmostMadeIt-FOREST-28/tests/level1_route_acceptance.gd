extends "res://tests/first_steps_course.gd"
var samples:=0
var offscreen:=0
var camera_rotation_changed:=false
var original_basis:=Basis.IDENTITY
var scene_changes:=0
var capture:=false
var route_wins:=0

func step() -> void:
    await super.step()
    if not capture or not is_instance_valid(game):return
    if game.state!=game.RunState.PLAYING:return
    samples+=1
    var actor:Vector3=game.runner.position+Vector3.UP*.8
    var screen:Vector2=game.camera.unproject_position(actor)/Vector2(root.size)
    if game.camera.is_position_behind(actor) or screen.x<0 or screen.x>1 or screen.y<.18 or screen.y>1:offscreen+=1
    camera_rotation_changed=camera_rotation_changed or not game.camera.global_basis.is_equal_approx(original_basis)

func run() -> void:
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--physics-hz="):hz=arg.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second=hz;root.size=Vector2i(720,1280)
    campaign=root.get_node("Campaign");campaign.save_path="user://acceptance26-route.json"
    campaign.clear_progress();campaign.dirty=false
    scene_changed.connect(func()->void:scene_changes+=1)
    level=1;await fresh()
    original_basis=game.camera.global_basis
    var changes:=scene_changes
    game.level_completed.connect(func(_coins:int,_falls:int)->void:route_wins+=1)
    var start_frame:=Engine.get_physics_frames()
    capture=true;await traverse();capture=false
    check(scene_changes==changes,"all five areas traverse without a scene change or loading transition")
    check(Engine.get_physics_frames()-start_frame>hz*120 and offscreen==0,"avatar stays inside gameplay camera and below top HUD throughout route (%d/%d outside)"%[offscreen,samples])
    check(not camera_rotation_changed,"camera preserves established angle through curves and elevations")
    check(game.coins==5 and game.completed_coins==5 and game.completed_falls==game.deaths,"victory results match physical run and all five pickups")
    check(route_wins==1 and game.completion_count==1,"full uninterrupted run emits exactly one victory")
    var state:=Vector3(game.runner.position)
    var elapsed:float=game.elapsed_seconds
    for i in range(20):game._try_finish();game._respawn()
    await seconds(.5)
    check(game.runner.position==state and game.elapsed_seconds==elapsed and route_wins==1,"completed gameplay freezes and duplicate requests cannot change results")
    print("ACCEPTANCE_ROUTE hz=",hz," samples=",samples," offscreen=",offscreen," scene_changes_during_run=",scene_changes-changes," victories=",route_wins," elapsed=",game.completed_seconds)
    game.restart();await scene_changed;game=current_scene;await seconds(.5)
    var at:Vector3=game.runner.position;var camera_at:Vector3=game.camera.position
    await seconds(15)
    check(game.state==game.RunState.PLAYING and game.runner.position.distance_to(at)<.001 and game.camera.position.distance_to(camera_at)<.001,"restart returns to safe stationary avatar and camera for 15 seconds")
    print("LEVEL1 ROUTE ACCEPTANCE RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
