extends "res://tests/world1_regression.gd"
var output := "user://adventure-evidence"
func capture(label: String) -> void:
    await RenderingServer.frame_post_draw
    var pixels := root.get_texture().get_image()
    check(not pixels.is_empty() and pixels.save_png(output+"/"+label+".png") == OK,"actual rendered viewport: "+label)
func run() -> void:
    root.size = Vector2i(720,1280)
    root.position = Vector2i.ZERO
    DirAccess.make_dir_recursive_absolute(output)
    var previews := [Vector3(-2,0,-17),Vector3(-1.5,0,-15),Vector3(3.5,0,-20),Vector3(0,0,-27),Vector3(2,0,-25),Vector3(3.3,0,-32),Vector3(0,0,-32),Vector3(2,0,-34),Vector3(2,0,-39),Vector3(0,0,-98)]
    for number in range(1,11):
        current_level = number
        await fresh()
        for i in range(5): await step()
        await capture("level-%02d-opening" % number)
        fixture(previews[number-1]+Vector3.UP*.08) # Composition preview, not a traversal claim.
        for i in range(5): await step()
        await capture("level-%02d-signature" % number)
    game.queue_free()
    await step()
    print("ADVENTURE RENDERED RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
