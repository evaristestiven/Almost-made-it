extends "res://tests/swipe_movement.gd"
var output := "user://swipe12-evidence"
func capture(name: String) -> void:
    await RenderingServer.frame_post_draw
    var pixels := root.get_texture().get_image()
    check(not pixels.is_empty() and pixels.save_png(output+"/"+name+".png") == OK,"captured real viewport: "+name)
func run() -> void:
    root.size = Vector2i(720,1280)
    root.position = Vector2i.ZERO
    DirAccess.make_dir_recursive_absolute(output)
    await fresh()
    await capture("idle-phone")
    var start: Vector3 = game.runner.position
    drag_direction(Vector2.UP)
    await seconds(.25)
    await capture("drag-phone")
    check(game.runner.position.z < start.z-1,"real rendered drag moves actual avatar")
    release()
    await seconds(.4)
    jump()
    await seconds(.15)
    release(2)
    await capture("jump-phone")
    root.size = Vector2i(1024,1366)
    for i in range(10): await step()
    await capture("tablet")
    game.queue_free()
    await step()
    print("SWIPE RENDERED RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
