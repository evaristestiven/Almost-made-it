extends "res://tests/solid_physics.gd"
# Optional rendered evidence: uses real startup scene, mesh and solid colliders.
# Outputs to user://phase6-evidence; no recording code executes in normal play.
var output := "user://phase6-evidence"
func capture(name: String) -> void:
    await RenderingServer.frame_post_draw
    var file := root.get_texture().get_image()
    require(not file.is_empty(),"rendered viewport produces pixels: "+name)
    require(file.save_png(output+"/"+name+".png") == OK,"saved rendered evidence: "+name)

func run() -> void:
    root.size = Vector2i(720,1280)
    root.position = Vector2i.ZERO
    DirAccess.make_dir_recursive_absolute(output)
    await fresh()
    fixture(Vector3(2.2,.02,-5))
    bar().rotation.y = -.5
    bar().spin_speed = 1.8
    game.camera.setup(game.runner)
    # A small captured sequence shows actual visible bar and avatar movement.
    var start: Vector3 = game.runner.position
    var accepted_at := -1
    var after_direction := 0.0
    var minimum_distance := 1000.0
    var total_frames := 120
    for i in range(total_frames):
        await frame()
        minimum_distance = minf(minimum_distance,game.camera.position.distance_to(game.runner.position+Vector3.UP*.7))
        if hits > 0 and accepted_at < 0: accepted_at = i
        if i%3 == 0: await capture("standing-%03d" % i)
        if accepted_at >= 0:
            after_direction = (game.runner.position-hit_position).dot(game.runner.last_normal)
    print("RENDERED_SWEEP_EVIDENCE start=%s end=%s hit=%s impulse=%s accepted=%d displacement=%.5f along_normal=%.5f" % [str(start),str(game.runner.position),str(hit_position),str(impulse),accepted_at,start.distance_to(game.runner.position),after_direction])
    require(minimum_distance >= 2.99,"contact never collapses camera lens into avatar")
    require(hits > 0 and start.distance_to(game.runner.position) > .1,"rendered real-level standing sweep physically displaces capsule")
    # Actual fall via touch, then capture the framed death and checkpoint return.
    await fresh()
    touch("right",1,true)
    for i in range(240):
        await frame()
        if game.state == game.RunState.DYING: break
    touch("right",1,false)
    await capture("fall")
    for i in range(240):
        await frame()
        if game.state == game.RunState.PLAYING: break
    await capture("respawn")
    # Legitimate overlap from a trusted nearby finish fixture, same live HUD.
    fixture(Vector3(0,.08,-74.4))
    game.runner.allow_forward = true
    game.camera.setup(game.runner)
    game.coins = 3
    game.deaths = 2
    for i in range(90):
        await frame()
        if game.won: break
    for i in range(20): await frame()
    await capture("victory-iphone")
    root.size = Vector2i(1024,1366)
    for i in range(20): await frame()
    await capture("victory-ipad")
    require(game.won and game.hud.result_coins.text == "3 / 5","rendered victory uses legitimate finish and actual results")
    game.queue_free()
    await frame()
    print("PHASE6 RENDERED RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
