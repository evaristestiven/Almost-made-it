extends "res://tests/swipe_movement.gd"
func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    await fresh()
    var start: Vector3 = game.runner.position
    finger(1,true,gesture_start())
    await seconds(1)
    check(game.controls.movement() == Vector2.ZERO and horizontal(game.runner.position-start).length() < .001,"touch-and-hold without dragging stays stationary")
    drag_to(1,game.controls.drag_origin+Vector2(0,-4)*game.controls.gesture_scale)
    await seconds(.2)
    check(game.controls.movement() == Vector2.ZERO,"sub-dead-zone drag cannot move avatar")
    release()
    # Freeze only the body for gesture-only tests: real input/camera/UI still run.
    game.runner.set_physics_process(false)
    var camera_start: Vector3 = game.camera.position
    for point in [Vector2(.15,.2),Vector2(.5,.4),Vector2(.7,.6)]:
        var origin: Vector2 = game.controls.movement_area.position+game.controls.movement_area.size*point
        finger(1,true,origin)
        check(game.controls.drag_origin.distance_to(origin) < .01 and game.controls.movement() == Vector2.ZERO,"gesture origin is the actual initial touch, not a fixed stick")
        drag_to(1,origin+Vector2(0,-96)*game.controls.gesture_scale)
        await seconds(.2)
        check(game.controls.movement().distance_to(Vector2.UP) < .001,"same drag works at different gameplay origins")
        release()
    check(game.camera.position.distance_to(camera_start) < .001,"screen drag alone never moves camera when actual avatar stays still")
    finger(1,true,gesture_start())
    for i in range(20):
        var axis := Vector2.UP if i%2 == 0 else Vector2.DOWN
        drag_direction(axis)
        check(game.controls.movement().distance_to(axis) < .001,"rapid direction reversal updates immediately, sample%d" % i)
    var held: Vector2 = game.controls.movement()
    await seconds(3)
    check(game.controls.movement() == held,"held drag maintains movement without repeated swipes")
    finger(5,true,gesture_start()+Vector2(40,0))
    drag_to(5,gesture_start()+Vector2(-180,0))
    check(game.controls.movement_finger == 1 and game.controls.movement() == held,"second movement finger cannot steal gesture ownership")
    release()
    check(game.controls.movement() == Vector2.ZERO and game.controls.movement_finger == -999,"owner release clears input without promoting an ignored finger")
    drag_to(5,gesture_start()+Vector2(180,0))
    check(game.controls.movement() == Vector2.ZERO,"ignored held finger cannot resurrect a released gesture")
    release(5)
    drag_direction(Vector2.UP)
    var canceled := InputEventScreenTouch.new()
    canceled.index = 1
    canceled.pressed = false
    canceled.canceled = true
    Input.parse_input_event(canceled)
    Input.flush_buffered_events()
    check(game.controls.movement() == Vector2.ZERO and game.controls.movement_finger == -999,"touch cancellation clears owner and vector")
    drag_direction(Vector2.RIGHT)
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    check(game.controls.movement() == Vector2.ZERO and game.controls.fingers.is_empty() and game.state == game.RunState.PAUSED,"focus loss clears touch ownership and pauses safely")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    await seconds(.1)
    check(game.controls.movement() == Vector2.ZERO,"focus return cannot revive stale drag")
    finger(1,true,game.hud.coin_label.get_global_rect().get_center())
    drag_to(1,gesture_start())
    check(game.controls.movement_finger == -999,"touch starting on HUD cannot become a movement gesture")
    release()
    finger(1,true,game.hud.pause_button.get_global_rect().get_center())
    release()
    check(game.state == game.RunState.PAUSED and game.controls.movement_finger == -999,"pause button cannot start movement")
    finger(1,true,gesture_start())
    drag_to(1,gesture_start()+Vector2(0,-200))
    check(game.controls.movement() == Vector2.ZERO,"modal backdrop excludes gameplay drag")
    release()
    finger(1,true,game.hud.height_slider.get_global_rect().get_center())
    drag_to(1,game.hud.height_slider.get_global_rect().get_center()+Vector2(50,0))
    check(game.controls.movement_finger == -999,"menu slider is never interpreted as movement")
    release()
    finger(3,true,game.hud.resume_button.get_global_rect().get_center())
    release(3)
    check(game.state == game.RunState.PLAYING and game.controls.movement() == Vector2.ZERO,"actual resume button restores idle input")
    for screen in [Vector2i(320,568),Vector2i(390,844),Vector2i(720,1280),Vector2i(1290,2796),Vector2i(768,1024),Vector2i(1024,1366)]:
        root.size = screen
        for i in range(5): await step()
        var controls = game.controls
        finger(1,true,gesture_start())
        drag_to(1,controls.drag_origin+Vector2(48,0)*controls.gesture_scale)
        var expected: float = (48.0-controls.drag_dead_zone)/(controls.max_drag_distance-controls.drag_dead_zone)
        check(absf(controls.movement().x-expected) < .001,"density-independent half drag matches analog magnitude: "+str(screen))
        drag_direction(Vector2(1,-1))
        check(absf(controls.movement().length()-1) < .001,"diagonal stays normalized: "+str(screen))
        release()
    game.controls.drag_sensitivity = 2.0
    finger(1,true,gesture_start())
    drag_to(1,game.controls.drag_origin+Vector2(0,-48)*game.controls.gesture_scale)
    check(game.controls.movement().distance_to(Vector2.UP) < .001,"configurable sensitivity scales full-speed distance")
    release()
    game.controls.drag_sensitivity = 1.0
    drag_direction(Vector2.UP)
    root.size = Vector2i(720,1280)
    for i in range(5): await step()
    check(game.controls.movement() == Vector2.ZERO and game.controls.movement_finger == -999,"resize safely cancels old-coordinate gesture")
    # No production joystick property or directional button remains.
    var fields: Array[String] = []
    for property in game.controls.get_property_list(): fields.append(property.name)
    check(not fields.has("joystick_center") and not fields.has("joystick_radius") and not game.controls.buttons.has("left") and not game.controls.buttons.has("right"),"no fixed invisible joystick or directional movement buttons remain")
    game.queue_free()
    await step()
    print("SWIPE GESTURES RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
