extends "res://tests/solid_physics.gd"
func run() -> void:
    var previous: bool = ProjectSettings.get_setting("debug/collision_test/enabled",false)
    ProjectSettings.set_setting("debug/collision_test/enabled",true)
    root.size = Vector2i(720,1280)
    await fresh()
    require(game.diagnostics != null and game.diagnostics.BUILD_ID == "PHASE6-10","identified mobile build shows physics overlay without console flags")
    for size in [Vector2i(720,1280),Vector2i(1290,2796),Vector2i(1024,1366)]:
        root.size = size
        for i in range(4): await frame()
        game.diagnostics.layout()
        for i in range(2): await frame()
        var panel: Rect2 = game.diagnostics.panel.get_global_rect()
        var jump := Rect2(game.controls.jump_center-Vector2.ONE*game.controls.jump_radius,Vector2.ONE*game.controls.jump_radius*2)
        var stick := Rect2(game.controls.joystick_center-Vector2.ONE*game.controls.joystick_radius,Vector2.ONE*game.controls.joystick_radius*2)
        require(not panel.intersects(jump) and not panel.intersects(stick) and game.controls.safe_rect.encloses(panel),"physics overlay fits safe area without covering controls: " + str(size))
    await fresh()
    touch("left",1,true)
    touch("jump",2,true)
    touch("jump",2,false)
    for i in range(2): await frame()
    require(game.runner.velocity.x < 0 and game.runner.velocity.y > 0,"multitouch steering persists after jump finger releases")
    touch("left",1,false)
    await fresh()
    for i in range(150):
        await frame()
        if hits: break
    game.diagnostics.refresh()
    require(game.diagnostics.accepted_hits > 0 and game.diagnostics.label.text.contains("Impulse:"),"overlay reports real accepted collision and physics fields")
    var accepted_normal: Vector3 = game.runner.last_normal
    var accepted_relative: Vector3 = game.runner.last_relative
    var accepted_frame: int = game.runner.last_impact_frame
    bar().contact_normal = -accepted_normal
    require(not game.runner.apply_bar_impact(bar()) and game.runner.last_normal == accepted_normal and game.runner.last_relative == accepted_relative and game.runner.last_impact_frame == accepted_frame,
        "rejected contact cannot overwrite the accepted impulse snapshot")
    print("VISIBLE_PHYSICS_DIAGNOSTICS\n",game.diagnostics.label.text)
    ProjectSettings.set_setting("debug/collision_test/enabled",false)
    await fresh()
    require(game.diagnostics == null,"production setting disables diagnostic processing and visuals")
    ProjectSettings.set_setting("debug/collision_test/enabled",previous)
    game.queue_free()
    await frame()
    print("SOLID DIAGNOSTICS RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
