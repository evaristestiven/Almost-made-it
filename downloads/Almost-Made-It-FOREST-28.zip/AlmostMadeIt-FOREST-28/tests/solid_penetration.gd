extends "res://tests/solid_physics.gd"
# Measures actual capsule-to-box separation in the complete playable level.
func box_separation(obstacle) -> float:
    var center: Vector3 = game.runner.position
    center.y = clampf(obstacle.position.y,center.y+game.runner.BODY_RADIUS,center.y+game.runner.BODY_HEIGHT-game.runner.BODY_RADIUS)
    var local: Vector3 = obstacle.global_transform.affine_inverse()*center
    var half: Vector3 = obstacle.get_child(0).mesh.size*.5
    return local.distance_to(local.clamp(-half,half))-game.runner.BODY_RADIUS

func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    for speed in [1.8,2.8,10.0]:
        await fresh()
        fixture(Vector3(2.2,.02,-5),true)
        bar().spin_speed = speed
        var minimum := 0.0
        for i in range(hz):
            await frame()
            minimum = minf(minimum, box_separation(bar()))
        print("PENETRATION_EVIDENCE hz=%d omega=%.1f deepest=%.5f" % [hz,speed,minimum])
        require(minimum > -.08,"rotating solid has no significant capsule penetration: " + str(speed))
    game.queue_free()
    await frame()
    print("SOLID PENETRATION RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
