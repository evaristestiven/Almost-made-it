extends "res://tests/sky_garden.gd"
func primary_trees(scenery:Node3D) -> Array:
    var result:Array=[]
    for entry in scenery.imported_trees:
        result.append([entry.model.transform,entry.model.scene_file_path,entry.mesh.mesh.surface_get_material(0).resource_path,entry.mesh.mesh.surface_get_material(1).resource_path])
    return result
func run() -> void:
    root.size=Vector2i(720,1280);current_level=1
    ProjectSettings.set_setting("visuals/starting_garden/enabled",false)
    raw(1,true)
    var original:=collision_snapshot()
    var scenery:Node3D=game.get_node("AdventureScenery")
    var outside:Array=scenery.outside_records.duplicate()
    var trees:=primary_trees(scenery)
    var rng_state:int=scenery.rng.state
    var environment:Environment=game.find_children("*","WorldEnvironment",true,false)[0].environment
    ProjectSettings.set_setting("visuals/starting_garden/enabled",true)
    raw(1,true);scenery=game.get_node("AdventureScenery")
    check(collision_snapshot()==original,"all course collision shapes/transforms/layers identical to previous build")
    check(scenery.outside_records==outside,"decorative mesh and beam placement outside Starting Garden unchanged")
    check(scenery.rng.state==rng_state,"private garden randomness leaves later scenery RNG unchanged")
    check(primary_trees(scenery)==trees,"all eight good imported trees retain transforms and original materials")
    check(scenery.find_children("*","CollisionObject3D",true,false).is_empty(),"new scenery adds no collision bodies or trigger areas")
    check(scenery.garden_trees.size()>2,"additional genuine tree clusters replace local basic trees")
    var scope:=true
    for bounds in scenery.garden_bounds:
        if bounds.position.z < -4.0 or bounds.end.z >9.0:
            print("OUT_OF_SCOPE ",bounds)
            scope=false
    check(scope,"complete new model bounds remain inside z=-4..9 Starting Garden")
    print("STARTING_GARDEN_BUDGETS ",JSON.stringify(scenery.garden_stats))
    check(scenery.garden_batches.size()==4 and scenery.garden_stats.instances<220,"four shared mesh batches keep added instance budget below 220")
    for entry in scenery.garden_trees:
        check(entry.model.scene_file_path.contains("CommonTree_") and entry.mesh.mesh.get_surface_count()==2,"native textured bark and leaf geometry: "+entry.model.name)
    for at in [Vector3(0,0,5),Vector3(0,0,2),Vector3(0,0,-2.8),Vector3(2,0,2),Vector3(-2,0,2),Vector3(0,1.5,2)]:
        var clear:=true
        for bounds in scenery.garden_bounds:
            if bounds.intersects_segment(at+Vector3(0,5.7,11),at+Vector3(0,.7,0))!=null:clear=false
        check(clear,"complete added model bounds clear camera/avatar line: "+str(at))
    for name in ["CommonTree_4","Plant_1","Rock_Medium_3","Pebble_Round_2","RockPath_Square_Thin"]:
        var model:PackedScene=load(scenery.ASSETS+name+".gltf")
        check(model!=null,"verified original glTF imports: "+name)
    for name in ["Leaves","Rocks_Diffuse","PathRocks_Diffuse"]:
        var map:Texture2D=load(scenery.ASSETS+name+".png")
        check(map!=null and maxf(map.get_width(),map.get_height())<=1024,"new texture import capped at 1024 with preserved source: "+name)
    scenery.set_quality(2)
    var high:int=scenery.garden_batches.filter(func(n):return n.name=="Starting_Plant_1")[0].multimesh.visible_instance_count
    scenery.set_quality(0)
    var low:int=scenery.garden_batches.filter(func(n):return n.name=="Starting_Plant_1")[0].multimesh.visible_instance_count
    var shadows_off:=true
    for entry in scenery.garden_trees:shadows_off=shadows_off and entry.mesh.cast_shadow==GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    check(low<high and shadows_off and not scenery.garden_fill.visible,"low quality reduces new groundcover density and disables extra light/shadows")
    scenery.set_quality(1)
    check(scenery.garden_fill.visible,"balanced quality restores local fill light")
    check(game.find_children("*","WorldEnvironment",true,false)[0].environment.background_mode==environment.background_mode,"global sky mode remains unchanged")
    await fresh();scenery=game.get_node("AdventureScenery")
    var before:float=scenery.garden_trees[0].model.rotation.z
    await seconds(.2)
    check(scenery.garden_trees[0].model.rotation.z!=before,"cosmetic imported tree wind advances during gameplay")
    game.set_paused(true);before=scenery.garden_trees[0].model.rotation.z
    await seconds(.2)
    check(scenery.garden_trees[0].model.rotation.z==before,"pause freezes new tree motion")
    game.set_paused(false)
    check(ProjectSettings.get_setting("application/run/main_scene")=="res://scenes/level_select.tscn","normal game startup retained")
    game.queue_free();await step()
    print("STARTING GARDEN RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
