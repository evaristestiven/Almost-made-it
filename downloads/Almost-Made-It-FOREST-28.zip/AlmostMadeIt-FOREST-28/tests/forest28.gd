extends "res://tests/sky_garden.gd"
func run() -> void:
    root.size=Vector2i(720,1280)
    ProjectSettings.set_setting("visuals/forest28/enabled",false);raw(1,true)
    var before:=collision_snapshot()
    ProjectSettings.set_setting("visuals/forest28/enabled",true);raw(1,true)
    check(collision_snapshot()==before,"pine integration changes no gameplay collisions")
    var scenery:Node3D=game.get_node("AdventureScenery")
    var species:Dictionary={}
    var supported:=true
    for entry in scenery.forest_roots:
        species[entry.name]=int(species.get(entry.name,0))+1
        if entry.name.begins_with("Pine"):
            supported=supported and absf(entry.root.y-(scenery.terrain_height(entry.root)-.025))<.01
    check(int(species.get("Pine_1",0))>10 and int(species.get("Pine_5",0))>10,"both verified pine variants appear in actual Level1 forest")
    check(int(species.get("CommonTree_3",0))>50 and int(species.get("CommonTree_4",0))>50,"existing detailed broadleaf forest is retained")
    check(supported,"all pine trunk roots connect to actual decorative terrain")
    for name in ["Pine_1","Pine_5"]:
        var source:Dictionary=scenery.source(name)
        var mesh:Mesh=source.mesh
        check(mesh.get_surface_count()==2,"separate imported bark/leaves surfaces "+name)
        var leaf:StandardMaterial3D=mesh.surface_get_material(1)
        var bark:StandardMaterial3D=mesh.surface_get_material(0)
        check(leaf.albedo_texture.resource_path.ends_with("Leaf_Pine_C.png") and leaf.transparency==BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR,"correct pine atlas and alpha mask "+name)
        check(leaf.albedo_texture.get_size()==Vector2(1024,1024),"mobile pine atlas import respects 1024px limit "+name)
        check(bark.normal_enabled and bark.albedo_texture.resource_path.ends_with("Bark_NormalTree.png") and bark.normal_texture.resource_path.ends_with("Bark_NormalTree_Normal.png"),"original shared bark albedo and normal maps "+name)
        var triangles:=0
        for i in range(2):
            var arrays:=mesh.surface_get_arrays(i)
            triangles+=arrays[Mesh.ARRAY_INDEX].size()/3
            check(arrays[Mesh.ARRAY_VERTEX].size()>0 and arrays[Mesh.ARRAY_NORMAL].size()==arrays[Mesh.ARRAY_VERTEX].size() and arrays[Mesh.ARRAY_TEX_UV].size()==arrays[Mesh.ARRAY_VERTEX].size(),"geometry, normals and UVs intact "+name+" surface"+str(i))
        print("FOREST28_MODEL ",name," triangles=",triangles," bounds=",source.bounds)
    check(scenery.find_children("*","CollisionObject3D",true,false).is_empty(),"vegetation introduces no collision bodies")
    print("FOREST28_SPECIES ",JSON.stringify(species))
    game.free()
    print("FOREST28 RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
