extends "res://tests/course_completion.gd"
# Loads the configured real main scene normally. No fixture positions, modified
# bar transforms/speeds, forced immunity, callback mocks or velocity overrides.
var hits := 0
var accepted_position := Vector3.ZERO
var accepted_velocity := Vector3.ZERO
var accepted_knockback := Vector3.ZERO
var checkpoint_at_hit := -1
var accepted_frame := 0

func real_level() -> void:
    if touch_direction != "":
        touch(touch_direction,1,false)
        touch_direction = ""
    hits = 0
    accepted_position = Vector3.ZERO
    accepted_velocity = Vector3.ZERO
    accepted_knockback = Vector3.ZERO
    checkpoint_at_hit = -1
    var path: String = ProjectSettings.get_setting("application/run/main_scene")
    require(change_scene_to_file(path) == OK,"configured playable scene loads: " + path)
    await scene_changed
    game = current_scene
    game.runner.hit.connect(func() -> void:
        hits += 1
        accepted_position = game.runner.position
        accepted_velocity = game.runner.velocity
        accepted_knockback = game.runner.knockback
        checkpoint_at_hit = game.checkpoint_index
        accepted_frame = Engine.get_physics_frames()
    )
    for tick in range(50):
        await frame()
        if game.state == game.RunState.PLAYING: break

func outcome(name: String) -> void:
    print("REAL_LEVEL_EVIDENCE ",JSON.stringify({"scenario":name,"scene":game.scene_file_path,
        "hits":hits,"falls":game.deaths,"checkpoint":game.checkpoint_index,
        "position":[game.runner.position.x,game.runner.position.y,game.runner.position.z],
        "hit_position":[accepted_position.x,accepted_position.y,accepted_position.z],
        "hit_velocity":[accepted_velocity.x,accepted_velocity.y,accepted_velocity.z],
        "hit_knockback":[accepted_knockback.x,accepted_knockback.y,accepted_knockback.z]}))

func run() -> void:
    root.size = Vector2i(720,1280)
    await real_level()
    for tick in range(100):
        await frame()
        if hits > 0: break
    require(hits == 1 and accepted_velocity.is_finite() and accepted_knockback.length() > .1,
        "A: straight approach in actual level produces accepted physical penalty")
    for tick in range(8): await frame()
    require(game.runner.position.distance_to(accepted_position) > .05,
        "A: solid character actually moves after contact-based impulse")
    outcome("A_direct")

    await real_level()
    var jumped := false
    for tick in range(130):
        if not jumped and game.runner.position.z <= 1.5:
            touch("jump",2,true)
            touch("jump",2,false)
            jumped = true
        await frame()
        if game.runner.position.z <= -7.5: break
    require(jumped and hits == 0 and game.runner.position.z <= -7.5 and game.deaths == 0,
        "B: clean timed jump over unmodified actual bar produces no hit")
    outcome("B_jump")

    await real_level()
    for tick in range(130):
        steer_to(3.5)
        await frame()
        if game.runner.position.z <= -7.5: break
    require(hits == 0 and game.runner.position.z <= -7.5 and game.runner.is_on_floor(),
        "C: side dodge outside actual bar produces no hit")
    outcome("C_dodge")

    await real_level()
    var jumped_gap := false
    for tick in range(350):
        steer_to(3.5)
        if not jumped_gap and game.runner.position.z <= -7.8:
            touch("jump",2,true)
            touch("jump",2,false)
            jumped_gap = true
        await frame()
        if game.checkpoint_index == 0: break
    require(game.checkpoint_index == 0 and hits == 0,"actual checkpoint reached using touch and physics")
    if touch_direction != "":
        touch(touch_direction,1,false)
        touch_direction = ""
    touch("right",1,true)
    for tick in range(200):
        await frame()
        if game.deaths == 1: break
    touch("right",1,false)
    var recovery_protection_seen := false
    for tick in range(100):
        await frame()
        if game.state == game.RunState.RESPAWNING:
            recovery_protection_seen = game.runner.spawn_protection_left > 0
        if game.state == game.RunState.PLAYING: break
    require(game.checkpoint_index == 0 and game.deaths == 1 and recovery_protection_seen,
        "real checkpoint respawn occurs with finite protection")
    jumped_gap = false
    var expired_before_hit := false
    for tick in range(220):
        if game.runner.spawn_protection_left == 0: expired_before_hit = true
        if not jumped_gap and game.runner.position.z <= -31.3:
            touch("jump",2,true)
            touch("jump",2,false)
            jumped_gap = true
        await frame()
        if hits > 0: break
    require(expired_before_hit and hits == 1 and checkpoint_at_hit == 0 and accepted_knockback.length() > .1
        and accepted_position.z < -44,
        "A repeated: real next bar hits after checkpoint protection naturally expires")
    while Engine.get_physics_frames()-accepted_frame < 10:
        await physics_frame
    var elapsed := float(Engine.get_physics_frames()-accepted_frame)/Engine.physics_ticks_per_second
    var free_run_distance: float = game.runner.RUN_SPEED*elapsed
    # A lateral blow need not halt all forward travel. Compare against free
    # autorun and require the accepted external channel to survive held input.
    require(accepted_position.z-game.runner.position.z < free_run_distance*.5 and
        game.runner.knockback.dot(accepted_knockback) > .1,
        "post-checkpoint impact persists under input and substantially interrupts free autorun")
    require(game.runner.position.distance_to(accepted_position) > .05,"post-checkpoint contact physically displaces collision body")
    outcome("A_after_checkpoint")
    game.queue_free()
    await frame()
    await frame()
    print("COLLISION EVIDENCE RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
