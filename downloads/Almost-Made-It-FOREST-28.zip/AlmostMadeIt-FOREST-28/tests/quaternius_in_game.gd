extends "res://tests/sky_garden.gd"
func run() -> void:
    root.size=Vector2i(720,1280);current_level=1
    raw(1,false);var original:=collision_snapshot()
    raw(1,true)
    var scenery:Node3D=game.get_node("AdventureScenery")
    check(scenery.get_script().resource_path=="res://scripts/environment/garden_landscape.gd","actual Level1 selects Quaternius integration")
    check(scenery.imported_trees.size()==8 and scenery.trees.is_empty(),"eight imported near trees replace procedural near trees")
    check(collision_snapshot()==original,"all course collision shapes/transforms/layers remain identical")
    check(scenery.find_children("*","CollisionObject3D",true,false).is_empty(),"decorative trees add no collision or triggers")
    var shared:Material=scenery.imported_trees[0].mesh.mesh.surface_get_material(0)
    var shared_leaf:Material=scenery.imported_trees[0].mesh.mesh.surface_get_material(1)
    for entry in scenery.imported_trees:
        check(entry.model.scene_file_path=="res://assets/nature/quaternius/CommonTree_3/CommonTree_3.gltf" and entry.mesh.mesh.surface_get_material(0)==shared and entry.mesh.mesh.surface_get_material(1)==shared_leaf,"genuine imported tree shares original bark/leaf resources: "+entry.model.name)
    for position in [Vector3(0,0,4),Vector3(0,0,-1.5),Vector3(0,0,-15.7),Vector3(0,0,-43),Vector3(0,0,-70)]:
        var visible:=true
        for entry in scenery.imported_trees:
            if entry.bounds.intersects_segment(position+Vector3(0,5.7,11),position+Vector3(0,.7,0))!=null:visible=false
        check(visible,"tree bounds clear camera/avatar line at "+str(position.z))
    scenery.set_quality(0)
    var no_shadows:=true
    for entry in scenery.imported_trees:no_shadows=no_shadows and entry.mesh.cast_shadow==GeometryInstance3D.SHADOW_CASTING_SETTING_OFF and entry.mesh.visibility_range_end==48
    check(no_shadows,"low quality disables tree shadows and reduces draw distance")
    scenery.set_quality(1)
    check(scenery.imported_trees[0].mesh.visibility_range_end==72,"balanced quality restores shared tree draw distance")
    await fresh();scenery=game.get_node("AdventureScenery")
    var before:float=scenery.imported_trees[0].model.rotation.z
    await seconds(.2)
    check(scenery.imported_trees[0].model.rotation.z!=before,"cosmetic tree sway animates without physics")
    game.set_paused(true);before=scenery.imported_trees[0].model.rotation.z
    await seconds(.2)
    check(scenery.imported_trees[0].model.rotation.z==before,"pause freezes imported tree sway")
    game.set_paused(false)
    check(ProjectSettings.get_setting("application/run/main_scene")=="res://scenes/level_select.tscn","game build launches normal level selection, not tree preview")
    for number in range(2,11):
        raw(number,true)
        check(game.find_children("CommonTree3_*","Node3D",true,false).is_empty(),"Level%d has no added imported trees"%number)
    game.queue_free();await step()
    print("QUATERNIUS GAME RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
