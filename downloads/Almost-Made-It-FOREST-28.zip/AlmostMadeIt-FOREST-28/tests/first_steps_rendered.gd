extends "res://tests/world1_regression.gd"
func run() -> void:
    root.size=Vector2i(720,1280);root.position=Vector2i.ZERO
    var output:=OS.get_environment("COURSE_EVIDENCE_PATH")
    if output.is_empty():output="user://course23-evidence"
    DirAccess.make_dir_recursive_absolute(output)
    current_level=1;await fresh()
    var views:Array=game.level_data.sections.duplicate(true)
    for view in views:
        var index:int=[0,14,27,40,56][view.area]
        var cell:Dictionary=game.level_data.cells[index]
        view.at=cell.at+Basis(Vector3.UP,cell.yaw)*Vector3(0,0,3.8)
    views.append({"name":"Golden Finish Gate","at":game.level_data.cells[-1].at+Vector3(0,0,3),"area":5})
    for section in views:
        fixture(section.at+Vector3.UP*.08)
        game.runner.set_physics_process(false)
        game.camera.setup(game.runner)
        for i in range(12):await step()
        await RenderingServer.frame_post_draw
        var pixels:=root.get_texture().get_image()
        var name:String="%02d-%s"%[section.area+1,section.name.to_lower().replace(" ","-")]
        check(not pixels.is_empty() and pixels.save_png(output+"/"+name+".png")==OK,"gameplay camera renders "+section.name)
        check(not game.camera.is_position_behind(game.runner.global_position+Vector3.UP*.7),"avatar faces gameplay camera in "+section.name)
        print("COURSE23_RENDER ",name," player=",game.runner.global_position," camera=",game.camera.global_position," draws=",Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)," primitives=",Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME))
    game.queue_free();await step()
    print("COURSE23 RENDERED RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
