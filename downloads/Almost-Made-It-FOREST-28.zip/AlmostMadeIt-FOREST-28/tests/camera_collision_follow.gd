extends "res://tests/collision_evidence.gd"
func visible_player() -> bool:
    var point: Vector3 = game.runner.position + Vector3.UP*.7
    return not game.camera.is_position_behind(point) and game.camera.get_viewport().get_visible_rect().has_point(game.camera.unproject_position(point))
func run() -> void:
    root.size = Vector2i(720,1280)
    await real_level()
    for i in range(200):
        await frame()
        if hits: break
    require(hits > 0,"actual first rotating bar produces collision response for camera test")
    var backward_seen := false
    var wrong_way := false
    var framed := true
    for i in range(40):
        var camera_before: Vector3 = game.camera.position
        var player_before: Vector3 = game.runner.position
        await frame()
        var shift: Vector3 = game.runner.position-player_before
        if shift.z > .001:
            backward_seen = true
            wrong_way = wrong_way or game.camera.position.z < camera_before.z-.001
        framed = framed and visible_player()
    print("CAMERA_KNOCKBACK_EVIDENCE reverse_seen=%s wrong_way=%s framed=%s" % [backward_seen,wrong_way,framed])
    require(backward_seen and not wrong_way,"camera does not advance forward during actual backward obstacle push")
    require(framed,"actual knockback keeps avatar in frame")
    # Actual platform departure, death and timer-driven respawn. No body fixtures.
    touch("right",1,true)
    for i in range(200):
        await frame()
        if game.deaths: break
    touch("right",1,false)
    require(game.deaths == 1,"actual fall triggers a single death for camera recovery test")
    var fall_visible := visible_player()
    for i in range(10):
        await frame()
        if game.state == game.RunState.DYING: fall_visible = fall_visible and visible_player()
    require(fall_visible,"camera keeps actual falling/dead avatar visible briefly")
    for i in range(100):
        await frame()
        if game.state == game.RunState.PLAYING: break
    for i in range(30): await frame()
    require(game.camera.target == game.runner and visible_player() and not game.camera.transitioning,"actual respawn returns to normal player tracking")
    # Geometry fixtures test terrain AND obstacle layers using the actual camera.
    game.runner.set_physics_process(false)
    game.runner.position = Vector3(3.5,0,3)
    game.camera.setup(game.runner)
    for layer in [1,4]:
        var wall := StaticBody3D.new()
        wall.collision_layer = layer
        wall.collision_mask = 0
        wall.position = Vector3(3.5,2.5,9)
        game.add_child(wall)
        var shape := CollisionShape3D.new()
        var box := BoxShape3D.new()
        box.size = Vector3(4,4,1)
        shape.shape = box
        wall.add_child(shape)
        for i in range(5): await frame()
        require(game.camera.position.z < 8.3,"camera volume stays clear of obstruction layer " + str(layer))
        var position: Vector3 = game.camera.position
        for i in range(60): await frame()
        require(game.camera.position.distance_to(position) < .001,"obstruction cannot accumulate stationary follow drift")
        wall.queue_free()
        for i in range(60): await frame()
        require(game.camera.position.distance_to(game.runner.position+game.camera.OFFSET) < .03,"camera restores preferred offset after obstruction clears")
    game.queue_free()
    await frame()
    print("CAMERA COLLISION FOLLOW RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
