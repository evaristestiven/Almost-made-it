extends "res://tests/course_completion.gd"
# Normal project entry and touch only; verifies actual loss of forward travel,
# not merely hit signals/particles or a nonzero impulse variable.
var hit_count := 0
var contact := Vector3.ZERO
var contact_tick := 0

func run() -> void:
    root.size = Vector2i(720,1280)
    var scene_path: String = ProjectSettings.get_setting("application/run/main_scene")
    require(change_scene_to_file(scene_path)==OK,"launch configured Skybound Sprint scene")
    await scene_changed
    game = current_scene
    game.runner.hit.connect(func() -> void:
        hit_count += 1
        if hit_count == 1:
            contact = game.runner.position
            contact_tick = Engine.get_physics_frames()
    )
    for tick in range(120):
        await frame()
        if hit_count == 1:break
    require(hit_count==1,"actual first bar accepts direct hit")
    while Engine.get_physics_frames()-contact_tick < 10:
        await physics_frame
    # This centered contact has zero tangential Z: old auto-run travels ~1.63m
    # in these ten ticks despite being hit; recovery should stop that advance.
    var advance: float = contact.z-game.runner.position.z
    print("HIT_INTERRUPTION_MEASUREMENT ",JSON.stringify({"ticks":Engine.get_physics_frames()-contact_tick,
        "forward_advance":advance,"rise":game.runner.position.y-contact.y,
        "velocity":[game.runner.velocity.x,game.runner.velocity.y,game.runner.velocity.z]}))
    require(advance < .2,"direct hit visibly interrupts forward travel for first ten physics ticks")
    require(game.runner.position.y > contact.y+.3,"existing upward reaction remains physical")
    game.set_paused(true)
    var point: Vector3 = game.runner.position
    for i in range(20):await frame()
    require(game.runner.position==point,"pause freezes interrupted hit motion")
    game.set_paused(false)
    for i in range(24):await physics_frame
    require(game.runner.velocity.z < -9 and game.runner.position.z < contact.z-.5,
        "finite hit recovery restores normal auto-run")
    require(hit_count==1 and game.deaths==0,"same contact adds no repeated hit or death")
    game.set_paused(true)
    await frame()
    await frame()
    touch("restart",4,true)
    touch("restart",4,false)
    await frame()
    await frame()
    game = current_scene
    require(game.deaths==0 and not game.won,"restart clears interrupted run")
    game.queue_free()
    await frame()
    await frame()
    print("HIT INTERRUPTION RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
