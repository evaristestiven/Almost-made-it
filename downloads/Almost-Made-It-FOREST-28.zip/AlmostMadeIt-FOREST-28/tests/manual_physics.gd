extends "res://tests/manual_movement.gd"
func separation(obstacle: AnimatableBody3D) -> float:
    var center: Vector3 = game.runner.position
    center.y = clampf(obstacle.position.y,center.y+game.runner.BODY_RADIUS,center.y+game.runner.BODY_HEIGHT-game.runner.BODY_RADIUS)
    var local: Vector3 = obstacle.global_transform.affine_inverse()*center
    var half: Vector3 = obstacle.get_child(0).mesh.size*.5
    return local.distance_to(local.clamp(-half,half))-game.runner.BODY_RADIUS
func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    for index in range(3):
        for protected in [false,true]:
            await fresh()
            var obstacle = get_nodes_in_group("hazards")[index]
            fixture(Vector3(2.2,.02,obstacle.position.z))
            if protected:
                game.runner.spawn_protection_left = 5
                game.runner.invulnerable_left = 5
            var start: Vector3 = game.runner.position
            var minimum := 0.0
            var until := Engine.get_physics_frames()+hz*2
            while Engine.get_physics_frames() < until:
                await step()
                minimum = minf(minimum,separation(obstacle))
            print("MANUAL_SOLID bar=%d protected=%s hz=%d separation=%.5f displacement=%.5f hits=%d" % [index,protected,hz,minimum,start.distance_to(game.runner.position),hits])
            check(game.runner.position.distance_to(start) > .1 and minimum > -.08,"actual bar %d physically displaces idle avatar without penetration, protected=%s" % [index,protected])
            check(game.runner.collision_mask == 5 and (hits == 0 if protected else hits > 0),"protection suppresses impulse only, not solid blocking")
    # Real commanded approach, then a clean jump and a side dodge.
    for scenario in ["direct","jump","dodge"]:
        await fresh()
        if scenario == "dodge":
            stick(Vector2.RIGHT)
            while game.runner.position.x < 2.45: await step()
            release()
            await seconds(.4)
        stick(Vector2.UP)
        var jumped := false
        var limit := Engine.get_physics_frames()+hz*4
        while Engine.get_physics_frames() < limit:
            if scenario == "jump" and not jumped and game.runner.position.z <= 1.5:
                jump()
                release(2)
                jumped = true
            await step()
            if hits > 0 or game.runner.position.z < -7.5: break
        check(hits == 1 if scenario == "direct" else hits == 0 and game.runner.position.z < -7.5,"actual full-manual bar approach: "+scenario)
    await fresh()
    var bridge = game.get_node("DriftingStep")
    fixture(Vector3(bridge.position.x,.08,bridge.position.z))
    await seconds(.3)
    var start: Vector3 = game.runner.position
    await seconds(.3)
    check(game.runner.move_input == Vector2.ZERO and game.runner.control_velocity == Vector3.ZERO and game.runner.position.distance_to(start) > .01 and game.runner.is_on_floor(),"zero motor request preserves native moving-platform carrying")
    game.queue_free()
    await step()
    print("MANUAL PHYSICS RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
