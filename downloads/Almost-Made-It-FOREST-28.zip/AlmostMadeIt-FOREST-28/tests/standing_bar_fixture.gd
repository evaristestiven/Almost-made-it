extends Node
# Device-only QA entry point: instantiate the EXISTING playable course and hold
# its movement input idle. This scene is never loaded by normal gameplay.
var game: Node3D
var test_ready := false

func _ready() -> void:
    game = load("res://main.tscn").instantiate()
    add_child(game)
    while game.state != game.RunState.PLAYING:
        await get_tree().physics_frame
    var bar: AnimatableBody3D = get_tree().get_nodes_in_group("hazards")[0]
    game.runner.reset_at(Vector3(2.2,.02,bar.position.z),false)
    game.runner.grace_left = 0
    game.runner.move_input = Vector2.ZERO
    game.route.restore(game.runner.position,game.route.distance_at(game.runner.position))
    game.camera.setup(game.runner)
    game.hud.notify("STANDING SWEEP TEST - LEAVE CONTROLS IDLE")
    game.hud.notified = 10
    test_ready = true

func _physics_process(_delta: float) -> void:
    if test_ready and is_instance_valid(game) and game.state == game.RunState.PLAYING:
        game.runner.move_input = Vector2.ZERO
