extends "res://tests/world1_regression.gd"
func count_kind(kind: String) -> int:
    var count := 0
    for event in game.almost_moments.events:
        if event.kind == kind: count+=1
    return count
func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz=argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second=hz
    root.size=Vector2i(720,1280)
    current_level=1
    await fresh()
    var moments=game.almost_moments
    moments.save_path="user://almost_tests/highlights.json"
    var sound_events: Array[String]=[]
    game.feedback.sound_triggered.connect(func(kind: String) -> void: sound_events.append(kind))
    var bar:Node3D=get_nodes_in_group("hazards")[0]
    fixture(bar.position+Vector3(bar.width*.5+game.runner.BODY_RADIUS+.17,-1.03,0))
    var before: Vector3=game.runner.position
    await seconds(10)
    print("BAR_NEAR events=",JSON.stringify(moments.events)," hits=",hits," delta=",game.runner.position-before)
    check(count_kind("near_miss")==1 and hits==0,"real rotating bar close pass produces one near miss without a contact")
    check(horizontal(game.runner.position-before).length()<.001 and game.runner.knockback==Vector3.ZERO,"near miss does not alter stationary player's physics")
    check(sound_events.has("near_miss") and game.feedback.streams.has("near_miss"),"near miss reaches original feedback pool with real audio asset")
    await seconds(9)
    check(count_kind("near_miss")==1 and moments.performance_points==0,"repeated close passes cannot farm events or currency")
    fixture(bar.position+Vector3(2.2,-1.03,0))
    var end:=Engine.get_physics_frames()+hz*6
    while hits==0 and Engine.get_physics_frames()<end: await step()
    check(hits>0 and count_kind("impact")>=1,"accepted solid bar strike produces impact metadata")
    var near_before:=count_kind("near_miss")
    await seconds(.2)
    check(count_kind("near_miss")==near_before,"a real contact cannot masquerade as a near miss")
    current_level=6
    await fresh()
    moments=game.almost_moments
    fixture(Vector3(3.1,.02,-15))
    await seconds(6)
    print("BALL_NEAR events=",JSON.stringify(moments.events)," hits=",hits)
    check(count_kind("near_miss")==1 and hits==0,"real swinging sphere registers a clean close pass")
    # Real airborne strike followed by swipe steering, never a synthetic hit call.
    current_level=3
    await fresh()
    moments=game.almost_moments
    moments.performance_bonus_enabled=true
    moments.save_path="user://almost_tests/highlights.json"
    fixture(Vector3(1.7,.02,-24))
    jump();release(2)
    end=Engine.get_physics_frames()+hz*5
    while hits==0 and Engine.get_physics_frames()<end: await step()
    print("AIR_HIT pos=",game.runner.position," impulse=",game.runner.last_impulse," candidate=",moments.candidate)
    check(hits>0 and game.runner.last_impulse.length()>3,"actual layered bar delivers a substantial airborne hit")
    drag_direction(Vector2(-.4,0))
    end=Engine.get_physics_frames()+hz*3
    while (not game.runner.is_on_floor() or game.runner.position.y>.15) and game.deaths==0 and Engine.get_physics_frames()<end: await step()
    release()
    await seconds(.45)
    print("RECOVERY events=",JSON.stringify(moments.events)," candidate=",moments.candidate," pos=",game.runner.position," falls=",game.deaths)
    check(count_kind("clutch_recovery")==1 and game.deaths==0,"real impact plus corrective swipe and stable landing earns a clutch recovery")
    check(moments.performance_points>0 and moments.performance_points<=10 and game.coins<=5,"optional performance bonus stays separate from coins")
    check(moments.flush_highlights() and FileAccess.file_exists(moments.save_path),"bounded highlight metadata saves inside user storage")
    var data=JSON.parse_string(FileAccess.get_file_as_string(moments.save_path))
    check(data!=null and data.schema==1 and data.actor=="local-player" and data.events.size()>0,"saved highlights carry versioned per-actor metadata")
    # Actual departure and coyote jump: no rescue, just the unchanged input.
    current_level=1
    await fresh()
    moments=game.almost_moments
    fixture(Vector3(4.6,.02,4))
    await seconds(.1)
    drag_direction(Vector2.RIGHT)
    end=Engine.get_physics_frames()+hz
    while game.runner.is_on_floor() and Engine.get_physics_frames()<end: await step()
    print("EDGE_DEPARTURE pos=",game.runner.position," coyote=",game.runner.coyote_left," candidate=",moments.candidate)
    jump();release(2)
    drag_direction(Vector2.LEFT)
    end=Engine.get_physics_frames()+hz*2
    while game.runner.position.x>3.8 and game.deaths==0 and Engine.get_physics_frames()<end: await step()
    release()
    end=Engine.get_physics_frames()+hz*2
    while (not game.runner.is_on_floor() or game.runner.position.y>.15) and game.deaths==0 and Engine.get_physics_frames()<end: await step()
    await seconds(.4)
    print("EDGE_RECOVERY events=",JSON.stringify(moments.events)," candidate=",moments.candidate," pos=",game.runner.position)
    check(count_kind("clutch_recovery")==1 and game.deaths==0,"real edge departure and coyote jump can earn a legitimate clutch save")
    # Pause, a genuine fall, and lifecycle cancellation.
    game.set_paused(true)
    var tick_before:int=moments.tick
    await seconds(.3)
    check(moments.tick==tick_before,"pause freezes moment timers and recognition")
    game.set_paused(false)
    var falls_before:int=game.deaths
    drag_direction(Vector2.RIGHT)
    end=Engine.get_physics_frames()+hz*4
    while game.deaths==falls_before and Engine.get_physics_frames()<end: await step()
    release()
    check(game.deaths==falls_before+1 and count_kind("fall")==1 and moments.candidate.is_empty(),"fall produces one highlight and cancels recovery")
    end=Engine.get_physics_frames()+hz*4
    while game.state!=game.RunState.PLAYING and Engine.get_physics_frames()<end: await step()
    check(moments.candidate.is_empty() and game.runner.move_input==Vector2.ZERO,"respawn carries no stale recovery candidate or input")
    # Raised course surfaces use departure height, never an assumed world Y=0.
    current_level=2
    await fresh()
    moments=game.almost_moments
    fixture(Vector3(-2.6,1.07,-25))
    await seconds(.1)
    drag_direction(Vector2(.5,0))
    end=Engine.get_physics_frames()+hz
    while game.runner.is_on_floor() and Engine.get_physics_frames()<end:await step()
    jump();release(2)
    drag_direction(Vector2(-.5,0))
    end=Engine.get_physics_frames()+hz*2
    while game.runner.position.x> -3 and game.deaths==0 and Engine.get_physics_frames()<end:await step()
    release()
    await seconds(1)
    print("RAISED_EDGE_RECOVERY events=",JSON.stringify(moments.events)," pos=",game.runner.position)
    check(count_kind("clutch_recovery")==1 and game.deaths==0 and absf(game.runner.position.y-1.05)<.1 and str(moments.events[-1].landing_surface).begins_with("L02/P"),"raised-platform edge recovery uses actual departure and landing heights")
    game.queue_free();await step()
    print("ALMOST MOMENTS RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
