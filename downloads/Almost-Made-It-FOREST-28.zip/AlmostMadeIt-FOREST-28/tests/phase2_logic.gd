extends SceneTree
const ROUTE = preload("res://scripts/components/route_progress.gd")
var game
var checks := 0
var failures := 0
var jumps := 0
var hits := 0
var builds := 0
var count_builds := false

func _initialize() -> void:
    call_deferred("run")
func frames(count := 1) -> void:
    for tick in range(count):
        await process_frame
        await physics_frame
func check(condition: bool, text: String) -> void:
    checks += 1
    print("PASS: " if condition else "FAIL: ", text)
    if not condition:
        failures += 1
func fresh() -> void:
    paused = false
    if is_instance_valid(game):
        game.queue_free()
        await frames(2)
    game = load("res://main.tscn").instantiate()
    root.add_child(game)
    current_scene = game
    jumps = 0
    hits = 0
    game.runner.jumped.connect(func() -> void: jumps += 1)
    game.runner.hit.connect(func() -> void: hits += 1)
    await frames(22)
func area(z: float):
    for child in game.get_children():
        if child is Area3D and is_equal_approx(child.position.z, z):
            return child
    return null
# Explicit isolated-test fixture; all full-course tests use uninterrupted input
# and physics instead. Teleport exploitation below deliberately omits restore.
func fixture(at: Vector3) -> void:
    game.recovery_timer.stop()
    game.runner.reset_at(at)
    game.runner.grace_left = 0
    game.route.restore(at, game.route.distance_at(at))
    game._set_state(game.RunState.PLAYING)
    game._sync_state()
func touch(index: int, at: Vector2, down := true) -> void:
    var event := InputEventScreenTouch.new()
    event.index = index
    event.position = at
    event.pressed = down
    game.controls._input(event)
func wall(at: Vector3, size := Vector3(2, 2, 2)) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.position = at
    var collider := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collider.shape = shape
    body.add_child(collider)
    game.add_child(body)
    return body
func advance_route(path, start: Vector3, end: Vector3, count: int) -> void:
    var before := start
    for i in range(1, count + 1):
        var after := start.lerp(end, float(i) / count)
        path.observe(before, after, 1.0 / 60.0)
        before = after

func run() -> void:
    root.size = Vector2i(720, 1280)
    await fresh()
    check(game.state == game.RunState.PLAYING, "READY settles before entering PLAYING")
    var moving = get_nodes_in_group("moving_platforms")[0]
    moving.period = 0
    await frames(2)
    check(moving.position.is_finite() and moving.position == moving.origin, "invalid moving-platform period freezes safely instead of producing NaN or a launch")
    moving.period = 4.0
    game.runner.jump_requested = true
    await frames(3)
    check(jumps == 1 and game.runner.velocity.y > 0, "grounded jump is accepted once")
    for i in range(10):
        game.runner.jump_requested = true
        await frames()
    check(jumps == 1, "repeated airborne requests cannot create a double jump")
    fixture(Vector3(0, 3, 3))
    var previous_jumps := jumps
    game.runner.jump_requested = true
    await frames(38)
    check(jumps == previous_jumps and game.runner.is_on_floor(), "early airborne buffer expires before landing")
    fixture(Vector3(0, 0.14, 3))
    game.runner.velocity.y = -1
    game.runner.coyote_left = 0
    game.runner.jump_requested = true
    await frames(4)
    check(jumps == previous_jumps + 1 and game.runner.velocity.y > 0, "near-landing buffer produces one timely jump")
    fixture(Vector3(2.3, 3, 3))
    var side_wall := wall(Vector3(3, 3, 3), Vector3(0.4, 3, 3))
    Input.action_press("ui_right")
    await frames(12)
    previous_jumps = jumps
    game.runner.jump_requested = true
    await frames(2)
    check(not game.runner.is_on_floor() and jumps == previous_jumps, "wall contact is not a jumpable ground surface")
    Input.action_release("ui_right")
    side_wall.queue_free()

    fixture(Vector3(0, 0.08, 3))
    await frames(3)
    game.runner.invulnerable_left = 0
    game.runner.hit_by_spinner(game.runner.position + Vector3(2, 0, 0), 2)
    previous_jumps = jumps
    game.runner.jump_requested = true
    await frames(3)
    check(jumps == previous_jumps and game.runner.velocity.y < 6.0, "upward obstacle bounce cannot reuse stale floor contact for a double jump")

    await fresh()
    area(-52).body_entered.emit(game.runner)
    area(-76).body_entered.emit(game.runner)
    check(game.checkpoint_index == -1 and not game.won, "remote callbacks cannot save checkpoints or award victory")
    game.runner.position = Vector3(0, 0.08, -76)
    await frames(4)
    check(not game.route.position_valid and not game.won and game.progress_percent() == 0, "teleport into finish cannot skip the route")
    await fresh()
    fixture(Vector3(4.92, 1.0, -75.2))
    await frames(7)
    check(not game.won, "unsupported finish-edge overlap cannot award a win followed by falling")
    await fresh()
    fixture(Vector3(0, 0.08, -28.9))
    await frames(5)
    check(game.checkpoint_index == 0 and game.spawn.z == -30, "physical forward checkpoint entry saves first checkpoint")
    area(-30).body_entered.emit(game.runner)
    area(-30).body_entered.emit(game.runner)
    check(game.checkpoint_index == 0, "duplicate checkpoint callback cannot reactivate its reward")
    fixture(Vector3(0, 0.08, -50.9))
    await frames(5)
    check(game.checkpoint_index == 1 and game.spawn.z == -52, "later checkpoint becomes authoritative")
    var high_water: int = game.progress_percent()
    fixture(Vector3(0, -13, -54))
    await frames(1)
    game._respawn()
    game._respawn()
    check(game.deaths == 1 and game.state == game.RunState.DYING, "one failure enters DYING and counts one death")
    var frozen: Vector3 = game.runner.position
    game.runner.jump_requested = true
    touch(1, game.controls.jump_center)
    await frames(8)
    check(game.runner.position == frozen and game.runner.velocity == Vector3.ZERO and game.runner.jump_buffer == 0 and game.runner.knockback == Vector3.ZERO, "death freezes motion and clears stale jump/knockback")
    game.runner.position = Vector3(0, 0.08, -76)
    await frames(2)
    area(-76).body_entered.emit(game.runner)
    check(not game.won and game.runner.collision_layer == 0, "dead body inside finish volume cannot trigger victory")
    await frames(48)
    check(game.state == game.RunState.PLAYING and game.runner.position.z < -52 and game.runner.position.z > -54, "recovery restores latest checkpoint and enters PLAYING")
    check(game.deaths == 1 and game.checkpoint_index == 1 and game.progress_percent() >= high_water, "checkpoint and furthest progress persist through death")
    check(game.runner.velocity.y <= 0 and game.runner.knockback == Vector3.ZERO and not game.runner.jump_requested and game.runner.rotation == Vector3.ZERO, "respawn has no leftover launch or jump")
    check(game.hud.notice.text.contains("PROTECTED"), "respawn protection is announced in existing notification")

    check(game._spawn_safe(Vector3(0, 0.08, -52)) and not game._spawn_safe(Vector3(0, 0.08, -5)), "spawn validation accepts ground and rejects a rotating hazard")
    # Block the most recent saved point: use a previously valid point safely.
    fixture(Vector3(0, 0.08, -53))
    var blocked := wall(Vector3(0, 0.8, -52))
    await frames(2)
    game._respawn()
    await frames(55)
    check(game.checkpoint_index == 1 and game.runner.position.z > -33 and game.runner.position.z < -30, "blocked checkpoint falls back to earlier safe spawn without losing saved state")
    blocked.queue_free()
    await frames(2)
    fixture(Vector3(0, 0.08, -53))
    game._respawn()
    game.set_paused(true)
    var remaining: float = game.recovery_timer.time_left
    await frames(40)
    check(paused and game.recovery_timer.time_left == remaining and game.deaths == 3, "pause during death freezes recovery timer and counters")
    game.set_paused(false)
    await frames(56)
    check(game.state == game.RunState.PLAYING and game.runner.position.z < -52, "unpause resumes the same recovery lifecycle")

    await fresh()
    var blocked_start := wall(Vector3(0, 0.8, 5))
    game._respawn()
    await frames(60)
    check(game.state == game.RunState.RESPAWNING and game.deaths == 1 and not game.runner.running, "all unsafe spawns wait without repeated deaths or activating movement")
    blocked_start.queue_free()
    await frames(32)
    check(game.state == game.RunState.PLAYING and game.deaths == 1, "safe-spawn retry recovers when obstruction clears")

    await fresh()
    var paused_pickup = area(-1)
    var original: Callable = paused_pickup.get_signal_connection_list("body_entered")[0].callable
    paused_pickup.body_entered.disconnect(original)
    # Inject a pause immediately before the real area's original callback.
    paused_pickup.body_entered.connect(func(_body: Node3D) -> void: game.set_paused(true), CONNECT_ONE_SHOT)
    paused_pickup.body_entered.connect(original)
    fixture(Vector3(2, 0.08, 0.1))
    await frames(8)
    check(paused and game.coins == 0, "pause before a real coin callback prevents rewarding while paused")
    game.set_paused(false)
    await frames(3)
    check(game.coins == 1, "resuming rechecks a legitimate pending coin overlap exactly once")

    await fresh()
    fixture(Vector3(2, 0.08, 0.1))
    var pickup = area(-1)
    pickup.body_entered.connect(func(body: Node3D) -> void:
        if not pickup.get_meta("probe", false):
            pickup.set_meta("probe", true)
            pickup.body_entered.emit(body)
            pickup.body_entered.emit(body)
    )
    await frames(6)
    check(game.coins == 1 and area(-1) == null, "real coin pickup grants once despite reentrant callbacks")
    fixture(Vector3(0, -13, 2))
    await frames(1)
    await frames(56)
    check(game.coins == 1 and area(-1) == null and game.deaths == 1, "death preserves collected coins without respawning rewards")
    fixture(Vector3(0, 1, -74.8))
    await frames(5)
    check(game.won and game.completion_count == 1 and game.completed_coins == 1 and game.completed_falls == 1, "alive physical finish succeeds without all coins and records exact results")
    area(-76).body_entered.emit(game.runner)
    game._respawn()
    game.set_paused(true)
    await frames(3)
    check(game.completion_count == 1 and game.deaths == 1 and game.coins == 1 and game.progress_percent() == 100, "duplicate completion/death/pause cannot change finalized results")
    check(game.hud.progress_bar.value == 100 and game.hud.detail.text.contains("1 / 5 COINS"), "completion HUD matches authoritative results")
    game.notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    check(game.won and game.progress_percent() == 100, "backgrounding preserves the completed result and 100 percent")
    game.notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    var position_at_win: Vector3 = game.runner.position
    await frames(30)
    check(game.runner.is_on_floor() and is_equal_approx(game.runner.position.z, position_at_win.z), "completion settles safely without forward movement")

    await fresh()
    fixture(Vector3(0, 0.05, -5))
    game.runner.set_physics_process(false)
    game.runner.invulnerable_left = 0.15
    var spinner = area(-5)
    var matching_hub := false
    for child in spinner.get_children():
        if child is CollisionShape3D and child.shape is CylinderShape3D:
            matching_hub = is_equal_approx(child.shape.radius, 0.36) and is_equal_approx(child.shape.height, 0.58)
    check(matching_hub, "spinner hub collider matches its visible cylinder")
    spinner.spin_speed = 0
    await frames(5)
    check(hits == 0, "protected contact does not knock back")
    game.runner.invulnerable_left = 0
    await frames(3)
    check(hits == 1 and game.runner.knockback.length() <= 5.01, "pending overlap hits once when protection expires")
    game.runner.invulnerable_left = 0
    await frames(70)
    check(hits == 1, "same continuous contact cannot repeatedly launch player")
    fixture(Vector3(0, 0.08, 2))
    game.runner.set_physics_process(false)
    await frames(3)
    fixture(Vector3(0, 0.05, -5))
    game.runner.set_physics_process(false)
    game.runner.invulnerable_left = 0
    await frames(3)
    check(hits == 2, "exiting and reentering permits a new obstacle contact")
    game._respawn()
    spinner.contact.emit(game.runner)
    check(hits == 2, "hazard callbacks cannot hit after death")
    await fresh()
    check(not game.runner.hit_by_spinner(Vector3(INF, 0, 0), 2), "nonfinite obstacle inputs are rejected")
    game.runner.invulnerable_left = 0
    game.runner.grace_left = 0
    game.runner.hit_by_spinner(game.runner.position + Vector3(2, 0, 0), 2)
    check(game.runner.knockback.z > 0 and game.runner.knockback.length() <= 5.01, "knockback follows positive bar rotation with bounded force")

    fixture(Vector3(0, 0.08, 3))
    game.runner.invulnerable_left = 0
    game.runner.hit_by_spinner(game.runner.position + Vector3(2, 0, 0), -2)
    check(game.runner.knockback.z < 0, "negative bar rotation reverses tangential knockback")

    await fresh()
    var stick: Vector2 = game.controls.joystick_center - Vector2(game.controls.joystick_radius * 0.7, 0)
    touch(1, stick)
    touch(2, game.controls.jump_center)
    touch(2, game.controls.jump_center, false)
    check(game.controls.steering() == -1 and game.runner.jump_requested, "one finger steers while another jumps and releases independently")
    var drag := InputEventScreenDrag.new()
    drag.index = 1
    drag.position = game.controls.joystick_center - Vector2(600, 0)
    game.controls._input(drag)
    check(game.controls.steering() == -1, "drag outside joystick remains clamped and responsive")
    drag.position = Vector2(INF, 0)
    game.controls._input(drag)
    check(game.controls.steering() == 0, "invalid touch coordinates cannot inject invalid movement forces")
    game.set_paused(true)
    touch(3, game.controls.buttons.pause.get_global_rect().get_center())
    touch(4, game.controls.jump_center)
    check(paused and game.state == game.RunState.PAUSED and not game.runner.jump_requested and game.controls.steering() == 0, "modal pause blocks underlying pause button and gameplay input")
    game.notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    game.notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    check(paused, "background/resume preserves manual pause")
    game.set_paused(false)
    await frames(2)
    check(game.controls.fingers.is_empty() and not game.runner.jump_requested, "resuming cannot replay modal touch input")

    await fresh()
    fixture(Vector3(0, 0.08, -28.9))
    await frames(5)
    game._respawn()
    builds = 0
    count_builds = true
    node_added.connect(func(node: Node) -> void:
        if count_builds and node.name == "Runner":
            builds += 1
    )
    for i in range(8):
        game.restart()
        game.set_paused(true)
    check(game.state == game.RunState.TRANSITIONING and game.recovery_timer.is_stopped(), "restart latches TRANSITIONING and cancels death timer")
    await frames(4)
    count_builds = false
    game = current_scene
    check(builds == 1 and game.coins == 0 and game.deaths == 0 and game.checkpoint_index == -1 and game.progress_percent() == 0, "rapid restart/pause presses create one clean run with reset checkpoints")
    await frames(60)
    check(game.deaths == 0 and not game.respawning, "old recovery signal cannot affect restarted scene")
    Input.action_press("ui_right")
    game.restart()
    await frames(4)
    game = current_scene
    await frames(22)
    check(absf(game.runner.position.x) < 0.01 and not game.keyboard_armed, "restart cannot carry held keyboard steering into new run")
    Input.action_release("ui_right")
    await frames(2)
    Input.action_press("ui_right")
    await frames(4)
    check(game.runner.velocity.x > 0, "keyboard re-arms after release and remains usable")
    Input.action_release("ui_right")
    check(not game.has_method("next_level"), "no fake next-level action exists for the single-course project")

    var path = ROUTE.new()
    check(path.configure(PackedVector3Array([Vector3.ZERO, Vector3(0,0,-10), Vector3(10,0,-10), Vector3(10,0,-20)])), "ordered route supports turns without changing the existing level")
    advance_route(path, Vector3.ZERO, Vector3(0,0,-10), 50)
    check(path.percent() == 33, "first route leg measures path distance")
    advance_route(path, Vector3(0,0,-10), Vector3(10,0,-10), 50)
    check(path.percent() == 66, "horizontal turn advances progress despite unchanged Z")
    advance_route(path, Vector3(10,0,-10), Vector3(10,0,-20), 50)
    check(path.percent() == 99, "route endpoint remains below 100 until completion")
    path.restore(Vector3.ZERO, 0)
    check(path.current_distance == 0 and path.percent() == 99, "physical respawn position is distinct from furthest progress")
    path.restore(Vector3.ZERO, 0, false)
    advance_route(path, Vector3.ZERO, Vector3(3,3,0), 30)
    check(path.percent() == 0, "jump height and lateral motion cannot inflate progress")
    path.restore(Vector3.ZERO, 0, false)
    path.observe(Vector3.ZERO, Vector3(10,0,-10), 1.0/60)
    check(not path.position_valid and path.percent() == 0, "route rejects skipped markers and implausible displacement")
    game.queue_free()
    await frames(3)
    print("PHASE2 RESULT: %d checks, %d failures" % [checks, failures])
    quit(1 if failures else 0)
