extends "res://tests/swipe_movement.gd"
func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    await fresh()
    var next_jump := 0
    var takeoffs := [-7.8,-31.3,-53.3]
    var steps := 0
    while not game.won and game.deaths == 0 and steps < hz*25:
        var z: float = game.runner.position.z
        var target_x := 2.0 if game.coins == 0 and z > -2 else (3.5 if z > -59 else 2.0)
        var vx: float = game.runner.control_velocity.x
        var stop_x: float = game.runner.position.x+signf(vx)*vx*vx/(2*game.runner.ground_acceleration)
        var steer := clampf((target_x-stop_x)*5.0,-1.0,1.0)
        drag_direction(Vector2(steer,-1).normalized())
        if next_jump < takeoffs.size() and z <= takeoffs[next_jump]:
            jump()
            release(2)
            next_jump += 1
        await step()
        steps += 1
    print("SWIPE_COURSE hz=%d steps=%d position=%s coins=%d falls=%d cp=%d" % [hz,steps,str(game.runner.position),game.coins,game.deaths,game.checkpoint_index])
    check(game.won and game.deaths == 0,"full course completed with explicit two-axis touch input and all real hazards active")
    check(game.checkpoint_index == 1 and game.coins > 0,"manual route legitimately activates both checkpoints and collects coins")
    check(game.completion_count == 1 and game.hud.completed and game.progress_percent() == 100,"manual route reaches real finish once with accurate victory")
    release()
    for i in range(10): await step()
    finger(3,true,game.hud.restart_button.get_global_rect().get_center())
    release(3)
    for i in range(10): await step()
    game = current_scene
    await seconds(.5)
    var point: Vector3 = game.runner.position
    await seconds(1)
    check(game.runner.position.distance_to(point) < .001 and game.coins == 0 and game.deaths == 0,"real victory Replay resets to idle manual control")
    game.queue_free()
    await step()
    print("SWIPE COURSE RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
