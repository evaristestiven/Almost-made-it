extends RefCounted
# Real touch input only; no actor teleports, immunity or obstacle removal.
static func traverse(t:Object) -> bool:
    var links:Dictionary={}
    for link in t.game.level_data.links:links[link.kind]=int(links.get(link.kind,0))+1
    print("COURSE23_LAYOUT ",JSON.stringify({"length":t.game.route.total_length,"cells":t.game.level_data.cells.size(),"links":links,"obstacles":t.game.level_data.obstacles.size(),"checkpoints":t.game.checkpoints.size(),"coins":t.get_nodes_in_group("coins").size(),"sections":t.game.level_data.sections}))
    var contacts:=[0]
    t.game.runner.hit.connect(func()->void:contacts[0]+=1)
    var start_time:float=t.game.elapsed_seconds
    for link in t.game.level_data.links:
        var a:Dictionary=t.game.level_data.cells[link.from]
        var b:Dictionary=t.game.level_data.cells[link.to]
        var direction:Vector3=(b.at-a.at).normalized()
        direction.y=0;direction=direction.normalized()
        var takeoff:Vector3=a.at+direction*3.8
        var landing:Vector3=b.at-direction*3.8
        var okay:bool=await t.move_to(takeoff)
        if okay:
            if link.kind=="bridge":okay=await t.move_to(landing)
            elif link.kind=="stones":
                for stone in link.stones:
                    if okay:okay=await t.hop(t.fixed(stone))
                if okay:okay=await t.hop(t.fixed(landing))
            elif link.kind=="moving":
                var ferry:Node3D
                for node in t.get_nodes_in_group("moving_platforms"):
                    if t.horizontal(node.origin-link.at).length()<.1:ferry=node;break
                okay=await t.hop(func()->Vector3:return ferry.position+Vector3.UP*.35)
                if okay:
                    await t.seconds(.08)
                    okay=await t.hop(t.fixed(landing))
            else:okay=await t.hop(t.fixed(landing))
        # Walk around each center hazard with real touch steering, keeping the
        # contact geometry intact. Side clearance is a skill route, no immunity.
        var hazardous:bool=b.hazard
        if okay and hazardous:
            var side:Vector3=Basis(Vector3.UP,b.yaw).x*3.5*float(b.get("bypass_side",1.0))
            okay=await t.move_to(landing+side)
            if okay:okay=await t.move_to(b.at+side)
            if okay:okay=await t.move_to(b.at+direction*3.8+side)
        elif okay:okay=await t.move_to(b.at)
        for detour in t.game.level_data.get("coin_detours",[]):
            if okay and detour.cell==link.to and not "--skip-detours" in OS.get_cmdline_user_args():
                okay=await t.hop(t.fixed(detour.at))
                if okay:okay=await t.hop(t.fixed(b.at))
        if not okay or t.game.deaths>0:
            print("COURSE23_STOP cell=",link.to," position=",t.game.runner.position," velocity=",t.game.runner.velocity," floor=",t.game.runner.is_on_floor()," deaths=",t.game.deaths," route=",t.game.route.position_valid," cursor=",t.game.route.segment_index)
            t.check(false,"connected physical traversal reaches cell %d"%link.to)
            return false
        print("COURSE23_CELL area=%s cell=%d at=%s time=%.2f progress=%d route=%s"%[t.game.level_data.sections[b.area].name,link.to,str(t.game.runner.position),t.game.elapsed_seconds,t.game.progress_percent(),t.game.route.position_valid])
        t.check(t.game.route.position_valid,"continuous movement preserves winding route at cell%d"%link.to)
        if b.index==0:t.check(t.game.checkpoint_index==b.area-1,"area%d checkpoint activates during real traversal"%(b.area+1))
    await t.move_to(Vector3(t.game.finish_x,t.game.level_data.finish_height,t.game.finish_z)-Vector3(0,0,.5))
    print("COURSE23_COMPLETE seconds=%.2f falls=%d hits=%d coins=%d won=%s"%[t.game.elapsed_seconds-start_time,t.game.deaths,contacts[0],t.game.coins,t.game.won])
    t.check(t.game.won and t.game.completion_count==1,"entire connected %d-area course reaches legitimate finish once"%t.game.level_data.sections.size())
    return t.game.won and t.game.completion_count==1
