extends "res://tests/course_completion.gd"
# Actual configured level; contact comes from the first rotating bar, and all
# movement is delivered through the existing touch controls. No hit mocks.
var hits := 0
var at_hit := Vector3.ZERO
var hit_frame := 0
var impulse := Vector3.ZERO

func run() -> void:
    root.size = Vector2i(720,1280)
    var path: String = ProjectSettings.get_setting("application/run/main_scene")
    require(change_scene_to_file(path)==OK,"load actual playable Skybound Sprint")
    await scene_changed
    game = current_scene
    game.runner.hit.connect(func() -> void:
        hits += 1
        if hits == 1:
            at_hit = game.runner.position
            hit_frame = Engine.get_physics_frames()
            impulse = game.runner.knockback
    )
    var held := false
    for tick in range(120):
        # Hold the input BEFORE contact, close enough that this remains a real
        # strike rather than an outside-area dodge.
        if not held and game.runner.position.z <= -3.5:
            touch("left",1,true)
            Input.flush_buffered_events()
            held = true
        await frame()
        if hits > 0:break
    require(held and hits==1 and impulse.x > 4,"real bar registers a rightward impulse while opposite steering is held")
    var lowest_vx := INF
    while Engine.get_physics_frames()-hit_frame < 10:
        lowest_vx = minf(lowest_vx,game.runner.velocity.x)
        await physics_frame
    var dx: float = game.runner.position.x-at_hit.x
    print("HELD_INPUT_EVIDENCE ",JSON.stringify({"held_steering":game.controls.steering(),"impulse_x":impulse.x,
        "lowest_recovery_vx":lowest_vx,"lateral_displacement":dx,
        "forward_displacement":at_hit.z-game.runner.position.z,"recovery_left":game.runner.hit_recovery_left}))
    require(game.controls.steering() < -.9,"opposite touch is genuinely held during impact")
    require(lowest_vx > 0 and dx > .3,"held movement cannot cancel or reverse hit knockback")
    require(at_hit.z-game.runner.position.z < .2,"hit still interrupts autorun")
    for tick in range(22):await physics_frame
    require(game.runner.hit_recovery_left==0 and game.runner.velocity.x < 0,"held steering resumes after finite recovery without another touch")
    require(hits==1,"same collision does not cause repeated hit events")
    touch("left",1,false)
    game.queue_free()
    await frame()
    await frame()
    print("HELD INPUT RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
