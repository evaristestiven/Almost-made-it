extends "res://tests/ninja_challenges.gd"
func run() -> void:
    root.size=Vector2i(720,1280)
    campaign=root.get_node("Campaign");campaign.save_path="user://acceptance26-camera.json"
    campaign.clear_progress();campaign.dirty=false
    for index in range(-1,4):
        await restart_fixture()
        if index>=0:
            var saved:Dictionary=game.checkpoints[index]
            fixture(saved.spawn+Vector3(0,0,1.6))
            drag_direction(Vector2.UP);await seconds(.3);release();await seconds(.2)
            check(game.checkpoint_index==index,"camera test checkpoint activates by real overlap "+str(index))
        var checkpoint:Vector3=game.spawn
        drag_direction(Vector2.RIGHT)
        var deadline:=Engine.get_physics_frames()+hz*6
        var max_lens:=0.0
        var hidden:=0
        var falling_frames:=0
        while game.deaths==0 and Engine.get_physics_frames()<deadline:
            await step()
            if game.runner.position.y<game.runner.course_floor_height-.3:
                falling_frames+=1
                var center:Vector3=game.runner.position+Vector3.UP*.8
                max_lens=maxf(max_lens,game.camera.position.distance_to(center))
                var screen:Vector2=game.camera.unproject_position(center)/Vector2(root.size)
                if game.camera.is_position_behind(center) or screen.x<0 or screen.x>1 or screen.y<.18 or screen.y>1:hidden+=1
        release()
        check(game.deaths==1 and falling_frames>0,"one physical fall enters recovery from checkpoint "+str(index))
        check(hidden==0 and max_lens<16,"fall camera keeps avatar visible without excessive distance at "+str(index))
        deadline=Engine.get_physics_frames()+hz*5
        while game.state!=game.RunState.PLAYING and Engine.get_physics_frames()<deadline:
            check(not game.runner.accept_jump_input and game.controls.movement()==Vector2.ZERO,"recovery holds input until camera ready")
            await step()
        check(game.state==game.RunState.PLAYING and game.camera.is_recovery_ready() and game.runner.position.distance_to(checkpoint)<.15,"recentered camera and correct spawn precede controls "+str(index))
        await seconds(2)
        check(game.deaths==1 and game.runner.is_on_floor() and game.runner.spawn_protection_left==0,"spawn survives beyond protection without unavoidable second death "+str(index))
        print("ACCEPTANCE_CAMERA checkpoint=",index," falling_frames=",falling_frames," hidden=",hidden," max_lens=",max_lens," recovered=",game.camera.is_recovery_ready()," falls=",game.deaths)
    print("LEVEL1 CAMERA RECOVERY RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
