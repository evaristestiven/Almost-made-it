extends SceneTree
var game
var checks := 0
var failures := 0
func _initialize() -> void:
    call_deferred("run")
func frame(count := 1) -> void:
    for i in range(count):
        await process_frame
        await physics_frame
func check(condition: bool, message: String) -> void:
    checks += 1
    print("PASS: " if condition else "FAIL: ", message)
    if not condition:
        failures += 1
func press(index: int, point: Vector2, down := true) -> void:
    var event := InputEventScreenTouch.new()
    event.index = index
    event.position = point
    event.pressed = down
    Input.parse_input_event(event)
func drag(index: int, point: Vector2) -> void:
    var event := InputEventScreenDrag.new()
    event.index = index
    event.position = point
    Input.parse_input_event(event)
func run() -> void:
    root.size = Vector2i(720, 1280)
    game = load("res://main.tscn").instantiate()
    root.add_child(game)
    current_scene = game
    await frame(22)
    # Isolate animation timing from newly correct pending hazard contacts.
    # Active-hazard behavior is covered by phase2_logic and both course suites.
    for hazard in get_nodes_in_group("hazards"):
        hazard.monitoring = false
    check(game.runner.face.state == "running", "runner changes from idle to running")
    var controls = game.controls
    press(1, controls.joystick_center)
    drag(1, controls.joystick_center + Vector2(controls.joystick_radius * 0.35, 0))
    await frame(1)
    check(controls.steering() > 0.35 and controls.steering() < 0.55, "joystick supplies proportional analog steering")
    press(2, controls.jump_center)
    press(2, controls.jump_center, false)
    await frame(3)
    check(game.runner.face.state == "jumping" and game.runner.velocity.y > 0.0, "multitouch analog steering and jump reach physics and animation")
    check(game.runner.face.scale.y > 1.0, "jump stretches visual child only")
    press(1, controls.joystick_center, false)
    await frame(32)
    check(game.runner.face.state == "falling", "descending flight uses falling expression")
    await frame(34)
    check(game.runner.is_on_floor(), "animated character still lands physically")
    for hazard in get_nodes_in_group("hazards"):
        hazard.monitoring = true
    check(controls.steering() == 0, "releasing joystick clears analog steering")
    press(3, controls.buttons.pause.get_global_rect().get_center())
    await frame(2)
    var position_before: Vector3 = game.runner.position
    await frame(10)
    check(paused and game.hud.menu_open and game.runner.position.is_equal_approx(position_before), "pause UI freezes gameplay but remains interactive")
    press(3, controls.buttons.pause.get_global_rect().get_center(), false)
    game.notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    game.notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    check(paused, "foregrounding preserves a manually paused run")
    game.hud.height_slider.value = 0.75
    check(is_equal_approx(controls.joystick_anchor.y, 0.75), "pause setting adjusts control height")
    press(4, controls.buttons.resume.get_global_rect().get_center())
    press(4, controls.buttons.resume.get_global_rect().get_center(), false)
    await frame(4)
    check(not paused and not game.hud.menu_open, "resume button resumes gameplay")
    controls.injected_safe_rect = Rect2(36, 76, 648, 1140)
    game.hud.layout()
    await frame(3)
    check(controls.safe_rect.encloses(Rect2(controls.jump_center - Vector2.ONE * controls.jump_radius, Vector2.ONE * controls.jump_radius * 2)), "jump control stays inside simulated notch/home safe area")
    check(game.hud.top.position.y >= 76 and game.hud.top.get_global_rect().end.x <= 684, "HUD respects simulated safe area")
    # Both HUD and controls must remain separate at wider device proportions.
    root.size = Vector2i(1024, 1366)
    await frame(4)
    game.hud.layout()
    await frame(3)
    check(not game.hud.coin_label.get_global_rect().intersects(game.hud.falls_label.get_global_rect()), "counter labels do not overlap at iPad proportions")
    check(game.hud.progress_bar.value == game.progress_percent(), "HUD progress bar reflects course progress")
    # Actual moving-platform contact, with forward grace to isolate transport.
    var platform = get_nodes_in_group("moving_platforms")[0]
    game.runner.reset_at(platform.global_position + Vector3(0, 0.45, 0))
    game.runner.grace_left = 10.0
    await frame(10)
    var relative_x: float = game.runner.position.x - platform.position.x
    await frame(15)
    check(game.runner.is_on_floor() and absf(game.runner.position.x - platform.position.x - relative_x) < 0.12, "CharacterBody3D rides actual moving platform without slipping")
    game.runner.jump_requested = true
    game.runner.grace_left = 0
    await frame(2)
    check(game.runner.velocity.y > 0 and game.runner.velocity.x == 0, "jump leaves moving platform without accumulating lateral launch velocity")
    var collider_scale: Vector3 = game.runner.get_child(0).scale
    game.runner.face.react("landing")
    await frame(3)
    check(game.runner.face.scale.y < 1.0 and game.runner.get_child(0).scale == collider_scale, "landing squash never scales physics collider")
    game.runner.hit_by_spinner(game.runner.position, 2.0)
    game.runner.face.react("fail")
    await frame(1)
    check(game.runner.face.state == "reaction", "failure has a distinct expression")
    check(game.feedback.streams.size() == 8 and game.feedback.voices.size() == 4, "eight local sound cues load into bounded voice pool")
    for i in range(12):
        game.feedback.play("coin", game.runner.position)
    check(game.feedback.effects.size() <= 6, "particle effects are capped under repeated rewards")
    game.runner.reset_at(Vector3(0, 0.08, 5))
    game.runner.grace_left = 100.0
    game.camera.setup(game.runner)
    var wall := StaticBody3D.new()
    wall.position = Vector3(0, 3.5, 11)
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(2, 2, 2)
    shape.shape = box
    wall.add_child(shape)
    game.add_child(wall)
    await frame(4)
    check(not AABB(Vector3(-1, 2.5, 10), Vector3(2, 2, 2)).has_point(game.camera.position) and game.camera.position.distance_to(game.runner.position) < 8.0, "camera boom shortens outside an actual physics obstruction")
    wall.queue_free()
    await frame(3)
    check(absf(game.camera.position.z - game.runner.position.z - 11.0) < 0.001, "camera restores follow distance after obstruction clears")
    game.queue_free()
    await frame(4)
    print("OVERHAUL RESULT: %d checks, %d failures" % [checks, failures])
    quit(1 if failures else 0)
