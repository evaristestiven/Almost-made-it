extends "res://tests/swipe_movement.gd"
const CATALOG = preload("res://scripts/campaign/level_catalog.gd")
var campaign: Node
var level := 1
var actions := 0
func fresh() -> void:
    if is_instance_valid(game):
        game.queue_free()
        await step()
    change_scene_to_file(CATALOG.scene_path(level))
    await scene_changed
    game = current_scene
    for i in range(90):
        await step()
        if game.state == game.RunState.PLAYING: break
func command_to(point: Vector3) -> void:
    var p: Vector3 = game.runner.position
    var v: Vector3 = game.runner.control_velocity
    var stop := Vector2(p.x,p.z)+Vector2(signf(v.x)*v.x*v.x,signf(v.z)*v.z*v.z)/90.0
    var direction := (Vector2(point.x,point.z)-stop)*3.0
    drag_direction(direction.limit_length(1.0))
func move_to(point: Vector3, duration := 4.0) -> bool:
    var deadline := Engine.get_physics_frames()+ceili(duration*hz)
    while Engine.get_physics_frames() < deadline and game.deaths == 0:
        command_to(point)
        await step()
        if horizontal(game.runner.position-point).length() < .22 and horizontal(game.runner.velocity).length() < 1: return true
    return false
func hop(target: Callable, duration := 2.0) -> bool:
    var deadline := Engine.get_physics_frames()+ceili(duration*hz)
    while not game.runner.is_on_floor() and Engine.get_physics_frames() < deadline: await step()
    jump()
    release(2)
    var airborne := false
    while Engine.get_physics_frames() < deadline and game.deaths == 0:
        var point: Vector3 = target.call()
        command_to(point)
        await step()
        airborne = airborne or game.runner.position.y > .3
        if airborne and game.runner.is_on_floor():
            print("HOP_LAND level=%d point=%s actual=%s" % [level,str(point),str(game.runner.position)])
            return horizontal(game.runner.position-point).length() < 3
    return false
func fixed(point: Vector3) -> Callable:
    return func() -> Vector3: return point
func run_waypoints() -> void:
    if level == 4:
        var bridges := get_nodes_in_group("moving_platforms")
        await move_to(Vector3(0,0,-5.7))
        var deadline := Engine.get_physics_frames()+hz*7
        while bridges[0].position.z < -12 and Engine.get_physics_frames() < deadline:
            command_to(Vector3(0,0,-5.7));await step()
        await hop(func() -> Vector3: return bridges[0].position+Vector3(0,.35,1))
        deadline = Engine.get_physics_frames()+hz*7
        while bridges[0].position.z > -14.5 and Engine.get_physics_frames() < deadline and game.deaths == 0:
            command_to(bridges[0].position+Vector3(0,.35,0));await step()
        await hop(fixed(Vector3(0,0,-22)))
        await move_to(Vector3(0,0,-27.5))
        await hop(func() -> Vector3: return bridges[1].position+Vector3(0,.35,1))
        deadline = Engine.get_physics_frames()+hz*2
        while game.runner.position.z > -37.2 and Engine.get_physics_frames() < deadline and game.deaths == 0:
            command_to(Vector3(bridges[1].position.x,0,-37.5));await step()
        print("FERRY_EDGE ",game.runner.position)
        await hop(fixed(Vector3(0,0,-45)))
        await move_to(Vector3(0,0,-51.7))
        deadline = Engine.get_physics_frames()+hz*7
        while bridges[2].position.z < -59 and Engine.get_physics_frames() < deadline:
            command_to(Vector3(0,0,-51.7));await step()
        await hop(func() -> Vector3: return bridges[2].position+Vector3(0,.35,1))
        deadline = Engine.get_physics_frames()+hz*7
        while bridges[2].position.z > -60 and Engine.get_physics_frames() < deadline and game.deaths == 0:
            command_to(bridges[2].position+Vector3(0,.35,0));await step()
        await hop(fixed(Vector3(0,0,-67)))
    elif level == 7:
        await move_to(Vector3(0,0,-5.7))
        for z in [-13.,-20.,-27.]: await hop(fixed(Vector3(0,0,z)))
        await move_to(Vector3(0,0,-33.7))
        for z in [-40.,-48.,-56.]: await hop(fixed(Vector3(0,0,z)))
        await move_to(Vector3(0,0,-63.7))
        for z in [-70.,-76.,-82.]: await hop(fixed(Vector3(0,0,z)))
    elif level == 8:
        await move_to(Vector3(0,0,-5.7))
        for point in [Vector3(0,0,-13),Vector3(0,0,-19),Vector3(2,0,-26),Vector3(2,0,-33)]: await hop(fixed(point))
        await move_to(Vector3(2,0,-37.7))
        for point in [Vector3(-1,0,-45),Vector3(-1,0,-52),Vector3(0,0,-59)]: await hop(fixed(point))
    elif level == 10:
        await move_to(Vector3(3.5,0,-7.4))
        await move_to(Vector3(0,0,-7.5))
        var bridge = get_nodes_in_group("moving_platforms")[0]
        await hop(func() -> Vector3: return bridge.position+Vector3(0,.35,1))
        await hop(fixed(Vector3(0,0,-21)))
        # Spring launches toward the next island, steer outside the pendulum.
        var deadline := Engine.get_physics_frames()+hz*5
        while game.runner.position.z > -43 and game.deaths == 0 and Engine.get_physics_frames() < deadline:
            var side := 3.5 if game.runner.position.z < -31 else 0.0
            command_to(Vector3(side,0,-48))
            await step()
        await move_to(Vector3(3.5,0,-51.5))
        await move_to(Vector3(0,0,-52.3))
        for z in [-58.,-64.,-72.]: await hop(fixed(Vector3(0,0,z)))
        await move_to(Vector3(0,0,-80.7))
        await hop(fixed(Vector3(0,0,-88)))
        await hop(fixed(Vector3(0,0,-96)))
        await move_to(Vector3(0,0,-104.7))
        await hop(fixed(Vector3(0,0,-112)))
        await hop(fixed(Vector3(0,0,-119)))
        await move_to(Vector3(3.8,0,-120))
        await move_to(Vector3(3.8,0,-132))
    if game.deaths == 0: await move_to(Vector3(game.finish_x,0,game.finish_z-.4),5)
func run_continuous() -> void:
    var takeoffs: Array = []
    match level:
        1: takeoffs = [-7.8,-31.3,-53.3]
        2: takeoffs = [-6.8,-18.8,-32.8,-48.8]
        3: takeoffs = [-6.8,-26.8,-46.8]
        6: takeoffs = [-6.8,-25.8,-45.8,-65.8]
        9: takeoffs = [-6.8,-25.8,-35.8,-51.8,-61.8,-79.8]
    var jump_index := 0
    var deadline := Engine.get_physics_frames()+hz*35
    while not game.won and game.deaths == 0 and Engine.get_physics_frames() < deadline:
        var z: float = game.runner.position.z
        var target_x := 3.5
        match level:
            1: target_x = 3.5
            2: target_x = -1.5 if z > -8 else (1.5 if z > -20 else (-1.5 if z > -34 else 0.0))
            3: target_x = 3.5
            5: target_x = 0.0 if z > -9 else (2.0 if z > -32 else (-2.0 if z > -58 else 0.0))
            6: target_x = 3.35 if z > -72 else 3.6
            9: target_x = 0.0 if z > -22 else (2.0 if z > -52.0 else (-2.0 if z > -79 else 0.0))
        if z < game.finish_z+3: target_x = game.finish_x
        var v: float = game.runner.control_velocity.x
        var stop_x: float = game.runner.position.x+signf(v)*v*v/90.0
        drag_direction(Vector2(clampf((target_x-stop_x)*5,-1,1),-1).normalized())
        if jump_index < takeoffs.size() and z <= takeoffs[jump_index] and game.runner.is_on_floor():
            jump();release(2);jump_index += 1
        await step()
func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    campaign = root.get_node("Campaign")
    campaign.save_path = "user://world1_full_course.json"
    campaign.clear_progress()
    campaign.dirty = false
    for number in range(1,11):
        level = number
        await fresh()
        if level==1:await load("res://tests/course23_driver.gd").traverse(self)
        elif level in [4,7,8,10]: await run_waypoints()
        else: await run_continuous()
        print("WORLD1_COURSE level=%d won=%s falls=%d cp=%d pos=%s route=%s" % [level,game.won,game.deaths,game.checkpoint_index,str(game.runner.position),game.route.position_valid])
        check(game.won,"full touch-controlled course%d reaches real finish" % number)
        if not game.won: break
        check(campaign.completed[number-1] and campaign.can_start(mini(10,number+1)),"legitimate completion advances sequential saved campaign")
        release()
    check(campaign.world_completed(),"ten real course completions mark The Beginning complete")
    campaign.load_progress()
    check(campaign.world_completed(),"fully played campaign survives save reload")
    if is_instance_valid(game):game.queue_free()
    await step()
    print("WORLD1 FULL COURSE RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
