extends "res://tests/camera_follow.gd"
func run() -> void:
    await camera_fixture()
    game.hud.show_win(2,3)
    for i in range(10): await frame()
    print("BASELINE_VICTORY panel=",game.hud.panel.get_global_rect()," safe=",game.controls.safe_rect," min=",game.hud.panel.get_combined_minimum_size()," detail=",game.hud.detail.size)
    game.hud.hide_pause()
    game.runner.position=Vector3(9,0,-20)
    game.camera.setup(game.runner)
    for i in range(60):
        var t: float = float(i)/60
        game.runner.position.y=-11*t*t
        await frame()
    print("BASELINE_FALL body=",game.runner.position," camera=",game.camera.position," distance=",game.camera.position.distance_to(game.runner.position)," visible=",visible_player())
    game.runner.position=game.checkpoints[0].spawn
    game.camera.recover()
    await frame()
    print("BASELINE_RESPAWN camera=",game.camera.position," follow=",game.camera.follow_position," distance=",game.camera.position.distance_to(game.runner.position)," visible=",visible_player())
    game.queue_free()
    await frame()
    quit()
