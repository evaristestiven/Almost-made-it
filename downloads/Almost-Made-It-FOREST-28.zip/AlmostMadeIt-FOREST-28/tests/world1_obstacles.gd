extends "res://tests/world1_regression.gd"
func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    current_level = 1
    await fresh()
    var bar = get_nodes_in_group("hazards")[0]
    fixture(bar.position+Vector3(2.2,-1.03,0))
    var start: Vector3 = game.runner.position
    var end := Engine.get_physics_frames()+hz*5
    while hits == 0 and Engine.get_physics_frames() < end: await step()
    await seconds(.1)
    check(hits > 0 and game.runner.position.distance_to(start) > .1,"reusable bar scene preserves solid standing impact")
    check(bar.get_child(0).mesh.size == bar.colliders[0].shape.size,"bar mesh and solid box match exactly")
    current_level = 4
    await fresh()
    var ferry = get_nodes_in_group("moving_platforms")[0]
    fixture(Vector3(ferry.position.x,.08,ferry.position.z))
    await seconds(.3)
    start = game.runner.position
    await seconds(.4)
    check(game.runner.is_on_floor() and game.runner.position.distance_to(start) > .1 and game.runner.control_velocity == Vector3.ZERO,"moving-platform scene carries idle avatar through native floor physics")
    current_level = 5
    await fresh()
    var pad = get_nodes_in_group("bounce_pads")[0]
    fixture(Vector3(pad.position.x,.2,pad.position.z))
    var highest := 0.0
    var top_screen := 1.0
    for i in range(hz*2):
        await step()
        highest = maxf(highest,game.runner.position.y)
        var head: Vector3 = game.runner.position+Vector3.UP*game.runner.BODY_HEIGHT
        top_screen = minf(top_screen,game.camera.unproject_position(head).y/game.camera.get_viewport().get_visible_rect().size.y)
    print("SPRING_EVIDENCE max_height=%.4f minimum_head_screen_y=%.5f" % [highest,top_screen])
    check(highest > 6 and horizontal(game.runner.velocity).length() < .001,"spring pad launches vertically without introducing autorun")
    check(top_screen > .21,"spring-height camera keeps whole avatar clear of HUD")
    current_level = 6
    await fresh()
    var ball = get_nodes_in_group("swinging_balls")[0]
    fixture(Vector3(0,.08,ball.position.z))
    start = game.runner.position
    end = Engine.get_physics_frames()+hz*5
    while hits == 0 and Engine.get_physics_frames() < end: await step()
    var impulse: Vector3 = game.runner.last_impulse
    var normal: Vector3 = game.runner.last_normal
    await seconds(.1)
    print("PENDULUM_EVIDENCE hits=%d impulse=%s normal=%s displacement=%s" % [hits,str(impulse),str(normal),str(game.runner.position-start)])
    check(hits > 0 and impulse.length() > .1 and impulse.dot(normal) > 0 and impulse.length() <= 18.01,"pendulum relative contact velocity produces bounded normal impulse")
    check(game.runner.position.distance_to(start) > .1,"sweeping wrecking ball physically displaces actual avatar")
    check(is_equal_approx(ball.colliders[0].shape.radius,ball.radius) and is_equal_approx(ball.get_child(0).mesh.radius,ball.radius),"wrecking ball sphere and mesh align")
    current_level = 7
    await fresh()
    var collapse = get_nodes_in_group("collapsing_platforms")[0]
    fixture(Vector3(0,.08,collapse.position.z))
    await seconds(.15)
    check(collapse.triggered and collapse.elapsed < collapse.warning_time,"collapsing platform detects standing player and warns before dropping")
    game.runner.set_physics_process(false)
    await seconds(collapse.warning_time+.5)
    check(collapse.position.y < collapse.origin.y-.5 and collapse.collider.disabled == false,"collapse moves actual solid shape after warning")
    game._respawn()
    await step()
    check(collapse.position == collapse.origin and not collapse.triggered,"death resets collapsing geometry for recovery")
    game.runner.set_physics_process(true)
    current_level = 8
    await fresh()
    var disc = get_nodes_in_group("rotating_discs")[0]
    fixture(Vector3(disc.position.x+1.3,.08,disc.position.z))
    await seconds(.2)
    start = game.runner.position
    await seconds(.5)
    check(game.runner.is_on_floor() and game.runner.position.distance_to(start) > .1 and game.runner.control_velocity == Vector3.ZERO,"rotating disc carries idle avatar through angular platform velocity")
    current_level = 9
    await fresh()
    var belt = get_nodes_in_group("conveyors")[0]
    fixture(Vector3(belt.position.x,.08,belt.position.z))
    await seconds(.2)
    start = game.runner.position
    await seconds(.5)
    check(game.runner.position.z-start.z > .7 and game.runner.control_velocity == Vector3.ZERO,"conveyor native surface velocity moves idle avatar")
    drag_direction(Vector2.UP)
    start = game.runner.position
    await seconds(.4)
    check(game.runner.position.z < start.z-1 and game.runner.control_velocity.z < -9,"manual forward input can overcome opposing belt")
    game.runner.knockback = Vector3(4,0,0)
    release()
    await seconds(.05)
    check(game.runner.knockback.x > 2,"releasing drag on belt preserves external knockback")
    game.queue_free()
    await step()
    print("WORLD1 OBSTACLES RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
