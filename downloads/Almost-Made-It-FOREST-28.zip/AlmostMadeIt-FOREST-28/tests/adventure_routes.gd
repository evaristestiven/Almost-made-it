extends "res://tests/world1_course.gd"
# No pose fixtures: each optional route begins at the real level start and uses
# the same ScreenTouch/ScreenDrag/jump events as the campaign playthrough.
func coin_near(point: Vector2) -> bool:
    for coin in get_nodes_in_group("coins"):
        if Vector2(coin.position.x,coin.position.z).distance_to(point)<.1: return true
    return false
func branch_hop(point: Vector3, top: float) -> void:
    var landed := await hop(fixed(point))
    check(landed and game.runner.is_on_floor() and absf(game.runner.position.y-top)<.15 and horizontal(game.runner.position-point).length()<1.2,"branch%d lands on authored solid at %s" % [level,str(point)])
func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    campaign = root.get_node("Campaign")
    campaign.save_path = "user://adventure_routes.json"
    campaign.clear_progress()
    campaign.dirty = false
    # Level 1's replaced lookout is covered by first_steps_course/recovery.
    # Keep the original optional-route physics assertions for Levels 2–10.
    for number in [2,4,5,6,7,8]:
        level = number
        for i in range(level-1): campaign.completed[i] = true # Unlock fixture only, no player repositioning.
        await fresh()
        match level:
            1:
                await move_to(Vector3(-3.5,0,-7.8))
                await hop(fixed(Vector3(-3.5,0,-17)))
                await move_to(Vector3(-3.5,0,-19))
                await branch_hop(Vector3(-4.4,0,-22),.55)
                check(not coin_near(Vector2(-4.4,-22)),"meadow lookout coin reached by real jump")
                await branch_hop(Vector3(-3.5,0,-28),0)
            2:
                await move_to(Vector3(-1.5,0,-6.8))
                await hop(fixed(Vector3(-1.5,0,-15)))
                await move_to(Vector3(-2.5,0,-18.8))
                await branch_hop(Vector3(-4,0,-21.5),.6)
                check(not coin_near(Vector2(-4,-21.5)),"orchard shortcut coin reached")
                await branch_hop(Vector3(-3,0,-25),1.05)
                await branch_hop(Vector3(1.5,0,-29),0)
            4:
                var bridges := get_nodes_in_group("moving_platforms")
                await move_to(Vector3(0,0,-5.7))
                var deadline := Engine.get_physics_frames()+hz*7
                while bridges[0].position.z < -12 and Engine.get_physics_frames()<deadline: await step()
                await hop(func() -> Vector3: return bridges[0].position+Vector3(0,.35,1))
                deadline = Engine.get_physics_frames()+hz*7
                while bridges[0].position.z > -14.5 and Engine.get_physics_frames()<deadline:
                    command_to(bridges[0].position+Vector3(0,.35,0));await step()
                await hop(fixed(Vector3(0,0,-22)))
                await move_to(Vector3(0,0,-27.5))
                await hop(func() -> Vector3: return bridges[1].position+Vector3(0,.35,1))
                await branch_hop(Vector3(4.1,0,-36),0)
                check(not coin_near(Vector2(4.1,-36)),"cargo dock bonus collected from moving ferry")
                await branch_hop(Vector3(0,0,-44),0)
            5:
                var deadline := Engine.get_physics_frames()+hz*8
                while Engine.get_physics_frames()<deadline and game.deaths == 0:
                    command_to(Vector3(0 if game.runner.position.z > -9 else 2,0,-25))
                    await step()
                    if game.runner.position.z < -23 and game.runner.is_on_floor(): break
                check(game.runner.position.z < -23 and game.runner.is_on_floor(),"first spring reaches middle island")
                var launched := false
                deadline = Engine.get_physics_frames()+hz*7
                while Engine.get_physics_frames()<deadline and game.deaths == 0:
                    launched = launched or game.runner.velocity.y > 15
                    command_to(Vector3(4.3,0,-39) if launched else Vector3(2,0,-31))
                    await step()
                    if launched and game.runner.is_on_floor(): break
                check(launched and absf(game.runner.position.y-2)<.15 and horizontal(game.runner.position-Vector3(4.3,2,-39)).length()<.5,"second spring lands on raised carnival balcony")
                check(not coin_near(Vector2(4.3,-39)),"aerial balcony coin collectible through flight")
                await branch_hop(Vector3(-2,0,-47),0)
            6:
                await move_to(Vector3(3.35,0,-6.8))
                await hop(fixed(Vector3(3.35,0,-16)))
                await move_to(Vector3(3.35,0,-25.8))
                await hop(fixed(Vector3(3.35,0,-36)))
                await move_to(Vector3(4.4,0,-38))
                check(game.runner.is_on_floor() and not coin_near(Vector2(4.4,-38)),"foundry recovery ledge is solid and its coin reachable")
                await move_to(Vector3(3.35,0,-42))
            7:
                await move_to(Vector3(0,0,-5.7))
                for z in [-13.,-20.,-27.]: await hop(fixed(Vector3(0,0,z)))
                await move_to(Vector3(0,0,-33.7))
                await branch_hop(Vector3(3.8,0,-39),.35)
                await branch_hop(Vector3(3.8,0,-46),.65)
                check(not coin_near(Vector2(3.8,-46)),"aqueduct alternate-route coin reached")
                await branch_hop(Vector3(2.5,0,-53),.3)
                await branch_hop(Vector3(0,0,-58),0)
            8:
                await move_to(Vector3(0,0,-5.7))
                for point in [Vector3(0,0,-13),Vector3(0,0,-19),Vector3(2,0,-26),Vector3(2,0,-33)]: await hop(fixed(point))
                await move_to(Vector3(2,0,-35))
                await branch_hop(Vector3(3.5,0,-38.5),.6)
                await branch_hop(Vector3(3.5,0,-43),1.2)
                check(not coin_near(Vector2(3.5,-43)),"observatory upper-walkway coin reached")
                await branch_hop(Vector3(2,0,-48),.6)
                await branch_hop(Vector3(-1,0,-52),0)
        check(game.deaths == 0 and game.route.position_valid and game.route.on_route,"level%d optional route rejoins course without death or invalid progress" % level)
        release()
    if is_instance_valid(game): game.queue_free()
    await step()
    print("ADVENTURE ROUTES RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
