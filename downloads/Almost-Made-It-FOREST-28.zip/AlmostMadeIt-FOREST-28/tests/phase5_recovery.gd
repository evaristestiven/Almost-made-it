extends "res://tests/solid_physics.gd"
func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    await fresh()
    game._respawn()
    game.camera.set_process(false)
    game.camera.position = game.runner.position + Vector3(0,5,-30)
    game.camera.follow_position = game.camera.position
    for i in range(120):
        await frame()
        if game.state == game.RunState.RESPAWNING: break
    require(game.state == game.RunState.RESPAWNING and game.runner.collision_layer == 2,"real death timer places a respawning player")
    var protection: float = game.runner.spawn_protection_left
    for i in range(60): await frame()
    print("RECOVERY_GATE_EVIDENCE state=%s camera_transition=%s controls=%s protection=%.3f initial=%.3f" % [game.RunState.keys()[game.state],game.camera.transitioning,game.controls.accept_gameplay_input,game.runner.spawn_protection_left,protection])
    require(game.state == game.RunState.RESPAWNING and not game.controls.accept_gameplay_input,"camera not ready: recovery cannot release gameplay controls")
    require(is_equal_approx(game.runner.spawn_protection_left,protection),"camera recovery cannot consume the player's protected gameplay window")
    game.camera.set_process(true)
    for i in range(150):
        await frame()
        if game.state == game.RunState.PLAYING: break
    require(game.state == game.RunState.PLAYING and not game.camera.transitioning,"camera convergence releases recovery without soft lock")
    require(game.camera.is_recovery_ready() and game.runner.spawn_protection_left > 1.0,"controls resume only with full-body framing and useful protection")
    # Pause during a real death/recovery timer, then restart while paused.
    await fresh()
    game._respawn()
    game.set_paused(true)
    var timer_left: float = game.recovery_timer.time_left
    for i in range(25): await frame()
    require(game.state == game.RunState.PAUSED and game.recovery_timer.time_left == timer_left and game.deaths == 1,"pause freezes death timer and keeps exactly one fall")
    game.restart()
    for i in range(5): await frame()
    game = current_scene
    require(not paused and game.deaths == 0 and game.checkpoint_index == -1 and game.state != game.RunState.TRANSITIONING,"restart during paused death restores one clean run")

    for cp in [0,1]:
        await fresh()
        var saved: Dictionary = game.checkpoints[cp]
        fixture(saved.spawn+Vector3(0,0,1.1))
        game.runner.allow_forward = true
        game.camera.setup(game.runner)
        for i in range(10): await frame()
        require(game.checkpoint_index == cp and game.spawn == saved.spawn,"actual checkpoint overlap saves correct recovery position")
        game.runner.spawn_protection_duration = .55
        for attempt in [1,2]:
            game.runner.rotation.y = 1.2
            game.runner.knockback = Vector3(4,0,2)
            game.runner.jump_requested = true
            game.runner.jump_buffer = .12
            game._respawn()
            for callback in range(20):
                game.runner.fell.emit()
                game._respawn()
                game.finish_area.body_entered.emit(game.runner)
            require(game.deaths == attempt and not game.won,"overlapping death/finish callbacks cannot duplicate fall or win")
            for i in range(hz*3):
                await frame()
                if game.state == game.RunState.RESPAWNING: break
            require(game.runner.position.distance_to(saved.spawn) < .1 and game.runner.rotation == Vector3.ZERO and game.runner.knockback == Vector3.ZERO and not game.runner.jump_requested and game.runner.jump_buffer == 0,"saved checkpoint resets orientation, residual forces and buffered jump")
            game.set_paused(true)
            var left: float = game.runner.spawn_protection_left
            var rotation: float = bar().rotation.y
            for i in range(12): await frame()
            require(game.runner.spawn_protection_left == left and bar().rotation.y == rotation,"pause during recenter freezes protection and hazards")
            game.set_paused(false)
            for i in range(hz*3):
                await frame()
                if game.state == game.RunState.PLAYING: break
            require(game.camera.is_recovery_ready() and game.runner.is_on_floor() and game.runner.spawn_protection_left >= .55-2.1/hz,"each checkpoint returns control with framed grounded avatar and configured protection")
            game.runner.allow_forward = false
            for i in range(hz): await frame()
            require(game.runner.spawn_protection_left == 0 and game.runner.invulnerable_left == 0 and game.runner.collision_mask == 5,"configured protection expires without removing solid collision")
    # Restart while a placed body is still waiting on camera readiness.
    await fresh()
    game._respawn()
    game.camera.set_process(false)
    for i in range(100):
        await frame()
        if game.state == game.RunState.RESPAWNING: break
    for tap in range(20):
        game.restart()
        game.set_paused(true)
        game._complete_respawn()
    for i in range(5): await frame()
    game = current_scene
    require(game.deaths == 0 and game.runner.spawn_protection_left == 0 and not game.runner.recovery_hold and get_nodes_in_group("hazards").size() == 3,"rapid restart/pause during respawn leaves no stale timer/protection/recovery hold")
    game.queue_free()
    await frame()
    print("PHASE5 RECOVERY RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
