extends SceneTree
const ASSET := "res://assets/nature/quaternius/CommonTree_3/"
const SCENE := "res://scenes/visual_tests/common_tree_3_test.tscn"
var checks:=0
var failures:=0
func _initialize() -> void:call_deferred("run")
func check(okay: bool,message: String) -> void:
    checks+=1
    if okay:print("PASS: ",message)
    else:failures+=1;push_error("FAIL: "+message)
func run() -> void:
    root.size=Vector2i(720,1000)
    var packed:PackedScene=load(SCENE)
    check(packed!=null,"isolated test scene loads")
    if packed==null:quit(1);return
    var scene:=packed.instantiate();root.add_child(scene);current_scene=scene
    var tree:Node3D=scene.get_node("Tree")
    var meshes:=tree.find_children("*","MeshInstance3D",true,false)
    check(meshes.size()==1,"one imported tree mesh instance")
    check(tree.find_children("*","CollisionObject3D",true,false).is_empty(),"tree import has no generated collision bodies")
    var mesh_instance:MeshInstance3D=meshes[0]
    var mesh:Mesh=mesh_instance.mesh
    check(mesh.get_surface_count()==2,"separate bark and foliage mesh surfaces")
    var triangles:=0
    var material_info:Array=[]
    for i in range(mesh.get_surface_count()):
        var arrays:=mesh.surface_get_arrays(i)
        triangles+=arrays[Mesh.ARRAY_INDEX].size()/3
        check(not arrays[Mesh.ARRAY_VERTEX].is_empty() and arrays[Mesh.ARRAY_NORMAL].size()==arrays[Mesh.ARRAY_VERTEX].size(),"surface %d has geometry and normals"%i)
        check(arrays[Mesh.ARRAY_TEX_UV].size()==arrays[Mesh.ARRAY_VERTEX].size(),"surface %d retains texture coordinates"%i)
        var material:StandardMaterial3D=mesh.surface_get_material(i)
        check(material!=null and material.albedo_texture!=null,"surface %d has an imported textured PBR material"%i)
        check(material.cull_mode==BaseMaterial3D.CULL_DISABLED and material.transparency==BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR,"surface %d retains glTF double-sided alpha mask"%i)
        material_info.append({"name":material.resource_name,"texture":material.albedo_texture.resource_path,"normal_enabled":material.normal_enabled,"normal_texture":material.normal_texture.resource_path if material.normal_texture!=null else "","vertex_color":material.vertex_color_use_as_albedo})
    check(triangles==3505,"all 3505 source triangles retained")
    check(material_info[0].texture==ASSET+"Bark_NormalTree.png" and material_info[0].normal_enabled and material_info[0].normal_texture==ASSET+"Bark_NormalTree_Normal.png","bark albedo and normal map resolve to original filenames")
    check(material_info[1].texture==ASSET+"Leaves_NormalTree_C.png","foliage atlas resolves to original filename")
    for pair in [["Bark_NormalTree.png",Vector2(2048,2048)],["Bark_NormalTree_Normal.png",Vector2(2048,2048)],["Leaves_NormalTree_C.png",Vector2(1024,1024)]]:
        var image:Texture2D=load(ASSET+pair[0])
        check(image!=null and image.get_size()==pair[1],"texture imports at source resolution: "+pair[0])
    print("TREE_IMPORT_GEOMETRY triangles=",triangles," bounds=",mesh.get_aabb())
    print("TREE_IMPORT_MATERIALS ",JSON.stringify(material_info))
    if "--render" in OS.get_cmdline_user_args():
        var output:=OS.get_environment("TREE_EVIDENCE_PATH")
        if output.is_empty():output="user://common-tree-evidence"
        DirAccess.make_dir_recursive_absolute(output)
        var camera:Camera3D=scene.get_node("Camera")
        var views:=[{"name":"01-full-tree","at":Vector3(12,7.4,14),"focus":Vector3(0,4.5,0)},{"name":"02-reverse-view","at":Vector3(-12,7.4,-14),"focus":Vector3(0,4.5,0)},{"name":"03-bark-detail","at":Vector3(3.4,3.2,4),"focus":Vector3(0,2.7,0)},{"name":"04-leaf-detail","at":Vector3(5,7.4,5),"focus":Vector3(0,6.6,0)}]
        for view in views:
            camera.position=view.at;camera.look_at(view.focus,Vector3.UP)
            for frame in range(4):await process_frame
            await RenderingServer.frame_post_draw
            var pixels:=root.get_texture().get_image()
            check(not pixels.is_empty() and pixels.save_png(output+"/"+view.name+".png")==OK,"actual rendered viewport saved: "+view.name)
    scene.queue_free();await process_frame
    print("COMMON TREE RESULT: %d checks, %s"%[checks,"ALL PASSED" if failures==0 else "FAILED"])
    quit(0 if failures==0 else 1)
