extends "res://tests/first_steps_course.gd"
func run() -> void:
    root.size=Vector2i(720,1280)
    campaign=root.get_node("Campaign");campaign.save_path="user://adventure27-features.json"
    campaign.clear_progress();campaign.dirty=false
    level=1;await fresh()
    check(game.level_data.skill_stones.size()==3 and game.level_data.coin_detours.size()==2,"three skill links and two optional coin gardens load in actual Level1")
    var landings:=0
    for node in get_nodes_in_group("platforms"):
        if node.get_meta("skill_landing",false):
            landings+=1
            check(node.get_child(0).mesh.size==node.get_child(1).shape.size,"new landing mesh matches enabled solid collider")
    check(landings==5,"all five new solid landings exist")
    var lifts:=0
    for node in get_nodes_in_group("moving_platforms"):
        if horizontal(node.travel).length()>.01 and node.travel.y>.3:lifts+=1
    check(lifts==2,"two gorge ferries combine sideways and vertical travel")
    var right:=false;var left:=false
    for cell in game.level_data.cells:
        if cell.area==1 and cell.hazard:
            left=left or cell.bypass_side<0;right=right or cell.bypass_side>0
    check(left and right,"courtyard teaches both approaches rather than one repeated bypass")
    await traverse();release()
    var expected_coins:=3 if "--skip-detours" in OS.get_cmdline_user_args() else 5
    check(game.won and game.completion_count==1 and game.coins==expected_coins,"entire route wins with optional detours="+str(expected_coins==5))
    print("ADVENTURE27 FEATURES RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
