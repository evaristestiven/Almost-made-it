extends "res://tests/garden_polish.gd"
func detailed_trees(scenery:Node3D) -> Array:
    var result:Array=[]
    for entry in scenery.imported_trees+scenery.garden_trees:
        result.append([entry.model.transform,entry.model.scene_file_path,entry.mesh.mesh.surface_get_material(0),entry.mesh.mesh.surface_get_material(1)])
    return result
func run() -> void:
    root.size=Vector2i(720,1280);current_level=1
    ProjectSettings.set_setting("visuals/landscape/enabled",false);raw(1,true)
    var collisions:=collision_snapshot();var hud_before:=hud_snapshot();var lights:=lighting_snapshot()
    var scenery:Node3D=game.get_node("AdventureScenery")
    var trees:=detailed_trees(scenery)
    var camera_before:Transform3D=game.camera.transform
    var rng_state:int=scenery.rng.state
    ProjectSettings.set_setting("visuals/landscape/enabled",true);raw(1,true)
    scenery=game.get_node("AdventureScenery")
    check(collision_snapshot()==collisions,"landscape retains all gameplay collider geometry/transforms/layers")
    check(hud_before==hud_snapshot() and lights==lighting_snapshot(),"HUD and lighting retain exact prior presentation settings")
    check(game.camera.transform==camera_before,"camera position, angle and framing remain unchanged")
    check(detailed_trees(scenery)==trees,"all sixteen detailed entrance/primary trees retain transforms and source resources")
    check(scenery.rng.state==rng_state,"landscape private RNG leaves existing course/scenery randomness unchanged")
    check(scenery.find_children("*","CollisionObject3D",true,false).is_empty(),"background terrain and vegetation create no collision bodies or triggers")
    for point in [Vector3(-53,12,-163),Vector3(53,13,-178)]:
        var projected:Vector2=game.camera.unproject_position(point)
        check(Rect2(0,240,720,1040).has_point(projected),"distant island accent lies inside portrait gameplay background: "+str(projected))
    print("LANDSCAPE_STATS ",JSON.stringify(scenery.landscape_stats))
    check(scenery.landforms.size()==63 and scenery.land_meshes.size()==4,"four irregular meshes form layered ridges, valley and distant islands")
    check(scenery.land_nodes.size()<40 and scenery.background_nodes.size()<=12,"terrain/details remain spatially batched within draw-call budget")
    check(scenery.forest_roots.size()==172 and scenery.landscape_stats.groves==35,"existing tree count becomes 35 groves rather than added individual primitive trees")
    for variant in scenery.land_meshes:
        var mesh:Mesh=scenery.land_meshes[variant]
        var faces:=mesh.get_faces();var top:=0;var wrong:=0
        for i in range(0,faces.size(),3):
            var normal:Vector3=(faces[i+1]-faces[i]).cross(faces[i+2]-faces[i])
            if normal.length_squared()<.00000001:continue
            if (faces[i].y+faces[i+1].y+faces[i+2].y)/3>0:
                top+=1
                if normal.y<0:wrong+=1
        check(top>500 and wrong==0 and faces.size()/3<=900,"rolling landform top winding and mesh complexity valid: "+str(variant))
    var wider:=true;var seated:=true;var neighbours:=0
    var ratio_sum:=0.0;var maximum_ratio:=0.0
    for entry in scenery.forest_roots:
        var pose:Transform3D=scenery.forest[entry.key].poses[entry.index]
        var data:Dictionary=scenery.source(entry.name)
        var frame:Transform3D=pose*data.local.affine_inverse()
        var ratio:float=frame.basis.x.length()/frame.basis.y.length()
        ratio_sum+=ratio;maximum_ratio=maxf(maximum_ratio,ratio)
        wider=wider and ratio>=1.09
        var bottom:float=(pose*data.mesh.get_aabb()).position.y
        seated=seated and is_finite(scenery.terrain_height(entry.root)) and absf(bottom-scenery.terrain_height(entry.root)+.025)<.002
        var near:=false
        for other in scenery.forest_roots:
            if entry!=other and entry.root.distance_to(other.root)<4.5:near=true;break
        if near:neighbours+=1
    check(wider and ratio_sum/scenery.forest_roots.size()>1.5 and maximum_ratio>1.9,"native tree crowns use varied broader proportions without primitive replacements")
    check(seated,"actual imported instance trunk bottoms sit on final irregular terrain")
    check(neighbours>130,"forest trees have close grove neighbours while hills retain clearings")
    check(scenery.background_bounds.size()<320 and scenery.background_bounds.size()>150,"native rocks and undergrowth add bounded landscape detail")
    for position in [Vector3(0,0,5),Vector3(0,0,2),Vector3(2,1.5,2),Vector3(0,0,-15.7),Vector3(0,0,-43),Vector3(0,0,-70)]:
        var clear:=true
        var bounds_all:Array[AABB]=[]
        for form in scenery.landforms:bounds_all.append(form.pose*form.mesh.get_aabb())
        bounds_all.append_array(scenery.forest_bounds);bounds_all.append_array(scenery.background_bounds)
        for bounds in bounds_all:
            if bounds.intersects_segment(position+Vector3(0,5.7,11),position+Vector3(0,.7,0))!=null:clear=false
        check(clear,"landscape leaves camera/avatar sightline clear at "+str(position))
    scenery.set_quality(0)
    var low:bool=scenery.land_nodes[0].visibility_range_end==190
    scenery.set_quality(1)
    check(low and scenery.land_nodes[0].visibility_range_end==250,"quality reduces scenery visibility distance")
    check(scenery.rotors.size()==2 and scenery.butterflies.size()==3,"existing windmills and garden wildlife remain")
    check(scenery.forest_batches.size()<25,"native forest stays instanced by depth/species/region")
    for number in range(2,11):
        ProjectSettings.set_setting("visuals/landscape/enabled",false);raw(number,true)
        var original_collisions:=collision_snapshot();var visuals:=visual_snapshot();var original_hud:=hud_snapshot();var original_lights:=lighting_snapshot()
        ProjectSettings.set_setting("visuals/landscape/enabled",true);raw(number,true)
        check(original_collisions==collision_snapshot() and visuals==visual_snapshot() and original_hud==hud_snapshot() and original_lights==lighting_snapshot(),"Level%d course, visuals, lighting and HUD remain identical"%number)
    game.queue_free();await step()
    print("LANDSCAPE RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
