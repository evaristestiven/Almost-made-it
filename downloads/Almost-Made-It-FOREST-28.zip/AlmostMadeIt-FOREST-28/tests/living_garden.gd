extends "res://tests/sky_garden.gd"
func clear_view(nature: Node3D,at: Vector3) -> bool:
    var camera_at:=at+Vector3(0,5.7,11)
    var focus:=at+Vector3(0,.7,0)
    for bounds in nature.decoration_bounds:
        if bounds.intersects_segment(camera_at,focus)!=null:return false
    return true
func run() -> void:
    root.size=Vector2i(720,1280)
    raw(1,false);var original:=collision_snapshot()
    raw(1,true)
    var nature:Node3D=game.get_node("AdventureScenery")
    print("LIVING_WORLD_STATS ",JSON.stringify(nature.world_stats))
    check(original==collision_snapshot(),"living world retains every original collision shape/transform/layer/mask")
    check(nature.find_children("*","CollisionObject3D",true,false).is_empty(),"living scenery creates no bodies, triggers, shortcuts or physics areas")
    check(nature.zones.size()==5 and nature.zones[0].name=="Starting Garden" and nature.zones[4].name=="Finish Plaza","five named districts connect one unchanged continuous course")
    check(game.level_data.platforms.size()==4 and game.finish_z==-76 and game.checkpoints.size()==1,"course length, four primary islands, checkpoint and finish unchanged")
    check(nature.rotors.size()==2 and nature.butterflies.size()==3 and nature.banners.size()>=8,"two windmills, three butterflies and district banners are instantiated")
    check(nature.batch_nodes.size()<85 and nature.world_stats.instances<4500,"scenery stays within 85 spatial batches and 4500 authored instances")
    var mesh:Mesh=nature.primitive("blob")
    var data:=mesh.surface_get_arrays(0)
    var outward:=true
    for i in range(data[Mesh.ARRAY_VERTEX].size()):
        if data[Mesh.ARRAY_VERTEX][i].dot(data[Mesh.ARRAY_NORMAL][i])<.5:outward=false
    check(outward,"rounded scenery mesh normals point outward (render regression)")
    var terrain:Mesh=nature.primitive("terrace")
    var vertices:=terrain.surface_get_arrays(0)
    var upward:=true
    for normal in vertices[Mesh.ARRAY_NORMAL]:
        if normal.y<.1:upward=false
    check(upward,"terrain caps face upward without inverted triangles")
    for view in [Vector3(0,0,4),Vector3(0,0,-1.5),Vector3(0,0,-15.7),Vector3(0,0,-43),Vector3(0,0,-70)]:
        check(clear_view(nature,view),"authored scenery bounds clear camera-to-avatar ray at "+str(view))
        check(clear_view(nature,view+Vector3(2,1.5,0)) and clear_view(nature,view+Vector3(-2,0,0)),"sideways/jump camera envelopes remain clear at "+str(view.z))
    for shader_name in ["grass","sky","water","falls","props"]:
        var shader:Shader=load("res://shaders/living_garden/"+shader_name+".gdshader")
        check(not shader.get_shader_uniform_list().is_empty(),"new shader interface parses: "+shader_name)
    current_level=1;await fresh();nature=game.get_node("AdventureScenery")
    var before:float=nature.rotors[0].rotation.z
    await seconds(.2)
    check(nature.rotors[0].rotation.z!=before,"windmill follows cosmetic clock during gameplay")
    game.set_paused(true)
    var clock_before:float=nature.clock;var rotor_pose:Transform3D=nature.rotors[0].transform
    var butterfly_pose:Transform3D=nature.butterflies[0].node.transform
    await seconds(.3)
    check(nature.clock==clock_before and nature.rotors[0].transform==rotor_pose and nature.butterflies[0].node.transform==butterfly_pose,"pause freezes windmills, water clock, butterflies and flags")
    game.set_paused(false);await seconds(.1)
    check(nature.clock>clock_before,"resume restores environmental animation")
    var counts:Dictionary=nature.world_stats.duplicate()
    await fresh();nature=game.get_node("AdventureScenery")
    check(nature.world_stats==counts,"restart produces stable scenery counts and no duplicate districts")
    game.queue_free();await step()
    print("LIVING GARDEN RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
