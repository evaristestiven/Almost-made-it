extends "res://tests/course_completion.gd"
# All three actual rotating obstacles, same run, only touch/physics. No direct
# hit calls, route restores, teleports, immunity changes or disabled hazards.
var bar_hits: Dictionary = {}
var hit_count := 0

func run() -> void:
    root.size = Vector2i(720,1280)
    var path: String = ProjectSettings.get_setting("application/run/main_scene")
    require(change_scene_to_file(path)==OK,"launch configured course for repeated real contacts")
    await scene_changed
    game = current_scene
    game.runner.hit.connect(func() -> void:
        hit_count += 1
        for bar in get_nodes_in_group("hazards"):
            if bar.has_contact(game.runner):
                var key: String = str(bar.position.z)
                bar_hits[key] = bar_hits.get(key,0)+1
                print("MULTIPLE_BAR_EVIDENCE ",JSON.stringify({"bar":str(bar.get_path()),"bar_z":bar.position.z,
                    "hits_for_bar":bar_hits[key],"spawn_protection":game.runner.spawn_protection_left,
                    "velocity":[game.runner.velocity.x,game.runner.velocity.y,game.runner.velocity.z]}))
    )
    var takeoffs := [-7.8,-31.3,-53.3]
    var jump_index := 0
    for tick in range(800):
        steer_to(0)
        if jump_index < takeoffs.size() and game.runner.position.z <= takeoffs[jump_index]:
            touch("jump",2,true)
            touch("jump",2,false)
            jump_index += 1
        await frame()
        if game.won or game.deaths > 0:break
    require(bar_hits.get("-5.0",0)==1,"first active bar penalizes once")
    require(bar_hits.get("-25.0",0)==1,"second active bar penalizes once in same run")
    require(bar_hits.get("-48.0",0)==1,"third active bar penalizes once in same run")
    require(hit_count==3,"three distinct contacts produce exactly three accepted hits")
    require(game.won and game.deaths==0,"course remains completable after all three penalties")
    if touch_direction != "":touch(touch_direction,1,false)
    game.queue_free()
    await frame()
    await frame()
    print("MULTIPLE BARS RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
