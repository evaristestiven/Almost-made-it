extends "res://tests/world1_regression.gd"
func run() -> void:
    root.size=Vector2i(720,1280);root.position=Vector2i.ZERO
    ProjectSettings.set_setting("visuals/world25/enabled",not "--before" in OS.get_cmdline_user_args())
    var output:=OS.get_environment("COURSE_EVIDENCE_PATH")
    if output.is_empty():output="user://world25-evidence"
    DirAccess.make_dir_recursive_absolute(output)
    current_level=1;await fresh()
    var views:=[{"name":"01-starting-garden","cell":0},{"name":"02-training-courtyard","cell":12},{"name":"03-courtyard-timing","cell":14},{"name":"04-waterfall-crossing","cell":27},{"name":"05-windmill-hills","cell":40},{"name":"06-finish-plaza","cell":56},{"name":"07-crown-gate","cell":59}]
    if "--gate-only" in OS.get_cmdline_user_args():views=views.slice(6)
    for view in views:
        var cell:Dictionary=game.level_data.cells[view.cell]
        var pose:Vector3=cell.at+Basis(Vector3.UP,cell.yaw)*Vector3(0,.08,3.8)
        fixture(pose);game.runner.set_physics_process(false);game.camera.setup(game.runner)
        for i in range(18):await step()
        await RenderingServer.frame_post_draw
        var pixels:=root.get_texture().get_image()
        check(not pixels.is_empty() and pixels.save_png(output+"/"+view.name+".png")==OK,"actual gameplay-camera world composition "+view.name)
        print("WORLD25_RENDER ",view.name," draws=",Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)," primitives=",Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME))
    game.queue_free();await step()
    print("WORLD25 RENDERED RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
