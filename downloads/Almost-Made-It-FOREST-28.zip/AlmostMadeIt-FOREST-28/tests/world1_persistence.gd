extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
    var campaign := root.get_node("Campaign")
    if not campaign.world_completed() or campaign.completed.count(true) != 10:
        push_error("Fresh process could not load the genuinely completed World1 save")
        quit(1)
        return
    print("PASS: separate Godot process reloads all10 actual course completions")
    change_scene_to_file("res://scenes/level_select.tscn")
    await scene_changed
    for i in range(5): await process_frame
    var menu = current_scene
    for button in menu.buttons:
        if button.disabled:
            push_error("Completed world contains locked replay button")
            quit(1)
            return
    print("PASS: fresh-process selection exposes all completed replays and World Complete")
    current_scene.queue_free()
    await process_frame
    print("WORLD1 PERSISTENCE RESULT: 2 checks, ALL PASSED")
    quit()
