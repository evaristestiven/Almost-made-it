extends "res://tests/phase3_reliability.gd"
const ENABLED := "debug/collision_test/enabled"

func screen_touch(index: int, point: Vector2, down := true) -> void:
    var event := InputEventScreenTouch.new()
    event.index = index
    event.position = root.get_final_transform()*point
    event.pressed = down
    Input.parse_input_event(event)
    Input.flush_buffered_events()

func summary(label: String) -> void:
    game.diagnostics.refresh()
    print("MOBILE_DIAGNOSTIC_OBSERVATION ",JSON.stringify({"scenario":label,"build":game.diagnostics.BUILD_ID,
        "scene":game.scene_file_path,"overlay":game.diagnostics.label.text}))

func run() -> void:
    var original: bool = ProjectSettings.get_setting(ENABLED,false)
    ProjectSettings.set_setting(ENABLED,true)
    root.size = Vector2i(720,1280)
    await fresh()
    check(game.mobile_collision_test and is_instance_valid(game.diagnostics),"test package enables overlay without console flags or debug-engine assumptions")
    check(game.scene_file_path=="res://main.tscn" and game.diagnostics.build_label.text.contains("COLLISION-TEST-05"),"actual startup scene visibly identifies COLLISION-TEST-05")
    check(game.diagnostics.player_fingerprint==FileAccess.get_sha256("res://scripts/player.gd").left(8),"visible player fingerprint matches loaded project file")
    for bar in get_nodes_in_group("hazards"):
        check(bar.get_script().resource_path=="res://scripts/spinner.gd" and bar.visible_diagnostics,"actual live bar script is instrumented: z="+str(bar.position.z))
        var enabled_shapes := 0
        for collider in bar.colliders:
            if not collider.disabled: enabled_shapes += 1
            if collider.shape is BoxShape3D:
                check(collider.global_transform==bar.get_child(0).global_transform and collider.shape.size==bar.get_child(0).mesh.size,
                    "live box shares exact visible bar transform and dimensions")
        check(enabled_shapes==2 and bar.collision_mask==2 and bar.monitoring and bar.monitorable,"live bar has enabled matching masks/shapes/monitoring")
    for size in [Vector2i(720,1280),Vector2i(1290,2796),Vector2i(1024,1366)]:
        root.size = size
        await frames(4)
        game.diagnostics.layout()
        await frames(2)
        var panel: Rect2 = game.diagnostics.panel.get_global_rect()
        var jump := Rect2(game.controls.jump_center-Vector2.ONE*game.controls.jump_radius,Vector2.ONE*game.controls.jump_radius*2)
        var joystick := Rect2(game.controls.joystick_center-Vector2.ONE*game.controls.joystick_radius,Vector2.ONE*game.controls.joystick_radius*2)
        check(not panel.intersects(jump) and not panel.intersects(joystick) and game.controls.safe_rect.encloses(panel),
            "readable diagnostic panel stays inside safe area and above controls: " + str(size))
    # Reset after layout probes so a prior bar hit cannot intentionally suppress
    # steering during this independent input-through-overlay check.
    await fresh()
    var stick: Vector2 = game.controls.joystick_center-Vector2(game.controls.joystick_radius*.7,0)
    screen_touch(100,stick)
    screen_touch(101,game.controls.jump_center)
    screen_touch(101,game.controls.jump_center,false)
    await ticks(2)
    check(game.runner.velocity.x < 0 and game.runner.velocity.y > 0 and game.controls.steering() < -.9,"overlay leaves real simultaneous touch steering/jump responsive")
    screen_touch(100,stick,false)
    check(game.diagnostics.panel.mouse_filter==Control.MOUSE_FILTER_IGNORE and game.diagnostics.label.mouse_filter==Control.MOUSE_FILTER_IGNORE,
        "overlay consumes no gameplay touch events")

    # Test A: the real level/bar, prepared at a grounded standing position only.
    # This is disclosed fixture setup; B/C/D/E additionally run via uninterrupted
    # touch physics in collision_evidence and other integration scripts.
    await fresh()
    fixture(Vector3(2.2,.08,-5))
    game.runner.invulnerable_left = 0
    game.runner.spawn_protection_left = 0
    game.runner.allow_forward = false
    var start: Vector3 = game.runner.position
    for i in range(150):
        await ticks(1)
        if hits>0:break
    check(hits==1 and game.diagnostics.accepted_hits==1 and game.diagnostics.contact_count>0,"A stationary capsule is swept by actual rotating bar and overlay records acceptance")
    await ticks(3)
    check(game.runner.position.y>start.y and game.runner.knockback.length()>0,"A standing-player contact physically moves capsule")
    summary("A_standing_real_bar_prepared_fixture")

    await fresh()
    fixture(Vector3(0,.05,-5))
    game.runner.allow_forward = false
    await ticks(5)
    summary("protected_contact")
    check(hits==0 and game.diagnostics.last_result=="REJECTED" and game.diagnostics.last_reason=="spawn_protection"
        and game.diagnostics.label.text.contains("protection=ON"),"overlay shows actual protected rejection and exact reason")
    menu("pause",200)
    menu("pause",200,false)
    var remaining: float = game.runner.spawn_protection_left
    await frames(15)
    game.diagnostics.refresh()
    check(paused and game.runner.spawn_protection_left==remaining and game.diagnostics.label.text.contains("State: PAUSED"),"visible state and protection remain accurate while paused")
    menu("resume",201)
    menu("resume",201,false)
    game.runner.allow_forward = false
    for i in range(110):
        await ticks(1)
        if hits>0:break
    summary("D_protection_naturally_expired")
    check(hits==1 and game.runner.spawn_protection_left==0 and game.diagnostics.last_result=="ACCEPTED"
        and game.diagnostics.label.text.contains("protection=OFF") and game.diagnostics.last_reason=="none", "D natural expiry restores hit and visible OFF/ACCEPTED state")
    check(game.diagnostics.last_handler_called,"overlay confirms player hit handler was called")
    menu("pause",202)
    menu("pause",202,false)
    await frames(2)
    menu("restart",203)
    menu("restart",203,false)
    await frames(4)
    game = current_scene
    check(game.diagnostics.BUILD_ID=="COLLISION-TEST-05" and game.diagnostics.accepted_hits==0 and game.deaths==0,"E actual restart retains build identity and resets run/contact totals")
    for i in range(120):
        await ticks(1)
        if game.diagnostics.accepted_hits>0:break
    summary("E_restart_direct_approach")
    check(game.diagnostics.accepted_hits==1 and game.diagnostics.last_result=="ACCEPTED","E normal direct collision still works after real restart")

    ProjectSettings.set_setting(ENABLED,false)
    await fresh()
    check(game.diagnostics==null,"normal production configuration creates no overlay or build label")
    var disabled := true
    for bar in get_nodes_in_group("hazards"):
        disabled = disabled and not bar.visible_diagnostics and bar.diagnostic_contact_count==0
    check(disabled,"normal production configuration disables diagnostic counters")
    ProjectSettings.set_setting(ENABLED,original)
    game.queue_free()
    await frames(3)
    print("MOBILE OVERLAY RESULT: %d checks, %d failures" % [checks,failures])
    quit(1 if failures else 0)
