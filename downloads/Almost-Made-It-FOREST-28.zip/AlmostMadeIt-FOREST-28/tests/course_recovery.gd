extends "res://tests/course_completion.gd"

func run() -> void:
    root.size = Vector2i(720, 1280)
    await frame()
    game = load("res://main.tscn").instantiate()
    root.add_child(game)
    current_scene = game
    await frame()
    # Collect a real coin, then intentionally steer off the real platform twice.
    # No position/velocity overrides, route reseeding or collision disabling.
    for tick in range(120):
        steer_to(2.0)
        await frame()
        if game.coins > 0:
            break
    require(game.coins == 1, "actual coin collected before failure sequence")
    if touch_direction != "":
        touch(touch_direction, 1, false)
        touch_direction = ""
    var preserved: int = game.progress_percent()
    for target_falls in [1, 2]:
        touch("right", 1, true)
        for tick in range(200):
            await frame()
            if game.deaths >= target_falls:
                break
        require(game.deaths == target_falls and game.state == game.RunState.DYING, "real platform departure counts exactly one death, fall=" + str(target_falls))
        touch("right", 1, false)
        var count: int = game.deaths
        touch("jump", 2, true)
        touch("jump", 2, false)
        for tick in range(80):
            await frame()
            if game.state == game.RunState.PLAYING:
                break
        require(game.state == game.RunState.PLAYING and game.deaths == count and game.runner.knockback == Vector3.ZERO and not game.runner.jump_requested,
            "normal recovery rejects stale touch jump and adds no duplicate deaths")
        require(game.coins == 1 and game.progress_percent() >= preserved, "run coin and legitimate high-water progress survive real fall")
    var takeoffs := [-7.8, -31.3, -53.3]
    var jump_index := 0
    for tick in range(650):
        var z: float = game.runner.position.z
        steer_to(3.5 if z > -59 else 2.0)
        if jump_index < takeoffs.size() and z <= takeoffs[jump_index]:
            touch("jump", 2, true)
            touch("jump", 2, false)
            jump_index += 1
        await frame()
        if game.won or game.deaths > 2:
            break
    require(game.won and game.completed_falls == 2 and game.completion_count == 1, "complete active-obstacle course after two actual falls")
    require(game.coins >= 2 and game.coins < 5 and game.completed_coins == game.coins, "completion records preserved/new coins without requiring every coin")
    require(game.checkpoint_index == 1 and game.progress_percent() == 100, "both checkpoints and final progress validate after recovery")
    game.queue_free()
    await frame()
    await frame()
    print("RECOVERY COURSE RESULT: %d checks, %s" % [checks, "FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
