extends "res://tests/world1_regression.gd"
var output := "user://world1-evidence"
func capture(label: String) -> void:
    await RenderingServer.frame_post_draw
    var pixels := root.get_texture().get_image()
    check(not pixels.is_empty() and pixels.save_png(output+"/"+label+".png") == OK,"rendered viewport saved: "+label)
func run() -> void:
    root.size = Vector2i(720,1280)
    root.position = Vector2i.ZERO
    DirAccess.make_dir_recursive_absolute(output)
    for number in range(1,11):
        current_level = number
        await fresh()
        for i in range(5): await step()
        await capture("level-%02d" % number)
        if number == 5:
            var pad = get_nodes_in_group("bounce_pads")[0]
            fixture(Vector3(pad.position.x,.2,pad.position.z))
            await seconds(.9)
            await capture("spring-apex")
    fixture(Vector3(game.finish_x,.08,game.finish_z+1.7))
    drag_direction(Vector2.UP)
    await seconds(.4)
    release()
    for i in range(20): await step()
    check(game.won and campaign.world_completed(),"rendered actual finish opens world-completion results")
    await capture("world-complete-phone")
    root.size = Vector2i(1024,1366)
    for i in range(10): await step()
    await capture("world-complete-tablet")
    game._level_selection()
    for i in range(10): await step()
    await capture("selection-tablet")
    root.size = Vector2i(720,1280)
    for i in range(10): await step()
    await capture("selection-phone")
    current_scene.queue_free()
    await step()
    print("WORLD1 RENDERED RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
