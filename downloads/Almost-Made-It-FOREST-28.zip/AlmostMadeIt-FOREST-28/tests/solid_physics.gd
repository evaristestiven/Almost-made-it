extends "res://tests/course_completion.gd"
var hits := 0
var hz := 60
var at_hit := Vector3.ZERO
var hit_position := Vector3.ZERO
var impulse := Vector3.ZERO
var external_at_hit := Vector3.ZERO
var control_at_hit := Vector3.ZERO

func fresh() -> void:
    if is_instance_valid(game):
        if touch_direction != "": touch(touch_direction,1,false)
        touch_direction = ""
        game.queue_free()
        await frame()
    change_scene_to_file(ProjectSettings.get_setting("application/run/main_scene"))
    await scene_changed
    game = current_scene
    hits = 0
    at_hit = Vector3.ZERO
    impulse = Vector3.ZERO
    game.runner.hit.connect(func():
        hits += 1
        at_hit = game.runner.velocity
        hit_position = game.runner.position
        impulse = game.runner.last_impulse
        external_at_hit = game.runner.knockback
        control_at_hit = game.runner.control_velocity
    )
    for i in range(30):
        await frame()
        if game.state == game.RunState.PLAYING: break

func fixture(position: Vector3, protected := false) -> void:
    game.runner.reset_at(position,protected)
    game.runner.grace_left = 0
    game.runner.allow_forward = false
    game.runner.accept_jump_input = true
    game.state = game.RunState.PLAYING
    game.route.restore(position,game.route.distance_at(position))

func bar(index := 0):
    return get_nodes_in_group("hazards")[index]

func evidence(name: String) -> void:
    print("PHYSICS_EVIDENCE ",JSON.stringify({"scenario":name,"hz":hz,"hits":hits,
        "angle":bar().rotation.y,"body":str(bar().get_path()),"class":bar().get_class(),"velocity":str(at_hit),
        "impulse":str(impulse),"normal":str(game.runner.last_normal),
        "contact_speed":game.runner.last_contact_speed,"position":str(game.runner.position)}))

func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    await fresh()
    require(bar() is AnimatableBody3D and game.runner.collision_mask == 5,"actual playable bar is solid and player mask includes it")
    for i in range(ceili(hz*2.0)):
        await frame()
        if hits: break
    require(hits == 1 and impulse.length() > 0,"real startup autorun receives physical impulse")
    require(external_at_hit.distance_to(Vector3(impulse.x,0,impulse.z)/game.runner.effective_mass) < .001,
        "actual first-hit external channel stores impulse delta-v, not total autorun")
    require(Vector2(control_at_hit.x+external_at_hit.x-at_hit.x,control_at_hit.z+external_at_hit.z-at_hit.z).length() < .001,
        "motor plus external velocity equals computed post-impact horizontal motion")
    evidence("actual_startup_direct")
    var point: Vector3 = game.runner.position
    for i in range(ceili(hz*.15)): await frame()
    require(game.runner.position.distance_to(point) > .05,"impulse displaces actual player collider")

    await fresh()
    var jumped := false
    for i in range(hz*3):
        if not jumped and game.runner.position.z <= 1.5:
            touch("jump",2,true)
            touch("jump",2,false)
            jumped = true
        await frame()
        if game.runner.position.z < -7.5: break
    require(jumped and hits == 0 and game.runner.position.z < -7.5,"actual startup clean touch jump clears solid bar")
    evidence("actual_jump")
    await fresh()
    for i in range(hz*3):
        steer_to(3.5)
        await frame()
        if game.runner.position.z < -7.5: break
    require(hits == 0 and game.runner.position.z < -7.5,"actual touch dodge clears solid bar")

    # Controlled fixtures still instantiate the entire real playable scene.
    var previous_impulse := 0.0
    for speed in [.6,1.8,5.0,10.0]:
        await fresh()
        bar().rotation.y = -.5
        bar().spin_speed = speed
        fixture(Vector3(2.2,.02,-5))
        for i in range(hz*12):
            await frame()
            if hits: break
        require(hits > 0 and impulse.is_finite() and at_hit.length() <= 18.01,"stationary player struck at angular speed " + str(speed))
        require(impulse.length() > previous_impulse,"higher speed increases impulse at comparable radius")
        previous_impulse = impulse.length()
        require(at_hit.dot(game.runner.last_normal) > 0,"stationary avatar displacement velocity follows outward contact normal")
        evidence("speed_" + str(speed))
        var observed_edge_fall := false
        for i in range(hz):
            await frame()
            observed_edge_fall = observed_edge_fall or game.runner.position.y < -.1
        require(game.runner.position.is_finite() and game.runner.velocity.is_finite(),"moving solid remains stable after impact")
        if speed == 10.0:
            require(observed_edge_fall,"strong real impact carries avatar beyond platform edge into a fall")

    # Moving physical contacts must displace a protected player as well.
    await fresh()
    fixture(Vector3(2.2,.02,-5),true)
    bar().spin_speed = 5.0
    var protected_start: Vector3 = game.runner.position
    var protected_contact := false
    for i in range(ceili(hz*.8)):
        await frame()
        protected_contact = protected_contact or bar().contact_this_tick
    require(protected_contact and hits == 0,"moving bar contact during protection suppresses extra impulse")
    require(game.runner.position.distance_to(protected_start) > .2,"protection preserves physical moving-body displacement")
    require(game.runner.collision_mask == 5,"protection never removes solid hazard mask")
    evidence("protected_moving_contact")

    await fresh()
    bar().spin_speed = 0
    # sync_to_physics buffers transforms; establish this STATIC fixture pose
    # explicitly instead of having the next callback overwrite the request.
    bar().sync_to_physics = false
    bar().rotation.y = 0
    bar().sync_to_physics = true
    await frame()
    fixture(Vector3(0,.02,-3))
    game.runner.allow_forward = true
    game.runner.spawn_protection_left = 1.3
    game.runner.invulnerable_left = 1.3
    for i in range(hz*2): await frame()
    require(game.runner.position.z > -4.35,"solid blocking persists through protection and continuous autorun")
    require(game.runner.spawn_protection_left == 0 and game.runner.invulnerable_left < 1.01,"protection expires while solid collision stays active")
    evidence("stationary_wall_blocking")
    var angle: float = bar().rotation.y
    game._set_state(game.RunState.PAUSED)
    for i in range(10): await frame()
    require(bar().rotation.y == angle,"pause freezes solid obstacle")
    paused = false
    game._set_state(game.RunState.PLAYING)
    game.queue_free()
    await frame()
    print("SOLID PHYSICS RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
