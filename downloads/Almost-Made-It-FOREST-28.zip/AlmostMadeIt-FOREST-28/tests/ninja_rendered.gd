extends "res://tests/world1_regression.gd"
func run() -> void:
    root.size=Vector2i(720,1280);root.position=Vector2i.ZERO
    var output:=OS.get_environment("COURSE_EVIDENCE_PATH")
    if output.is_empty():output="user://ninja24-evidence"
    DirAccess.make_dir_recursive_absolute(output)
    current_level=1;await fresh()
    var views:=[{"name":"01-garden-intro-sweep","cell":8},{"name":"02-courtyard-precision","cell":15},{"name":"03-narrow-gorge-bridge","cell":27},{"name":"04-hills-combination","cell":42},{"name":"05-final-precision-jump","cell":58},{"name":"06-golden-finish-gate","cell":59}]
    views.append({"name":"07-gorge-recovery-deck","cell":0,"at":game.level_data.recovery_ledges[0].at+Vector3.UP*.08})
    for view in views:
        var cell:Dictionary=game.level_data.cells[view.cell]
        var pose:Vector3=view.at if view.has("at") else cell.at+Basis(Vector3.UP,cell.yaw)*Vector3(0,.08,3.8)
        fixture(pose);game.runner.set_physics_process(false);game.camera.setup(game.runner)
        for i in range(10):await step()
        await RenderingServer.frame_post_draw
        var pixels:=root.get_texture().get_image()
        check(not pixels.is_empty() and pixels.save_png(output+"/"+view.name+".png")==OK,"actual gameplay-camera view of "+view.name)
        print("NINJA_RENDER ",view.name," draws=",Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)," primitives=",Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME))
    game.queue_free();await step()
    print("NINJA RENDERED RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
