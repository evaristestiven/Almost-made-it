extends "res://tests/world1_regression.gd"
func capture(folder:String,file:String) -> void:
    for i in range(18):await step()
    await RenderingServer.frame_post_draw
    var pixels:=root.get_texture().get_image()
    check(not pixels.is_empty() and pixels.save_png(folder+"/"+file+".png")==OK,"rendered pine evidence "+file)
func run() -> void:
    root.size=Vector2i(720,1280)
    var folder:=OS.get_environment("COURSE_EVIDENCE_PATH")
    DirAccess.make_dir_recursive_absolute(folder)
    change_scene_to_file("res://scenes/visual_tests/pines_test.tscn");await scene_changed
    await capture(folder,"01-pine-models")
    var camera:Camera3D=current_scene.get_node("Camera")
    camera.position=Vector3(-.5,2.8,5);camera.look_at(Vector3(-3,2,0),Vector3.UP)
    await capture(folder,"02-pine-bark-and-leaves")
    current_level=1;game=current_scene;await fresh()
    for index in [4,43]:
        var cell:Dictionary=game.level_data.cells[index]
        fixture(cell.at+Basis(Vector3.UP,cell.yaw)*Vector3(0,.08,3.8))
        game.runner.set_physics_process(false);game.camera.setup(game.runner)
        await capture(folder,"03-forest-garden" if index==4 else "04-forest-hills")
    print("FOREST28 RENDERED RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
