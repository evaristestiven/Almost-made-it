extends "res://tests/solid_physics.gd"

func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    await fresh()
    var jumped_gap := false
    for i in range(hz*8):
        steer_to(3.5)
        if not jumped_gap and game.runner.position.z <= -7.8:
            touch("jump",2,true)
            touch("jump",2,false)
            jumped_gap = true
        await frame()
        if game.checkpoint_index == 0: break
    require(game.checkpoint_index == 0 and hits == 0,"real touch traversal legitimately activates checkpoint")
    if touch_direction != "": touch(touch_direction,1,false)
    touch_direction = ""
    touch("right",1,true)
    for i in range(hz*4):
        await frame()
        if game.deaths: break
    touch("right",1,false)
    var saw_protection := false
    for i in range(hz*3):
        await frame()
        saw_protection = saw_protection or game.runner.spawn_protection_left > 0
        if game.state == game.RunState.PLAYING: break
    require(game.deaths == 1 and game.checkpoint_index == 0 and saw_protection,"one real fall restores checkpoint with protection")
    jumped_gap = false
    var expired := false
    for i in range(hz*5):
        expired = expired or game.runner.spawn_protection_left == 0
        if not jumped_gap and game.runner.position.z <= -31.3:
            touch("jump",2,true)
            touch("jump",2,false)
            jumped_gap = true
        await frame()
        if hits: break
    require(expired and hits > 0 and hit_position.z < -44,"actual post-checkpoint bar hits after natural protection expiration")
    evidence("real_checkpoint_respawn_then_hit")
    var external: Vector3 = game.runner.knockback
    for i in range(1): await frame()
    require(game.runner.knockback.dot(external) > 0,"input motor does not erase external velocity after checkpoint impact")

    # Whole-level fixtures for directions, airborne contacts and repeated runs.
    for index in range(3):
        await fresh()
        var obstacle = bar(index)
        fixture(Vector3(2.0,.02,obstacle.position.z))
        for i in range(hz*4):
            await frame()
            if hits: break
        require(hits == 1,"each actual course obstacle can strike stationary avatar: " + str(index))
        var initial: int = hits
        for i in range(maxi(1,hz/4)): await frame()
        require(hits == initial,"single contact does not accumulate duplicate impacts")
        require(game.runner.velocity.is_finite() and game.runner.position.is_finite(),"side impact remains finite")

    await fresh()
    fixture(Vector3(2.2,.02,-5))
    bar().spin_speed = 5.0
    # Opposing held joystick is present before collision, then remains held.
    touch("left",1,true)
    for i in range(hz*2):
        await frame()
        if hits: break
    require(hits > 0,"simultaneous held movement receives obstacle hit")
    external = game.runner.knockback
    for i in range(1): await frame()
    require(game.runner.knockback.dot(external) > 0,"held joystick cannot cancel composed external impact velocity")
    touch("left",1,false)

    # Airborne fixture intersects bar height, rather than pretending a clear
    # jump should collide. Gravity acts normally after reset.
    await fresh()
    fixture(Vector3(2.2,.65,-5))
    bar().spin_speed = 10.0
    for i in range(hz*2):
        await frame()
        if hits: break
    require(hits > 0 and at_hit.is_finite(),"actual airborne collider contact produces bounded impact")
    game.set_paused(true)
    var saved_angle: float = bar().rotation.y
    var saved_protection: float = game.runner.spawn_protection_left
    for i in range(10): await frame()
    require(bar().rotation.y == saved_angle and game.runner.spawn_protection_left == saved_protection,"pause freezes moving bar and immunity clock")
    game.set_paused(false)
    for i in range(5): await frame()
    require(bar().rotation.y != saved_angle,"resume restores bar physics")
    game.restart()
    for i in range(10): await frame()
    game = current_scene
    require(game.deaths == 0 and game.checkpoint_index == -1 and game.runner.collision_mask == 5,"restart resets run and retains solid hazard collisions")
    game.queue_free()
    await frame()
    print("SOLID RECOVERY RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
