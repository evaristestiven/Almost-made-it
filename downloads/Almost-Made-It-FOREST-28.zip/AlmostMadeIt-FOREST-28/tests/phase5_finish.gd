extends "res://tests/solid_physics.gd"
func run() -> void:
    root.size = Vector2i(720,1280)
    await fresh()
    var zone: Area3D = game.finish_area
    require(zone.position == Vector3(0,1.2,-76) and zone.get_child(0).shape.size == Vector3(9,3,1.2),"actual finish has intended position and unchanged collider dimensions")
    require(zone.monitoring and zone.monitorable and zone.collision_mask == 2 and not zone.get_child(0).disabled,"actual finish monitors real player's enabled collision layer")
    print("FINISH_INSTANCE_EVIDENCE path=%s layer=%d mask=%d shape=%s" % [zone.get_path(),zone.collision_layer,zone.collision_mask,str(zone.get_child(0).shape.size)])
    # Trusted initial fixtures isolate entry geometry; full-course tests below
    # remain the evidence for legitimate route traversal without trusted restores.
    for x in [-3.8,0.0,3.8]:
        for jumping in [false,true]:
            await fresh()
            fixture(Vector3(x,.08,-72.5 if jumping else -74.4))
            game.runner.allow_forward = true
            game.camera.setup(game.runner)
            for i in range(3): await frame()
            if jumping: game.runner.jump_requested = true
            for i in range(60):
                await frame()
                if game.won: break
            require(game.won and game.completion_count == 1 and game.hud.completed and game.hud.overlay.visible,"intended finish lane x=%.1f jump=%s opens one completion screen" % [x,jumping])
            require(game.completed_coins == 0 and game.progress_percent() == 100,"missing all five coins still permits legitimate finish")
            for callback in range(20):
                game.finish_area.body_entered.emit(game.runner)
                game._try_finish()
                game._respawn()
            for i in range(10): await frame()
            require(game.completion_count == 1 and game.deaths == 0 and game.completed_falls == 0 and game.completed_coins == 0,"duplicate finish/death events cannot change results")
    await fresh()
    game.route.furthest_distance = game.route.total_length
    game._try_finish()
    require(not game.won,"displayed maximum progress alone cannot trigger victory")
    game.runner.position = Vector3(0,.08,-76)
    for i in range(5): await frame()
    require(not game.won and not game.route.position_valid,"untracked teleport into finish cannot bypass ordered route validation")
    for target_state in [game.RunState.DYING,game.RunState.RESPAWNING]:
        await fresh()
        fixture(Vector3(0,.08,-75.8))
        game._set_state(target_state)
        if target_state == game.RunState.DYING: game.runner.stop()
        else:
            game.runner.recovery_hold = true
            game.camera.set_process(false)
            game.camera.transitioning = true
        for i in range(4): await frame()
        for callback in range(10): game.finish_area.body_entered.emit(game.runner)
        require(not game.won and game.completion_count == 0,"finish rejects state "+game.RunState.keys()[target_state])
    for x in [-4.94,4.94]:
        await fresh()
        fixture(Vector3(x,1,-75.3))
        game.runner.allow_forward = true
        for i in range(8): await frame()
        require(not game.won,"unsupported outside edge is not an intended finish approach")
    await fresh()
    fixture(Vector3(0,.08,-74.4))
    game.runner.allow_forward = true
    game.finish_area.set_deferred("monitoring",false)
    for i in range(16): await frame()
    require(not game.won and game.completion_count == 0,"disabled finish monitoring cannot be bypassed by route progress")
    await fresh()
    fixture(Vector3(0,.08,-74.4))
    game.runner.allow_forward = true
    for i in range(30):
        await frame()
        if game.won: break
    game.restart()
    for i in range(5): await frame()
    game = current_scene
    require(not game.won and game.completion_count == 0 and game.deaths == 0 and game.coins == 0 and game.checkpoint_index == -1,"restart after victory initializes one clean run")
    game.queue_free()
    await frame()
    print("PHASE5 FINISH RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
