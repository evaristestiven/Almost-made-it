extends "res://tests/swipe_movement.gd"
const CATALOG = preload("res://scripts/campaign/level_catalog.gd")
var current_level := 1
var campaign: Node
func fresh() -> void:
    if is_instance_valid(game):
        game.queue_free()
        await step()
    campaign = root.get_node("Campaign")
    campaign.save_path = "user://world1_regression.json"
    campaign.clear_progress()
    campaign.dirty = false
    for i in range(current_level-1): campaign.completed[i] = true # Explicit unlock fixture, not claimed route traversal.
    change_scene_to_file(CATALOG.scene_path(current_level))
    await scene_changed
    game = current_scene
    hits = 0
    game.runner.hit.connect(func() -> void: hits += 1)
    for i in range(60):
        await step()
        if game.state == game.RunState.PLAYING: break
    await seconds(.1)
func run() -> void:
    root.size = Vector2i(720,1280)
    var signatures: Array[String] = []
    for number in range(1,11):
        current_level = number
        await fresh()
        print("WORLD1_AUDIT level=%d name=%s scene=%s" % [number,game.level_data.name,game.scene_file_path])
        check(game.state == game.RunState.PLAYING and game.runner.is_on_floor() and game._spawn_safe(game.spawn),"level%d loads at valid solid spawn" % number)
        var start: Vector3 = game.runner.position
        await seconds(.2)
        check(horizontal(game.runner.position-start).length() < .001,"level%d has no autorun" % number)
        check(get_nodes_in_group("coins").size() == 5 and game.checkpoints.size() >= 1,"level%d contains5 coins and valid checkpoints" % number)
        var sig := str(game.level_data.platforms)+str(game.level_data.obstacles)
        check(not signatures.has(sig),"level%d has unique layout and mechanic configuration" % number)
        signatures.append(sig)
        drag_direction(Vector2.RIGHT)
        jump()
        await seconds(.1)
        release(2)
        check(game.runner.velocity.x > 0 and game.runner.velocity.y > 0,"level%d swipe+jump work together" % number)
        release()
        await seconds(1)
        check(game.camera.target == game.runner and game.camera.is_recovery_ready(),"level%d camera follows actual body" % number)
        for coin in get_nodes_in_group("coins"):
            var previous: int = game.coins
            var approach:=Vector3(coin.position.x,coin.position.y-1.17,coin.position.z)
            if number==1:
                # A solid bar may separate an actor teleported into its center
                # before Area3D observes it. Approach the new courtyard pickup
                # through real motion, as in the dedicated recovery suite.
                fixture(approach+Vector3(0,0,1.6))
                drag_direction(Vector2.UP);await seconds(.3);release();await seconds(.12)
            else:
                fixture(approach)
                await seconds(.08)
            check(game.coins == previous+1,"level%d real coin overlap grants exactly once" % number)
        check(game.coins == 5,"level%d all five coins collectible" % number)
        for index in range(game.checkpoints.size()):
            var checkpoint: Vector3 = game.checkpoints[index].spawn
            fixture(checkpoint+Vector3(0,0,1.4))
            drag_direction(Vector2.UP)
            await seconds(.28)
            release()
            await seconds(.15)
            check(game.checkpoint_index == index,"level%d checkpoint%d activates through forward overlap" % [number,index+1])
            check(game._spawn_safe(checkpoint),"level%d checkpoint%d stays outside obstacle volumes" % [number,index+1])
            var before_fall: int = game.deaths
            drag_direction(Vector2.RIGHT)
            var limit := Engine.get_physics_frames()+hz*4
            while game.deaths == before_fall and Engine.get_physics_frames() < limit: await step()
            release()
            limit = Engine.get_physics_frames()+hz*4
            while game.state != game.RunState.PLAYING and Engine.get_physics_frames() < limit: await step()
            check(game.deaths == before_fall+1 and game.runner.position.distance_to(checkpoint) < .2,"level%d checkpoint%d physically restores its saved pose after death" % [number,index+1])
            check(game.camera.is_recovery_ready() and game.runner.knockback == Vector3.ZERO and game.runner.spawn_protection_left > 1,"level%d checkpoint%d releases camera/input with full protection" % [number,index+1])
        # Real controlled departure/fall from the last checkpoint, timer recovery.
        var saved: Vector3 = game.spawn
        var falls: int = game.deaths
        drag_direction(Vector2.RIGHT)
        var deadline := Engine.get_physics_frames()+hz*4
        while game.deaths == falls and Engine.get_physics_frames() < deadline: await step()
        release()
        check(game.deaths == falls+1,"level%d physical fall counts once" % number)
        deadline = Engine.get_physics_frames()+hz*4
        while game.state != game.RunState.PLAYING and Engine.get_physics_frames() < deadline: await step()
        check(game.runner.position.distance_to(saved) < .2 and game.camera.is_recovery_ready() and game.runner.move_input == Vector2.ZERO,"level%d restores checkpoint, camera and clear inputs" % number)
        check(game.coins == 5,"level%d coins persist after death" % number)
        await seconds(1.5)
        check(game.runner.spawn_protection_left == 0 and game.runner.collision_mask == 5,"level%d protection expires with solids enabled" % number)
        game.set_paused(true)
        var time_before: float = game.elapsed_seconds
        var obstacle_positions: Array[Transform3D] = []
        var physical: Array = get_nodes_in_group("hazards")+get_nodes_in_group("moving_platforms")+get_nodes_in_group("rotating_discs")
        for body in physical: obstacle_positions.append(body.transform)
        await seconds(.25)
        var frozen := true
        for i in range(physical.size()): frozen = frozen and physical[i].transform == obstacle_positions[i]
        check(frozen and game.elapsed_seconds == time_before,"level%d pause freezes obstacles and completion timer" % number)
        game.set_paused(false)
        # Independent finish-geometry fixture, with missing coins explicitly allowed.
        game.coins = 2
        fixture(Vector3(game.finish_x,.08,game.finish_z+1.7))
        drag_direction(Vector2.UP)
        await seconds(.4)
        release()
        check(game.won and game.completion_count == 1 and game.completed_coins == 2 and game.completed_falls == game.deaths,"level%d legitimate finish snapshots accurate results with missing coins" % number)
        check(game.hud.detail.text.contains(game.level_data.name.to_upper()) and game.hud.time_label.visible,"level%d results show correct name/time" % number)
        check(campaign.completed[number-1] and (campaign.can_start(number+1) if number < 10 else campaign.world_completed()),"level%d unlocks next or completes World1" % number)
        campaign.load_progress()
        check(campaign.completed[number-1],"level%d progress saves and reloads" % number)
        for i in range(5): await step()
        check(game.controls.safe_rect.encloses(game.hud.panel.get_global_rect()),"level%d results fit mobile safe region" % number)
        var count: int = game.completion_count
        for i in range(5): game._try_finish()
        check(game.completion_count == count,"level%d duplicate completion does not award twice" % number)
        game.restart()
        for i in range(10): await step()
        game = current_scene
        await seconds(.4)
        check(game.level_number == number and game.deaths == 0 and game.coins == 0 and game.checkpoint_index == -1 and game.runner.move_input == Vector2.ZERO,"level%d replay resets current run without resetting unlocks" % number)
    game.queue_free()
    await step()
    print("WORLD1 REGRESSION RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
