extends SceneTree
var game
var failed := false
var checks := 0
var hz := 60
var hits := 0
func _initialize() -> void: call_deferred("run")
func check(value: bool, description: String) -> void:
    checks += 1
    if value: print("PASS: ",description)
    else:
        failed = true
        push_error("FAIL: "+description)
func step() -> void:
    await process_frame
    await physics_frame
func seconds(time: float) -> void:
    var end := Engine.get_physics_frames()+ceili(time*hz)
    while Engine.get_physics_frames() < end: await step()
func horizontal(v: Vector3) -> Vector2: return Vector2(v.x,v.z)
func fresh() -> void:
    if is_instance_valid(game):
        game.queue_free()
        await step()
    change_scene_to_file(ProjectSettings.get_setting("application/run/main_scene"))
    await scene_changed
    game = current_scene
    hits = 0
    game.runner.hit.connect(func() -> void: hits += 1)
    for i in range(90):
        await step()
        if game.state == game.RunState.PLAYING: break
    await seconds(.35)
func finger(index: int, pressed: bool, position: Vector2) -> void:
    var event := InputEventScreenTouch.new()
    event.index = index
    event.pressed = pressed
    event.position = root.get_final_transform()*position
    Input.parse_input_event(event)
    Input.flush_buffered_events()
func stick(value: Vector2, index := 1) -> void:
    var controls = game.controls
    if not controls.fingers.has(index): finger(index,true,controls.joystick_center)
    var event := InputEventScreenDrag.new()
    event.index = index
    event.position = root.get_final_transform()*(controls.joystick_center+value*controls.joystick_radius*.7)
    Input.parse_input_event(event)
    Input.flush_buffered_events()
func release(index := 1) -> void: finger(index,false,game.controls.joystick_center+Vector2(500,500))
func jump(index := 2) -> void: finger(index,true,game.controls.jump_center)
func fixture(point: Vector3) -> void:
    game.runner.reset_at(point,false)
    game.runner.grace_left = 0
    game.controls.clear_input()
    game.route.restore(point,game.route.distance_at(point))
    game.camera.setup(game.runner)

func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    await fresh()
    var start: Vector3 = game.runner.position
    var camera_start: Vector3 = game.camera.position
    await seconds(15)
    print("MANUAL_IDLE hz=%d body_delta=%s camera_delta=%s motor=%s" % [hz,str(game.runner.position-start),str(game.camera.position-camera_start),str(game.runner.control_velocity)])
    check(horizontal(game.runner.position-start).length() < .001 and game.runner.move_input == Vector2.ZERO,"15 seconds untouched: no player-requested horizontal travel")
    check(game.camera.position.distance_to(camera_start) < .001,"15 seconds untouched: camera settles without independent advance")
    # Every cardinal direction uses actual ScreenTouch + ScreenDrag, not setting
    # the controller input field. Small excursions stay on the starting platform.
    for axis in [Vector2.UP,Vector2.DOWN,Vector2.LEFT,Vector2.RIGHT]:
        await fresh()
        start = game.runner.position
        var camera_before: Vector3 = game.camera.position
        stick(axis)
        await seconds(.25)
        var moving: Vector2 = horizontal(game.runner.control_velocity)
        check(moving.dot(axis) > 8 and absf(moving.dot(axis.orthogonal())) < .01,"joystick moves in intended direction "+str(axis))
        check(horizontal(game.camera.position-camera_before).dot(axis) > .1,"camera follows actual movement direction "+str(axis))
        release()
        check(game.controls.joystick_vector == Vector2.ZERO and game.controls.movement() == Vector2.ZERO,"finger release recenters and clears both axes")
        check(horizontal(game.runner.control_velocity).length() > 1,"release does not forcibly zero existing motor velocity")
        await seconds(.4)
        var settled: Vector3 = game.runner.position
        check(horizontal(game.runner.control_velocity).length() < .001,"release smoothly decelerates motor to rest")
        await seconds(.4)
        check(horizontal(game.runner.position-settled).length() < .001,"released direction cannot remain stuck")
        check(horizontal(game.runner.position-start).dot(axis) > .5,"actual collider follows requested direction")
    await fresh()
    stick(Vector2(1,-1))
    await seconds(.3)
    check(absf(game.controls.movement().length()-1) < .001 and absf(horizontal(game.runner.control_velocity).length()-game.runner.MOVE_SPEED) < .02,"diagonal input is normalized to cardinal maximum speed")
    check(absf(absf(game.runner.control_velocity.x)-absf(game.runner.control_velocity.z)) < .01,"diagonal direction retains equal axis components")
    release()
    await fresh()
    start = game.runner.position
    var jumped := false
    game.runner.jumped.connect(func() -> void: jumped = true)
    jump()
    await seconds(.15)
    release(2)
    check(game.runner.position.y > .5 and horizontal(game.runner.velocity).length() < .001,"jump in place rises without creating forward velocity")
    await seconds(1)
    check(horizontal(game.runner.position-start).length() < .001 and game.runner.is_on_floor(),"jump lands in place without camera/course-driven movement")
    check(absf(game.camera.position.z-camera_start.z) < .01,"jump in place cannot advance camera down course")
    await fresh()
    stick(Vector2.UP)
    jump()
    await seconds(.1)
    release(2)
    check(game.controls.joystick_finger == 1 and game.controls.movement().y < -.9,"releasing jump finger preserves simultaneous movement")
    check(game.runner.position.y > .4 and game.runner.velocity.z < -1,"simultaneous movement and jump affect real body")
    release()
    await seconds(.25)
    check(game.runner.position.y > .5 and game.controls.movement() == Vector2.ZERO and horizontal(game.runner.control_velocity).length() < .01,"airborne joystick release clears input and decelerates without cancelling gravity")
    await fresh()
    stick(Vector2.UP)
    jump()
    await seconds(.1)
    release()
    check(game.controls.fingers.has(2) and game.controls.joystick_finger == -999,"releasing movement finger preserves the other active touch")
    release(2)
    # Actual moving obstacle from the existing level, standing still, no fake hit.
    await fresh()
    var obstacle = get_nodes_in_group("hazards")[0]
    fixture(Vector3(2.2,.02,obstacle.position.z))
    start = game.runner.position
    var wait_until := Engine.get_physics_frames()+hz*4
    while hits == 0 and Engine.get_physics_frames() < wait_until: await step()
    var external: Vector3 = game.runner.knockback
    check(hits == 1 and external.length() > .1,"idle avatar receives real rotating-bar impact")
    stick(Vector2.RIGHT)
    await seconds(.05)
    var before_release: Vector3 = game.runner.knockback
    release()
    await seconds(.05)
    check(before_release.length() > .1 and game.runner.knockback.dot(before_release) > 0,"joystick release does not cancel legitimate external knockback")
    check(game.runner.position.distance_to(start) > .05,"bar displaces actual stationary collider")
    print("MANUAL_IMPACT hz=%d impulse=%s external=%s displacement=%s" % [hz,str(game.runner.last_impulse),str(game.runner.knockback),str(game.runner.position-start)])
    # Checkpoint fixture: saved state is set through the real checkpoint area.
    await fresh()
    fixture(Vector3(0,.08,-28.7))
    stick(Vector2.UP)
    await seconds(.25)
    release()
    await seconds(.3)
    check(game.checkpoint_index == 0,"actual checkpoint overlap saves checkpoint")
    stick(Vector2.RIGHT)
    var deadline := Engine.get_physics_frames()+hz*4
    while game.deaths == 0 and Engine.get_physics_frames() < deadline: await step()
    check(game.deaths == 1 and game.state == game.RunState.DYING,"held movement off platform produces one death")
    deadline = Engine.get_physics_frames()+hz*4
    while game.state != game.RunState.PLAYING and Engine.get_physics_frames() < deadline: await step()
    check(game.runner.position.distance_to(game.checkpoints[0].spawn) < .15 and game.runner.move_input == Vector2.ZERO and game.controls.fingers.is_empty(),"checkpoint recovery clears old movement, jump and touches")
    start = game.runner.position
    await seconds(2)
    check(horizontal(game.runner.position-start).length() < .001 and game.runner.spawn_protection_left == 0,"respawn remains stationary and finite protection expires")
    # Pause clears all input axes. External momentum is preserved/frozen in pause.
    stick(Vector2.UP)
    await seconds(.12)
    game.set_paused(true)
    start = game.runner.position
    await seconds(.5)
    check(game.runner.position == start and game.controls.movement() == Vector2.ZERO,"pause freezes physics and clears movement input")
    game.set_paused(false)
    await seconds(.5)
    start = game.runner.position
    await seconds(.5)
    check(horizontal(game.runner.position-start).length() < .001,"resume without touching decelerates then remains stationary")
    Input.action_press("ui_down")
    await seconds(.2)
    check(game.runner.move_input.y > .9 and game.runner.velocity.z > 1,"keyboard backward direction is available")
    game.set_paused(true)
    game.set_paused(false)
    await seconds(.1)
    check(game.runner.move_input == Vector2.ZERO,"held keyboard direction cannot carry across pause")
    Input.action_release("ui_down")
    await seconds(.1)
    Input.action_press("ui_up")
    await seconds(.1)
    check(game.runner.move_input.y < -.9,"keyboard re-arms after all directions are released")
    Input.action_release("ui_up")
    game.restart()
    for i in range(10): await step()
    game = current_scene
    await seconds(.5)
    start = game.runner.position
    await seconds(2)
    check(game.deaths == 0 and game.coins == 0 and horizontal(game.runner.position-start).length() < .001 and game.controls.movement() == Vector2.ZERO,"restart creates clean stationary run")
    game.queue_free()
    await step()
    print("MANUAL MOVEMENT RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
