extends "res://tests/world1_course.gd"
# Full sequential campaign, with the summit's optional high balcony included.
func move_to(point: Vector3, duration := 4.0) -> bool:
    if level == 10 and is_equal_approx(point.z,-104.7):
        await super.move_to(Vector3(0,0,-100))
        var landed := await hop(fixed(Vector3(-3.8,0,-101)))
        check(landed and game.runner.is_on_floor() and absf(game.runner.position.y-.7)<.15,"summit bonus balcony reached during full campaign")
        var remaining := false
        for coin in get_nodes_in_group("coins"):
            if Vector2(coin.position.x,coin.position.z).distance_to(Vector2(-3.8,-101))<.1: remaining = true
        check(not remaining,"summit balcony coin collected without teleporting")
        await hop(fixed(Vector3(0,0,-103)))
    return await super.move_to(point,duration)
