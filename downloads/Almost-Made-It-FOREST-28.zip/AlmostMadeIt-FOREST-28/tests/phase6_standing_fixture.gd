extends "res://tests/solid_physics.gd"
func run() -> void:
    root.size = Vector2i(720,1280)
    change_scene_to_file("res://tests/standing_bar_fixture.tscn")
    await scene_changed
    var test_scene = current_scene
    game = test_scene.game
    game.runner.hit.connect(func() -> void: hits += 1)
    for i in range(120):
        await frame()
        if test_scene.test_ready: break
    require(test_scene.test_ready and game.scene_file_path == "res://main.tscn","Xogot QA fixture loads actual playable course")
    require(game.runner.move_input == Vector2.ZERO and game.runner.spawn_protection_left == 0,"stationary fixture requests zero movement, with solid collision and no immunity")
    var start: Vector3 = game.runner.position
    for i in range(180):
        await frame()
        if hits > 0 and game.runner.position.distance_to(start) > .4: break
    print("DEVICE_FIXTURE_EVIDENCE hits=%d displacement=%.5f layer=%d mask=%d body=%s" % [hits,start.distance_to(game.runner.position),game.runner.collision_layer,game.runner.collision_mask,str(bar().get_path())])
    require(hits == 1 and game.runner.position.distance_to(start) > .4,"same fixture provided to device testers produces real solid displacement")
    require(game.runner.collision_layer == 2 and game.runner.collision_mask == 5,"device test keeps normal player collision configuration")
    test_scene.queue_free()
    await frame()
    print("PHASE6 STANDING FIXTURE RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
