extends SceneTree
var game
var failed := false
var checks := 0
var touch_direction := ""

func _initialize() -> void:
    call_deferred("run")

func touch(action: String, index: int, pressed: bool) -> void:
    var event := InputEventScreenTouch.new()
    event.index = index
    event.pressed = pressed
    if action in ["left", "right"]:
        event.position = game.controls.joystick_center + Vector2((-1 if action == "left" else 1) * game.controls.joystick_radius * 0.7, 0)
    elif action == "jump":
        event.position = game.controls.jump_center
    else:
        event.position = game.controls.buttons[action].get_global_rect().get_center()
    event.position = root.get_final_transform() * event.position
    Input.parse_input_event(event)

func steer_to(target: float) -> void:
    # Human-equivalent binary left/right buttons, with braking distance.
    var vx: float = game.runner.velocity.x
    var stop_x: float = game.runner.position.x + signf(vx) * vx * vx / 90.0
    var action := ""
    if target - stop_x > 0.06:
        action = "right"
    elif target - stop_x < -0.06:
        action = "left"
    if action != touch_direction:
        if touch_direction != "":
            touch(touch_direction, 1, false)
        touch_direction = action
        if action != "":
            touch(action, 1, true)

func require(condition: bool, label: String) -> void:
    checks += 1
    if condition:
        print("PASS: ", label)
    else:
        failed = true
        push_error("FAIL: " + label)

func frame() -> void:
    # Observe after _process has updated the follow camera, before next physics.
    await process_frame
    await physics_frame

func run() -> void:
    root.size = Vector2i(720, 1280)
    await frame()
    # Tested at fixed 30 and 60 render FPS, with 60 Hz physics in both cases.
    for phase in [0.0, PI * 0.5, PI]:
        root.size = Vector2i(720, 1280) if phase == 0.0 else (Vector2i(1080, 1920) if phase < PI else Vector2i(1024, 1366))
        await frame()
        game = load("res://main.tscn").instantiate()
        root.add_child(game)
        current_scene = game
        await frame()
        for hazard in get_nodes_in_group("hazards"):
            hazard.rotation.y = phase
        var camera_basis: Basis = game.camera.global_basis
        var max_forward_error := 0.0
        var max_rotation_error := 0.0
        var max_lateral_error := 0.0
        var all_on_screen := true
        var upcoming_on_screen := true
        var max_air_height := 0.0
        var previous_progress := 0
        var progress_monotonic := true
        var jump_index := 0
        var takeoffs := [-7.8, -31.3, -53.3]
        for tick in range(650):
            var z: float = game.runner.position.z
            # Stay outside every spinner's swept radius, then collect a coin.
            # No player teleports, velocity overrides, disabled collisions, or
            # hazard immunity overrides occur in this completion run.
            steer_to(3.5 if z > -59.0 else 2.0)
            if jump_index < takeoffs.size() and z <= takeoffs[jump_index]:
                touch("jump", 2, true)
                touch("jump", 2, false)
                jump_index += 1
            await frame()
            max_forward_error = maxf(max_forward_error, absf(game.camera.position.z - game.runner.position.z - 11.0))
            max_rotation_error = maxf(max_rotation_error, game.camera.global_basis.get_rotation_quaternion().angle_to(camera_basis.get_rotation_quaternion()))
            max_lateral_error = maxf(max_lateral_error, absf(game.camera.position.x - game.runner.position.x))
            max_air_height = maxf(max_air_height, game.runner.position.y)
            all_on_screen = all_on_screen and not game.camera.is_position_behind(game.runner.position + Vector3(0, 0.7, 0))
            all_on_screen = all_on_screen and game.camera.get_viewport().get_visible_rect().has_point(game.camera.unproject_position(game.runner.position + Vector3(0, 0.7, 0)))
            var upcoming := Vector3(0.0, 1.0, game.runner.position.z - 6.0)
            upcoming_on_screen = upcoming_on_screen and not game.camera.is_position_behind(upcoming)
            upcoming_on_screen = upcoming_on_screen and game.camera.get_viewport().get_visible_rect().has_point(game.camera.unproject_position(upcoming))
            var progress: int = game.progress_percent()
            progress_monotonic = progress_monotonic and progress >= previous_progress
            previous_progress = progress
            if game.won or game.deaths > 0:
                break
        print("CAMERA metrics ", max_forward_error, " ", max_rotation_error, " ", max_lateral_error)
        print("COURSE phase=", phase, " z=", game.runner.position.z, " coins=", game.coins, " falls=", game.deaths)
        require(game.won and game.deaths == 0, "full course completed using touch events with all spinners active, phase=" + str(phase))
        require(game.spawn.z == -52.0, "real checkpoint overlaps advance to final checkpoint")
        require(game.coins >= 1, "real coin overlap increments counter during completion")
        require(progress_monotonic and game.progress_percent() == 100, "completion progress is monotonic and finishes at 100")
        require(max_rotation_error < 0.0001 and max_forward_error < 1.1 and max_lateral_error < 0.6,
            "camera keeps existing angle, bounded follow distance and limited steering lag")
        require(all_on_screen and upcoming_on_screen and max_air_height < 3.0, "player and upcoming course stay in view through every jump")
        if touch_direction != "":
            touch(touch_direction, 1, false)
            touch_direction = ""
        # Let the newly opened completion panel finish its container layout.
        await frame()
        await frame()
        # Restart from the actual button, not by manually resetting counters.
        touch("restart", 3, true)
        touch("restart", 3, false)
        await frame()
        await frame()
        game = current_scene
        require(is_instance_valid(game) and not game.won and game.coins == 0 and game.deaths == 0 and game.spawn.z == 5.0,
            "touch restart reloads a clean level")
        game.queue_free()
        await frame()
        await frame()
    print("COURSE RESULT: %d checks, %s" % [checks, "FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
