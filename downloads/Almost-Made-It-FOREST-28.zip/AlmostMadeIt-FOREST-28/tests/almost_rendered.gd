extends "res://tests/world1_regression.gd"
var output:="user://almost-evidence"
func capture(label: String) -> void:
    await RenderingServer.frame_post_draw
    var pixels:=root.get_texture().get_image()
    check(not pixels.is_empty() and pixels.save_png(output+"/"+label+".png")==OK,"actual rendered feedback saved: "+label)
func run() -> void:
    root.size=Vector2i(720,1280)
    root.position=Vector2i.ZERO
    DirAccess.make_dir_recursive_absolute(output)
    current_level=1
    await fresh()
    fixture(Vector3(3.25,.02,-5))
    var signaled: Array[String]=[]
    game.almost_moments.feedback_requested.connect(func(kind: String,_words: String,_at: Vector3) -> void: signaled.append(kind))
    var deadline:=Engine.get_physics_frames()+hz*10
    while not signaled.has("near_miss") and Engine.get_physics_frames()<deadline:await step()
    check(signaled.has("near_miss") and hits==0 and game.hud.notice.text=="ALMOST!","rendered real clean pass reaches ALMOST notice")
    await capture("near-miss")
    current_level=3
    await fresh()
    game.almost_moments.performance_bonus_enabled=true # Demonstrate optional score, default is OFF.
    signaled.clear()
    game.almost_moments.feedback_requested.connect(func(kind: String,_words: String,_at: Vector3) -> void: signaled.append(kind))
    fixture(Vector3(1.7,.02,-24))
    jump();release(2)
    deadline=Engine.get_physics_frames()+hz*5
    while hits==0 and Engine.get_physics_frames()<deadline:await step()
    drag_direction(Vector2(-.4,0))
    deadline=Engine.get_physics_frames()+hz*3
    while (not game.runner.is_on_floor() or game.runner.position.y>.15) and game.deaths==0 and Engine.get_physics_frames()<deadline:await step()
    release()
    while not signaled.has("clutch") and game.deaths==0 and Engine.get_physics_frames()<deadline:await step()
    check(hits>0 and signaled.has("clutch") and game.hud.notice.text.contains("WHAT A SAVE!") and game.deaths==0,"rendered real impact and corrective landing reaches clutch notice")
    await capture("clutch-recovery")
    game.queue_free();await step()
    print("ALMOST RENDERED RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
