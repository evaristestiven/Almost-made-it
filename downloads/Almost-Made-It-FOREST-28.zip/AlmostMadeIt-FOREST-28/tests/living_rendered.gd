extends "res://tests/world1_regression.gd"
func run() -> void:
    root.size=Vector2i(720,1280);root.position=Vector2i.ZERO
    var output:=OS.get_environment("LIVING_EVIDENCE_PATH")
    if output.is_empty():output="user://living-evidence"
    DirAccess.make_dir_recursive_absolute(output)
    current_level=1;await fresh()
    var views:=[{"name":"01-starting-garden","at":Vector3(0,0,4)},{"name":"02-training-courtyard","at":Vector3(0,0,-1.5)},{"name":"03-waterfall-crossing","at":Vector3(0,0,-15.7)},{"name":"04-windmill-hills","at":Vector3(0,0,-43)},{"name":"05-finish-plaza","at":Vector3(0,0,-70)}]
    for view in views:
        fixture(view.at);game.runner.set_physics_process(false)
        for i in range(6):await step()
        await RenderingServer.frame_post_draw
        var pixels:=root.get_texture().get_image()
        check(not pixels.is_empty() and pixels.save_png(output+"/"+view.name+".png")==OK,"actual gameplay-camera rendered composition: "+view.name)
        print("CAMERA_VIEW ",view.name," player=",game.runner.global_position," camera=",game.camera.global_position)
    game.queue_free();await step()
    print("LIVING RENDERED RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
