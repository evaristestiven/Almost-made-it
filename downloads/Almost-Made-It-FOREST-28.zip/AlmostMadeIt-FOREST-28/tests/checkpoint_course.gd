extends "res://tests/course_completion.gd"
# Full integration: only normal touch input. No trusted fixtures, teleportation,
# route restoration, immunity/velocity overrides, or disabled obstacles.
func fail_and_recover(expected_falls: int, cp: int) -> void:
    if touch_direction != "":
        touch(touch_direction,1,false)
        touch_direction = ""
    var coins_before: int = game.coins
    var progress_before: int = game.progress_percent()
    touch("right",1,true)
    for tick in range(220):
        await frame()
        if game.deaths >= expected_falls:
            break
    require(game.deaths == expected_falls and game.state == game.RunState.DYING,
        "actual departure counts once at checkpoint %d, fall %d" % [cp,expected_falls])
    touch("right",1,false)
    var observed_spawn := false
    var clean_reset := false
    for tick in range(100):
        await frame()
        if game.state == game.RunState.RESPAWNING:
            observed_spawn = absf(game.runner.position.z-game.checkpoints[cp].spawn.z) < 0.01
            clean_reset = game.runner.knockback == Vector3.ZERO and not game.runner.jump_requested and game.runner.invulnerable_left > 0
        if game.state == game.RunState.PLAYING:
            break
    require(observed_spawn and clean_reset and game.state == game.RunState.PLAYING and game.deaths == expected_falls,
        "real timer restores protected latest checkpoint %d without extra deaths" % cp)
    require(game.coins == coins_before and game.progress_percent() >= progress_before and game.checkpoint_index == cp,
        "coins, progress and latest checkpoint survive real failure")

func run() -> void:
    root.size = Vector2i(720,1280)
    await frame()
    game = load("res://main.tscn").instantiate()
    root.add_child(game)
    current_scene = game
    await frame()
    for tick in range(120):
        steer_to(2)
        await frame()
        if game.coins == 1:
            break
    require(game.coins == 1, "real coin collected before checkpoint recovery course")
    var tested_cp := -1
    var jump_index := 0
    var takeoffs := [-7.8,-31.3,-53.3]
    for tick in range(850):
        if game.checkpoint_index > tested_cp:
            tested_cp = game.checkpoint_index
            await fail_and_recover(tested_cp * 2 + 1,tested_cp)
            await fail_and_recover(tested_cp * 2 + 2,tested_cp)
        var z: float = game.runner.position.z
        steer_to(3.5 if z > -59 else 2)
        if jump_index < takeoffs.size() and z <= takeoffs[jump_index]:
            touch("jump",2,true)
            touch("jump",2,false)
            jump_index += 1
        await frame()
        if game.won or game.deaths > (tested_cp+1)*2:
            break
    require(tested_cp == 1 and game.checkpoint_index == 1, "both actual checkpoint triggers exercised")
    require(game.won and game.completion_count == 1 and game.completed_falls == 4,
        "all-active course completes after two actual failures from each checkpoint")
    require(game.completed_coins == game.coins and game.coins >= 2 and game.coins < 5 and game.progress_percent() == 100,
        "four-fall finish preserves coins, permits missing coins, and displays 100 percent")
    game.queue_free()
    await frame()
    await frame()
    print("CHECKPOINT COURSE RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
