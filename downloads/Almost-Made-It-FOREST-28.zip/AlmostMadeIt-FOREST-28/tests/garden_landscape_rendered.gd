extends "res://tests/world1_regression.gd"
func run() -> void:
    root.size=Vector2i(720,1280);root.position=Vector2i.ZERO
    var output:=OS.get_environment("LIVING_EVIDENCE_PATH")
    if output.is_empty():output="user://living-evidence"
    DirAccess.make_dir_recursive_absolute(output)
    ProjectSettings.set_setting("visuals/landscape/enabled",not "--before" in OS.get_cmdline_user_args())
    current_level=1;await fresh()
    var views:=[{"name":"01-entrance","at":Vector3(0,0,5)},{"name":"02-garden-path","at":Vector3(0,0,2)},{"name":"03-garden-exit","at":Vector3(0,0,-2.8)},{"name":"04-eastern-view","at":Vector3(2,0,4)}]
    for view in views:
        fixture(view.at);game.runner.set_physics_process(false)
        for i in range(6):await step()
        await RenderingServer.frame_post_draw
        var pixels:=root.get_texture().get_image()
        check(not pixels.is_empty() and pixels.save_png(output+"/"+view.name+".png")==OK,"actual gameplay-camera rendered composition: "+view.name)
        print("RENDER_BUDGET draw_calls=",Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)," triangles=",Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME))
        print("CAMERA_VIEW ",view.name," player=",game.runner.global_position," camera=",game.camera.global_position)
    game.queue_free();await step()
    print("LANDSCAPE RENDERED RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
