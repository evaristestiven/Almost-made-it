extends "res://tests/solid_physics.gd"
func visible_player() -> bool:
    var point: Vector3 = game.runner.position + Vector3.UP*.7
    return not game.camera.is_position_behind(point) and game.camera.get_viewport().get_visible_rect().has_point(game.camera.unproject_position(point))
func camera_fixture() -> void:
    await fresh()
    game.runner.set_physics_process(false)
    game.runner.position = Vector3(3.5,.0,3)
    game.camera.setup(game.runner)
    await frame()

func run() -> void:
    root.size = Vector2i(720,1280)
    await camera_fixture()
    # The body may have a nonzero REQUESTED velocity while actually blocked.
    game.runner.velocity = Vector3(4,0,-9.8)
    var origin: Vector3 = game.camera.position
    var start_time := Engine.get_process_frames()
    var start_seconds: float = game.camera.clock
    var fps := 60
    var args := OS.get_cmdline_args()
    for index in range(args.size()-1):
        if args[index] == "--fixed-fps": fps = args[index+1].to_int()
    while game.camera.clock-start_seconds < 15.0: await frame()
    print("CAMERA_STATIONARY_EVIDENCE seconds=%.2f frames=%d delta=%s" % [game.camera.clock-start_seconds,Engine.get_process_frames()-start_time,str(game.camera.position-origin)])
    require(absf(game.camera.position.z-origin.z) < .001,"stationary avatar: no independent course advance for 15 simulated seconds")
    require(game.camera.position.distance_to(origin) < .001,"requested velocity alone cannot move a stationary-player camera")
    game.runner.velocity = Vector3.ZERO
    origin = game.camera.position
    game.runner.position.z -= 1
    await frame()
    require(absf(game.camera.position.z-origin.z) < .8,"forward tracking smooths a displacement instead of snapping to it")
    for i in range(fps): await frame()
    origin = game.camera.position
    for i in range(fps): await frame()
    require(game.camera.position.distance_to(origin) < .001,"stopped player: follow settles without accumulating drift")
    var angle: Basis = game.camera.global_basis
    # Establish steady forward motion then reverse: camera must never continue
    # forward against actual reverse displacement because of a stale target.
    for i in range(fps):
        game.runner.position.z -= 3.0/fps
        await frame()
    var wrong_way := false
    for i in range(fps):
        origin = game.camera.position
        game.runner.position.z += 3.0/fps
        await frame()
        wrong_way = wrong_way or game.camera.position.z < origin.z-.001
    require(not wrong_way and visible_player(),"reverse displacement never advances camera forward and player remains visible")
    require(game.camera.global_basis.is_equal_approx(angle),"existing camera angle is unchanged")
    # Jump in place with the existing ballistic height; track vertical excursion.
    var low: float = game.camera.position.y
    var high := low
    for i in range(fps):
        var t: float = float(i)/fps
        game.runner.position.y = maxf(0,10.4*t-11*t*t)
        await frame()
        high = maxf(high,game.camera.position.y)
        require_visible = require_visible and visible_player()
    for i in range(fps): await frame()
    require(high-low < 1.5 and require_visible,"jump stays visible with restrained vertical camera travel")
    game.runner.position.y = -3.5
    for i in range(fps/2): await frame()
    require(visible_player(),"falling avatar stays in frame briefly instead of falling below a fixed camera")
    origin = game.camera.follow_position
    game.runner.position = game.checkpoints[0].spawn
    game.camera.recover()
    await frame()
    require(game.camera.follow_position.distance_to(game.runner.position+game.camera.OFFSET) < 1.0 and visible_player(),"respawn resets world history and eases only a bounded checkpoint-local framing error")
    for i in range(fps): await frame()
    require(visible_player() and absf(game.camera.position.z-game.runner.position.z-11) < .04,"respawn recenters on actual checkpoint position")
    game.runner.set_physics_process(true)
    game.restart()
    for i in range(5): await frame()
    game = current_scene
    require(game.camera.target == game.runner and visible_player(),"restart resets tracking to new player instance")
    game.queue_free()
    await frame()
    print("CAMERA FOLLOW RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
var require_visible := true
