extends "res://tests/world1_course.gd"
var sections:=5
var failures_at: Array[String]=[]
var hit_total:=0

func goto_point(point:Vector3,duration:=5.0) -> bool:
    return await move_to(point,duration)

func traverse() -> void:
    await load("res://tests/course23_driver.gd").traverse(self)

func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--sections="):sections=argument.get_slice("=",1).to_int()
        if argument.begins_with("--physics-hz="):hz=argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second=hz
    root.size=Vector2i(720,1280)
    ProjectSettings.set_setting("development/course23/sections",sections)
    ProjectSettings.set_setting("visuals/sky_garden/enabled","--scenery" in OS.get_cmdline_user_args())
    campaign=root.get_node("Campaign");campaign.save_path="user://course23-test.json"
    campaign.clear_progress();campaign.dirty=false
    level=1
    await fresh()
    game.runner.hit.connect(func()->void:hit_total+=1)
    check(game.level_data.sections.size()==sections,"actual Level1 builds requested connected sections")
    check(game.state==game.RunState.PLAYING and game.runner.is_on_floor(),"safe initial spawn and playable controls")
    await traverse()
    release()
    print("COURSE23 RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
