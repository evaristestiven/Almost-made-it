extends "res://tests/solid_physics.gd"
func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    for index in range(3):
        for protected in [false,true]:
            await fresh()
            var obstacle = bar(index)
            fixture(Vector3(2.2,.02,obstacle.position.z),protected)
            game.camera.setup(game.runner)
            var smallest := 1000.0
            var largest := 0.0
            var start: Vector3 = game.runner.position
            for step in range(hz*2):
                await frame()
                var distance: float = game.camera.position.distance_to(game.runner.position+Vector3.UP*.7)
                smallest = minf(smallest,distance)
                largest = maxf(largest,distance)
            print("PHASE6_CONTACT_CAMERA bar=%d protected=%s hz=%d lens_min=%.5f lens_max=%.5f displacement=%.4f" % [index,protected,hz,smallest,largest,start.distance_to(game.runner.position)])
            require(smallest >= 2.99 and largest < 16,"standing bar %d cannot collapse lens into avatar, protection=%s" % [index,protected])
            require(start.distance_to(game.runner.position) > .1,"camera repair preserves actual physical bar displacement")
    game.queue_free()
    await frame()
    print("PHASE6 CONTACT CAMERA RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
