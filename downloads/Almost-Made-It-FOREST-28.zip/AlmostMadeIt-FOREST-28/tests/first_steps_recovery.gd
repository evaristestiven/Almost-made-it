extends "res://tests/first_steps_course.gd"

func steer(point:Vector3,duration:=4.0) -> bool:
    var until:=Engine.get_physics_frames()+ceili(duration*hz)
    while Engine.get_physics_frames()<until and game.state==game.RunState.PLAYING:
        command_to(point);await step()
        if horizontal(game.runner.position-point).length()<.2 and horizontal(game.runner.velocity).length()<1:return true
    return false

func run() -> void:
    root.size=Vector2i(720,1280)
    campaign=root.get_node("Campaign");campaign.save_path="user://course23-recovery.json"
    campaign.clear_progress();campaign.dirty=false
    await fresh()
    check(game.level_data.cells.size()==60 and game.checkpoints.size()==4,"60 landings and four ordered checkpoints in actual scene")
    check(game.route.total_length>800 and game.route.total_length<1100,"meaningful winding course length supports adventure duration")
    var at:Vector3=game.runner.position;var camera_at:Vector3=game.camera.position
    await seconds(15)
    check(game.runner.position.distance_to(at)<.001 and game.camera.position.distance_to(camera_at)<.001,"new course stays still for 15 seconds without touch")
    var scenery:Node3D=game.get_node("AdventureScenery")
    check(scenery.find_children("*","CollisionObject3D",true,false).is_empty(),"retained/repositioned scenery introduces no hidden colliders or shortcuts")
    check(scenery.zones.size()==5 and scenery.rotors.size()==3 and scenery.forest_roots.size()>300,"five scenic areas, original imported forests and animated windmills loaded")
    for i in range(game.checkpoints.size()):
        var saved:Dictionary=game.checkpoints[i]
        check(game._spawn_safe(saved.spawn),"checkpoint%d capsule clear with supported floor"%i)
        var index:int=game.level_data.sections[i+1].cell
        var direction:Vector3=(game.level_data.cells[index].at-game.level_data.cells[index-1].at).normalized()
        fixture(saved.spawn-direction*2.0)
        await seconds(.4)
        await steer(saved.spawn+direction*1.0)
        release()
        check(game.checkpoint_index==i,"checkpoint%d activates by actual moving body overlap"%i)
        var before:int=game.deaths
        # Walk off a real edge, without teleporting or calling _respawn().
        drag_direction(Vector2.RIGHT)
        var deadline:=Engine.get_physics_frames()+hz*5
        while game.deaths==before and Engine.get_physics_frames()<deadline:await step()
        release()
        check(game.deaths==before+1 and game.respawning,"one physical fall produces exactly one death at checkpoint%d"%i)
        var had_protection:=false
        deadline=Engine.get_physics_frames()+hz*5
        while Engine.get_physics_frames()<deadline:
            await step()
            had_protection=had_protection or game.runner.spawn_protection_left>0
            if game.state==game.RunState.PLAYING:break
        check(game.state==game.RunState.PLAYING and game.deaths==before+1,"checkpoint%d recovery returns to play without duplicate deaths"%i)
        check(game.runner.global_position.distance_to(saved.spawn)<.15,"checkpoint%d restores correct elevated location"%i)
        check(game.camera.is_recovery_ready(),"camera reframed before input restoration at checkpoint%d"%i)
        await seconds(1.4)
        check(had_protection and game.runner.spawn_protection_left<=0 and game.runner.invulnerable_left<=0,"checkpoint%d protection begins and expires"%i)
        check(game.controls.movement()==Vector2.ZERO and game.runner.knockback.length()<.001 and horizontal(game.runner.control_velocity).length()<.001,"checkpoint%d clears old drag and impact velocity"%i)
        var prior:float=game.route.furthest_distance
        check(game.route.current_distance<=prior and game.route.position_valid,"checkpoint%d restore keeps valid ordered progress"%i)
        print("COURSE23_RECOVERY checkpoint=",i," falls=",game.deaths," spawn=",game.runner.position," camera_ready=",game.camera.is_recovery_ready()," protection=",game.runner.spawn_protection_left)
    # All five coins can be collected through their real body-entered signals.
    for pickup in get_nodes_in_group("coins").duplicate():
        var p:Vector3=pickup.position-Vector3.UP*1.25
        fixture(p+Vector3(0,.08,1.6));await seconds(.4)
        var before:int=game.coins
        await steer(p-Vector3(0,0,.5));release();await seconds(.15)
        check(game.coins==before+1,"real pickup at %s is reachable exactly once"%str(p))
    check(game.coins==5,"all five optional coins collectible")
    game._respawn();await seconds(.1)
    check(game.finish_status().begins_with("state_"),"death cannot become victory")
    game.restart();await scene_changed;game=current_scene;await seconds(.6)
    check(game.state==game.RunState.PLAYING and game.checkpoint_index==-1 and game.deaths==0 and game.coins==0,"restart during recovery clears run state")
    check(game.runner.position.distance_to(Vector3(0,0,5))<.1 and game.controls.movement()==Vector2.ZERO,"restart restores manual stationary start")
    game.set_paused(true);var stopped:Vector3=game.runner.position
    await seconds(.2);game.set_paused(false);await seconds(.3)
    check(game.runner.position.distance_to(stopped)<.01 and game.controls.movement()==Vector2.ZERO,"pause/resume leaves new course and drag state stable")
    print("COURSE23 RECOVERY RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
