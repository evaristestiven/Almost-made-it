extends "res://tests/solid_physics.gd"
func run() -> void:
    root.size = Vector2i(720,1280)
    await fresh()
    fixture(Vector3(3.5,.02,3.0))
    for i in range(8): await frame()
    require(game.runner.is_on_floor(),"solid hazard mask preserves valid platform floor contact")
    var takeoffs := [0]
    game.runner.jumped.connect(func(): takeoffs[0] += 1)
    game.runner.jump_requested = true
    await frame()
    require(takeoffs[0] == 1 and game.runner.velocity.y > 0,"grounded jump remains responsive")
    var upward: float = game.runner.velocity.y
    game.runner.jump_requested = true
    await frame()
    require(takeoffs[0] == 1 and game.runner.velocity.y < upward,"airborne repeat input cannot double jump")
    for i in range(100):
        await frame()
        if game.runner.velocity.y < 0 and game.runner.position.y < .5:
            game.runner.jump_requested = true
            break
    for i in range(12):
        await frame()
        if takeoffs[0] == 2: break
    require(takeoffs[0] == 2 and game.runner.velocity.y > 0,"near-landing buffered jump fires once")
    for i in range(130): await frame()
    require(game.runner.is_on_floor() and absf(game.runner.position.y) < .02,"gravity and landing settle without hovering or floor penetration")
    game.runner.jump_requested = true
    game.runner.jump_buffer = .12
    game.runner.knockback = Vector3(5,0,2)
    game.runner.reset_at(Vector3(3.5,.08,3),true)
    require(game.runner.jump_buffer == 0 and not game.runner.jump_requested and game.runner.knockback == Vector3.ZERO and game.runner.velocity == Vector3.ZERO,"respawn clears pending jump, gravity motion and external force")
    game.queue_free()
    await frame()
    print("SOLID MOVEMENT RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
