extends "res://tests/phase2_logic.gd"
# Inherits the existing small assertion/scene-fixture harness. Fixtures position
# isolated cases explicitly; course_completion/recovery remain input-only runs.
func ticks(count: int) -> void:
    for tick in range(count):
        await physics_frame

func wait_state(target: int, limit := 150) -> bool:
    for tick in range(limit):
        if game.state == target:
            return true
        await ticks(1)
    return game.state == target

func menu(action: String, index: int, down := true) -> void:
    var event := InputEventScreenTouch.new()
    event.index = index
    event.pressed = down
    event.position = root.get_final_transform() * game.controls.buttons[action].get_global_rect().get_center()
    Input.parse_input_event(event)
    Input.flush_buffered_events()

func run() -> void:
    root.size = Vector2i(720,1280)
    for x in [-3.8, 0.0, 3.8]:
        for jumping in [false, true]:
            await fresh()
            fixture(Vector3(x,0.08,-72.5 if jumping else -74.4))
            await ticks(3)
            if jumping:
                game.runner.jump_requested = true
            await wait_state(game.RunState.COMPLETED, 50)
            check(game.won and game.completion_count == 1 and game.hud.overlay.visible and game.hud.completed,
                "supported finish entry opens completion: x=%s jumping=%s" % [x,jumping])
            check(game.progress_percent() == 100 and game.completed_falls == 0 and game.completed_coins < 5,
                "finish accepts missing coins and finalizes exact results: x=%s jumping=%s" % [x,jumping])
            var z: float = game.runner.position.z
            area(-76).body_entered.emit(game.runner)
            game._respawn()
            await ticks(12)
            check(game.completion_count == 1 and game.deaths == 0 and is_equal_approx(game.runner.position.z,z),
                "completed run cannot move forward, die or complete twice: x=%s jumping=%s" % [x,jumping])

    # Reproduction of the actual Phase 3 finish failure. Only initial fixture is
    # positioned; the side excursion, recovery and win use real input/physics.
    await fresh()
    fixture(Vector3(3.5,0.08,-65))
    await ticks(2)
    game.runner.jump_requested = true
    Input.action_press("ui_right")
    await ticks(18)
    check(game.runner.position.x > 5 and not game.route.on_route, "airborne side excursion genuinely leaves reward corridor")
    var held_progress: float = game.route.furthest_distance
    Input.action_release("ui_right")
    Input.action_press("ui_left")
    await ticks(3)
    check(game.route.furthest_distance == held_progress, "off-route motion grants no additional progress")
    await ticks(19)
    Input.action_release("ui_left")
    await wait_state(game.RunState.COMPLETED, 45)
    check(game.won and game.route.on_route and game.deaths == 0, "returning safely from side jump restores progress and finish eligibility")

    for x in [-4.94,4.94]:
        await fresh()
        fixture(Vector3(x,1,-75.2))
        await ticks(8)
        check(not game.won, "unsupported finish side cannot award victory: x=" + str(x))
    await fresh()
    area(-76).body_entered.emit(game.runner)
    game.runner.position = Vector3(0,0.08,-76)
    await ticks(5)
    check(not game.won and not game.route.position_valid, "remote callback and teleport cannot bypass finish route validation")
    await fresh()
    game._respawn()
    game.runner.position = Vector3(0,0.08,-76)
    area(-76).body_entered.emit(game.runner)
    await ticks(4)
    check(not game.won and game.deaths == 1 and game.state == game.RunState.DYING, "finish rejects a dying body inside its volume")

    # Every real saved checkpoint, repeated recoveries, and three physical bar
    # phases. Scene-owned timer/reset paths are exercised, not reset_at directly.
    for cp in [0,1]:
        for phase in [0.0,PI * 0.5,PI]:
            await fresh()
            for hazard in get_nodes_in_group("hazards"):
                hazard.rotation.y = phase
            var saved: Dictionary = game.checkpoints[cp]
            fixture(saved.spawn + Vector3(0,0,1.1))
            await ticks(7)
            check(game.checkpoint_index == cp and game.spawn == saved.spawn, "legitimate checkpoint saves cp=%d phase=%s" % [cp,phase])
            saved.area.body_entered.emit(game.runner)
            check(game.checkpoint_index == cp and game._spawn_safe(saved.spawn), "duplicate checkpoint is inert and spawn clears actual hazards")
            for retry in [1,2]:
                var progress: int = game.progress_percent()
                game.runner.rotation.y = 1.2
                game.runner.jump_requested = true
                game.runner.knockback = Vector3(4,0,3)
                game._respawn()
                for collision in range(16):
                    game.runner.fell.emit()
                    area(-48).contact.emit(game.runner)
                    area(-76).body_entered.emit(game.runner)
                check(game.deaths == retry and not game.won, "rapid death/hazard/finish callbacks count once: cp=%d retry=%d" % [cp,retry])
                await wait_state(game.RunState.RESPAWNING)
                check(absf(game.runner.position.z-saved.spawn.z) < 0.01 and game.runner.rotation == Vector3.ZERO
                    and game.runner.velocity.x == 0 and game.runner.velocity.z == 0 and game.runner.knockback == Vector3.ZERO
                    and game.runner.jump_buffer == 0 and not game.runner.jump_requested and game.runner.invulnerable_left > 1,
                    "checkpoint recovery restores safe position/orientation and clears impulses: cp=%d retry=%d" % [cp,retry])
                area(-76).body_entered.emit(game.runner)
                check(not game.won, "respawning state cannot activate finish")
                await wait_state(game.RunState.PLAYING)
                check(game.deaths == retry and game.checkpoint_index == cp and game.progress_percent() >= progress
                    and game.runner.is_on_floor(), "checkpoint recovery returns control without repeated death or lost milestone")

    await fresh()
    fixture(Vector3(0,0.05,-5))
    game.runner.allow_forward = false # Isolate immunity timing, not motion logic.
    area(-5).spin_speed = 0
    await ticks(8)
    check(area(-5).overlaps_body(game.runner) and hits == 0, "real hazard overlap is harmless during actual spawn protection")
    game.set_paused(true)
    var immune: float = game.runner.invulnerable_left
    var angle: float = area(-5).rotation.y
    var step = get_nodes_in_group("moving_platforms")[0]
    var elapsed: float = step.elapsed
    await ticks(30)
    check(game.runner.invulnerable_left == immune and area(-5).rotation.y == angle and step.elapsed == elapsed,
        "pause freezes protection, hazard physics and platform timing")
    game.set_paused(false)
    game.runner.allow_forward = false
    for tick in range(90):
        if hits > 0:
            break
        await ticks(1)
    check(hits == 1 and game.runner.grace_left == 0 and game.runner.knockback.length() <= 5.01,
        "natural protection expiry resolves pending contact with one bounded hit")
    await ticks(5)
    check(hits == 1, "rapid continued physical contact does not multiply knockback")

    await fresh()
    fixture(Vector3(0,0.08,3)) # Explicit recovery protection, not new-run immunity.
    game.runner.allow_forward = false
    for tick in range(100):
        if game.runner.invulnerable_left <= 0:
            break
        await ticks(1)
    check(game.runner.invulnerable_left == 0, "configured protection expires through real physics time")
    game.runner.position.y = -13
    await ticks(2)
    check(game.deaths == 1 and game.state == game.RunState.DYING, "fall immediately after protection expires counts one death")

    await fresh()
    fixture(Vector3(0,0.05,-5))
    game.runner.allow_forward = false
    game.runner.invulnerable_left = 0
    game.route.position_valid = false
    await ticks(5)
    check(hits == 1 and not game.won, "invalid progress cannot confer immunity to a real hazard overlap")
    await fresh()
    var pickup = area(-1)
    pickup.body_entered.connect(func(body: Node3D) -> void:
        if not pickup.get_meta("phase3_duplicate",false):
            pickup.set_meta("phase3_duplicate",true)
            pickup.body_entered.emit(body)
            pickup.body_entered.emit(body)
    )
    fixture(Vector3(2,0.08,0.1))
    await ticks(7)
    check(game.coins == 1 and area(-1) == null, "reentrant physical coin callbacks award exactly once")
    fixture(Vector3(0,0.08,-28.9))
    await ticks(7)
    for death in [1,2]:
        var progress: int = game.progress_percent()
        game._respawn()
        await ticks(4)
        check(game.coins == 1 and game.progress_percent() == progress, "death preserves coins and freezes progress: fall=" + str(death))
        await wait_state(game.RunState.PLAYING)
    check(game.deaths == 2 and game.coins == 1 and game.checkpoint_index == 0, "two checkpoint recoveries preserve authoritative run statistics")
    menu("pause",100)
    menu("pause",100,false)
    await frames(2)
    var point: Vector3 = game.runner.position
    var progress: int = game.progress_percent()
    var hazard = area(-25)
    angle = hazard.rotation.y
    step = get_nodes_in_group("moving_platforms")[0]
    elapsed = step.elapsed
    for tap in range(8):
        menu("pause",110+tap)
        touch(120+tap,game.controls.jump_center)
    await ticks(20)
    check(paused and game.runner.position == point and hazard.rotation.y == angle and step.elapsed == elapsed
        and not game.runner.jump_requested and game.controls.steering() == 0, "Take a Breather freezes run and blocks controls beneath its dialog")
    check(game.hud.detail.text.contains("whole run"), "Try Again explicitly describes full-run restart")
    for tap in range(8):
        menu("resume",130+tap)
    check(not paused and game.state == game.RunState.PLAYING and game.runner.position == point and game.coins == 1
        and game.deaths == 2 and game.checkpoint_index == 0 and game.progress_percent() == progress,
        "rapid Keep Going resumes same run without respawn or stat reset")
    menu("pause",150)
    await frames(2)
    for tap in range(8):
        menu("restart",160+tap)
    check(game.state == game.RunState.TRANSITIONING and game.recovery_timer.is_stopped(), "rapid Try Again requests latch a single transition")
    await frames(4)
    game = current_scene
    check(game.deaths == 0 and game.coins == 0 and game.checkpoint_index == -1 and game.progress_percent() == 0
        and get_nodes_in_group("coins").size() == 5, "Try Again resets whole run, checkpoints, coins and progress")

    # Force the existing safe-spawn wait, then restart while actually RESPAWNING.
    await wait_state(game.RunState.PLAYING)
    var blocked := wall(Vector3(0,0.8,5))
    await ticks(2)
    game._respawn()
    await wait_state(game.RunState.RESPAWNING)
    check(not game.runner.running and game.deaths == 1, "unsafe respawn waits frozen without another fall")
    for tap in range(8):
        game.restart()
        game.set_paused(true)
    await frames(4)
    game = current_scene
    await ticks(65)
    check(game.state == game.RunState.PLAYING and game.deaths == 0 and not game.respawning,
        "restart during respawn cancels stale retry timer and repeated actions")

    await fresh()
    var stick: Vector2 = game.controls.joystick_center - Vector2(game.controls.joystick_radius * 0.7,0)
    touch(200,stick)
    touch(201,game.controls.jump_center)
    touch(201,game.controls.jump_center,false)
    await ticks(3)
    check(game.runner.velocity.x < 0 and game.runner.velocity.y > 0 and game.controls.steering() == -1,
        "simultaneous movement/jump reaches physics and releasing jump preserves steering")
    touch(200,stick,false)
    check(game.controls.steering() == 0, "remaining touch releases independently")
    for death in [1,2]:
        game._respawn()
        await wait_state(game.RunState.PLAYING)
    fixture(Vector3(0,0.08,-74.4))
    await wait_state(game.RunState.COMPLETED, 30)
    check(game.won and game.completed_falls == 2 and game.completed_coins == 0 and game.completion_count == 1,
        "completion after multiple falls requires no coins and snapshots final results")
    game.runner.fell.emit()
    area(-76).body_entered.emit(game.runner)
    check(game.deaths == 2 and game.progress_percent() == 100 and game.completion_count == 1,
        "final fall count and completion reward event stay frozen")

    # Below-route recovery and marker crossing exercise the projection cursor;
    # reward gates, continuity and turn guards remain independently verified.
    var path = ROUTE.new()
    path.configure(PackedVector3Array([Vector3.ZERO,Vector3(0,0,-1),Vector3(0,0,-4)]))
    var at := Vector3.ZERO
    for i in range(10):
        var next := at + Vector3(0,-0.04,-0.16)
        path.observe(at,next,1.0/60)
        at = next
    held_progress = path.furthest_distance
    for i in range(10):
        var next := at + Vector3(0,0.04,-0.16)
        path.observe(at,next,1.0/60)
        at = next
    check(path.on_route and is_equal_approx(path.current_distance,3.2), "continuous below-height recovery across a marker can resume valid progress")
    check(held_progress < 1 and path.percent() < 100, "below-height excursion grants no rewards and cannot fabricate completion")
    path.restore(Vector3.ZERO,0,false)
    path.observe(Vector3.ZERO,Vector3(0,0,-4),1.0/60)
    check(not path.position_valid and path.percent() == 0, "projection recovery still rejects teleport progress")
    game.queue_free()
    await frames(3)
    print("PHASE3 RESULT: %d checks, %d failures" % [checks,failures])
    quit(1 if failures else 0)
