extends SceneTree
var failures := 0
var checks := 0
var game

func _initialize() -> void:
    call_deferred("run")

func check(condition: bool, label: String) -> void:
    checks += 1
    if condition:
        print("PASS: ", label)
    else:
        failures += 1
        push_error("FAIL: " + label)

func frames(count: int) -> void:
    for frame in range(count):
        await physics_frame
        await process_frame

func fresh() -> void:
    if is_instance_valid(game):
        game.queue_free()
        await frames(2)
    game = load("res://main.tscn").instantiate()
    root.add_child(game)
    current_scene = game
    await frames(2)

func area_at(z: float, spinner: bool = false):
    for child in game.get_children():
        if child is Area3D and is_equal_approx(child.position.z, z):
            if not spinner or child.get_script() == load("res://scripts/spinner.gd"):
                return child
    return null

# Trusted fixture setup is explicit; teleport rejection is tested separately.
# Full-course integration tests never use this helper.
func fixture(point: Vector3, grace := 0.3) -> void:
    game.recovery_timer.stop()
    game.runner.reset_at(point)
    game.runner.grace_left = grace
    game.route.restore(point, game.route.distance_at(point))
    game._set_state(game.RunState.PLAYING)
    game._sync_state()

func touch(index: int, point: Vector2, pressed: bool) -> void:
    var event := InputEventScreenTouch.new()
    event.index = index
    event.position = point
    event.pressed = pressed
    game.controls._input(event)

func run() -> void:
    await fresh()
    check(game.progress_percent() == 0, "progress starts at zero")
    await frames(16)
    check(game.runner.is_on_floor(), "spawn settles on platform")
    var visual_bottom: float = minf(game.runner.face.feet[0].global_position.y, game.runner.face.feet[1].global_position.y) - 0.15 * 0.8
    check(absf(visual_bottom) < 0.015, "visible feet rest on the actual collision floor without floating")
    var matching_platforms := true
    for platform in get_nodes_in_group("platforms"):
        var box_mesh = platform.get_child(0)
        var box_collider = platform.get_child(1)
        matching_platforms = matching_platforms and box_mesh.mesh.size.is_equal_approx(box_collider.shape.size)
        matching_platforms = matching_platforms and box_mesh.global_transform.is_equal_approx(box_collider.global_transform)
    check(matching_platforms, "all platform mesh volumes match their physical collision volumes")
    var start_z: float = game.runner.position.z
    await frames(12)
    check(game.runner.position.z < start_z - 1.0, "automatic forward movement resumes")
    Input.action_press("ui_right")
    await frames(8)
    check(game.runner.velocity.x > 0.0, "keyboard steering reaches player on physics ticks")
    Input.action_release("ui_right")
    await frames(12)
    check(absf(game.runner.velocity.x) < 0.01, "steering release stops lateral motion")

    # Test actual floor contacts across all original gaps, not just jump equations.
    for child in game.get_children():
        if child is Area3D and child.get_script() == load("res://scripts/spinner.gd"):
            child.monitoring = false
    for gap in [[-9.0, -15.5], [-32.5, -37.5], [-54.5, -58.0]]:
        fixture(Vector3(0.0, 0.08, gap[0] + 1.1))
        await frames(20)
        game.runner.jump_requested = true
        await frames(62)
        check(game.runner.position.z < gap[1] and game.runner.is_on_floor() and game.runner.position.y > -0.1,
            "jump lands across gap at z=" + str(gap[0]))

    fixture(Vector3(0, 3, 2))
    game.runner.jump_requested = true
    await frames(40)
    check(game.runner.is_on_floor() and game.runner.velocity.y <= 0.0, "early airborne tap expires instead of auto-jumping on landing")
    fixture(Vector3(0, 0.08, 3))
    await frames(20)
    game.runner.position.y = 0.16
    game.runner.velocity.y = -1.0
    game.runner.coyote_left = 0.0
    game.runner.jump_requested = true
    await frames(3)
    check(game.runner.velocity.y > 0.0, "buffered near-ground jump is accepted")

    fixture(Vector3(0, 0.08, -8.5))
    await frames(18)
    for tick in range(12):
        await frames(1)
        if not game.runner.is_on_floor():
            break
    game.runner.jump_requested = true
    await frames(1)
    check(game.runner.velocity.y > 0.0, "jump still works immediately after leaving a platform edge")

    await fresh()
    var checkpoint = area_at(-30.0)
    fixture(Vector3(0, 0.08, -28.9), 0.0)
    await frames(5)
    check(game.spawn == Vector3(0, 0.08, -30), "checkpoint saves a grounded position beyond spinner")
    fixture(game.spawn)
    for child in game.get_children():
        if child is Area3D and child.get_script() == load("res://scripts/spinner.gd"):
            child.spin_speed = 0.0
            child.rotation.y = PI / 2.0
    await frames(28)
    check(game.deaths == 0 and game.runner.is_on_floor(), "checkpoint respawn avoids bar at worst-case rotation")
    fixture(Vector3(0, 0.08, -50.9), 0.0)
    await frames(5)
    checkpoint.body_entered.emit(game.runner)
    check(game.spawn.z == -52.0, "older checkpoint cannot overwrite newer checkpoint")
    fixture(game.spawn)
    await frames(28)
    check(game.deaths == 0 and game.runner.is_on_floor(), "second checkpoint also avoids bar")

    var pickup = area_at(-65.0)
    var count: int = game.coins
    pickup.body_entered.connect(func(body: Node3D) -> void:
        if not pickup.get_meta("duplicate_probe", false):
            pickup.set_meta("duplicate_probe", true)
            pickup.body_entered.emit(body)
            pickup.body_entered.emit(body)
    )
    fixture(Vector3(-2, 0.08, -63.9), 0.0)
    await frames(5)
    check(game.coins == count + 1, "coin is counted once even before deferred removal")
    game.runner.position.y = -13.0
    await frames(1)
    game._respawn()
    game._respawn()
    check(game.deaths == 1 and game.respawning, "one fall produces one respawn despite repeated requests")
    area_at(-76.0).body_entered.emit(game.runner)
    check(not game.won, "finish ignores a respawning player")
    await create_timer(0.9).timeout
    await frames(2)
    check(not game.respawning and game.runner.running and game.runner.position.y > -0.1,
        "deferred recovery restores player above checkpoint platform")
    check(game.coins == count + 1, "coins persist after fall")
    check(game.camera.position.distance_to(game.runner.position + Vector3(0, 5.7, 11)) < 0.9,
        "camera smoothly returns toward the recovered player")
    check(game.runner.knockback == Vector3.ZERO and not game.runner.jump_requested, "respawn clears movement impulses and jump input")

    game.runner.invulnerable_left = 0.0
    game.runner.grace_left = 0.0
    check(game.runner.hit_by_spinner(game.runner.position, 2.0), "bar hit starts recoverable knockback")
    check(game.runner.velocity.y > 0.0 and game.runner.knockback.length() <= 5.01, "knockback strength is bounded")
    check(not game.runner.hit_by_spinner(game.runner.position, 2.0), "bar cannot hit again during recovery immunity")
    var falls: int = game.deaths
    fixture(Vector3(0, 1.0, -74.8), 0.0)
    await frames(5)
    game._respawn()
    check(game.won and not game.runner.running and game.progress_percent() == 100 and game.deaths == falls,
        "finish stops runner, sets 100 percent, and blocks further deaths")

    game.runner.position.y = 1.0
    var finish_z: float = game.runner.position.z
    await frames(30)
    check(game.runner.is_on_floor() and absf(game.runner.position.y) < 0.015 and is_equal_approx(game.runner.position.z, finish_z),
        "winning during a jump settles onto the platform without continuing forward")

    await fresh()
    await frames(20)
    var left: Vector2 = game.controls.joystick_center + Vector2(-game.controls.joystick_radius * 0.7, 0)
    var jump: Vector2 = game.controls.jump_center
    check(game.controls.safe_rect.has_point(left) and game.controls.safe_rect.has_point(jump),
        "touch buttons anchor to viewport edges")
    touch(1, left, true)
    touch(2, jump, true)
    check(game.controls.steering() == -1.0 and game.runner.jump_requested, "two fingers can steer and jump together")
    touch(2, jump, false)
    check(game.controls.steering() == -1.0, "releasing jump preserves held steering finger")
    touch(1, left, false)
    check(game.controls.steering() == 0.0, "releasing steering clears input")
    touch(1, left, true)
    game.controls.notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    check(game.controls.steering() == 0.0, "backgrounding clears held touches")
    var canceled := InputEventScreenTouch.new()
    touch(1, left, true)
    canceled.index = 1
    canceled.pressed = true
    canceled.canceled = true
    canceled.position = left
    game.controls._input(canceled)
    check(game.controls.steering() == 0.0, "canceled touch clears steering even if pressed remains set")
    var initial_position: Vector3 = game.runner.global_position
    touch(1, left, true)
    game.runner.jump_requested = true
    game.notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    await frames(10)
    check(game.runner.global_position.is_equal_approx(initial_position) and not game.runner.jump_requested and game.controls.steering() == 0.0,
        "backgrounding pauses the course and clears pending mobile input")
    game.notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    await frames(24)
    check(not paused and game.runner.global_position.z < initial_position.z, "foregrounding resumes predictable automatic movement")
    var basis_before_fall: Basis = game.camera.global_basis
    game.runner.position.y = -4.0
    await frames(4)
    check(game.camera.global_basis.is_equal_approx(basis_before_fall) and game.camera.position.y >= 5.7,
        "camera keeps its horizon instead of diving toward a falling player")
    root.size = Vector2i(1024, 1366)
    await frames(2)
    var rect := Rect2(game.controls.jump_center - Vector2.ONE * game.controls.jump_radius, Vector2.ONE * game.controls.jump_radius * 2)
    var canvas_size: Vector2 = root.get_visible_rect().size
    check(game.controls.safe_rect.encloses(rect) and canvas_size.x > 720.0,
        "touch layout follows an iPad-sized viewport")
    for spinner_z in [-5.0, -25.0, -48.0]:
        await fresh()
        game.runner.invulnerable_left = 0.0
        game.runner.grace_left = 0.0
        fixture(Vector3(0.0, 0.05, spinner_z), 0.0)
        game.runner.invulnerable_left = 0.0
        await frames(4)
        check(game.runner.invulnerable_left > 0.0 and game.runner.velocity.y > 0.0 and game.deaths == 0,
            "real spinner overlap produces bounded knockback at z=" + str(spinner_z))

    await fresh()
    for child in game.get_children():
        if child is Area3D and child.get_script() == load("res://scripts/spinner.gd"):
            child.monitoring = false
    var takeoffs := [-7.8, -31.3, -53.3]
    var next_jump := 0
    for frame in range(650):
        if next_jump < takeoffs.size() and game.runner.global_position.z <= takeoffs[next_jump]:
            game.runner.jump_requested = true
            next_jump += 1
        await frames(1)
        if game.won:
            break
    check(game.won and game.deaths == 0 and game.spawn.z == -52.0,
        "continuous physics run crosses three gaps, activates checkpoints, and finishes")
    game.queue_free()
    await frames(2)
    print("RESULT: %d checks, %d failures" % [checks, failures])
    quit(1 if failures else 0)
