extends "res://tests/ninja_challenges.gd"
# Fixtures isolate each real course instance. Full uninterrupted traversal is
# executed separately by first_steps_course.gd, without fixtures or bypasses.
func run() -> void:
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--physics-hz="):hz=arg.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second=hz;root.size=Vector2i(720,1280)
    campaign=root.get_node("Campaign");campaign.save_path="user://acceptance26.json"
    campaign.clear_progress();campaign.dirty=false
    await restart_fixture()
    var hazard_count:=get_nodes_in_group("hazards").size()
    check(hazard_count==14,"actual Level1 contains nine solid bars and five pendulums")
    for index in range(hazard_count):
        await restart_fixture()
        var body:Node3D=get_nodes_in_group("hazards")[index]
        var bar:bool=body.get_script().resource_path.ends_with("rotating_bar.gd")
        var at:Vector3=body.position+Vector3(body.width*.5-.2,-1.03,0) if bar else body.pivot-Vector3.UP*3.78
        fixture(at)
        var start:Vector3=game.runner.position
        var deadline:=Engine.get_physics_frames()+hz*8
        while hits==0 and game.deaths==0 and Engine.get_physics_frames()<deadline:await step()
        var impact:Vector3=game.runner.last_impulse
        var normal:Vector3=game.runner.last_normal
        var depth:=0.0
        var external:float=game.runner.knockback.length()
        for j in range(ceili(.12*hz)):
            await step()
            if bar:depth=maxf(depth,penetration(body))
            else:
                var center:Vector3=body.capsule_point(body.position)
                depth=maxf(depth,maxf(0,body.radius+game.runner.BODY_RADIUS-center.distance_to(body.position)))
        check(hits>0,"instance%d registers actual moving-body contact"%index)
        check(game.runner.position.distance_to(start)>.03 and impact.length()>.1 and impact.dot(normal)>0,"instance%d physically separates and applies geometric impact"%index)
        check(depth<.07,"instance%d has no persistent penetration (%.5fm)"%[index,depth])
        print("ACCEPTANCE_CONTACT ",JSON.stringify({"index":index,"body":str(body.get_path()),"script":body.get_script().resource_path,"hz":hz,"hits":hits,"impulse":str(impact),"normal":str(normal),"initial_external_speed":external,"displacement":str(game.runner.position-start),"penetration":depth}))
    await restart_fixture()
    var platforms:Array=get_nodes_in_group("moving_platforms").duplicate()
    var carried:=0
    var shutter:Node3D
    for platform in platforms:
        if horizontal(platform.travel).length()<.01:shutter=platform;continue
        fixture(platform.position+Vector3.UP*(platform.dimensions.y*.5+.04))
        await seconds(.18)
        var actor:Vector3=game.runner.position
        var origin:Vector3=platform.position
        var path_length:=0.0
        var previous:Vector3=platform.position
        for sample in range(ceili(.45*hz)):
            await step()
            path_length+=platform.position.distance_to(previous)
            previous=platform.position
        var delta:Vector3=game.runner.position-actor
        var moving:Vector3=platform.position-origin
        check(game.runner.is_on_floor() and (delta-moving).length()<.16 and path_length>.02 and game.runner.control_velocity==Vector3.ZERO,"ferry%d carries idle avatar without motor input"%carried)
        print("ACCEPTANCE_CARRY body=",platform.get_path()," body_delta=",delta," platform_delta=",moving," native_velocity=",game.runner.get_platform_velocity())
        carried+=1
    check(carried==13,"every one of the 13 route ferries exercised")
    check(is_instance_valid(shutter),"timed courtyard shutter is a real moving solid")
    # Approach the shutter at the bottom of its natural cycle. No clock or
    # transform is modified to manufacture the closed state.
    var deadline:=Engine.get_physics_frames()+hz*6
    while shutter.position.y>shutter.origin.y-1.6 and Engine.get_physics_frames()<deadline:await step()
    fixture(Vector3(shutter.position.x,shutter.origin.y-1.97,shutter.position.z+1.1))
    drag_direction(Vector2.UP)
    var blocked:=false
    var minimum_z:float=game.runner.position.z
    for i in range(ceili(.15*hz)):
        await step()
        minimum_z=minf(minimum_z,game.runner.position.z)
        for j in range(game.runner.get_slide_collision_count()):
            if game.runner.get_slide_collision(j).get_collider()==shutter:blocked=true
    release()
    check(blocked and minimum_z>shutter.position.z+.2,"closed timed shutter physically blocks forward drag")
    print("ACCEPTANCE_SHUTTER blocked=",blocked," actor=",game.runner.position," shutter=",shutter.position)
    # Finish trigger guards, replay and result locking on this exact new route.
    await restart_fixture()
    game.route.furthest_distance=game.route.total_length
    game._try_finish()
    check(not game.won,"displayed maximum progress alone cannot grant victory")
    game.runner.position=Vector3(game.finish_x,game.level_data.finish_height+.08,game.finish_z)
    await seconds(.15)
    check(not game.won and not game.route.position_valid,"untracked shortcut teleport into finish cannot grant victory")
    for state_name in ["DYING","RESPAWNING"]:
        await restart_fixture()
        fixture(Vector3(game.finish_x,game.level_data.finish_height+.08,game.finish_z))
        game._set_state(game.RunState.get(state_name))
        game.runner.recovery_hold=true
        game.camera.set_process(false);game.camera.transitioning=true
        await seconds(.15)
        game.finish_area.body_entered.emit(game.runner);game._try_finish()
        check(game.finish_area.overlaps_body(game.runner) and not game.won and game.completion_count==0 and game.finish_status()=="state_"+state_name,"real finish overlap rejects "+state_name)
    for jumping in [false,true]:
        await restart_fixture()
        var cell:Dictionary=game.level_data.cells[-1]
        fixture(cell.at+Vector3.UP*.08)
        await seconds(.15)
        game.deaths=3 # Explicit results fixture; physical death coverage elsewhere.
        if jumping:jump();release(2)
        drag_direction(Vector2.UP)
        var end:=Engine.get_physics_frames()+hz*2
        while not game.won and Engine.get_physics_frames()<end:await step()
        release()
        check(game.won and game.completion_count==1 and game.completed_coins==0 and game.completed_falls==3,"real finish overlap works with missing coins and jumping="+str(jumping))
        var end_time:float=game.completed_seconds
        for i in range(20):
            game.finish_area.body_entered.emit(game.runner);game._try_finish();game._respawn()
        await seconds(.25)
        check(game.completion_count==1 and game.deaths==3 and game.completed_seconds==end_time and game.controls.movement()==Vector2.ZERO,"duplicate finish/death callbacks preserve frozen authoritative results")
        finger(5,true,game.hud.restart_button.get_global_rect().get_center())
        await scene_changed;game=current_scene;await seconds(.4)
        finger(5,false,Vector2.ZERO)
        check(game.state==game.RunState.PLAYING and game.completion_count==0 and game.deaths==0 and game.coins==0,"replay resets run after victory")
    print("LEVEL1 ACCEPTANCE RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
