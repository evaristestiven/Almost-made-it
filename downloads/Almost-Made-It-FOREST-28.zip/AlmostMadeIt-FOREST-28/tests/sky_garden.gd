extends "res://tests/world1_regression.gd"
func raw(number: int,enabled: bool) -> void:
    if is_instance_valid(game):game.free()
    ProjectSettings.set_setting("visuals/sky_garden/enabled",enabled)
    campaign=root.get_node("Campaign");campaign.clear_progress();campaign.dirty=false
    for i in range(number-1):campaign.completed[i]=true
    game=load(CATALOG.scene_path(number)).instantiate()
    root.add_child(game);current_scene=game
func collision_snapshot() -> Array:
    var result:Array=[]
    for shape in game.find_children("*","CollisionShape3D",true,false):
        var body:CollisionObject3D=shape.get_parent()
        var dimensions:Variant
        if shape.shape is BoxShape3D:dimensions=shape.shape.size
        elif shape.shape is SphereShape3D:dimensions=[shape.shape.radius]
        else:dimensions=[shape.shape.radius,shape.shape.height]
        result.append([body.get_class(),body.collision_layer,body.collision_mask,shape.disabled,shape.global_transform,shape.shape.get_class(),dimensions])
    return result
func visual_snapshot() -> Array:
    var result:Array=[]
    for node in game.find_children("*","MeshInstance3D",true,false):
        var material:Material=node.material_override
        result.append([node.mesh.get_class(),node.mesh.get_aabb(),node.global_transform,material.albedo_color if material is BaseMaterial3D else null])
    for node in game.get_children():
        if node is WorldEnvironment:result.append([node.environment.background_mode,node.environment.background_color,node.environment.ambient_light_energy,node.environment.fog_enabled])
        if node is DirectionalLight3D:result.append([node.transform,node.light_energy,node.light_color,node.shadow_enabled])
    return result
func run() -> void:
    root.size=Vector2i(720,1280)
    raw(1,false)
    var previous:=collision_snapshot()
    raw(1,true)
    check(collision_snapshot()==previous,"Level1 before/after collision shapes, transforms, layers and masks are identical")
    var nature:Node3D=game.get_node("AdventureScenery")
    check(nature.get_script().resource_path=="res://scripts/environment/garden_landscape.gd","only Level1 selects the nature environment")
    check(nature.find_children("*","CollisionObject3D",true,false).is_empty(),"nature contains no collision bodies or trigger areas")
    print("SKY_GARDEN_BUDGETS ",JSON.stringify(nature.budgets))
    check(nature.budgets.grass_instances>3000 and nature.budgets.grass_instances<15000 and nature.grass_cells.size()<50,"grass instance and cell counts stay within declared budget")
    var roots_inside:=true
    for cell in nature.grass_cells:
        var bounds:AABB=cell.root_bounds
        var at:Vector3=cell.surface;var size:Vector3=cell.platform_size
        roots_inside=roots_inside and bounds.position.x>=at.x-size.x*.5 and bounds.end.x<=at.x+size.x*.5 and bounds.position.z>=at.z-size.z*.5 and bounds.end.z<=at.z+size.z*.5
    check(roots_inside,"authored grass roots stay on the existing platform tops")
    var trees_valid:bool=nature.imported_trees.size()==8
    var route_clear:=true
    for entry in nature.imported_trees:
        trees_valid=trees_valid and entry.model.scene_file_path=="res://assets/nature/quaternius/CommonTree_3/CommonTree_3.gltf" and entry.mesh.mesh.get_surface_count()==2
        var bounds:AABB=entry.bounds
        for platform in game.level_data.platforms:
            var lane:=AABB(Vector3(platform[0]-platform[3]*.5-.3,-2,platform[1]-platform[2]*.5-.3),Vector3(platform[3]+.6,14,platform[2]+.6))
            if bounds.intersects(lane):route_clear=false
    check(trees_valid,"eight near trees instantiate the actual textured CommonTree_3 scene")
    check(route_clear,"complete imported tree bounds remain outside playable lanes and clearance margin")
    var balanced:=0
    for cell in nature.grass_cells:balanced+=cell.node.multimesh.visible_instance_count
    nature.set_quality(0)
    var low:=0
    for cell in nature.grass_cells:low+=cell.node.multimesh.visible_instance_count
    nature.set_quality(2)
    var high:=0
    for cell in nature.grass_cells:high+=cell.node.multimesh.visible_instance_count
    check(low<balanced and balanced<high,"low/balanced/high settings actually change grass draw density")
    game.camera.position=Vector3(0,6,200);nature.update_lod()
    var far:=0
    for cell in nature.grass_cells:far+=cell.node.multimesh.visible_instance_count
    check(far==0,"distance LOD removes distant grass instances")
    nature.set_quality(1)
    for file in ["grass","foliage","surface","ground","atmosphere","waterfall"]:
        var shader:Shader=load("res://shaders/sky_garden/"+file+".gdshader")
        check(shader!=null and not shader.get_shader_uniform_list().is_empty(),"Godot parses shader uniforms: "+file)
    for file in ["meadow_albedo","meadow_normal","meadow_roughness","soil_albedo","soil_normal","soil_roughness","rock_albedo","rock_normal","rock_roughness","bark_albedo","bark_normal","bark_roughness","leaf_sprig","leaf_normal","cloud_noise"]:
        var image:Texture2D=load("res://art/sky_garden/textures/"+file+".png")
        check(image!=null and image.get_size()==Vector2(512,512),"512px original texture present: "+file)
    for number in range(2,11):
        raw(number,false)
        var collisions:=collision_snapshot();var visuals:=visual_snapshot()
        raw(number,true)
        check(collisions==collision_snapshot() and visuals==visual_snapshot(),"Level%d visuals, lighting and collision are identical with nature switch on/off" % number)
        check(game.get_node("AdventureScenery").get_script().resource_path=="res://scripts/components/course_art.gd","Level%d keeps its existing scenery script" % number)
    current_level=1
    await fresh()
    nature=game.get_node("AdventureScenery")
    var clock_before:float=nature.clock
    await seconds(.2)
    check(nature.clock>clock_before,"wind/cloud/leaf clock advances during active play")
    game.set_paused(true);clock_before=nature.clock
    await seconds(.25)
    check(nature.clock==clock_before,"pause freezes cosmetic wind and environmental animation")
    game.set_paused(false)
    check(game.camera.get_script().resource_path=="res://scripts/components/follow_camera.gd" and game.runner.collision_mask==5,"original follow camera and player collision settings remain intact")
    game.queue_free();await step()
    print("SKY GARDEN RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
