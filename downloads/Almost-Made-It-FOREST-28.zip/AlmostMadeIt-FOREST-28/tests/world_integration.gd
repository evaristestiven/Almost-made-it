extends "res://tests/sky_garden.gd"

func run() -> void:
    root.size=Vector2i(720,1280)
    ProjectSettings.set_setting("visuals/world25/enabled",false)
    raw(1,true)
    var original:=collision_snapshot()
    var course:Dictionary=game.level_data.duplicate(true)
    ProjectSettings.set_setting("visuals/world25/enabled",true)
    raw(1,true)
    check(collision_snapshot()==original,"all Level1 collision shapes, transforms, dimensions, masks and layers remain identical")
    check(game.level_data==course,"route, obstacles, checkpoint and coin configuration unchanged")
    var nature:Node3D=game.get_node("AdventureScenery")
    var details:Node3D=nature.world_details
    check(is_instance_valid(details),"Level1 world integration is attached to actual playable scenery")
    check(nature.find_children("*","CollisionObject3D",true,false).is_empty(),"entire scenery adds no bodies, triggers or hidden walls")
    check(details.zone_stats.size()==5,"all five areas receive district-specific scenery")
    var stones:=0
    for zone in details.zone_stats:
        check(zone.landmarks>=3,"area%d has distinct landmarks"%zone.area)
        stones+=zone.path_stones
    check(stones==216,"216 reused imported stone pavers decorate garden, courtyard and plaza")
    check(details.rotating.size()==6 and nature.rotors.size()==3,"six cosmetic machine gears and three preserved windmills")
    check(details.floor_materials.size()<=8,"surface shaders reused across course")
    var clear_views:=true
    for cell in game.level_data.cells:
        var actor:Vector3=cell.at+Vector3.UP*.7
        var camera_anchor:Vector3=cell.at
        camera_anchor.y=minf(camera_anchor.y,2.5)*game.camera.jump_follow+maxf(0,camera_anchor.y-2.5)*.85 if camera_anchor.y>0 else camera_anchor.y
        var camera_at:Vector3=camera_anchor+game.camera.OFFSET
        for bounds in details.occluders:
            if bounds.intersects_segment(camera_at,actor)!=null:clear_views=false
    check(clear_views,"new opaque landmark meshes leave camera-to-avatar sightlines clear across all 60 landings")
    for name in ["CommonTree_3","CommonTree_4","Rock_Medium_3","Plant_1","RockPath_Square_Thin","Pebble_Round_2"]:
        check(not nature.source(name).is_empty(),"verified existing imported model "+name)
    for number in range(2,11):
        ProjectSettings.set_setting("visuals/world25/enabled",false)
        raw(number,true)
        var before:=collision_snapshot();var visuals:=visual_snapshot()
        ProjectSettings.set_setting("visuals/world25/enabled",true)
        raw(number,true)
        check(collision_snapshot()==before and visual_snapshot()==visuals,"Level%d visuals and collision unaffected"%number)
    game.free()
    print("WORLD25 INTEGRATION RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
