extends "res://tests/swipe_movement.gd"
func fresh() -> void:
    if is_instance_valid(game):
        game.queue_free()
        await step()
    change_scene_to_file("res://levels/world1/01_first_steps.tscn")
    await scene_changed
    game = current_scene
    hits = 0
    game.runner.hit.connect(func() -> void: hits += 1)
    for i in range(90):
        await step()
        if game.state == game.RunState.PLAYING: break
    await seconds(.35)
