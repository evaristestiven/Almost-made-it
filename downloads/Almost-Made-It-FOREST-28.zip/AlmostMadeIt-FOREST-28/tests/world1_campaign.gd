extends SceneTree
var checks := 0
var failed := false
var campaign: Node
func _initialize() -> void: call_deferred("run")
func step() -> void:
    await process_frame
    await physics_frame
func check(value: bool, description: String) -> void:
    checks += 1
    if value: print("PASS: ",description)
    else:
        failed = true
        push_error("FAIL: "+description)
func write(path: String, value: String) -> void:
    var file := FileAccess.open(path,FileAccess.WRITE)
    file.store_string(value)
    file.close()
func touch(index: int, pressed: bool, point: Vector2) -> void:
    var event := InputEventScreenTouch.new()
    event.index = index
    event.pressed = pressed
    event.position = root.get_final_transform()*point
    Input.parse_input_event(event)
    Input.flush_buffered_events()
func run() -> void:
    root.size = Vector2i(720,1280)
    campaign = root.get_node("Campaign")
    campaign.save_path = "user://world1_save_tests.json"
    for ending in ["",".bak",".tmp"]:
        var path: String = ProjectSettings.globalize_path(campaign.save_path+ending)
        if FileAccess.file_exists(path): DirAccess.remove_absolute(path)
    campaign.clear_progress()
    campaign.dirty = false
    check(campaign.can_start(1) and not campaign.can_start(2) and not campaign.world_completed(),"new campaign unlocks only First Steps")
    check(not campaign.open_level(0) and not campaign.open_level(11) and not campaign.open_level(2),"service refuses out-of-range and locked level entry")
    check(campaign.save_progress() and not campaign.decode(campaign.save_path).is_empty(),"atomic initial save verifies checksum")
    check(campaign.record_completion(1,3,24.5) and campaign.can_start(2),"completion commits one sequential unlock")
    check(campaign.record_completion(2,2,30) and campaign.can_start(3),"next completion saves correctly")
    campaign.record_completion(2,1,40)
    check(campaign.completed.count(true) == 2 and campaign.best_coins[1] == 2 and campaign.best_seconds[1] == 30,"replay cannot duplicate progression or worsen best results")
    campaign.load_progress()
    check(campaign.completed.count(true) == 2 and campaign.can_start(3),"save reload preserves authoritative unlocks")
    write(campaign.save_path,"{interrupted")
    campaign.load_progress()
    check(campaign.completed.count(true) == 2 and campaign.dirty,"corrupt primary recovers verified last-good backup")
    check(campaign.save_progress(),"recovered backup can be committed safely")
    write(campaign.save_path+".tmp","{interrupted temporary write")
    campaign.load_progress()
    check(campaign.completed.count(true) == 2,"interrupted temp write cannot replace valid committed progress")
    var original_path: String = campaign.save_path
    campaign.save_path = "user://world1_missing_directory/progress.json"
    check(not campaign.record_completion(3,5,20) and campaign.dirty,"storage failure reports unsaved progress instead of claiming persistence")
    check(not campaign.open_level(4),"transition is blocked until dirty progress can be saved")
    campaign.save_path = original_path
    check(campaign.save_progress(),"retry commits the preserved in-memory completion")
    for number in range(4,11): check(campaign.record_completion(number,1,30+number),"sequential save for level%d" % number)
    campaign.load_progress()
    check(campaign.world_completed() and campaign.unlocked_count() == 10,"World1 completion survives reload")
    # Actual UI entry from a fresh campaign, not direct button signal emission.
    campaign.clear_progress()
    campaign.dirty = false
    change_scene_to_file("res://scenes/level_select.tscn")
    await scene_changed
    for i in range(10): await step()
    var menu = current_scene
    check(menu.buttons.size() == 10 and not menu.buttons[0].disabled and menu.buttons[1].disabled,"selection presents10 levels with correct locks")
    var scroll: ScrollContainer = menu.margin.get_child(0)
    menu.margin.add_theme_constant_override("margin_bottom",500)
    for i in range(5): await step()
    var drag_point := Vector2(500,600)
    touch(8,true,drag_point)
    for i in range(4):
        var event := InputEventScreenDrag.new()
        event.index = 8
        event.position = root.get_final_transform()*(drag_point+Vector2(0,-70*(i+1)))
        event.relative = root.get_final_transform().basis_xform(Vector2(0,-70))
        Input.parse_input_event(event)
        Input.flush_buffered_events()
        await step()
    touch(8,false,drag_point+Vector2(0,-280))
    for i in range(5): await step()
    print("MENU_SCROLL max=",scroll.get_v_scroll_bar().max_value," page=",scroll.get_v_scroll_bar().page," at=",scroll.scroll_vertical)
    check(scroll.scroll_vertical > 0,"level selection scrolls using real touch drag")
    change_scene_to_file("res://levels/world1/10_first_gauntlet.tscn")
    await scene_changed
    for i in range(10): await step()
    menu = current_scene
    check(menu.get("buttons") != null,"direct scene entry to a locked level redirects to selection")
    var point: Vector2 = menu.buttons[0].get_global_rect().get_center()
    touch(4,true,point)
    touch(4,false,point)
    for i in range(15): await step()
    check(current_scene != menu and current_scene.get("level_number") == 1,"real screen-touch on selection starts unlocked level")
    if current_scene.get("runner") != null:
        var game = current_scene
        game.set_paused(true)
        for i in range(3): await step()
        point = game.hud.selection_button.get_global_rect().get_center()
        touch(4,true,point);touch(4,false,point)
        for i in range(10): await step()
        check(current_scene.get("buttons") != null and not paused,"pause-menu selection action restores menu and unpauses")
    current_scene.queue_free()
    await step()
    print("WORLD1 CAMPAIGN RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
