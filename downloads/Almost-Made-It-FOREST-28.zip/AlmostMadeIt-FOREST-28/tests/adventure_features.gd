extends "res://tests/world1_regression.gd"
func run() -> void:
    root.size = Vector2i(720,1280)
    var themes: Array[String] = []
    for number in range(1,11):
        current_level = number
        await fresh()
        var scenery: Node3D = game.get_node("AdventureScenery")
        var palette: String = game.level_data.theme.top
        check(not themes.has(palette),"level%d has distinct theme palette" % number)
        themes.append(palette)
        check(scenery.living.size()>0 and scenery.living.size()<=8,"level%d has bounded animated landmarks" % number)
        var rotor: Node3D = scenery.living[0]
        var before: Vector3 = rotor.rotation
        await seconds(.2)
        check(rotor.rotation != before,"level%d environment is alive" % number)
        game.set_paused(true)
        before = rotor.rotation
        await seconds(.2)
        check(rotor.rotation == before,"level%d environment respects pause" % number)
        game.set_paused(false)
        for p in game.level_data.extensions:
            var found := false
            for body in get_nodes_in_group("platforms"):
                if Vector2(body.position.x,body.position.z).distance_to(Vector2(p[0],p[1])) < .01:
                    var mesh: BoxMesh = body.get_child(0).mesh
                    var shape: BoxShape3D = body.get_child(1).shape
                    found = mesh.size == shape.size and absf(body.position.y+shape.size.y*.5-p[4])<.001 and body.collision_layer==1
            check(found,"level%d bonus platform mesh and enabled solid agree" % number)
    current_level = 3
    await fresh()
    var layers := get_nodes_in_group("hazards")
    var lower: Node3D
    var upper: Node3D
    for bar in layers:
        if is_equal_approx(bar.position.z,-24):
            if bar.position.y>2: upper=bar
            else: lower=bar
    check(is_instance_valid(upper) and is_instance_valid(lower) and upper.spin_speed*lower.spin_speed<0,"double-decker bars use actual counter-rotating solid instances")
    current_level = 9
    await fresh()
    var gate = get_nodes_in_group("moving_platforms")[0]
    var deadline := Engine.get_physics_frames()+hz*6
    while gate.position.y>1.8 and Engine.get_physics_frames()<deadline: await step()
    fixture(Vector3(2,.08,-42.7)) # Geometry test; campaign traversal tested separately.
    drag_direction(Vector2.UP)
    await seconds(.18)
    print("GATE_CLOSED body=%s gate_y=%.3f player=%s velocity=%s" % [gate.get_path(),gate.position.y,str(game.runner.position),str(game.runner.velocity)])
    check(game.runner.position.z > -43.5 and game.runner.control_velocity.z < -5,"closed timing gate physically blocks held forward input")
    deadline = Engine.get_physics_frames()+hz*5
    while game.runner.position.z>-45.5 and Engine.get_physics_frames()<deadline and game.deaths==0: await step()
    check(game.runner.position.z < -45.5 and game.deaths == 0,"rising timing gate provides a traversable open interval")
    release()
    game.queue_free()
    await step()
    print("ADVENTURE FEATURES RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
