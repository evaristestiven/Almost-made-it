extends "res://tests/course_completion.gd"
# Entire lifecycle uses only normal touch events and physics, including the
# first jump, a real hazard hit, platform failure, recovery and final restart.
var hit_count := 0
var jump_count := 0
var hit_impulse := Vector3.ZERO

func run() -> void:
    root.size = Vector2i(720,1280)
    await frame()
    game = load("res://main.tscn").instantiate()
    root.add_child(game)
    current_scene = game
    game.state_changed.connect(func(previous: int, current: int) -> void:
        print("PHASE5_INTEGRATION_STATE ",JSON.stringify({"from":game.RunState.keys()[previous],"to":game.RunState.keys()[current],"falls":game.deaths,"coins":game.coins,"checkpoint":game.checkpoint_index,"camera_ready":game.camera.is_recovery_ready(),"protection":game.runner.spawn_protection_left,"velocity":str(game.runner.velocity),"external":str(game.runner.knockback)}))
    )
    game.runner.hit.connect(func() -> void:
        hit_count += 1
        hit_impulse = game.runner.knockback
        print("PHASE5_INTEGRATION_HIT frame=%d impulse=%s external=%s" % [Engine.get_physics_frames(),str(game.runner.last_impulse),str(game.runner.knockback)])
    )
    game.runner.jumped.connect(func() -> void: jump_count += 1)
    for tick in range(50):
        await frame()
        if game.state == game.RunState.PLAYING: break
    touch("jump",2,true)
    touch("jump",2,false)
    var camera_basis: Basis = game.camera.global_basis
    for tick in range(100):
        await frame()
        if hit_count > 0: break
    require(jump_count == 1 and hit_count == 1 and hit_impulse.length() > .05,
        "actual touch jump is followed by real rotating-bar penalty")
    var body_before: Vector3 = game.runner.position
    await frame()
    require(game.runner.position.distance_to(body_before) > .001 and game.runner.velocity.is_finite(),
        "actual contact displaces body without a fabricated upward launch")
    require(game.camera.global_basis.is_equal_approx(camera_basis) and absf(game.camera.position.z-game.runner.position.z-11) < 1.5,
        "real knockback preserves stable camera angle and distance")
    touch("right",1,true)
    for tick in range(220):
        await frame()
        if game.deaths == 1: break
    touch("right",1,false)
    require(game.deaths == 1 and game.state == game.RunState.DYING,
        "real platform failure after hit counts exactly once")
    for tick in range(100):
        await frame()
        if game.state == game.RunState.PLAYING: break
    require(game.deaths == 1 and game.runner.position.z > 4 and game.runner.spawn_protection_left > 0
        and game.runner.knockback == Vector3.ZERO and game.controls.steering() == 0,
        "actual recovery returns to clean protected start with cleared touch")
    for tick in range(120):
        steer_to(2)
        await frame()
        if game.coins == 1: break
    require(game.coins == 1, "real pickup remains functional after hit and fall")
    var jump_index := 0
    var takeoffs := [-7.8,-31.3,-53.3]
    for tick in range(650):
        var z: float = game.runner.position.z
        steer_to(3.5 if z > -59 else 2)
        if jump_index < takeoffs.size() and z <= takeoffs[jump_index]:
            touch("jump",2,true)
            touch("jump",2,false)
            jump_index += 1
        await frame()
        if game.won or game.deaths > 1: break
    require(game.won and game.completion_count == 1 and game.checkpoint_index == 1,
        "hit/fall/recover course legitimately activates checkpoints and wins")
    require(game.completed_falls == 1 and game.completed_coins == game.coins and game.coins < 5 and game.progress_percent() == 100,
        "full lifecycle finalizes accurate results without requiring every coin")
    if touch_direction != "":
        touch(touch_direction,1,false)
        touch_direction = ""
    await frame()
    await frame()
    touch("restart",3,true)
    touch("restart",3,false)
    await frame()
    await frame()
    game = current_scene
    require(game.deaths == 0 and game.coins == 0 and game.checkpoint_index == -1 and game.progress_percent() == 0
        and game.runner.spawn_protection_left == 0,
        "real completion restart resets run and grants no hidden immunity")
    game.queue_free()
    await frame()
    await frame()
    print("HAZARD COURSE RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
