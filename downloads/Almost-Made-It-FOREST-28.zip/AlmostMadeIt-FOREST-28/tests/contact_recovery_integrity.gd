extends "res://tests/solid_penetration.gd"
# Whole-level runtime fixtures, specifically targeting TEST-06's recovery bug.
class FixedStepProbe:
    extends Node
    var sample: Callable
    func _physics_process(_delta: float) -> void:
        sample.call()
var probe_min := 0.0
var probe_steps := 0
var probe_index := 0
func observe_fixed_step() -> void:
    probe_steps += 1
    probe_min = minf(probe_min,box_separation(bar(probe_index)))

func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    await fresh()
    bar().spin_speed = 0
    fixture(Vector3(0,1.345,-5))
    # A stationary bar top must not turn normal floor support into repeated hits.
    for i in range(hz): await frame()
    print("SUPPORT_EVIDENCE hits=%d grounded=%s external=%s" % [hits,game.runner.is_on_floor(),str(game.runner.knockback)])
    require(hits == 0,"resting on stationary hub does not trigger impact recovery")

    await fresh()
    bar().spin_speed = 0
    fixture(Vector3(0,1.345,-5))
    game.runner.allow_forward = true
    var fastest_forward := 0.0
    var external_on_hit := Vector3.ZERO
    var hit_horizontal_impulse := Vector3.ZERO
    for i in range(hz):
        await frame()
        fastest_forward = minf(fastest_forward,game.runner.velocity.z)
        if hits > 0 and external_on_hit == Vector3.ZERO:
            external_on_hit = game.runner.knockback
            hit_horizontal_impulse = game.runner.last_impulse
    print("RECOVERY_COMPOSITION_EVIDENCE hz=%d fastest_forward=%.5f external=%s impulse=%s" % [hz,fastest_forward,str(external_on_hit),str(hit_horizontal_impulse)])
    require(fastest_forward >= -game.runner.RUN_SPEED-.15,"vertical top contact cannot duplicate autorun velocity after recovery")

    # Actual side sweep, zero motor: require displacement in contact direction.
    for protected in [false,true]:
        for speed in [1.8,2.8,10.0]:
            await fresh()
            fixture(Vector3(2.2,.02,-5),protected)
            bar().spin_speed = speed
            var start: Vector3 = game.runner.position
            probe_min = 0.0
            probe_steps = 0
            var probe := FixedStepProbe.new()
            probe.process_physics_priority = 100
            probe.sample = observe_fixed_step
            game.add_child(probe)
            var direction_correct := true
            for i in range(hz*2):
                var before: Vector3 = game.runner.position
                await frame()
                if hits > 0 and hit_position.distance_to(before) < .03:
                    direction_correct = direction_correct and at_hit.dot(game.runner.last_normal) >= -.01
            print("SEPARATION_RECOVERY_EVIDENCE protected=%s hz=%d speed=%.1f separation=%.5f displacement=%.4f" % [protected,hz,speed,probe_min,start.distance_to(game.runner.position)])
            require(probe_min > -.08,"swept capsule stays separated, protected=%s speed=%.1f" % [protected,speed])
            require(probe_steps > 0,"separation observed after each actual fixed physics step")
            require(start.distance_to(game.runner.position) > .1 and direction_correct,"bar physically displaces capsule in a consistent direction")
    for index in range(3):
        await fresh()
        probe_index = index
        probe_min = 0
        probe_steps = 0
        var obstacle = bar(index)
        fixture(Vector3(2.2,.02,obstacle.position.z),true)
        var start: Vector3 = game.runner.position
        var probe := FixedStepProbe.new()
        probe.process_physics_priority = 100
        probe.sample = observe_fixed_step
        game.add_child(probe)
        for i in range(hz*2): await frame()
        print("ACTUAL_BAR_SEPARATION index=%d z=%.0f omega=%.1f min=%.5f steps=%d displacement=%.4f" % [index,obstacle.position.z,obstacle.spin_speed,probe_min,probe_steps,start.distance_to(game.runner.position)])
        require(probe_min > -.08 and probe_steps > 0,"actual course bar %d remains physically separated" % index)
        require(start.distance_to(game.runner.position) > .1,"actual course bar %d displaces capsule" % index)
    game.queue_free()
    await frame()
    print("CONTACT RECOVERY INTEGRITY RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
