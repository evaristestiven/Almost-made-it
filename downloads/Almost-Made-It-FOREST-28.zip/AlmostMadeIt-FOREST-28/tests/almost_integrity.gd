extends "res://tests/world1_regression.gd"
func kinds(kind: String) -> int:
    var count:=0
    for event in game.almost_moments.events:
        if event.kind==kind: count+=1
    return count
func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): hz=argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second=hz
    root.size=Vector2i(720,1280)
    # Scope each observer invocation around an exact physics-state snapshot.
    # Cross-scene bitwise A/B traces are sensitive to the physics server's
    # synchronization phase at 120 Hz; this checks causation in the same run.
    current_level=1
    await fresh()
    fixture(get_nodes_in_group("hazards")[0].position+Vector3(2.2,-1.03,0))
    var observer=game.almost_moments
    observer.set_physics_process(false)
    var unchanged:=true
    for i in range(hz*6):
        await physics_frame
        var state_before=[game.runner.global_transform,game.runner.velocity,game.runner.control_velocity,game.runner.knockback,game.runner.collision_mask,game.runner.invulnerable_left,Engine.time_scale,game.elapsed_seconds,game.coins,game.deaths]
        observer._physics_process(1.0/hz)
        var state_after=[game.runner.global_transform,game.runner.velocity,game.runner.control_velocity,game.runner.knockback,game.runner.collision_mask,game.runner.invulnerable_left,Engine.time_scale,game.elapsed_seconds,game.coins,game.deaths]
        unchanged=unchanged and state_before==state_after
    observer.set_physics_process(true)
    check(hits>0,"observer invariance run includes a real solid obstacle strike")
    check(unchanged,"recognition never mutates physics, masks, race time or run results")
    current_level=4
    await fresh()
    var moments=game.almost_moments
    var ferry=get_nodes_in_group("moving_platforms")[0]
    fixture(Vector3(ferry.position.x,.08,ferry.position.z))
    await seconds(.2)
    var before:Vector3=game.runner.position
    await seconds(.6)
    check(game.runner.is_on_floor() and game.runner.position.distance_to(before)>.1,"real moving platform continues carrying the idle avatar")
    check(kinds("clutch_recovery")==0 and kinds("near_miss")==0,"ordinary moving-platform travel earns no spurious save")
    jump();release(2)
    await seconds(.9)
    check(kinds("clutch_recovery")==0,"ordinary jump is not a dangerous edge recovery")
    # Direct units for authority/replay and bounded optional points. They are
    # deliberately separate from the real physical recovery test suite.
    current_level=1
    await fresh()
    moments=game.almost_moments
    moments.performance_bonus_enabled=true
    var event={"id":"guard-test","reaction_seconds":.1}
    moments.authoritative=false
    moments._award_bonus(event)
    check(moments.performance_points==0,"non-authoritative observer cannot grant performance points")
    moments.authoritative=true
    moments._award_bonus(event)
    var points:int=moments.performance_points
    game.route.furthest_distance+=5 # Bonus-policy fixture only, not traversal evidence.
    moments._award_bonus(event)
    check(points==10 and moments.performance_points==points,"replayed event ID cannot award a second bonus even after progress")
    moments._award_bonus({"id":"fresh-source","reaction_seconds":.6})
    check(moments.performance_points==15,"slower correction earns fewer optional performance points")
    moments._award_bonus({"id":"same-progress","reaction_seconds":.1})
    check(moments.performance_points==15,"fresh source without new course progress cannot farm points")
    for i in range(20):
        game.route.furthest_distance+=5
        moments._award_bonus({"id":"cap%d" % i,"reaction_seconds":.1})
    check(moments.performance_points==60 and game.coins==0,"run performance cap does not change coin or progression state")
    moments.maximum_events=8
    moments.maximum_file_bytes=2048
    moments.save_path="user://almost_tests/bounded.json"
    for i in range(30):moments._record("test","unit",{"padding":"x".repeat(900)})
    check(moments.events.size()==8,"event ring remains bounded under event spam")
    check(moments.flush_highlights(),"bounded metadata flush succeeds")
    var file=FileAccess.open(moments.save_path,FileAccess.READ)
    var length:int=file.get_length();file.close()
    var saved=JSON.parse_string(FileAccess.get_file_as_string(moments.save_path))
    check(length<=2048 and saved.events.size()<8 and saved.events.size()>0,"file byte cap trims oldest metadata rather than growing storage")
    var block=FileAccess.open("user://almost_tests/not-a-directory",FileAccess.WRITE)
    block.store_string("test");block.close()
    moments.save_path="user://almost_tests/not-a-directory/latest.json"
    check(not moments.flush_highlights() and not moments.persistence_error.is_empty() and game.state==game.RunState.PLAYING,"metadata write failure does not stop gameplay")
    moments.persist_highlights=false
    moments.candidate={"source":"stale"}
    moments.enabled=false
    await seconds(.1)
    check(moments.candidate.is_empty(),"disabling recognition clears pending recovery")
    # Protection contact: real geometry remains, recognition does not create
    # danger/recovery bonuses out of harmless protected overlaps.
    await fresh()
    moments=game.almost_moments
    game.runner.reset_at(get_nodes_in_group("hazards")[0].position+Vector3(2.2,-1.03,0),true)
    game.route.restore(game.runner.position,game.route.distance_at(game.runner.position))
    game.camera.setup(game.runner)
    await seconds(.9)
    check(hits==0 and kinds("near_miss")==0 and kinds("clutch_recovery")==0,"protected real bar contacts produce neither a hit bonus nor a near miss")
    check(game.runner.collision_mask==5 and game.runner.spawn_protection_left>0,"recognition leaves protected solid collision and timer intact")
    # Legitimate finish and duplicate callback, then full restart.
    fixture(Vector3(game.finish_x,.08,game.finish_z+1.7))
    drag_direction(Vector2.UP)
    await seconds(.4);release()
    check(game.won and kinds("finish")==1,"real finish trigger emits one finish bookmark")
    moments._on_complete(game.completed_coins,game.completed_falls)
    check(kinds("finish")==1,"duplicate completion delivery cannot duplicate highlight")
    var old_run:String=moments.run_id
    game.restart()
    for i in range(20):await step()
    game=current_scene
    check(game.almost_moments.run_id!=old_run and game.almost_moments.performance_points==0 and game.almost_moments.events.is_empty(),"restart creates a fresh recognition run without stale rewards")
    game.queue_free();await step()
    print("ALMOST INTEGRITY RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
