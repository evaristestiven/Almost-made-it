extends "res://tests/world1_regression.gd"
func run() -> void:
    root.size = Vector2i(720,1280)
    current_level = 1
    await fresh()
    game.runner.position = Vector3(game.finish_x,.08,game.finish_z)
    await seconds(.1)
    check(not game.won and not game.route.position_valid,"untracked teleport to finish cannot grant victory")
    for target_state in [game.RunState.DYING,game.RunState.RESPAWNING]:
        await fresh()
        fixture(Vector3(game.finish_x,.08,game.finish_z))
        game._set_state(target_state)
        if target_state == game.RunState.DYING: game.runner.stop()
        else:
            game.runner.recovery_hold = true
            game.camera.set_process(false)
            game.camera.transitioning = true
        await seconds(.1)
        game._try_finish()
        check(not game.won,"finish rejects "+game.RunState.keys()[target_state])
    await fresh()
    fixture(Vector3(game.finish_x,.08,game.finish_z+1.7))
    drag_direction(Vector2.UP)
    await seconds(.4)
    release()
    check(game.won and campaign.can_start(2),"actual level1 finish unlocks level2")
    for i in range(8): await step()
    var point: Vector2 = game.hud.next_button.get_global_rect().get_center()
    finger(4,true,point);release(4)
    # Calling again during the transition cannot queue a second level.
    for i in range(12): game._next_level()
    for i in range(10): await step()
    game = current_scene
    check(game.level_number == 2 and game.state in [game.RunState.READY,game.RunState.PLAYING],"real Next Level tap loads the correct next level once")
    await seconds(.4)
    check(game.runner.move_input == Vector2.ZERO and game.controls.fingers.is_empty(),"next-level transition clears stale gesture ownership")
    game._respawn()
    game.restart()
    game.restart()
    for i in range(10): await step()
    game = current_scene
    check(game.level_number == 2 and game.deaths == 0 and campaign.completed[0],"rapid restart during death cancels timer and preserves campaign")
    await seconds(.4)
    game.set_paused(true)
    for i in range(5): await step()
    point = game.hud.selection_button.get_global_rect().get_center()
    finger(4,true,point);release(4)
    for i in range(10): await step()
    var menu = current_scene
    check(menu.get("buttons") != null and not paused and not menu.buttons[1].disabled and menu.buttons[2].disabled,"real selection action shows saved completed/unlocked/locked levels")
    for screen in [Vector2i(390,844),Vector2i(720,1280),Vector2i(1024,1366)]:
        root.size = screen
        for i in range(5): await step()
        check(menu.buttons[0].get_global_rect().position.x >= 0 and menu.buttons[0].size.x <= root.get_visible_rect().size.x,"selection list scales without horizontal overflow: "+str(screen))
    menu.queue_free()
    await step()
    print("WORLD1 NAVIGATION RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
