extends "res://tests/sky_garden.gd"
func hud_snapshot() -> Array:
    var result:Array=[]
    for control in [game.hud.top,game.hud.stack,game.hud.notice,game.hud.progress_bar,game.hud.pause_button]:
        result.append([control.position,control.size,control.mouse_filter])
    return result
func lighting_snapshot() -> Array:
    var result:Array=[]
    for node in game.get_children():
        if node is DirectionalLight3D:result.append([node.transform,node.light_energy,node.light_color,node.shadow_blur])
        if node is WorldEnvironment:result.append([node.environment.background_mode,node.environment.background_color,node.environment.ambient_light_color,node.environment.ambient_light_energy,node.environment.fog_density])
    return result
func run() -> void:
    root.size=Vector2i(720,1280);current_level=1
    ProjectSettings.set_setting("visuals/garden_polish/enabled",false)
    raw(1,true)
    var collisions:=collision_snapshot()
    var original:Node3D=game.get_node("AdventureScenery")
    var primary:Array=[]
    for entry in original.imported_trees:primary.append([entry.model.transform,entry.model.scene_file_path,entry.mesh.mesh.surface_get_material(0),entry.mesh.mesh.surface_get_material(1)])
    var rng_state:int=original.rng.state
    var old_cells:Array=[]
    for cell in original.grass_cells:old_cells.append([cell.total,cell.root_bounds,cell.surface])
    ProjectSettings.set_setting("visuals/garden_polish/enabled",true)
    raw(1,true)
    var scenery:Node3D=game.get_node("AdventureScenery")
    check(collisions==collision_snapshot(),"all actual course colliders/transforms/layers unchanged by polish")
    check(scenery.find_children("*","CollisionObject3D",true,false).is_empty(),"polished decoration contains no bodies, triggers or shortcuts")
    var retained:Array=[]
    for entry in scenery.imported_trees:retained.append([entry.model.transform,entry.model.scene_file_path,entry.mesh.mesh.surface_get_material(0),entry.mesh.mesh.surface_get_material(1)])
    check(primary==retained,"eight detailed trees retain original models, transforms and material resources")
    check(scenery.rng.state==rng_state,"scenery RNG remains unchanged; obstacle timing is untouched")
    var new_cells:Array=[]
    for cell in scenery.grass_cells:new_cells.append([cell.total,cell.root_bounds,cell.surface])
    check(new_cells==old_cells,"grass roots, density ceiling and floor ownership stay unchanged")
    check(scenery.forest_roots.size()==172 and scenery.garden_trees.size()==8,"all remaining 172 small/background primitive trees use imported meshes")
    check(scenery.forest_batches.size()<25,"imported forest uses fewer than 25 spatial/species batches")
    print("POLISH_STATS ",JSON.stringify(scenery.polish_stats))
    var imported:=true
    for node in scenery.forest_batches:
        imported=imported and node.multimesh.mesh.get_surface_count()==2 and node.multimesh.mesh.surface_get_material(0).albedo_texture!=null and node.multimesh.mesh.surface_get_material(1).albedo_texture!=null
    check(imported,"every forest batch retains original bark and leaf textures")
    var above_ground:=true
    for entry in scenery.forest_roots:
        if not is_finite(scenery.terrain_height(entry.root)): print("MISSING_TERRAIN ",entry.root)
        # The previous fixed elevation is no longer used for roots on hills.
        above_ground=above_ground and is_finite(scenery.terrain_height(entry.root)) and entry.root.distance_to(scenery.grounded_root(entry.root))<.001
    check(above_ground,"forest roots are placed on sampled decorative terrain surfaces")
    var transforms_grounded := true
    for entry in scenery.forest_roots:
        var pose: Transform3D = scenery.forest[entry.key].poses[entry.index]
        var data: Dictionary = scenery.source(entry.name)
        var actual_minimum: float = pose.origin.y+data.bounds.position.y*pose.basis.y.length()
        if absf(actual_minimum-entry.root.y)>.001:
            print("ROOT_TRANSFORM_MISMATCH ",entry.root," actual=",actual_minimum)
            transforms_grounded=false
    check(transforms_grounded,"actual imported tree instance transforms put trunk bottoms on final hill surface")
    var environment: Environment=game.find_children("*","WorldEnvironment",true,false)[0].environment
    check(environment.fog_enabled and environment.fog_sky_affect<.05,"distance haze preserves the layered sky instead of obscuring it")
    check(scenery.replaced_clouds==42 and scenery.find_children("GardenBatch_cloud*","MultiMeshInstance3D",true,false).is_empty(),"42 opaque cloud lobes replaced by layered sky shader")
    var rounded:=true
    var tuft_count:=0
    for cell in scenery.grass_cells:
        if is_zero_approx(cell.surface.z):
            tuft_count+=1
            rounded=rounded and cell.node.multimesh.mesh==scenery.tuft_mesh and cell.node.material_override==scenery.soft_grass
    check(rounded and tuft_count>0,"first island uses shared broad curved tufts instead of narrow dark strokes")
    check(scenery.tuft_mesh.get_surface_count()==1 and scenery.tuft_mesh.get_faces().size()/3==30,"rounded tuft stays within 30 triangle budget")
    var clear:=true
    for bounds in scenery.edge_bounds:
        if bounds.size.y>.4 and bounds.end.y>-.119:clear=false
        if bounds.position.z< -10 or bounds.end.z>10:clear=false
    check(clear,"rock cliff tops stay below floor and do not bridge end gaps")
    for at in [Vector3(0,0,5),Vector3(0,0,2),Vector3(0,0,-2.8),Vector3(-2,0,2),Vector3(2,1.5,2)]:
        var visible:=true
        for bounds in scenery.edge_bounds+scenery.forest_bounds:
            if bounds.intersects_segment(at+Vector3(0,5.7,11),at+Vector3(0,.7,0))!=null:visible=false
        check(visible,"new tree/edge bounds clear gameplay camera sightline: "+str(at))
    scenery.set_quality(0)
    var low:bool=scenery.forest_batches[0].visibility_range_end==135 and scenery.edge_nodes[0].visibility_range_end==28
    scenery.set_quality(1)
    check(low and scenery.forest_batches[0].visibility_range_end==185,"quality reduces forest/edge distance without adding shadows")
    for shader in ["sky","grass","ground","cliff"]:
        var source:Shader=load("res://shaders/garden_polish/"+shader+".gdshader")
        check(source!=null and not source.get_shader_uniform_list().is_empty(),"Godot parses polished shader interface: "+shader)
    for dimensions in [Vector2i(390,844),Vector2i(720,1280),Vector2i(768,1024),Vector2i(1024,1366)]:
        root.size=dimensions
        await step();game.hud.layout();await step()
        var hud:Control=game.hud
        var safe:Rect2=game.controls.safe_rect
        var inside:=safe.encloses(Rect2(hud.progress_backing.position,hud.progress_backing.size)) and safe.encloses(Rect2(hud.notice_backing.position,hud.notice_backing.size))
        var separated:bool=hud.progress_backing.position.y+hud.progress_backing.size.y<hud.notice_backing.position.y
        check(inside and separated,"backed tutorial and progress fit safe area with separation: "+str(dimensions))
        check(hud.notice_backing.mouse_filter==Control.MOUSE_FILTER_IGNORE and hud.progress_backing.mouse_filter==Control.MOUSE_FILTER_IGNORE,"HUD backing does not intercept drag or jump: "+str(dimensions))
    root.size=Vector2i(720,1280)
    for number in range(2,11):
        ProjectSettings.set_setting("visuals/garden_polish/enabled",false);raw(number,true);await step()
        var before_visuals:=visual_snapshot();var before_hud:=hud_snapshot();var before_light:=lighting_snapshot();var before_collision:=collision_snapshot()
        ProjectSettings.set_setting("visuals/garden_polish/enabled",true);raw(number,true);await step()
        check(before_visuals==visual_snapshot() and before_hud==hud_snapshot() and before_light==lighting_snapshot() and before_collision==collision_snapshot(),"Level%d scenery, lighting, HUD and physics stay identical"%number)
        check(game.hud.get_script().resource_path=="res://scripts/components/game_hud.gd","Level%d retains original HUD implementation"%number)
    game.queue_free();await step()
    print("GARDEN POLISH RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
