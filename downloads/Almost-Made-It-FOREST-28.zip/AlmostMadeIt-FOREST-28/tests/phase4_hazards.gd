extends "res://tests/phase3_reliability.gd"
var hz := 60
var key_action := ""
var impulse_at_hit := Vector3.ZERO
var velocity_at_hit := Vector3.ZERO

func observe_hit() -> void:
    impulse_at_hit = game.runner.knockback
    velocity_at_hit = game.runner.velocity

func isolated(point: Vector3, protected := false) -> void:
    await fresh()
    fixture(point)
    if not protected:
        game.runner.spawn_protection_left = 0
        game.runner.invulnerable_left = 0
    impulse_at_hit = Vector3.ZERO
    velocity_at_hit = Vector3.ZERO
    game.runner.hit.connect(observe_hit)

func wait_hit(seconds := 2.0) -> void:
    for tick in range(ceili(seconds*hz)):
        if hits > 0:
            return
        await ticks(1)

func steer_keyboard(target: float) -> void:
    var vx: float = game.runner.velocity.x
    var stop_x: float = game.runner.position.x + signf(vx)*vx*vx/90
    var next := "ui_right" if target-stop_x > .06 else ("ui_left" if target-stop_x < -.06 else "")
    if next != key_action:
        if key_action != "": Input.action_release(key_action)
        key_action = next
        if key_action != "": Input.action_press(key_action)

func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="):
            hz = argument.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second = hz
    root.size = Vector2i(720,1280)
    await fresh()
    check(game.runner.spawn_protection_left == 0 and game.runner.invulnerable_left == 0,
        "new run has no hidden recovery immunity")
    # Reproduce the normal-speed startup bypass using movement alone. At 60 Hz
    # the unchanged Phase 3 baseline has 11 geometric contacts and zero hits.
    for tick in range(ceili(1.4*hz)):
        steer_keyboard(1.6)
        await ticks(1)
        if hits > 0: break
    if key_action != "": Input.action_release(key_action)
    key_action = ""
    check(hits == 1, "normal-speed new-run bar crossing receives real knockback")
    check(game.diagnostics == null, "normal gameplay creates no debug overlay or outline processing")

    for z in [-5.0,-25.0,-48.0]:
        await isolated(Vector3(0,0.08,z+2.3))
        var bar = area(z)
        var camera_basis: Basis = game.camera.global_basis
        await wait_hit()
        check(hits == 1 and velocity_at_hit.y == 5.5 and is_equal_approx(impulse_at_hit.length(),5),
            "direct run hits actual rotating bar with bounded penalty: z=" + str(z))
        var before: Vector3 = game.runner.position
        await ticks(2)
        check(game.runner.velocity.y > 0 and game.runner.position.y > before.y and game.runner.knockback.length() > 0
            and game.runner.velocity.x*impulse_at_hit.x >= 0,
            "controller preserves knockback and upward interruption after hit: z=" + str(z))
        check(bar.monitoring and bar.monitorable and bar.collision_layer == 4 and bar.collision_mask == 2,
            "bar monitoring/layers remain correct: z=" + str(z))
        check(game.camera.global_basis.is_equal_approx(camera_basis) and absf(game.camera.position.z-game.runner.position.z-11) < .6,
            "knockback preserves camera angle and nearby follow distance")
        var matching := true
        for collider in bar.colliders:
            if collider.shape is BoxShape3D:
                matching = matching and collider.shape.size == bar.get_child(0).mesh.size and collider.transform == bar.get_child(0).transform
        check(matching, "sweep box matches existing visible red bar exactly")

        await isolated(Vector3(0,0.08,z+6.5))
        bar = area(z)
        # Time the unchanged rotating bar to be broadside at crossing. No hazard
        # is disabled; this is a clean timed jump, not immunity masquerading as one.
        bar.rotation.y = -bar.spin_speed*(6.5/game.runner.RUN_SPEED)
        await ticks(2)
        game.runner.jump_requested = true
        for tick in range(ceili(1.2*hz)):
            await ticks(1)
            if game.runner.position.z < z-1.5: break
        check(hits == 0 and game.runner.position.z < z-1.5 and game.runner.invulnerable_left == 0,
            "clean timed jump clears rotating bar without false penalty: z=" + str(z))

        await isolated(Vector3(3.5,0.08,z+3.2))
        for tick in range(ceili(1.1*hz)):
            await ticks(1)
            if game.runner.position.z < z-3.2: break
        check(hits == 0 and game.runner.position.z < z-3.2 and game.runner.is_on_floor(),
            "safe side dodge remains collision-free on platform: z=" + str(z))

    for radial in [Vector3(2.2,0,0),Vector3(-2.2,0,0),Vector3(0,0,2.2),Vector3(0,0,-2.2)]:
        await isolated(Vector3(0,0.08,-5)+radial)
        game.runner.allow_forward = false
        var bar = area(-5)
        bar.rotation.y = PI*.5 if radial.x != 0 else 0
        await wait_hit(2.2)
        var tangent := Vector3(radial.z,0,-radial.x).normalized()
        check(hits == 1 and impulse_at_hit.normalized().dot(tangent) > .9,
            "standing player receives rotation-directed sweep contact from " + str(radial))

    await isolated(Vector3(3.2,0.08,-5))
    game.runner.allow_forward = false
    area(-5).rotation.y = 0
    area(-5).spin_speed = 0
    await wait_hit(.3)
    await ticks(3)
    check(hits == 1 and game.runner.position.y >= 0 and game.deaths == 0,
        "near-edge tip contact gives knockback without pushing body through deck")

    await isolated(Vector3(0,.9,-5))
    await wait_hit(.3)
    game.runner.jump_requested = true
    await ticks(2)
    check(hits == 1 and jumps == 0 and game.runner.velocity.y > 0 and game.runner.velocity.y < 5.5,
        "airborne contact applies hit and cannot grant a stale-floor double jump")

    await isolated(Vector3(0,.08,3.5))
    wall(Vector3(0,1,2),Vector3(9,2,.4))
    await ticks(ceili(.5*hz))
    check(game.runner.position.z > 2.6 and game.runner.is_on_floor(),
        "CharacterBody cannot auto-run through an actual solid world collider")

    await isolated(Vector3(0,.05,-5),true)
    game.runner.allow_forward = false
    area(-5).spin_speed = 0
    await ticks(ceili(.2*hz))
    check(hits == 0 and game.runner.spawn_protection_left > 1 and area(-5).has_contact(game.runner),
        "real geometry contact is blocked by finite recovery protection")
    game.set_paused(true)
    var protected_time: float = game.runner.spawn_protection_left
    var turn: float = area(-5).rotation.y
    await ticks(ceili(.4*hz))
    check(game.runner.spawn_protection_left == protected_time and area(-5).rotation.y == turn,
        "pause freezes contact motion and recovery protection")
    game.set_paused(false)
    game.runner.allow_forward = false # Preserve this isolated stationary fixture.
    await wait_hit(1.6)
    check(hits == 1 and game.runner.spawn_protection_left == 0 and game.runner.invulnerable_left > 0,
        "protected contact resumes immediately on natural expiry; cooldown is distinct")
    for duplicate in range(20):
        area(-5).contact.emit(game.runner)
    check(hits == 1, "twenty duplicate contact callbacks cannot multiply one hit")

    # Keep a genuine continuous hub overlap after cooldown, without motion.
    await isolated(Vector3(0,.05,-5))
    game.runner.set_physics_process(false)
    area(-5).spin_speed = 0
    await wait_hit(.2)
    game.runner.invulnerable_left = 0 # Isolate latch independently of cooldown.
    for duplicate in range(10): area(-5).contact.emit(game.runner)
    await ticks(4)
    check(hits == 1, "continuous contact latch also rejects duplicate callbacks after cooldown")

    # Stress half/full turns: endpoints miss, real intervening bar intersects.
    # Signed full motion and current+previous body positions must be respected.
    for turns in [PI,-PI,TAU,-TAU]:
        await isolated(Vector3(2.4,.05,-5))
        game.runner.set_physics_process(false)
        area(-5).rotation.y = PI*.5
        area(-5).spin_speed = turns*hz
        await wait_hit(.2)
        check(hits == 1 and area(-5).contact_source == "swept", "fast signed rotation registers between-tick contact: turn=" + str(turns))
        game.runner.set_physics_process(true)
        game.runner.allow_forward = false
        await ticks(1)
        check(game.runner.velocity.y > 0 and game.runner.knockback.length() > 0, "swept contact applies physical knockback on next tick")
    await isolated(Vector3(3.5,.05,-5))
    game.runner.allow_forward = false
    area(-5).spin_speed = TAU*hz
    await ticks(6)
    check(hits == 0, "fast sweep does not replace thin shapes with unfair oversized radius")

    # Each saved checkpoint, several deaths, and a real post-recovery overlap.
    for cp in [0,1]:
        await fresh()
        fixture(game.checkpoints[cp].spawn+Vector3(0,0,1.1))
        await ticks(ceili(.15*hz))
        for death in [1,2,3]:
            game._respawn()
            for callback in range(10): game.runner.fell.emit()
            await wait_state(game.RunState.PLAYING,ceili(2*hz))
        check(game.checkpoint_index == cp and game.deaths == 3 and game._spawn_safe(game.checkpoints[cp].spawn),
            "multiple deaths retain safe authoritative checkpoint " + str(cp))
        # Explicit isolated positioning after exercising actual timer recoveries.
        fixture(Vector3(0,.05,-5))
        game.runner.spawn_protection_left = 0
        game.runner.invulnerable_left = 0
        game.runner.allow_forward = false
        await wait_hit(.2)
        check(hits == 1, "hazard detection still works after three checkpoint deaths")

    game.restart()
    await frames(4)
    game = current_scene
    check(game.coins == 0 and game.deaths == 0 and game.checkpoint_index == -1 and game.progress_percent() == 0
        and game.runner.spawn_protection_left == 0, "restart after hit resets run without stale immunity")

    await isolated(Vector3(2.2,.05,-5))
    game.runner.allow_forward = false
    var bar = area(-5)
    bar.rotation.y = PI*.5
    var position: Vector3 = game.runner.position
    game.set_paused(true)
    turn = bar.rotation.y
    await ticks(ceili(.4*hz))
    check(bar.rotation.y == turn and game.runner.position == position and hits == 0, "pause actually freezes moving obstacle near player")
    game.set_paused(false)
    game.runner.allow_forward = false
    await wait_hit(2)
    check(hits == 1, "resuming close to bar restores legitimate sweep collision")

    await fresh()
    game.queue_free()
    await frames(2)
    game = load("res://main.tscn").instantiate()
    game.gameplay_debug = true
    root.add_child(game)
    current_scene = game
    await ticks(2)
    check(is_instance_valid(game.diagnostics) and game.diagnostics.label.text.contains("spawn protection="),
        "explicit development flag activates collision/state diagnostics")
    var collider: CollisionShape3D = game.runner.get_child(0)
    check(collider.get_node_or_null("DebugCollisionOutline") != null and is_equal_approx(collider.shape.radius,game.runner.BODY_RADIUS),
        "debug boundary outlines exist without modifying physical capsule")
    fixture(Vector3(0,.05,-5))
    game.runner.spawn_protection_left = 0
    game.runner.invulnerable_left = 0
    game.runner.allow_forward = false
    await ticks(2)
    game.diagnostics.refresh()
    check(game.diagnostics.label.text.contains("HIT") and game.diagnostics.label.text.contains("mask="),
        "debug trace reports real accepted contact and live masks")
    game.queue_free()
    await frames(3)
    print("PHASE4 HAZARDS RESULT: %d checks, %d failures, physics=%d Hz" % [checks,failures,hz])
    quit(1 if failures else 0)
