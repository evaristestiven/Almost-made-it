extends "res://tests/camera_collision_follow.gd"

func avatar_fraction() -> float:
    var feet: Vector2 = game.camera.unproject_position(game.runner.position)
    var head: Vector2 = game.camera.unproject_position(game.runner.position+Vector3.UP*game.runner.BODY_HEIGHT)
    return feet.distance_to(head)/game.camera.get_viewport().get_visible_rect().size.y

func run() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--physics-hz="): Engine.physics_ticks_per_second = argument.get_slice("=",1).to_int()
    root.size = Vector2i(720,1280)
    await real_level()
    # Run the configured startup scene: real bar, touch departure, death timer,
    # checkpoint restore and camera. Observe size as well as frustum inclusion.
    for i in range(250):
        await frame()
        if hits: break
    require(hits > 0,"actual level bar delivers an impact before integrated recovery")
    var original_angle: Basis = game.camera.global_basis
    var minimum_size := 1.0
    var maximum_distance := 0.0
    var lowest_camera: float = game.camera.position.y
    var start_height := lowest_camera
    var framed := true
    var maximum_fall_elapsed := 0.0
    touch("right",1,true)
    for i in range(300):
        await frame()
        maximum_fall_elapsed = maxf(maximum_fall_elapsed,game.runner.fall_elapsed)
        minimum_size = minf(minimum_size,avatar_fraction())
        maximum_distance = maxf(maximum_distance,game.camera.position.distance_to(game.runner.position))
        lowest_camera = minf(lowest_camera,game.camera.position.y)
        framed = framed and visible_player()
        if game.state == game.RunState.DYING: break
    touch("right",1,false)
    print("PHASE6_FALL_EVIDENCE y=%s camera=%s fraction=%.5f max_distance=%.4f descent=%.4f" % [game.runner.position.y,str(game.camera.position),minimum_size,maximum_distance,start_height-lowest_camera])
    require(game.deaths == 1 and game.state == game.RunState.DYING,"unrecoverable fall enters one controlled death transition")
    require(game.runner.position.y > -5.5 and maximum_fall_elapsed+1.01/Engine.physics_ticks_per_second >= game.runner.fall_visibility_duration,"brief configurable fall window ends before a deep sky-filled fall")
    require(framed and minimum_size > .025 and maximum_distance < 16,"avatar remains visible at useful size, not merely somewhere in the frustum")
    require(start_height-lowest_camera < 5.0,"fall limits downward camera travel")
    require(not game.runner.accept_jump_input and game.controls.fingers.is_empty(),"death clears touches and disables jump input")
    for i in range(180):
        await frame()
        if game.state == game.RunState.RESPAWNING: break
    require(game.state == game.RunState.RESPAWNING,"real death timer reaches respawning")
    print("PHASE6_RECOVERY_EVIDENCE camera=%s body=%s lag=%.5f size=%.5f" % [str(game.camera.position),str(game.runner.position),game.camera.follow_position.distance_to(game.camera.follow_anchor(game.runner.position)+game.camera.OFFSET),avatar_fraction()])
    require(game.camera.follow_position.distance_to(game.camera.follow_anchor(game.runner.position)+game.camera.OFFSET) <= .751,"teleport resets old world history to a bounded local framing error")
    require(visible_player() and avatar_fraction() > .025,"avatar is framed immediately at the checkpoint")
    # Rendering may observe several settling physics steps after reset. Permit
    # only the gravity earned while falling the spawn's eight-centimetre gap.
    require(Vector2(game.runner.velocity.x,game.runner.velocity.z).length() < .001 and absf(game.runner.velocity.y) <= sqrt(2*game.runner.GRAVITY*.08)+game.runner.GRAVITY/Engine.physics_ticks_per_second and game.runner.knockback == Vector3.ZERO and game.runner.fall_elapsed == 0,"respawn clears falling motion, external forces and fall timer")
    for i in range(180):
        await frame()
        if game.state == game.RunState.PLAYING: break
    require(game.camera.is_recovery_ready() and game.runner.spawn_protection_left > 1.0,"control resumes after camera readiness with a full protection window")
    require(game.camera.global_basis.is_equal_approx(original_angle),"fall/recovery preserves established perspective")
    # Victory is caused by actual finish overlap from a trusted nearby fixture,
    # never by a progress percentage or a direct call to the HUD.
    game.runner.reset_at(Vector3(0,.08,-74.4),false)
    game.runner.grace_left = 0
    game.route.restore(game.runner.position,game.route.distance_at(game.runner.position))
    game.runner.allow_forward = true
    game.camera.setup(game.runner)
    game.coins = 3
    game.deaths = 2
    for i in range(60):
        await frame()
        if game.won: break
    require(game.won and game.completion_count == 1,"legitimate finish opens exactly one victory screen")
    require(game.hud.result_coins.text == "3 / 5" and game.hud.result_falls.text == "2","victory cards use authoritative run results")
    require(game.hud.restart_button.text == "REPLAY" and not game.hud.resume_button.visible and not game.hud.options.visible,"completion offers real replay without unavailable navigation")
    for screen in [Vector2i(320,568),Vector2i(390,844),Vector2i(720,1280),Vector2i(1080,1920),Vector2i(768,1024),Vector2i(1024,768),Vector2i(1024,1366)]:
        root.size = screen
        for i in range(10): await frame()
        var safe: Rect2 = game.controls.safe_rect
        var card: Rect2 = game.hud.panel.get_global_rect()
        print("PHASE6_VICTORY_LAYOUT screen=%s safe=%s card=%s" % [str(screen),str(safe),str(card)])
        require(safe.encloses(card) and card.size.y < 420 and card.get_center().distance_to(safe.get_center()) < 1,"compact victory card stays centered inside safe area: "+str(screen))
        require(card.encloses(game.hud.restart_button.get_global_rect()) and card.encloses(game.hud.results.get_global_rect()),"result cards and replay hitbox remain within panel")
    require(game.hud.panel.modulate.a > .99,"subtle victory reveal finishes without moving touch hitboxes")
    var frozen: Vector3 = game.runner.position
    for i in range(20):
        game.finish_area.body_entered.emit(game.runner)
        game._respawn()
        await frame()
    require(game.completion_count == 1 and game.completed_coins == 3 and game.completed_falls == 2 and game.runner.position.distance_to(frozen) < .1,"modal victory freezes movement and duplicate callbacks cannot mutate results")
    touch("restart",3,true)
    touch("restart",3,false)
    for i in range(5): await frame()
    game = current_scene
    require(not game.won and game.deaths == 0 and game.coins == 0 and game.checkpoint_index == -1,"real replay button creates one clean run")
    game.queue_free()
    await frame()
    print("PHASE6 PRESENTATION RESULT: %d checks, %s" % [checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
