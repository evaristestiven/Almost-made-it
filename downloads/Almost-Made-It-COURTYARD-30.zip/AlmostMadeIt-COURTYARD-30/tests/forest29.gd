extends "res://tests/sky_garden.gd"
func run() -> void:
    root.size=Vector2i(720,1280)
    ProjectSettings.set_setting("visuals/forest29/enabled",false);raw(1,true)
    var before:=collision_snapshot()
    var old_scenery:Node3D=game.get_node("AdventureScenery")
    var old_roots:Array=[]
    for entry in old_scenery.forest_roots:old_roots.append([entry.root,entry.height])
    ProjectSettings.set_setting("visuals/forest29/enabled",true);raw(1,true)
    check(collision_snapshot()==before,"tree upgrade changes no Level1 gameplay collisions")
    var scenery:Node3D=game.get_node("AdventureScenery")
    var species:Dictionary={}
    var supported:=true
    var new_roots:Array=[]
    for entry in scenery.forest_roots:
        species[entry.name]=int(species.get(entry.name,0))+1
        new_roots.append([entry.root,entry.height])
        supported=supported and absf(entry.root.y-(scenery.terrain_height(entry.root)-.025))<.01
    check(old_roots==new_roots,"tree count, terrain-supported positions and heights remain unchanged")
    check(int(species.get("CommonTree_5",0))>10,"new verified broadleaf appears in actual Level1 forest")
    check(int(species.get("Pine_1",0))==92 and int(species.get("Pine_5",0))==100,"existing pine placements are retained")
    check(int(species.get("CommonTree_3",0))>50 and int(species.get("CommonTree_4",0))>50,"existing broadleaf varieties remain present")
    check(supported,"all forest roots connect to decorative terrain")
    var source:Dictionary=scenery.source("CommonTree_5")
    var mesh:Mesh=source.mesh
    check(mesh.get_surface_count()==2,"imported tree has separate bark and foliage surfaces")
    var bark:StandardMaterial3D=mesh.surface_get_material(0)
    var leaf:StandardMaterial3D=mesh.surface_get_material(1)
    check(bark.normal_enabled and bark.albedo_texture.resource_path.ends_with("Bark_NormalTree.png") and bark.normal_texture.resource_path.ends_with("Bark_NormalTree_Normal.png"),"original shared bark and normal textures resolve")
    check(leaf.albedo_texture.resource_path.ends_with("Leaves_NormalTree_C.png") and leaf.transparency==BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR,"original leaf atlas and alpha mask resolve")
    var triangles:=0
    for i in range(2):
        var arrays:=mesh.surface_get_arrays(i)
        triangles+=arrays[Mesh.ARRAY_INDEX].size()/3
        check(arrays[Mesh.ARRAY_VERTEX].size()>0 and arrays[Mesh.ARRAY_NORMAL].size()==arrays[Mesh.ARRAY_VERTEX].size() and arrays[Mesh.ARRAY_TEX_UV].size()==arrays[Mesh.ARRAY_VERTEX].size(),"original vertices, normals and UVs intact: surface "+str(i))
    check(scenery.find_children("*","CollisionObject3D",true,false).is_empty(),"scenery introduces no collision bodies")
    print("FOREST29_MODEL triangles=",triangles," bounds=",source.bounds)
    print("FOREST29_SPECIES ",JSON.stringify(species))
    for level in range(2,11):
        ProjectSettings.set_setting("visuals/forest29/enabled",false);raw(level,true)
        var collisions:=collision_snapshot();var visuals:=visual_snapshot()
        ProjectSettings.set_setting("visuals/forest29/enabled",true);raw(level,true)
        check(collision_snapshot()==collisions and visual_snapshot()==visuals,"Level "+str(level)+" visuals and collisions unchanged")
    game.free()
    print("FOREST29 RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
