extends RefCounted
# Bespoke reusable architectural meshes; no external model impersonation.
static func surface(points:PackedVector3Array,uvs:=PackedVector2Array()) -> ArrayMesh:
    var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
    for i in points.size():
        if uvs.size()==points.size():st.set_uv(uvs[i])
        st.add_vertex(points[i])
    st.generate_normals();st.index();return st.commit()
static func quad(out:PackedVector3Array,a:Vector3,b:Vector3,c:Vector3,d:Vector3) -> void:
    out.append_array(PackedVector3Array([a,b,c,a,c,d]))
static func lathe(profile:Array,segments:=48) -> ArrayMesh:
    var p:=PackedVector3Array()
    for j in range(profile.size()-1):
        for i in segments:
            var a:=TAU*i/segments;var b:=TAU*(i+1)/segments
            var u:Vector2=profile[j];var v:Vector2=profile[j+1]
            quad(p,Vector3(cos(a)*u.x,u.y,sin(a)*u.x),Vector3(cos(b)*u.x,u.y,sin(b)*u.x),Vector3(cos(b)*v.x,v.y,sin(b)*v.x),Vector3(cos(a)*v.x,v.y,sin(a)*v.x))
    return surface(p)
static func sector(inner:float,outer:float,a:float,b:float,y:float,depth:float,steps:=5) -> ArrayMesh:
    var p:=PackedVector3Array()
    for i in steps:
        var u:=lerpf(a,b,float(i)/steps);var v:=lerpf(a,b,float(i+1)/steps)
        var v1:=Vector3(cos(u)*inner,y,sin(u)*inner);var v2:=Vector3(cos(v)*inner,y,sin(v)*inner)
        var v3:=Vector3(cos(v)*outer,y,sin(v)*outer);var v4:=Vector3(cos(u)*outer,y,sin(u)*outer)
        quad(p,v1,v2,v3,v4);quad(p,v4,v3,v3-Vector3.UP*depth,v4-Vector3.UP*depth)
        quad(p,v2,v1,v1-Vector3.UP*depth,v2-Vector3.UP*depth)
    for i in range(0,p.size(),3):
        var swap:=p[i+1];p[i+1]=p[i+2];p[i+2]=swap
    return surface(p)
static func rounded_box(size:Vector3,radius:=.07) -> ArrayMesh:
    # Extruded rounded footprint, beveled upper and lower edges.
    var points:=PackedVector3Array();var rings:Array=[]
    var r:=minf(radius,minf(size.x,size.z)*.45)
    for layer in [Vector2(-size.y*.5,r*.55),Vector2(-size.y*.5+r*.55,0),Vector2(size.y*.5-r*.55,0),Vector2(size.y*.5,r*.55)]:
        var ring:=PackedVector3Array()
        for corner in 4:
            var sx:=1.0 if corner in [0,3] else -1.0;var sz:=1.0 if corner in [0,1] else -1.0
            var center:=Vector2(sx*(size.x*.5-r),sz*(size.z*.5-r))
            for k in 5:
                var a:float=corner*PI*.5+k*PI*.5/4
                ring.append(Vector3(center.x+cos(a)*(r-layer.y),layer.x,center.y+sin(a)*(r-layer.y)))
        rings.append(ring)
    for j in 3:
        for i in 20:quad(points,rings[j][i],rings[j][(i+1)%20],rings[j+1][(i+1)%20],rings[j+1][i])
    for i in 20:
        points.append_array(PackedVector3Array([Vector3(0,size.y*.5,0),rings[3][i],rings[3][(i+1)%20]]))
        points.append_array(PackedVector3Array([Vector3(0,-size.y*.5,0),rings[0][(i+1)%20],rings[0][i]]))
    return surface(points)
static func cliff(seed_value:int,radius:float,height:float) -> ArrayMesh:
    var p:=PackedVector3Array();var rng:=RandomNumberGenerator.new();rng.seed=seed_value
    var rings:Array=[];var count:=18
    for layer in 5:
        var ring:=PackedVector3Array()
        var factor:float=[1.0,1.04,.88,.65,.12][layer]
        for i in count:
            var a:float=TAU*i/count;var r:float=radius*factor*(1+rng.randf_range(-.08,.08))
            ring.append(Vector3(cos(a)*r,-height*layer/4.0+(.0 if layer==0 else rng.randf_range(-.6,.6)),sin(a)*r))
        rings.append(ring)
    for layer in 4:
        for i in count:quad(p,rings[layer][i],rings[layer+1][i],rings[layer+1][(i+1)%count],rings[layer][(i+1)%count])
    return surface(p)
