extends SceneTree
# Run with a graphical Godot display. Never substitute headless dummy images.
var scene:Node3D
var index:=0
var settling:=0
var folder:String
var capturing:=false
func _initialize() -> void:call_deferred("start")
func start() -> void:
    if DisplayServer.get_name()=="headless":
        printerr("Courtyard screenshots require a graphical rendering backend; no images generated.");quit(2);return
    root.size=Vector2i(1280,960)
    folder=OS.get_environment("COURSE_EVIDENCE_PATH")
    if folder.is_empty():folder="user://courtyard30-screenshots"
    DirAccess.make_dir_recursive_absolute(folder)
    change_scene_to_file("res://prototypes/training_courtyard/training_courtyard.tscn");await scene_changed
    scene=current_scene;scene.runner.set_physics_process(false)
    scene.runner.global_position=Vector3(0,.08,-3);scene.camera.setup(scene.runner)
    scene.set_view(0);scene.rotor.set_physics_process(false)
func _process(_delta:float) -> bool:
    if not is_instance_valid(scene) or capturing:return false
    settling+=1
    if settling<12:return false
    capturing=true;capture();return false
func capture() -> void:
    await RenderingServer.frame_post_draw
    var pixels:=root.get_texture().get_image()
    if pixels.is_empty():printerr("No rendered output");quit(3);return
    var file:=folder+"/"+str(scene.views[index].name)+".png"
    if pixels.save_png(file)!=OK:printerr("Cannot save "+file);quit(4);return
    print("CAPTURED ",file);index+=1;settling=0;capturing=false
    if index==5:print("COURTYARD CAPTURE: 5 actual views saved");quit();return
    scene.set_view(index)
