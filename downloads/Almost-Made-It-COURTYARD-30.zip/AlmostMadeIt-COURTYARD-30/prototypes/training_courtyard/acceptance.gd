extends "res://tests/swipe_movement.gd"
var results:Array=[]
func fixture(point:Vector3) -> void:
    game.runner.reset_at(point,false);game.runner.grace_left=0
    game.controls.clear_input();game.camera.setup(game.runner)
func fresh() -> void:
    change_scene_to_file("res://prototypes/training_courtyard/training_courtyard.tscn");await scene_changed;game=current_scene
    await seconds(.5)
func impact_trial(speed:float) -> Dictionary:
    game.rotor.spin_speed=speed;game.reset_rotor()
    fixture(game.CENTER+Vector3(5,.02,-1.7))
    var start:Vector3=game.runner.position;var first:int=game.accepted_hits
    var peak:=0.0;var impulse:=0.0
    var until:=Engine.get_physics_frames()+hz*4
    while Engine.get_physics_frames()<until:
        await step();peak=maxf(peak,game.runner.knockback.length());impulse=maxf(impulse,game.runner.last_impulse.length())
        if game.accepted_hits>first and Engine.get_physics_frames()-game.runner.last_impact_frame>hz*.3:break
    var record:Dictionary={"speed":speed,"hits":game.accepted_hits-first,"displacement":horizontal(game.runner.position-start).length(),"peak_knockback":peak,"impulse":impulse}
    print("COURTYARD_IMPACT ",JSON.stringify(record));results.append(record);return record
func run() -> void:
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--physics-hz="):hz=arg.get_slice("=",1).to_int()
    Engine.physics_ticks_per_second=hz;root.size=Vector2i(720,1280)
    await fresh()
    check(game.runner.get_script().resource_path=="res://scripts/player.gd" and game.camera.get_script().resource_path=="res://scripts/components/follow_camera.gd" and game.controls.get_script().resource_path=="res://scripts/touch_controls.gd","prototype reuses original player, follow camera and swipe input")
    check(game.runner.is_on_floor() and game.runner.collision_layer==2 and game.runner.collision_mask==5,"safe supported entrance spawn with original collision settings")
    var start:Vector3=game.runner.position;var cam:Vector3=game.camera.position
    await seconds(15)
    check(horizontal(game.runner.position-start).length()<.001 and game.runner.move_input==Vector2.ZERO,"15 seconds untouched: no automatic movement")
    check(game.camera.position.distance_to(cam)<.001,"15 seconds untouched: stable gameplay camera")
    finger(1,true,gesture_start());await seconds(.1)
    check(game.runner.move_input==Vector2.ZERO,"touch without dragging does not move")
    drag_direction(Vector2.UP);jump();await seconds(.12)
    check(game.runner.velocity.z< -1 and game.runner.velocity.y>0,"real multitouch drag and jump work simultaneously")
    release(2);await seconds(.1)
    check(game.controls.movement().y< -.9,"releasing jump finger preserves movement touch")
    release();await seconds(.8)
    check(game.controls.movement()==Vector2.ZERO and horizontal(game.runner.control_velocity).length()<.01,"movement release clears input and decelerates motor")
    check(game.rotor.colliders.size()==2 and game.rotor.collision_layer==4 and game.rotor.collision_mask==2,"four-arm obstacle uses two centered solid cross shapes")
    check(game.rotor.sync_to_physics and game.rotor.query!=null,"native fixed-step collision and sweep queries configured")
    var slow:=await impact_trial(.25);var fast:=await impact_trial(1.2)
    check(slow.hits>0 and slow.displacement>.2 and slow.peak_knockback>.2,"stationary avatar is physically pushed by slow sweep")
    check(fast.hits>0 and fast.displacement>.5 and fast.peak_knockback>slow.peak_knockback,"fast sweep produces stronger real displacement and knockback")
    check(fast.impulse>slow.impulse,"relative-speed response scales impact impulse")
    game.rotor.spin_speed=.55;game.reset_rotor()
    fixture(game.CENTER+Vector3(5,1.25,-.2));game.runner.velocity.y=1.5
    var hits_before:int=game.accepted_hits;await seconds(.15)
    check(game.accepted_hits==hits_before,"avatar wholly above sweep collider clears it without a false hit")
    fixture(game.CENTER+Vector3(10.6,.02,0));hits_before=game.accepted_hits;await seconds(3.5)
    check(game.accepted_hits==hits_before,"outer waiting ring legitimately dodges all rotating arms")
    game.rotor.spin_speed=0;game.reset_rotor();fixture(game.CENTER+Vector3(5,.02,2.0))
    game.runner.spawn_protection_left=2;game.runner.invulnerable_left=2
    drag_direction(Vector2.UP);await seconds(.55)
    check(game.runner.position.z>game.CENTER.z+.85,"holding movement cannot run through stationary solid arm during protection")
    check(game.accepted_hits==hits_before,"protected contact does not award false damage")
    release();await seconds(2.1)
    check(game.runner.spawn_protection_left==0 and game.runner.invulnerable_left==0 and game.runner.collision_mask==5,"protection expires without disabling solid collision")
    # After natural expiration a moving sweep must hit again.
    var expired:=await impact_trial(.75)
    check(expired.hits>0,"normal physical response works again after protection expires")
    game.rotor.spin_speed=-.55;game.reset_rotor();fixture(game.CENTER+Vector3(5,.02,1.8))
    await seconds(.08);hits_before=game.accepted_hits
    drag_direction(Vector2.UP);jump();await seconds(.52);release();release(2)
    check(game.accepted_hits==hits_before and game.runner.position.z<game.CENTER.z-.8,"actual swipe and jump clears an approaching moving arm")
    game.restart();game.rotor.spin_speed=.55;await seconds(.5)
    for view in range(5):
        game.set_view(view)
        check(game.get_viewport().get_camera_3d()==(game.camera if view==4 else game.inspection_camera),"inspection camera view "+str(view+1)+" selects correctly")
    # Traverse the full safe outer arc through actual movement, no teleportation.
    var route:Array[Vector3]=[Vector3(0,0,-4.8),game.CENTER+Vector3(7.7,0,7.7),game.CENTER+Vector3(10.9,0,0),game.CENTER+Vector3(7.7,0,-7.7),Vector3(0,0,-27.0),Vector3(0,0,-43)]
    var completed:=true
    for point in route:
        var deadline:=Engine.get_physics_frames()+hz*8
        while horizontal(game.runner.position-point).length()>.3 and Engine.get_physics_frames()<deadline:
            drag_direction(horizontal(point-game.runner.position).normalized());await step()
            if game.recovering:completed=false;break
        if horizontal(game.runner.position-point).length()>.5:completed=false
        release();await seconds(.2)
    check(completed and game.falls==0,"entrance bridge, full arena outer arc and exit walkway are continuously traversable")
    game.restart();await seconds(.5)
    fixture(Vector3(7,2,6));var fall_count:int=game.falls
    await seconds(2)
    check(game.falls==fall_count+1 and not game.recovering and game.runner.position.distance_to(game.SPAWN)<.2,"physical fall counts once and restores entrance with recentered camera")
    check(game.camera.is_recovery_ready() and game.controls.movement()==Vector2.ZERO,"camera ready and stale inputs cleared after recovery")
    game.toggle_pause();finger(1,true,gesture_start());drag_direction(Vector2.UP);game.toggle_pause();await seconds(.25)
    check(game.controls.movement()==Vector2.ZERO,"pause/resume clears previous touch input")
    game.restart();await seconds(.5)
    check(game.runner.position.distance_to(game.SPAWN)<.2 and game.runner.knockback==Vector3.ZERO and game.falls==0,"reset restores initial pose, velocity, counters and camera")
    print("COURTYARD_STATS ",JSON.stringify(game.stats))
    print("COURTYARD30 RESULT: %d checks, %s"%[checks,"FAILED" if failed else "ALL PASSED"])
    quit(1 if failed else 0)
