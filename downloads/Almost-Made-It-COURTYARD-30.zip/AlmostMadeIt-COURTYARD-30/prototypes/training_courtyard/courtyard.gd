extends Node3D
const C=preload("res://prototypes/training_courtyard/craft.gd")
const PLAYER=preload("res://scripts/player.gd")
const CAMERA=preload("res://scripts/components/follow_camera.gd")
const INPUT=preload("res://scripts/touch_controls.gd")
const SWEEP=preload("res://prototypes/training_courtyard/sweep.gd")
const ASSETS="res://assets/nature/quaternius/CommonTree_3/"
const CENTER=Vector3(0,0,-16)
const SPAWN=Vector3(0,.08,9)
const BUILD="COURTYARD-30"
var runner:CharacterBody3D
var camera:Camera3D
var controls:Control
var rotor:AnimatableBody3D
var elapsed:=0.0
var falls:=0
var accepted_hits:=0
var recovering:=false
var recovery_left:=0.0
var paused:=false
var label:Label
var materials:Dictionary={}
var meshes:Dictionary={}
var batches:Dictionary={}
var imported_sources:Dictionary={}
var flags:Array[ShaderMaterial]=[]
var sky_material:ShaderMaterial
var rng:=RandomNumberGenerator.new()
var stats:Dictionary={}
var test_input:=false
var inspection_index:=4
var inspection_camera:Camera3D
var views: Array[Dictionary]=[
    {"name":"01-overview","at":Vector3(34,32,24),"look":Vector3(0,0,-16)},
    {"name":"02-entrance","at":Vector3(8,5,18),"look":Vector3(0,1,-8)},
    {"name":"03-central-mechanism","at":Vector3(11,5,-7),"look":Vector3(0,1,-16)},
    {"name":"04-exit","at":Vector3(8,5,-37),"look":Vector3(0,1,-22)},
    {"name":"05-gameplay"}]
var last_hit:Dictionary={}

func mat(key:String,color:String,metal:=0.0,rough:=.75) -> Material:
    if not materials.has(key):
        var m:=StandardMaterial3D.new();m.albedo_color=Color(color);m.metallic=metal;m.roughness=rough
        materials[key]=m
    return materials[key]
func instance_mesh(parent:Node3D,mesh:Mesh,material:Material,pose:Transform3D) -> MeshInstance3D:
    var n:=MeshInstance3D.new();n.mesh=mesh;n.material_override=material;parent.add_child(n);n.transform=pose;return n
func batch(key:String,mesh:Mesh,material:Material,at:Vector3,scale_value:=Vector3.ONE,yaw:=0.0) -> void:
    if not batches.has(key):batches[key]={"mesh":mesh,"material":material,"poses":[]}
    batches[key].poses.append(Transform3D(Basis(Vector3.UP,yaw).scaled(scale_value),at))
func box(key:String,size:Vector3,at:Vector3,material:Material,yaw:=0.0) -> void:
    var id:=key+str(size)
    if not meshes.has(id):meshes[id]=C.rounded_box(size,.05)
    batch(id,meshes[id],material,at,Vector3.ONE,yaw)
func radial(key:String,profile:Array,at:Vector3,material:Material,segments:=48) -> void:
    if not meshes.has(key):meshes[key]=C.lathe(profile,segments)
    batch(key,meshes[key],material,at)
func beam(a:Vector3,b:Vector3,width:float,material:Material) -> void:
    var key:="beam"+str(width)
    if not meshes.has(key):meshes[key]=C.rounded_box(Vector3(width,width,1),.035)
    var direction:=b-a
    var basis:=Basis.looking_at(direction.normalized(),Vector3.UP if absf(direction.normalized().y)<.99 else Vector3.RIGHT)
    if not batches.has(key+str(material.get_instance_id())):batches[key+str(material.get_instance_id())]={"mesh":meshes[key],"material":material,"poses":[]}
    batches[key+str(material.get_instance_id())].poses.append(Transform3D(basis.scaled(Vector3(1,1,direction.length())),(a+b)*.5))
func solid_box(at:Vector3,size:Vector3) -> void:
    var body:=StaticBody3D.new();body.collision_layer=1;body.collision_mask=2;add_child(body);body.position=at
    var cs:=CollisionShape3D.new();var shape:=BoxShape3D.new();shape.size=size;cs.shape=shape;body.add_child(cs)
func source(name:String) -> Dictionary:
    if not imported_sources.has(name):
        var scene:PackedScene=load(ASSETS+name+".gltf");var model:=scene.instantiate();var node:MeshInstance3D=model.find_children("*","MeshInstance3D",true,false)[0]
        var pose:Transform3D=node.transform;var parent:Node3D=node.get_parent()
        while parent!=model:pose=parent.transform*pose;parent=parent.get_parent()
        imported_sources[name]={"mesh":node.mesh,"local":pose,"bounds":pose*node.mesh.get_aabb()};model.free()
    return imported_sources[name]
func plant(name:String,at:Vector3,height:float,yaw:float) -> void:
    var data:=source(name);var size:float=height/data.bounds.size.y
    var key:="asset_"+name+str(floori(at.z/25))
    if not batches.has(key):batches[key]={"mesh":data.mesh,"material":null,"poses":[]}
    var pose:=Transform3D(Basis(Vector3.UP,yaw).scaled(Vector3.ONE*size),at-Vector3.UP*data.bounds.position.y*size)
    batches[key].poses.append(pose*data.local)
func _ready() -> void:
    rng.seed=3030;process_physics_priority=0
    lighting();arena();bridges();towers();landscape();build_rotor();flush()
    runner=CharacterBody3D.new();runner.name="Runner";runner.set_script(PLAYER);add_child(runner)
    runner.horizontal_death_limit=42;runner.reset_at(SPAWN,false)
    runner.fell.connect(begin_recovery);runner.hit.connect(on_hit)
    rotor.track_body(runner)
    rotor.contact.connect(func(body:Node3D) -> void:
        if body==runner and runner.apply_bar_impact(rotor):rotor.mark_hit(body))
    camera=Camera3D.new();camera.name="GameplayCamera";camera.set_script(CAMERA);camera.fov=67;camera.current=true;add_child(camera);camera.setup(runner)
    inspection_camera=Camera3D.new();inspection_camera.name="InspectionCamera";inspection_camera.fov=56;add_child(inspection_camera)
    hud()
    stats={"batches":batches.size(),"instances":0,"imported_species":imported_sources.keys()}
    for data in batches.values():stats.instances+=data.poses.size()
func lighting() -> void:
    var world:=WorldEnvironment.new();var env:=Environment.new();var sky:=Sky.new()
    sky_material=ShaderMaterial.new();sky_material.shader=load("res://shaders/world25/sky.gdshader")
    sky_material.set_shader_parameter("noise_map",load("res://art/sky_garden/textures/cloud_noise.png"))
    sky.sky_material=sky_material;env.background_mode=Environment.BG_SKY;env.sky=sky
    env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;env.ambient_light_color=Color("bed6e5");env.ambient_light_energy=.68
    env.tonemap_mode=Environment.TONE_MAPPER_FILMIC;env.tonemap_exposure=1.12
    env.fog_enabled=true;env.fog_light_color=Color("c1dcdf");env.fog_density=.0018
    world.environment=env;add_child(world)
    var sun:=DirectionalLight3D.new();sun.name="WarmSun";sun.rotation_degrees=Vector3(-48,-28,0);sun.light_color=Color("fff0cf");sun.light_energy=1.35
    sun.shadow_enabled=true;sun.directional_shadow_max_distance=65;sun.directional_shadow_mode=DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
    sun.shadow_bias=.045;sun.shadow_blur=1.5;add_child(sun)
func arena() -> void:
    var stone:=mat("limestone","b8c7c4");var pale:=mat("paving","e6d7b5");var dark:=mat("dark","294757",.35,.55);var gold:=mat("gold","dca83d",.65,.32)
    radial("foundation",[Vector2(0,-1.5),Vector2(11.8,-1.5),Vector2(12.8,-.7),Vector2(12.8,-.25),Vector2(12.3,-.02),Vector2(0,-.02)],CENTER,stone,80)
    var body:=StaticBody3D.new();body.name="SolidArena";body.collision_layer=1;body.collision_mask=2;add_child(body);body.position=CENTER-Vector3.UP*.55
    var shape:=CollisionShape3D.new();var cylinder:=CylinderShape3D.new();cylinder.radius=12.3;cylinder.height=1.1;shape.shape=cylinder;body.add_child(shape)
    for ring in range(4):
        var inner:=1.5+ring*2.65;var outer:=inner+2.61
        var count:=16+ring*8
        var sector:=C.sector(inner,outer,.008,TAU/count-.008,-.005,.15,4)
        for i in count:
            var material:=pale if (i+ring)%3!=0 else mat("paving2","cec4a7")
            var key:="tile"+str(ring)+str((i+ring)%3==0)
            batch(key,sector,material,CENTER,Vector3.ONE,i*TAU/count+ring*.11)
    for radius in [8.8,9.0,11.95,12.2]:
        radial("ring"+str(radius),[Vector2(radius,-.005),Vector2(radius,.035),Vector2(radius+.055,.035),Vector2(radius+.055,-.005)],CENTER,gold,96)
    # Inlaid radial compass marks, riveted deck edge and cushioned hub plinth.
    for i in 32:
        var angle:=TAU*i/32;var at:=CENTER+Vector3(cos(angle),0,sin(angle))*11.4
        box("compass",Vector3(.07,.022,.62),at+Vector3.UP*.025,gold,-angle+PI/2)
        radial("rivet",[Vector2(0,0),Vector2(.07,0),Vector2(.07,.045),Vector2(0,.07)],CENTER+Vector3(cos(angle)*12.45,-.35,sin(angle)*12.45),gold,8)
    radial("hub_base",[Vector2(0,0),Vector2(1.7,0),Vector2(1.85,.18),Vector2(1.85,.32),Vector2(1.5,.47),Vector2(0,.47)],CENTER,dark)
    # The inaccessible central mechanism is solid, independent of hit cooldowns.
    var hub:=StaticBody3D.new();hub.collision_layer=1;hub.collision_mask=2;add_child(hub);hub.position=CENTER+Vector3.UP*1.1
    var cs:=CollisionShape3D.new();var hs:=CylinderShape3D.new();hs.radius=1.42;hs.height=2.2;cs.shape=hs;hub.add_child(cs)
    radial("hub_gasket",[Vector2(1.43,.40),Vector2(1.48,.45),Vector2(1.48,.57),Vector2(1.43,.62)],CENTER,gold)
func build_rotor() -> void:
    rotor=AnimatableBody3D.new();rotor.name="FourArmSweep";rotor.set_script(SWEEP);rotor.spin_speed=.55;rotor.position=CENTER+Vector3.UP*.68;add_child(rotor)
    var red:=mat("red_enamel","e85c53",.22,.3);var cream:=mat("ivory","fff1cf",.1,.44);var steel:Material=materials.dark;var gold:Material=materials.gold
    for yaw in [0.0,PI/2]:
        var pose:=Transform3D(Basis(Vector3.UP,yaw),Vector3.ZERO)
        instance_mesh(rotor,C.rounded_box(Vector3(16.4,.72,1),.04),red,pose)
        for x in [-7.92,-6.85,-2.5,2.5,6.85,7.92]:
            var band:=C.rounded_box(Vector3(.16,.728,1.008),.025)
            instance_mesh(rotor,band,cream,pose*Transform3D(Basis.IDENTITY,Vector3(x,0,0)))
        for side in [-1,1]:
            instance_mesh(rotor,C.rounded_box(Vector3(1.1,.06,.12),.02),gold,pose*Transform3D(Basis.IDENTITY,Vector3(side*4.9,.385,0)))
    instance_mesh(rotor,C.lathe([Vector2(0,-.25),Vector2(1.35,-.25),Vector2(1.48,-.05),Vector2(1.48,1.05),Vector2(1.25,1.3),Vector2(0,1.3)]),red,Transform3D.IDENTITY)
    instance_mesh(rotor,C.lathe([Vector2(1.43,.4),Vector2(1.52,.44),Vector2(1.52,.56),Vector2(1.43,.60)]),gold,Transform3D.IDENTITY)
    instance_mesh(rotor,C.lathe([Vector2(0,1.32),Vector2(.62,1.32),Vector2(.68,1.43),Vector2(.52,1.58),Vector2(0,1.58)],32),steel,Transform3D.IDENTITY)
    for i in 12:
        var angle:=TAU*i/12
        instance_mesh(rotor,C.rounded_box(Vector3(.22,.20,.13),.025),gold,Transform3D(Basis(Vector3.UP,-angle),Vector3(cos(angle)*1.46,.84,sin(angle)*1.46)))
func bridge(at:Vector3,length:float,width:float) -> void:
    var wood:=mat("wood","885637",0,.78);var edge:=mat("endgrain","b77f4f");var gold:Material=materials.gold
    solid_box(at-Vector3.UP*.22,Vector3(width,.44,length))
    var count:=ceili(length/.48)
    for i in count:
        var z:float=-length*.5+(i+.5)*length/count
        box("deck",Vector3(width-.06,.25,length/count-.045),at+Vector3(0,-.125,z),wood if i%4 else edge)
        for x in [-width*.5+.19,width*.5-.19]:
            radial("nail",[Vector2(0,0),Vector2(.037,0),Vector2(.037,.018),Vector2(0,.018)],at+Vector3(x,.012,z),gold,8)
    for side in [-1,1]:
        var x:float=side*(width*.5+.08)
        beam(at+Vector3(x,-.40,-length*.5),at+Vector3(x,-.40,length*.5),.27,wood)
        for i in range(ceili(length/2.0)+1):
            var z:float=-length*.5+i*length/ceili(length/2.0)
            box("post",Vector3(.2,1.5,.2),at+Vector3(x,.55,z),wood)
            radial("postcap",[Vector2(0,0),Vector2(.17,0),Vector2(.14,.14),Vector2(0,.17)],at+Vector3(x,1.3,z),gold,8)
        for y in [.48,1.02]:beam(at+Vector3(x,y,-length*.5),at+Vector3(x,y,length*.5),.10,edge)
func bridges() -> void:
    bridge(Vector3(0,0,3.8),15.7,4.4)
    bridge(Vector3(0,0,-34.5),13.8,4.4)
    solid_box(Vector3(0,-.4,12),Vector3(9,.8,5))
    solid_box(Vector3(0,-.4,-43),Vector3(11,.8,6))
    box("entrypad",Vector3(9,.3,5),Vector3(0,-.15,12),mat("entrysand","d9c59d"))
    box("exitpad",Vector3(11,.3,6),Vector3(0,-.15,-43),materials.entrysand)
    for z in [11.5,-42.5]:
        for x in [-3.8,3.8]:tower(Vector3(x,0,z),3.9,true)
        beam(Vector3(-3.8,4,z),Vector3(3.8,4,z),.34,materials.wood)
        box("gateway_plaque",Vector3(3.9,.65,.15),Vector3(0,3.7,z+.1),materials.dark)
        var title:=Label3D.new();title.text="TRAINING GARDEN" if z>0 else "COURTYARD COMPLETE";title.font_size=42;title.pixel_size=.0075;title.position=Vector3(0,3.7,z+.21);title.modulate=Color("ffe2a2");title.outline_size=8;add_child(title)
func tower(at:Vector3,height:float,small:=false) -> void:
    var wall:=mat("warm_stone","d9be86");var blue:=mat("roof","305878",.2,.52);var wood:=mat("wood","885637");var gold:Material=materials.gold
    var radius:=.55 if small else .95
    radial("towerbase"+str(radius),[Vector2(0,0),Vector2(radius+.25,0),Vector2(radius+.25,.35),Vector2(radius,.5),Vector2(0,.5)],at,materials.dark,24)
    radial("towerbody"+str(height),[Vector2(radius,.3),Vector2(radius,height-.3)],at,wall,24)
    for y in [.55,height*.5,height-.4]:
        radial("belt"+str(radius),[Vector2(radius,y-.075),Vector2(radius+.10,y-.075),Vector2(radius+.10,y+.075),Vector2(radius,y+.075)],at,gold,24)
    # Tiered roof, overhanging eaves, finial and hand-built timber braces.
    radial("roof"+str(height),[Vector2(0,height),Vector2(radius*1.55,height),Vector2(radius*1.55,height+.13),Vector2(radius*.8,height+.8),Vector2(radius*.65,height+.86),Vector2(.06,height+1.55),Vector2(0,height+1.55)],at,blue,8)
    radial("finial",[Vector2(0,0),Vector2(.12,0),Vector2(.12,.22),Vector2(0,.4)],at+Vector3.UP*(height+1.5),gold,12)
    for i in 4:
        var angle:=PI*.5*i;var outward:=Vector3(cos(angle),0,sin(angle))
        box("tower_beam",Vector3(.16,height-.8,.16),at+outward*(radius*.85)+Vector3.UP*(height*.5),wood,angle)
        var win:=at+outward*(radius+.02)+Vector3.UP*(height*.67)
        box("window",Vector3(.38,.72,.08),win,materials.dark,-angle+PI/2)
    if not small:
        banner(at+Vector3(-.25,height-.5,radius+.16),Color("9d4c92"))
        banner(at+Vector3(.25,height-.5,-radius-.16),Color("287e95"),PI)
func banner(at:Vector3,color:Color,yaw:=0.0) -> void:
    var shader:=ShaderMaterial.new();shader.shader=load("res://shaders/world25/flag.gdshader");shader.set_shader_parameter("cloth",color);flags.append(shader)
    var p:=PackedVector3Array();var uv:=PackedVector2Array()
    for row in 5:
        for col in 4:
            var a:=Vector3(col*.25,-row*.42,0);var b:=a+Vector3(.25,0,0);var c:=b-Vector3.UP*.42;var d:=a-Vector3.UP*.42
            p.append_array(PackedVector3Array([a,b,c,a,c,d]))
            uv.append_array(PackedVector2Array([Vector2(col/4.0,row/5.0),Vector2((col+1)/4.0,row/5.0),Vector2((col+1)/4.0,(row+1)/5.0),Vector2(col/4.0,row/5.0),Vector2((col+1)/4.0,(row+1)/5.0),Vector2(col/4.0,(row+1)/5.0)]))
    instance_mesh(self,C.surface(p,uv),shader,Transform3D(Basis(Vector3.UP,yaw),at))
func towers() -> void:
    for at in [Vector3(-11.2,0,-8),Vector3(11.2,0,-8),Vector3(-11.2,0,-24),Vector3(11.2,0,-24)]:tower(at,5.8)
    # Perimeter balustrade has generous open gateways at north and south.
    for i in 40:
        var angle:float=TAU*i/40;var next:float=TAU*(i+1)/40
        if absf(cos(angle))<.24 or absf(cos(next))<.24:continue
        var a:=CENTER+Vector3(cos(angle)*12.8,0,sin(angle)*12.8);var b:=CENTER+Vector3(cos(next)*12.8,0,sin(next)*12.8)
        box("baluster",Vector3(.22,1.35,.22),a+Vector3.UP*.5,materials.dark)
        for y in [.45,1.0]:beam(a+Vector3.UP*y,b+Vector3.UP*y,.12,materials.gold)
func island(at:Vector3,radius:float,height:float,seed_value:int) -> void:
    var rock:=mat("cliff","657e7b");var grass:=mat("meadow","739946")
    batch("cliff"+str(seed_value),C.cliff(seed_value,radius,height),rock,at)
    radial("grasscap"+str(radius),[Vector2(0,-.02),Vector2(radius*.92,-.02),Vector2(radius*.96,.06),Vector2(radius*.91,.18),Vector2(0,.18)],at,grass,48)
    for i in 7:
        var angle:=rng.randf()*TAU
        plant("Rock_Medium_3",at+Vector3(cos(angle)*radius*.8,-.35,sin(angle)*radius*.8),rng.randf_range(1.0,2.7),angle)
func landscape() -> void:
    # Entire arena cliff is below the existing solid arena; vegetation lies
    # on separate nonwalkable islands and cannot create gameplay shortcuts.
    island(CENTER-Vector3.UP*1.3,13.5,13,30)
    var pockets:Array=[]
    for side in [-1,1]:
        for j in 4:
            var at:=Vector3(side*(18.2+(j%2)*3),-.25,-1-j*12.5)
            var radius:=5.2 if j%2==0 else 6.5
            island(at,radius,10+j*2,100+j+side*10);pockets.append(at)
            for i in 5:
                var angle:=i*2.399+j;var r:=1.2+sqrt(i)*1.2
                var pos:=at+Vector3(cos(angle)*r,.18,sin(angle)*r)
                plant(["CommonTree_3","CommonTree_4","CommonTree_5","Pine_1","Pine_5"][(i+j)%5],pos,rng.randf_range(4.8,7.8),angle)
            for i in 30:
                var angle:=rng.randf()*TAU;var radius2:=sqrt(rng.randf())*radius*.85
                plant("Plant_1",at+Vector3(cos(angle)*radius2,.18,sin(angle)*radius2),rng.randf_range(.35,.7),angle)
    # Low beds frame the arena without hiding sweep-arm silhouettes.
    for i in 24:
        var a:=TAU*i/24
        if absf(cos(a))<.30:continue
        var at:=CENTER+Vector3(cos(a)*13.8,-.55,sin(a)*13.8)
        island(at,1.7,4,300+i)
        for j in 6:
            var point:=at+Vector3(cos(j*2.4)*1.05,.18,sin(j*2.4)*1.05)
            plant("Plant_1",point,.5,j)
            flower(point+Vector3(.15,.1,.15),i+j)
    for side in [-1,1]:
        for j in 5:
            var at:=Vector3(side*(45+j*7),-8-j*2,-45-j*18)
            island(at,9+j*1.5,18+j*2,500+j+side*10)
            for i in 4:plant("Pine_5",at+Vector3(i*2-3,.18,0),7+j*.5,i)
    # Entrance and exit landscaped terraces, kept outside the walking deck.
    for z in [11.5,-43.0]:
        for side in [-1,1]:
            var at:=Vector3(side*7.5,-.3,z);island(at,3.5,7,600+int(z)+side)
            plant("CommonTree_5",at+Vector3(side*.4,.18,-1),6.0,side)
            for i in 12:
                var point:=at+Vector3(cos(i*2.4)*2,.18,sin(i*2.4)*2)
                plant("Plant_1",point,.55,i);flower(point,i)
func flower(at:Vector3,index:int) -> void:
    # Custom tiny five-petal flowers; no flower mesh exists in verified assets.
    var color:String=["e6a3c0","e7c967","91b9db"][absi(index)%3]
    var stem:=mat("stem","63814a");beam(at,at+Vector3.UP*.25,.025,stem)
    var material:=mat("petal"+color,color)
    for i in 5:
        var a:=TAU*i/5
        box("petal"+color,Vector3(.13,.04,.09),at+Vector3(cos(a)*.09,.26,sin(a)*.09),material,-a)
    radial("pollen",[Vector2(0,0),Vector2(.055,0),Vector2(.055,.035),Vector2(0,.035)],at+Vector3.UP*.28,materials.gold,8)
func flush() -> void:
    for key in batches:
        var data:Dictionary=batches[key];var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.mesh=data.mesh;mm.instance_count=data.poses.size()
        for i in mm.instance_count:mm.set_instance_transform(i,data.poses[i])
        var node:=MultiMeshInstance3D.new();node.name=key;node.multimesh=mm;node.material_override=data.material
        node.visibility_range_end=180 if key.begins_with("asset") else 240
        if key.begins_with("asset"):node.visibility_range_end=125;node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(node)
func hud() -> void:
    var canvas:=CanvasLayer.new();add_child(canvas)
    controls=Control.new();controls.name="SwipeControls";controls.set_script(INPUT);controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);canvas.add_child(controls)
    controls.jump_pressed.connect(func() -> void:
        if not recovering and not paused:runner.jump_requested=true)
    label=Label.new();label.position=Vector2(24,24);label.add_theme_font_size_override("font_size",18);label.add_theme_color_override("font_color",Color("fff1d1"));label.add_theme_color_override("font_shadow_color",Color("102c3e"));label.add_theme_constant_override("shadow_offset_x",2);label.add_theme_constant_override("shadow_offset_y",2);controls.add_child(label)
    for action in ["restart","pause","view"]:
        var button:=Button.new();button.text="RESET" if action=="restart" else "PAUSE" if action=="pause" else "VIEW";button.size=Vector2(100,44);button.position=Vector2(24 if action=="restart" else 136 if action=="pause" else 248,110)
        controls.add_child(button)
        if action=="view":
            button.mouse_filter=Control.MOUSE_FILTER_STOP;button.pressed.connect(func() -> void:set_view((inspection_index+1)%5));controls.register_touch_blocker(button)
        else:controls.register_button(action,button)
    controls.restart_pressed.connect(restart);controls.pause_pressed.connect(toggle_pause)
func set_view(index:int) -> void:
    inspection_index=clampi(index,0,4)
    if inspection_index==4:camera.make_current()
    else:
        inspection_camera.global_position=views[inspection_index].at
        inspection_camera.look_at(views[inspection_index].look,Vector3.UP);inspection_camera.make_current()
func _unhandled_key_input(event:InputEvent) -> void:
    if not event.is_pressed() or event.is_echo():return
    if event.is_action_pressed("ui_accept") and not paused and not recovering:runner.jump_requested=true
    if event is InputEventKey:
        if event.keycode==KEY_R:restart()
        elif event.keycode==KEY_P:toggle_pause()
        elif event.keycode==KEY_V:set_view((inspection_index+1)%5)
func on_hit() -> void:
    accepted_hits+=1;camera.impact(.06)
    last_hit={"speed":runner.last_contact_speed,"impulse":runner.last_impulse,"frame":Engine.get_physics_frames()}
func begin_recovery() -> void:
    if recovering:return
    falls+=1;recovering=true;recovery_left=.28;controls.clear_input();controls.accept_gameplay_input=false
func reset_rotor() -> void:
    rotor.sync_to_physics=false;rotor.rotation.y=0;rotor.delivered.clear();rotor.sync_to_physics=true
func restart() -> void:
    if get_tree().paused:get_tree().paused=false
    paused=false;falls=0;accepted_hits=0;elapsed=0;recovering=false;reset_rotor()
    controls.clear_input();controls.accept_gameplay_input=true;runner.reset_at(SPAWN,false);runner.accept_jump_input=true;camera.setup(runner)
    controls.buttons.pause.text="PAUSE"
func toggle_pause() -> void:
    paused=not paused;controls.clear_input();runner.clear_input();controls.accept_gameplay_input=not paused and not recovering
    controls.buttons.pause.text="RESUME" if paused else "PAUSE";get_tree().paused=paused
func _notification(what:int) -> void:
    if what==NOTIFICATION_APPLICATION_FOCUS_OUT and is_instance_valid(controls):
        controls.clear_input();runner.clear_input()
        if not paused:toggle_pause()
func _physics_process(delta:float) -> void:
    elapsed+=delta
    if recovering:
        recovery_left-=delta
        if recovery_left<=0 and not runner.recovery_hold:
            runner.reset_at(SPAWN,true);runner.recovery_hold=true;camera.recover()
        if runner.recovery_hold and runner.grace_left<=0 and camera.is_recovery_ready():
            runner.finish_recovery();recovering=false;controls.clear_input();controls.accept_gameplay_input=true
    if not test_input:runner.move_input=(controls.movement()+Input.get_vector("ui_left","ui_right","ui_up","ui_down")).limit_length(1) if not recovering else Vector2.ZERO
func _process(_delta:float) -> void:
    sky_material.set_shader_parameter("cloud_time",elapsed)
    for flag in flags:flag.set_shader_parameter("nature_time",elapsed)
    if is_instance_valid(label):label.text="COURTYARD-30 • VISUAL PROTOTYPE\nDRAG TO MOVE • JUMP TO CLEAR SWEEPS\nHits %d  |  Falls %d  |  %s"%[accepted_hits,falls,"RECENTERING" if recovering else "PROTECTED" if runner.spawn_protection_left>0 else "TRAINING"]
