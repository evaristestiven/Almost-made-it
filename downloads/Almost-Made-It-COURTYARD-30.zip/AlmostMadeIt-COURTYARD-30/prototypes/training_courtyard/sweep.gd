extends "res://scripts/spinner.gd"
# Existing fixed-step solid sweep, relative contact velocity and hit suppression.
# Two centered perpendicular solids form four continuous arms with no offset
# collider assumptions. Rounded visual edge bevel is only 0.04 world units.
func _ready() -> void:
    collision_layer=4;collision_mask=2
    add_to_group("hazards")
    for size in [Vector3(16.4,.72,1.0),Vector3(1.0,.72,16.4)]:
        var shape:=CollisionShape3D.new();var box:=BoxShape3D.new()
        box.size=size;shape.shape=box;add_child(shape)
    super._ready()
